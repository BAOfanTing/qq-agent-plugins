// 禁漫漫画查询（jm-album）· 插件 API v2 —— 只查不下载：给文字元数据 + 几条直链。
// 不合 PDF、不上传文件；封面图默认不发（设置打开后仅群聊试发一次，失败回落成转发指令）。
//
// ── 网络为什么全部改走宿主（v2 的核心改动）─────────────────────────────────
// v1 是插件进程自己 fetch。Linux 上宿主默认用 unshare --net 把插件放进独立网络命名空间，
// 进程根本没有网卡 → 整个插件在那种机器上一律 E_NETWORK。v2 改走 cap.http.request：
// 请求在宿主侧发出，插件无网也能用；同时域名白名单也交给宿主兜。
// 代价是响应体积受 manifest.httpMaxBytes 限制，宿主算的是 limit = min(maxChars, httpMaxBytes)：
// 所以 maxChars 必须【等于】httpMaxBytes（524288）。传小一点会把密文尾部静默切掉、truncated
// 还是 false —— 表现成「不是 JSON」，那种错最难查。
//
// ── 为什么只剩「移动端加密 API」这一条路 ──────────────────────────────────
// 网页版（/album/<id>、/search/photos）实测被 Cloudflare 挡成 403 "Just a moment..."，
// 所以没有网页兜底。可用的是 App 自己调的那套接口：
//   · ts = 秒级时间戳；token = md5(ts + '185Hcomic3PAPP7R')；tokenparam = "<ts>,2.1.7"
//   · UA 必须是 App 的 UA —— 实测桌面 Chrome UA 会被判 "Not legal request"（code 401）
//   · 响应体 = AES-256-ECB(base64)，key = md5(ts + 密钥) 的 32 字节；自己按 PKCS#7 去填充
//
// ── 单文件、零依赖 ──────────────────────────────────────────────────────
// 只 import node: 内置模块。不写文件、不 spawn、读不到插件目录外的任何东西 —— 状态一律经
// cap.storage 落在宿主侧。作为主模块运行时才启动 stdin 的 NDJSON 循环；被 import 时什么都不跑。
//
// ── 时间预算 ────────────────────────────────────────────────────────────
// 工具级 timeoutMs 是 25s / 30s（manifest），但这里仍给自己 15 秒总预算：单个域名/章节请求
// 各自限时，且被剩余预算二次裁剪；预算用尽就带着已取到的部分 + notes 返回，不硬等。
import crypto from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

export const UA_APP =
  'Mozilla/5.0 (Linux; Android 9; V1938CT Build/PQ3A.190705.11211812; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Safari/537.36';

const APP_VERSION = '2.1.7';
const APP_TOKEN_SECRET = '185Hcomic3PAPP7R'; // 与 jmcomic 2.7.7 的移动端一致：token = md5(ts + 它)
const WEB_BASE = 'https://18comic.vip';

/** 内置 API 域名池（四个都实测过 code 200）。域名会换，所以配置里可以额外填。 */
export const DEFAULT_API_DOMAINS = ['www.cdnhjk.net', 'www.cdngwc.cc', 'www.cdngwc.net', 'www.cdngwc.club'];

/** 图片 CDN 池，只用来拼封面直链（拼完就给人/模型，插件默认不去取）。 */
export const IMAGE_DOMAINS = [
  'cdn-msp.jmapiproxy1.cc',
  'cdn-msp.jmapiproxy2.cc',
  'cdn-msp2.jmapiproxy2.cc',
  'cdn-msp3.jmapiproxy2.cc',
  'cdn-msp.jmapinodeudzn.net',
  'cdn-msp3.jmapinodeudzn.net'
];

/**
 * ⚠️ 必须等于 plugin.json 的 httpMaxBytes。宿主侧 limit = min(maxChars, httpMaxBytes)，
 * 传 512000 这种「看着差不多」的值会把末尾十几 KB 静默切掉（truncated 仍是 false）。
 */
export const HTTP_MAX_CHARS = 524288;

const PAGE_SIZE = 80;          // 搜索接口每页固定 80 条（实测）
const TOTAL_CAP = 10000;       // 搜索接口的 total 上限值（实测常驻 10000，别当真数）
const BUDGET_MS = 15000;       // 单次工具调用总预算
const RESERVE_MS = 400;        // 留给序列化/写回响应的余量
const PER_REQUEST_MS = 8000;   // 单个域名上的一次请求最多等多久（宿主侧 HTTP 空闲超时固定 20s）
const CAP_TIMEOUT_MS = 9000;   // 能力调用自身的兜底超时（宿主没回话就别挂着）
const STORAGE_TIMEOUT_MS = 2500;
const PROBE_BUDGET_MS = 1500;  // probe 总预算（控制台检测按钮只能等这么久）
const PROBE_MAX_DOMAINS = 2;   // probe 只真探前几个域名，其余 checks 标 skipped
const PROBE_ALBUM_ID = '350234';
const MAX_DESC = 800;          // description 截断长度
const MAX_COUNT = 20;          // search_album 的 count 硬上限
const MAX_CHAPTERS_CAP = 20;   // maxChapters 的硬上限
const CHAPTER_CONCURRENCY = 4; // 同时取几话的页数
const MAX_COVER_BYTES = 8 * 1024 * 1024; // 封面单文件上限（宿主 media 上限 80MB）

/**
 * 与 plugin.json settings.groups 的 default 逐项对应（自验会逐项比对，防止两处漂移）。
 * 来源：查询 query 组 4 项 + 网络 network 组 1 项 + 封面发送 send 组 2 项。
 */
export const DEFAULTS = Object.freeze({
  maxResults: 8,
  maxChapters: 6,
  includeCover: true,
  sendCover: false,
  domains: '',
  sendMode: 'auto',
  sendHostRetryMinutes: 30
});

const SEND_MODES = ['auto', 'forward', 'host'];
// 协议端读不到宿主给的绝对路径时 NapCat 报的就是这些词；原始报错里带宿主路径，只进日志
const HOST_FILE_BROKEN_RE = /ENOENT|realpath|retcode=100/i;
const HOST_BROKEN_HUMAN = '本部署的协议端读不到宿主给的文件路径，已改成让协议端自己去取图（细节见插件日志）';

const SENT_ADVISE = '封面图已直接发到这个群（cover.delivered=true），不要再贴链接、也不要再调 send_group_file 重复转发。';
const FORWARD_ADVISE = '封面没经过宿主发文件：立刻用宿主内置 send_group_file，把 cover.forward.url 与 cover.forward.name 原样传进去，不要自己拼参数，也不要让用户复制链接。';
const LINK_ADVISE = '这次没有发图：把 coverUrl 原样给用户让它自己点开；不要自己拼 send_group_file 的参数。';

// ───────────────────────── 纯函数 ─────────────────────────

const md5hex = (s) => crypto.createHash('md5').update(String(s), 'utf8').digest('hex');
const isPlainObject = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v);

/** 取第一个像样的字符串（数字也认），否则空串。 */
function firstString(...vals) {
  for (const v of vals) {
    if (typeof v === 'string' && v.trim()) return v.trim();
    if (typeof v === 'number' && Number.isFinite(v)) return String(v);
  }
  return '';
}

function asArray(v) {
  if (Array.isArray(v)) return v;
  if (v === null || v === undefined || v === '') return [];
  return [v];
}

/** 去掉孤立代理项（半个 emoji）—— 孤立代理项会让整个模型请求 400。 */
function stripLoneSurrogates(value) {
  const s = String(value ?? '');
  let out = '';
  for (let i = 0; i < s.length; i++) {
    const code = s.charCodeAt(i);
    if (code >= 0xd800 && code <= 0xdbff) {
      const next = s.charCodeAt(i + 1);
      if (next >= 0xdc00 && next <= 0xdfff) { out += s[i] + s[i + 1]; i += 1; }
      continue;
    }
    if (code >= 0xdc00 && code <= 0xdfff) continue;
    out += s[i];
  }
  return out;
}

/** 安全截断：按 UTF-16 码元切，且不在结尾留半个 emoji。 */
function safeSlice(value, max) {
  const s = String(value ?? '');
  const limit = Math.max(0, Math.floor(Number(max)) || 0);
  return stripLoneSurrogates(limit >= s.length ? s : s.slice(0, limit));
}

/** 去重 + 丢掉空串与 'N/A'（禁漫的作者/标签字段里这两种占位很常见）。 */
function uniqClean(list) {
  const out = [];
  const seen = new Set();
  for (const raw of asArray(list)) {
    const s = firstString(raw);
    if (!s) continue;
    if (/^n\/?a$/i.test(s)) continue;
    const key = s.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(s);
  }
  return out;
}

function clampInt(value, fallback, lo, hi) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(hi, Math.max(lo, Math.trunc(n)));
}

function num(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.trunc(n)) : 0;
}

/** 布尔读取：模型有时把 true 写成字符串 "true"/"false"，别让 "false" 变成 true。 */
function toBool(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'boolean') return value;
  const s = String(value).trim().toLowerCase();
  if (['true', '1', 'yes', 'on', '是', '开'].includes(s)) return true;
  if (['false', '0', 'no', 'off', '否', '关'].includes(s)) return false;
  return fallback;
}

/**
 * 车牌号归一化：从 "jm123456" / "JM-123456" / "/album/123456/x" 里取出纯数字。
 * ⚠️ 必须带数字边界断言（(?<!\d)…(?!\d)）：否则 "123456789012" 会被截成 "123456789"
 * 当成合法车牌号去联网 —— 白白轮询一圈域名，还查出一本毫不相干的本子。
 * 认不出来（包括那种超长数字串）一律返回空串，让上层报 E_ARGS。
 */
export function normalizeAlbumId(raw) {
  const s = String(raw ?? '').trim();
  if (!s) return '';
  const pick = (digits) => {
    const d = String(digits || '').replace(/^0+(?=\d)/, '');
    return d.length >= 2 && d.length <= 9 ? d : ''; // 超长不截断，直接算认不出
  };
  // ① 链接里的 /album/<id> 或 /photo/<id> —— 最可靠（18comic.vip/album/350234/
  //    里还有个 "18" 会被裸数字匹配先撞上，所以这一步必须在兜底之前）。
  const inUrl = s.match(/\/(?:album|photo)\/(\d{1,12})(?!\d)/i);
  if (inUrl) { const got = pick(inUrl[1]); if (got) return got; }
  // ② jm123456 / JM-123456 / JM 123456 这类前缀写法。
  const prefixed = s.match(/(?:^|[^a-z0-9])jm[-\s]?(\d{1,12})(?!\d)/i);
  if (prefixed) { const got = pick(prefixed[1]); if (got) return got; }
  // ③ 兜底：整串里就一个数字（或长短很明显的几个数字取最长的那个）。必须带数字边界，
  //    否则 "123456789012" 会被截成 "123456789" 当成合法车牌号去联网。
  const runs = s.match(/(?<!\d)\d{2,9}(?!\d)/g) || [];
  if (!runs.length) return '';
  return pick(runs.reduce((best, cur) => (cur.length >= best.length ? cur : best), ''));
}

/**
 * {code, data(base64 密文)} → AES-256-ECB 解密 → JSON。
 * setAutoPadding(false) + 自己按 PKCS#7 去填充：个别响应会让 node 的自动去填充抛 bad decrypt。
 * 解不出来就抛带中文原因的 Error，由调用方决定这是「换个域名再试」还是「直接报错」。
 */
export function decodeApiEnvelope(text, ts) {
  let envelope;
  try {
    envelope = JSON.parse(String(text));
  } catch {
    throw new Error('响应不是 JSON（域名可能已失效或被挡出一个网页）');
  }
  if (!isPlainObject(envelope)) throw new Error('响应形状不认识（不是对象）');
  if (envelope.code !== undefined && Number(envelope.code) !== 200) {
    const detail = firstString(envelope.error_msg, envelope.message, envelope.msg);
    throw new Error('接口返回 code=' + envelope.code + (detail ? '（' + safeSlice(detail, 80) + '）' : ''));
  }
  if (typeof envelope.data !== 'string' || !envelope.data) throw new Error('响应里没有密文 data');

  const key = Buffer.from(md5hex(ts + APP_TOKEN_SECRET), 'utf8');
  const decipher = crypto.createDecipheriv('aes-256-ecb', key, null);
  decipher.setAutoPadding(false);
  const plain = Buffer.concat([decipher.update(Buffer.from(envelope.data, 'base64')), decipher.final()]);
  const pad = plain.length ? plain[plain.length - 1] : 0;
  const body = pad > 0 && pad <= 16 && pad <= plain.length ? plain.subarray(0, plain.length - pad) : plain;
  try {
    return JSON.parse(body.toString('utf8'));
  } catch {
    throw new Error('解密后的内容不是 JSON（密钥或时间戳对不上）');
  }
}

/** 秒级时间戳 → UTC+8 的 YYYY-MM-DD。禁漫返回的都是秒（不是毫秒）。 */
export function formatDate(seconds) {
  let n = Number(seconds);
  if (!Number.isFinite(n) || n <= 0) return '';
  if (n > 1e11) n = Math.floor(n / 1000); // 个别字段给的是毫秒，不折成秒会算到几万年以后
  const d = new Date((n + 8 * 3600) * 1000);
  return Number.isNaN(d.getTime()) ? '' : d.toISOString().slice(0, 10);
}

/** 拼图片直链：https://<cdn>/media/photos/<chapterId>/<fileName>[?v=ts]。 */
/**
 * 官方方形封面（实测未做竖切打乱）：/media/albums/<id>.jpg。
 * 注意内容是 WebP，扩展名照样是 .jpg；本子没有封面时返回 200 + 0 字节，靠下载回执判断。
 */
export function buildAlbumCoverUrl(albumId, imageDomain) {
  const domain = String(imageDomain || IMAGE_DOMAINS[0]).trim().replace(/^https?:\/\//i, '').replace(/\/.*$/, '');
  const id = String(albumId ?? '').trim();
  if (!domain || !/^\d+$/.test(id)) return null;
  return 'https://' + domain + '/media/albums/' + id + '.jpg';
}

export function buildImageUrl(imageDomain, chapterId, fileName, stamp) {
  const domain = String(imageDomain || IMAGE_DOMAINS[0]).trim()
    .replace(/^https?:\/\//i, '').replace(/\/.*$/, '');
  const chapter = String(chapterId ?? '').trim();
  const name = String(fileName ?? '').split('?')[0].split('/').pop();
  if (!domain || !chapter || !name) return null;
  const v = Number(stamp) > 0 ? '?v=' + Math.trunc(Number(stamp)) : '';
  return 'https://' + domain + '/media/photos/' + encodeURIComponent(chapter) + '/' + encodeURIComponent(name) + v;
}

/**
 * 域名候选：用户填的排最前（他填的是「这台机器上已知可用」），随后是内置池。
 * 填错没有额外代价 —— 失败会继续试内置池，只是慢一点。
 */
export function domainCandidates(userDomains = '') {
  const extra = String(userDomains || '')
    .split(/[\s,;]+/)
    .map((s) => s.trim().replace(/^https?:\/\//i, '').replace(/\/.*$/, ''))
    .filter(Boolean);
  const out = [];
  const seen = new Set();
  for (const d of [...extra, ...DEFAULT_API_DOMAINS]) {
    const key = d.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(d);
  }
  return out;
}

/** 搜到的一条 → 契约形状。category 是对象 {id,title}，别直接 firstString 上去。 */
export function normalizeSearchItem(raw) {
  const item = isPlainObject(raw) ? raw : {};
  const id = firstString(item.id, item.album_id);
  return {
    id,
    title: firstString(item.name, item.title) || (id ? 'JM' + id : ''),
    authors: uniqClean(item.author ?? item.authors),
    category: firstString(item.category?.title, item.category, item.category_sub),
    updatedAt: formatDate(firstString(item.update_at, item.adddate, item.update_date)),
    pageUrl: id ? WEB_BASE + '/album/' + id + '/' : ''
  };
}

/** 从 URL 里取主机名（拼 media.download 的 referer 用）。 */
export function hostOfUrl(url) {
  try {
    return new URL(String(url)).hostname;
  } catch {
    return '';
  }
}

/** 封面转发指令：让模型一步调用宿主内置 send_group_file（群聊限定），别自己拼参数。 */
export function coverForward(coverUrl, name) {
  if (!coverUrl) return null;
  return { tool: 'send_group_file', url: String(coverUrl), name: safeSlice(name || 'jm-cover.jpg', 60) };
}

// ───────────────────────── 上下文与错误 ─────────────────────────

function fail(code, message) {
  return { ok: false, error: { code, message: safeSlice(message, 400) } };
}

const REJECTED_RE = /^接口返回 code=/;

/** 没有注入宿主能力时的兜底：明确报错，别假装查到了什么。 */
async function missingCap() {
  throw Object.assign(new Error('这个上下文没有宿主能力（单测请注入 cap）'), { code: 'E_CAP' });
}

/** 把配置收成一次调用用的上下文。deadline 由调用方在开头设。 */
export function makeContext(settings = {}, options = {}) {
  const merged = { ...DEFAULTS };
  for (const [k, v] of Object.entries(isPlainObject(settings) ? settings : {})) {
    if (v !== undefined && v !== null) merged[k] = v;
  }
  const mode = String(merged.sendMode ?? '').trim();
  return {
    maxResults: clampInt(merged.maxResults, DEFAULTS.maxResults, 1, MAX_COUNT),
    maxChapters: clampInt(merged.maxChapters, DEFAULTS.maxChapters, 0, MAX_CHAPTERS_CAP),
    includeCover: toBool(merged.includeCover, DEFAULTS.includeCover),
    sendCover: toBool(merged.sendCover, DEFAULTS.sendCover),
    sendMode: SEND_MODES.includes(mode) ? mode : DEFAULTS.sendMode,
    sendHostRetryMinutes: clampInt(merged.sendHostRetryMinutes, DEFAULTS.sendHostRetryMinutes, 1, 720),
    baseDomains: domainCandidates(merged.domains),
    domainList: [],            // 本次实际尝试顺序（prepareDomains 填）
    deadDomains: new Set(),    // 本次调用内已失败的域名（只影响这次的尝试顺序）
    preferred: '',             // 域名记忆里那个「上次成功」的域名
    cap: typeof options.cap === 'function' ? options.cap : missingCap,
    context: isPlainObject(options.context) ? options.context : {},
    deadline: Number(options.deadline) || 0
  };
}

function buildHeaders(domain, ts) {
  return {
    'user-agent': UA_APP,
    accept: 'application/json, text/plain, */*',
    'accept-language': 'zh-CN,zh;q=0.9',
    referer: 'https://' + domain + '/',
    origin: 'https://' + domain,
    token: md5hex(ts + APP_TOKEN_SECRET),
    tokenparam: ts + ',' + APP_VERSION
  };
}

const remaining = (ctx) => Math.max(0, (ctx.deadline || 0) - Date.now() - RESERVE_MS);

// ───────────────────────── 能力调用（storage / log）─────────────────────────
// storage 失败（E_ARGS / E_FULL / 超时）一律当成「没记住」，绝不阻断查询。

async function storageGet(ctx, key) {
  try {
    const result = await ctx.cap('cap.storage.get', { key }, STORAGE_TIMEOUT_MS);
    return isPlainObject(result) ? result.value : null;
  } catch {
    return null;
  }
}

async function storageSet(ctx, key, value) {
  try {
    await ctx.cap('cap.storage.set', { key, value }, STORAGE_TIMEOUT_MS);
    return true;
  } catch {
    return false;
  }
}

/** 日志失败不该影响主流程；原始报错（带宿主路径）只进日志，不进结果。 */
async function logWarn(ctx, message) {
  try {
    await ctx.cap('cap.log.write', { level: 'warn', message: safeSlice(message, 400) }, STORAGE_TIMEOUT_MS);
  } catch { /* 记不下来也照常返回 */ }
}

// ───────────────────────── 域名记忆（cap.storage）─────────────────────────

const PREFERRED_KEY = 'preferredDomain';
const DOMAIN_FAILS_KEY = 'domainFails'; // { domain, count }：连续失败计数，2 次就丢掉偏好

/** 读出上次成功的域名；只有在候选列表里才用（用户可能已经把域名从配置里删了）。 */
async function prepareDomains(ctx) {
  const base = Array.isArray(ctx.baseDomains) && ctx.baseDomains.length ? ctx.baseDomains : domainCandidates('');
  const raw = await storageGet(ctx, PREFERRED_KEY);
  const stored = typeof raw === 'string' ? raw.trim() : '';
  const hit = stored ? base.find((d) => d.toLowerCase() === stored.toLowerCase()) : '';
  ctx.preferred = hit || '';
  ctx.domainList = hit ? [hit, ...base.filter((d) => d !== hit)] : [...base];
  return ctx.domainList;
}

async function noteDomainSuccess(ctx, domain) {
  if (!domain) return;
  const changed = domain !== ctx.preferred;
  ctx.preferred = domain;
  await storageSet(ctx, PREFERRED_KEY, domain);
  if (changed || (await storageGet(ctx, DOMAIN_FAILS_KEY))) await storageSet(ctx, DOMAIN_FAILS_KEY, null);
}

/** 连续 2 次失败才清除偏好（一次抖动不该丢掉「这台机器上唯一可用」的域名）。 */
async function noteDomainFailure(ctx, domain) {
  if (!domain) return;
  const raw = await storageGet(ctx, DOMAIN_FAILS_KEY);
  const prev = isPlainObject(raw) && String(raw.domain || '') === domain ? num(raw.count) : 0;
  await storageSet(ctx, DOMAIN_FAILS_KEY, { domain, count: prev + 1 });
  if (prev + 1 >= 2) await storageSet(ctx, PREFERRED_KEY, null);
}

/**
 * 本次调用内记住「这个域名刚失败了」：从 domainList 移到末尾，后面的 apiGet 先试别的。
 * 纯内存，不写 storage、也不改 preferred —— 跨调用的记忆仍然只由 noteDomainFailure 负责。
 */
function noteDeadDomain(ctx, domain) {
  if (!domain) return;
  if (!(ctx.deadDomains instanceof Set)) ctx.deadDomains = new Set();
  ctx.deadDomains.add(domain);
  if (Array.isArray(ctx.domainList) && ctx.domainList.includes(domain)) {
    ctx.domainList = ctx.domainList.filter((d) => d !== domain).concat(domain);
  }
}

// ───────────────────────── HTTP（只走宿主）─────────────────────────

/**
 * 打一次接口（单个域名）。不抛异常，把「这次为什么没成」分类带回去：
 *   ok / status / ms / error / code(宿主错误码) / truncated
 */
async function fetchOne(ctx, domain, pathname, query, timeoutMs) {
  const search = query ? '?' + new URLSearchParams(query).toString() : '';
  const url = 'https://' + domain + pathname + search;
  const ts = Math.floor(Date.now() / 1000);
  const startedAt = Date.now();
  try {
    const result = await ctx.cap('cap.http.request', {
      url,
      method: 'GET',
      headers: buildHeaders(domain, ts),
      maxChars: HTTP_MAX_CHARS,
      decompress: true
    }, Math.max(500, Math.min(timeoutMs || PER_REQUEST_MS, CAP_TIMEOUT_MS)));
    const ms = Date.now() - startedAt;
    const status = Number(result?.status) || 0;
    // 截断的密文解不开；这里必须先认出来，不能让上层报成「不是 JSON」
    if (result && result.truncated === true) {
      return { ok: false, domain, status, ms, truncated: true, error: '响应被截断（超过 httpMaxBytes=' + HTTP_MAX_CHARS + '）' };
    }
    if (status < 200 || status >= 300) {
      return { ok: false, domain, status, ms, error: 'HTTP ' + (status || '?') };
    }
    return { ok: true, domain, status, ms, ts, body: String(result?.body ?? '') };
  } catch (error) {
    return {
      ok: false,
      domain,
      status: 0,
      ms: Date.now() - startedAt,
      code: String(error?.code || ''),
      error: String(error?.message || error)
    };
  }
}

/**
 * 打一次加密接口，按域名池依次重试。
 * 返回 {ok:true, data, domain} 或 {ok:false, kind:'network'|'timeout'|'rejected'|'truncated'|'domain', message}。
 */
async function apiGet(ctx, pathname, query) {
  const all = Array.isArray(ctx.domainList) && ctx.domainList.length ? ctx.domainList : domainCandidates('');
  // 本次调用里失败过的域名排到最后；都不剩活域名时兜回完整列表（防一次抖动就零请求）
  const dead = ctx.deadDomains instanceof Set ? ctx.deadDomains : new Set();
  const alive = all.filter((d) => !dead.has(d));
  const list = alive.length ? alive : all;
  let lastMessage = '';
  let sawTimeout = false;
  let sawRejected = false;

  for (const domain of list) {
    const left = remaining(ctx);
    if (left < 500) { sawTimeout = true; lastMessage = lastMessage || '整体预算已用完'; break; }
    const per = Math.min(PER_REQUEST_MS, left);
    const got = await fetchOne(ctx, domain, pathname, query, per);
    // 域名不在 manifest.httpDomains 白名单：配置错误，换域名也没用（其它域名同样被拒）
    if (got.code === 'E_DOMAIN') return { ok: false, kind: 'domain', message: got.error };
    if (got.truncated) return { ok: false, kind: 'truncated', message: domain + ' ' + got.error };
    if (!got.ok) {
      lastMessage = got.code === 'E_CAP_TIMEOUT' ? domain + ' 超时（' + per + 'ms）' : domain + ' ' + safeSlice(got.error, 80);
      if (got.code === 'E_CAP_TIMEOUT') sawTimeout = true;
      if (domain === ctx.preferred) await noteDomainFailure(ctx, domain);
      noteDeadDomain(ctx, domain);
      continue;
    }
    let data;
    try {
      data = decodeApiEnvelope(got.body, got.ts);
    } catch (error) {
      const message = String(error?.message || error);
      lastMessage = domain + ' ' + message;
      if (REJECTED_RE.test(message)) { sawRejected = true; break; } // 签名/UA 被拒，换域名也没用
      noteDeadDomain(ctx, domain);
      continue;                                                     // 解不开就换域名再试
    }
    await noteDomainSuccess(ctx, domain);
    return { ok: true, domain, data };
  }

  if (sawRejected) return { ok: false, kind: 'rejected', message: lastMessage };
  if (sawTimeout) return { ok: false, kind: 'timeout', message: lastMessage };
  return { ok: false, kind: 'network', message: lastMessage };
}

/** 网络类失败 → 可照做的中文。code 只有 E_NETWORK / E_TIMEOUT（契约里就这几个）。 */
function netFail(kind, message, domains) {
  if (kind === 'truncated') {
    return fail('E_NETWORK', '响应被截断（httpMaxBytes 不够），请报给作者：' + message + '。这不是域名问题，换域名也一样。');
  }
  if (kind === 'domain') {
    return fail('E_NETWORK', message + '。这是插件配置错误（宿主 httpDomains 少了这个域名），不是网络问题，请报给作者。');
  }
  if (kind === 'timeout') {
    return fail('E_TIMEOUT', '查询超时：15 秒预算内没拿到完整结果（' + (message || '预算用尽') + '）。把 maxChapters 调小一点（或 album_detail 传 withChapters:false）能让每次请求更快收场。');
  }
  if (kind === 'rejected') {
    return fail('E_NETWORK', '禁漫接口拒绝了请求（' + message + '）。多半是接口域名改版或被风控：把当前可用的域名填进插件设置「额外优先域名」后重试。');
  }
  return fail('E_NETWORK', '所有接口域名都不通（已试过 ' + ((domains || []).join(' / ') || '（空）') + '；最后错误：' + (message || '无') + '）。请在插件设置「额外优先域名」里填入当前可用的域名（一行一个，例如 www.cdngwc.cc）后重试。');
}

// ───────────────────────── 「宿主发文件在这个部署里能不能用」──────────────────────
// 与 pixiv-illust 2.0.0 同一套键名与语义：单独一个 storage 键，探测窗口 30 分钟起、
// 连续失败翻倍、封顶 12 小时；成功一次清零。

const SEND_HOST_KEY = 'sendHost';
const SEND_HOST_MAX_MS = 12 * 60 * 60 * 1000;

export function sendHostWindowMs(failures, baseMinutes) {
  const count = Math.max(1, Math.floor(Number(failures) || 1));
  const base = Math.max(1, Number(baseMinutes) || DEFAULTS.sendHostRetryMinutes);
  return Math.min(SEND_HOST_MAX_MS, base * 60 * 1000 * Math.pow(2, count - 1));
}

async function readSendHost(ctx) {
  const value = await storageGet(ctx, SEND_HOST_KEY);
  if (!isPlainObject(value)) return null;
  const brokenAt = Number(value.brokenAt) || 0;
  if (!brokenAt) return null;
  return { brokenAt, failures: Math.max(0, Math.floor(Number(value.failures) || 0)), reason: String(value.reason || '') };
}

export function sendHostActive(record, cfg) {
  return Boolean(record && record.brokenAt
    && (Date.now() - record.brokenAt) <= sendHostWindowMs(record.failures, cfg.sendHostRetryMinutes));
}

async function markSendHostBroken(ctx, reason, previousFailures) {
  const record = {
    brokenAt: Date.now(),
    failures: Math.max(1, Math.floor(Number(previousFailures) || 0) + 1),
    reason: safeSlice(reason, 200)
  };
  await storageSet(ctx, SEND_HOST_KEY, record);
  return record;
}

// ───────────────────────── 封面发送（默认关，仅群聊）─────────────────────────

const GROUP_KEY_RE = /^group:[0-9]+$/;

/**
 * 发封面：只写进结果的 cover 字段，**任何失败都不影响元数据返回**。
 * via: 'host'（宿主直接把文件发进群） / 'forward'（给转发指令） / 'none'（只给链接）
 */
function coverFileName(id, url, tag) {
  const ext = (String(url || '').split('?')[0].match(/\.(webp|jpe?g|png|gif)$/i) || [null, '.jpg'])[1].toLowerCase();
  // 方形封面内容是 WebP 但 URL 叫 .jpg：发出去时按真实格式命名，免得某些客户端按扩展名解码失败
  const real = tag === 'cover' ? '.webp' : (ext === 'jpeg' ? '.jpg' : ext);
  return 'jm-' + id + '-' + tag + real;
}

/**
 * 发封面：只写进结果的 cover 字段，**任何失败都不影响元数据返回**。
 * 先试官方方形封面（未竖切打乱），失败再退回第一页图（新本子可能被打乱）。
 * via: 'host'（宿主直接把文件发进群） / 'forward'（给转发指令） / 'none'（只给链接）
 */
async function deliverCover(ctx, id, primaryUrl, fallbackUrl) {
  const chatKey = String(ctx.context?.chatKey || '');
  // 宿主 cap.send.file 只接受 group:<数字>；私聊/控制台一律回落成链接
  if (!GROUP_KEY_RE.test(chatKey)) {
    return { delivered: false, via: 'none', reason: '私聊不发图，用 coverUrl' };
  }
  const candidates = [];
  if (primaryUrl) candidates.push({ url: primaryUrl, name: coverFileName(id, primaryUrl, 'cover'), source: 'album' });
  if (fallbackUrl && fallbackUrl !== primaryUrl) {
    candidates.push({ url: fallbackUrl, name: coverFileName(id, fallbackUrl, 'page'), source: 'page' });
  }
  const first = candidates[0];
  const forward = first ? coverForward(first.url, first.name) : null;
  const record = await readSendHost(ctx);
  let mode;
  if (ctx.sendMode === 'forward') mode = 'forward';
  else if (ctx.sendMode === 'host') mode = 'host';
  else mode = sendHostActive(record, ctx) ? 'forward' : 'host';

  if (mode === 'forward') {
    return {
      delivered: false,
      via: 'forward',
      forward,
      reason: sendHostActive(record, ctx) ? HOST_BROKEN_HUMAN : '按设置只走转发（省一次下载）'
    };
  }

  let lastReason = '';
  const left = remaining(ctx);
  if (left < 800) {
    // 预算已经不够下载一张图：这一趟不花（宿主侧还有 20s 空闲超时，不能拿假地板去撞）
    await logWarn(ctx, '封面下载跳过 id=' + id + '：剩余预算 ' + left + 'ms');
    return { delivered: false, via: 'forward', forward, reason: '本次预算只剩 ' + left + 'ms，没时间下载封面图' };
  }
  for (const candidate of candidates) {
    const imageDomain = hostOfUrl(candidate.url);
    let downloaded;
    try {
      downloaded = await ctx.cap('cap.media.download', {
        url: candidate.url,
        name: candidate.name,
        maxBytes: MAX_COVER_BYTES,
        headers: { 'user-agent': UA_APP, referer: 'https://' + imageDomain + '/' }
      }, Math.min(10000, remaining(ctx)));
    } catch (error) {
      const message = String(error?.message || error);
      await logWarn(ctx, '封面下载失败 id=' + id + ' source=' + candidate.source + '：' + message);
      lastReason = String(error?.code || '') === 'E_DOMAIN'
        ? '封面图域名不在 httpDomains 白名单里（配置错误）'
        : '封面下载失败（' + safeSlice(message, 100) + '）';
      continue;
    }
    // 没有封面的本子回 200 + 0 字节；错误页是 text/html —— 两种都不能发
    const contentType = String(downloaded?.contentType || '').toLowerCase();
    const bytes = Number(downloaded?.bytes) || 0;
    if (!/^image\//i.test(contentType)) {
      lastReason = '下载到的不是图片（contentType=' + (contentType || '缺失') + '）';
      continue;
    }
    if (!bytes) { lastReason = '下载到的是空文件（这本可能没有封面）'; continue; }
    const file = String(downloaded?.file || candidate.name);
    const leftToSend = remaining(ctx);
    if (leftToSend < 800) {
      await logWarn(ctx, '宿主发文件跳过 id=' + id + '：剩余预算 ' + leftToSend + 'ms');
      return { delivered: false, via: 'forward', reason: '本次预算只剩 ' + leftToSend + 'ms，没时间把文件发进群（图已下载）', forward: coverForward(candidate.url, candidate.name), bytes, source: candidate.source };
    }
    try {
      await ctx.cap('cap.send.file', { chatKey, file, name: file }, Math.min(15000, remaining(ctx)));
    } catch (error) {
      const message = String(error?.message || error);
      const failedForward = coverForward(candidate.url, candidate.name);
      // 只有「协议端读不到宿主文件」这类错才降级；其它错（限频、没发送队列）不该改全局策略
      if (HOST_FILE_BROKEN_RE.test(message)) {
        await markSendHostBroken(ctx, message, record && record.failures);
        await logWarn(ctx, '宿主发文件不可用（id=' + id + '）：' + message);
        return { delivered: false, via: 'forward', reason: HOST_BROKEN_HUMAN, forward: failedForward, bytes, source: candidate.source };
      }
      await logWarn(ctx, '封面发送失败 id=' + id + '：' + message);
      return { delivered: false, via: 'none', reason: '发送失败（' + safeSlice(message, 100) + '）', forward: failedForward, bytes, source: candidate.source };
    }
    if (record) await storageSet(ctx, SEND_HOST_KEY, null); // 成了一次就清零，下次继续先试宿主
    return { delivered: true, via: 'host', bytes, source: candidate.source };
  }
  return { delivered: false, via: 'none', reason: lastReason || '没有可用的封面图链', forward };
}

// ───────────────────────── 两个工具 ─────────────────────────

async function searchAlbum(ctx, args) {
  const kw = firstString(args?.kw);
  if (!kw) return fail('E_ARGS', 'kw 不能为空：请给出要搜的关键词（例如 熟女、作者名、作品名片段）。');
  const page = clampInt(args?.page, 1, 1, 100);
  const count = clampInt(args?.count, ctx.maxResults, 1, MAX_COUNT);

  const got = await apiGet(ctx, '/search', { search_query: kw, page });
  if (!got.ok) return netFail(got.kind, got.message, ctx.domainList);
  if (!isPlainObject(got.data)) return fail('E_NETWORK', '搜索接口返回的形状不认识（不是对象）。多半是域名被换成了别的东西。');

  const items = asArray(got.data.content).filter(isPlainObject).map(normalizeSearchItem).filter((x) => x.id);
  const total = num(got.data.total);
  const results = items.slice(0, count);
  const hasMore = items.length > count || page * PAGE_SIZE < total;

  let advise;
  if (!results.length) {
    advise = '没有搜到「' + safeSlice(kw, 40) + '」的条目。换一个更短、更常见的关键词再试（例如只留作品名里的两三个字），或者用作者名搜。';
  } else {
    const capped = total >= TOTAL_CAP ? '（接口的 total 有 ' + TOTAL_CAP + ' 上限，实际远多于这个数，只能靠翻页往后看）' : '';
    // 搜索本身不带封面图：发不发图由 album_detail 决定。这里必须按设置说真话，
    // 否则模型会把「不要承诺发图」原样转述给用户（2026-10 实测踩过）。
    const coverHint = ctx.sendCover
      ? '设置里已允许发封面：调 album_detail 时会在群聊里直接把封面图发出来（私聊仍只给链接）。搜索本身不带图，别在这里承诺发图。'
      : '本插件默认只查不下载、不发图：想直接发封面，先让管理员在设置里打开「允许把封面图发到群里」；现在只把 pageUrl 与详情里的 coverUrl 给用户。';
    advise = '要把某一本看得更细，调用 album_detail 并把 id 传 ' + results[0].id + '（纯数字即可）' + capped + '。' + coverHint;
  }

  return { ok: true, query: kw, page, count, total, hasMore, results, advise };
}

async function albumDetail(ctx, args) {
  const rawId = args?.id;
  const id = normalizeAlbumId(rawId);
  if (!id) {
    return fail(
      'E_ARGS',
      'id 认不出车牌号：收到的是「' + safeSlice(String(rawId ?? ''), 40) + '」。请给纯数字（如 350234）、jm350234、JM-350234，或整条 /album/350234 链接。'
    );
  }
  const withChapters = toBool(args?.withChapters, true);
  const notes = [];

  const got = await apiGet(ctx, '/album', { id });
  if (!got.ok) return netFail(got.kind, got.message, ctx.domainList);
  const album = got.data;
  if (!isPlainObject(album) || (!firstString(album.id) && !firstString(album.name) && !asArray(album.series).length)) {
    return fail('E_NOT_FOUND', '没查到 JM' + id + '：接口没返回这本的内容。车牌号可能写错了，或者这本已被删/被隐藏。');
  }

  let chapters = asArray(album.series)
    .filter(isPlainObject)
    .map((ch) => ({ id: firstString(ch.id, ch.chapter_id), name: firstString(ch.name), sort: num(ch.sort) }))
    .filter((ch) => ch.id)
    .sort((a, b) => a.sort - b.sort || Number(a.id) - Number(b.id))
    .map((ch, index) => ({
      // 接口偶尔不给章节名（实测 350234 的第一话 name 为空串），补一个位置占位名
      id: ch.id,
      name: ch.name || '第' + (ch.sort || index + 1) + '话',
      sort: ch.sort,
      pages: null
    }));

  if (!chapters.length) {
    // 单话本子：接口有时不给 series，本子 ID 本身就是那一话的章节 ID。
    chapters = [{ id, name: firstString(album.name) || 'JM' + id, sort: 0, pages: null }];
    notes.push('接口没给章节列表，按本子 ID 当唯一一话处理。');
  }

  // 官方方形封面不依赖章节接口（/media/albums/<id>.jpg，实测未做竖切打乱）；
  // 第一页图只作兜底：部分本子的方形封面是 200 + 0 字节。
  const albumCoverUrl = ctx.includeCover ? buildAlbumCoverUrl(id, IMAGE_DOMAINS[0]) : null;
  let pageCoverUrl = null;
  let budgetExhausted = false;

  if (!withChapters) {
    notes.push('withChapters=false：没有请求章节接口，pages 一律为 null（方形封面不依赖章节，仍会给出）。');
  } else if (ctx.maxChapters <= 0) {
    notes.push('maxChapters=0：按设置不取每话页数，pages 一律为 null（方形封面不依赖章节，仍会给出）。');
  } else {
    const limit = Math.min(chapters.length, ctx.maxChapters);
    if (limit < chapters.length) {
      notes.push('共 ' + chapters.length + ' 话，只检查了前 ' + limit + ' 话的页数（受设置 maxChapters=' + ctx.maxChapters + ' 限制），其余 pages 为 null。');
    }
    const firstImages = new Map();
    const failed = [];
    for (let i = 0; i < limit; i += CHAPTER_CONCURRENCY) {
      if (remaining(ctx) < 400) { budgetExhausted = true; break; }
      const batch = chapters.slice(i, Math.min(limit, i + CHAPTER_CONCURRENCY));
      await Promise.all(batch.map(async (ch) => {
        const gotChapter = await apiGet(ctx, '/chapter', { id: ch.id });
        if (!gotChapter.ok) { failed.push(ch.id); return; }
        const images = asArray(gotChapter.data?.images).map((x) => firstString(x)).filter(Boolean);
        ch.pages = images.length;
        if (images[0]) firstImages.set(ch.id, images[0]);
      }));
      if (remaining(ctx) < 400) { budgetExhausted = true; break; }
    }
    if (failed.length) {
      notes.push('第 ' + failed.map((x) => chapters.findIndex((c) => c.id === x) + 1).filter((n) => n > 0).join('、') + ' 话的页数没取到（章节接口失败），pages 为 null。');
    }
    if (budgetExhausted) notes.push('15 秒预算用尽，后面的章节没有再请求，pages 为 null。');

    const first = chapters[0];
    const firstImage = first ? firstImages.get(first.id) : '';
    if (firstImage) pageCoverUrl = buildImageUrl(IMAGE_DOMAINS[0], first.id, firstImage, Math.floor(Date.now() / 1000));
  }

  let coverUrl = null;
  if (!ctx.includeCover) {
    notes.push('includeCover=false：按设置没有生成封面图链。');
  } else {
    // 优先方形封面；取不到（0 字节/非图片）时 deliverCover 会退回第一页图
    coverUrl = albumCoverUrl || pageCoverUrl;
    if (albumCoverUrl && pageCoverUrl) notes.push('封面优先用官方方形封面；它取不到时会退回第一页图（部分新本子的第一页被竖切打乱）。');
  }

  const pagesReported = chapters.filter((c) => typeof c.pages === 'number').length;
  const totalPages = chapters.reduce((sum, c) => sum + (typeof c.pages === 'number' ? c.pages : 0), 0);
  if (pagesReported > 0 && pagesReported < chapters.length) {
    notes.push('totalPages=' + totalPages + ' 只是已检查的 ' + pagesReported + ' 话之和，不是整本的总页数。');
  }

  // 封面：设置里没开就恒为 null；开了才试，失败只写进 cover 与 notes，不影响元数据
  let cover = null;
  let advise = '';
  if (ctx.sendCover) {
    if (!coverUrl) {
      cover = { delivered: false, via: 'none', reason: '设置里关掉了封面图链（includeCover=false）' };
    } else {
      cover = await deliverCover(ctx, id, albumCoverUrl, pageCoverUrl);
    }
    if (cover.reason) notes.push('封面没有直接发出去：' + cover.reason + '。');
    if (cover.via === 'forward') notes.push('首次发图报一次错属正常探路：降级期内直接用转发指令，到期后会自动再试一次宿主发文件。');
    advise = cover.delivered ? SENT_ADVISE : (cover.forward ? FORWARD_ADVISE : LINK_ADVISE);
  } else if (coverUrl) {
    advise = '设置里没开「允许把封面图发到群里」：把 coverUrl 原样给用户点开，不要自己拼 send_group_file；想直接发图请管理员打开那个开关。';
  } else {
    advise = '设置里关掉了封面图链（includeCover=false），这次没有图可给。要封面请管理员打开「详情里带封面图直链」。';
  }

  const payload = {
    ok: true,
    id,
    title: firstString(album.name, album.title) || 'JM' + id,
    authors: uniqClean(album.author ?? album.authors),
    tags: uniqClean(album.tags),
    works: uniqClean(album.works),
    actors: uniqClean(album.actors),
    description: safeSlice(firstString(album.description, album.desc), MAX_DESC),
    chapters,
    chapterCount: chapters.length,
    pagesReported,
    totalPages,
    stats: {
      views: num(firstString(album.total_views, album.views)),
      likes: num(album.likes),
      comments: num(firstString(album.total_comment, album.comment_total))
    },
    addedAt: formatDate(firstString(album.addtime, album.adddate)),
    pageUrl: WEB_BASE + '/album/' + id + '/',
    coverUrl,
    cover,
    notes
  };
  if (advise) payload.advise = advise;
  return payload;
}

/**
 * 工具总入口：永远返回一个纯 JSON 对象（成功对象或 {ok:false, error}），不抛异常。
 * 契约里 code 只有 E_ARGS / E_NOT_FOUND / E_NETWORK / E_TIMEOUT / E_UNKNOWN_TOOL 五种，
 * 所以「插件自己出了意外」也只能落到 E_NETWORK，message 里写明不是域名问题，便于排查。
 */
export async function runTool(ctx, name, args) {
  const tool = String(name || '');
  try {
    if (tool !== 'search_album' && tool !== 'album_detail') {
      return fail('E_UNKNOWN_TOOL', '本插件没有工具「' + safeSlice(tool, 40) + '」，只有 search_album 与 album_detail。');
    }
    if (!ctx.deadline) ctx.deadline = Date.now() + BUDGET_MS;
    await prepareDomains(ctx);
    return tool === 'search_album' ? await searchAlbum(ctx, args) : await albumDetail(ctx, args);
  } catch (error) {
    return fail('E_NETWORK', '插件内部出错（不是域名问题）：' + safeSlice(String(error?.message || error), 200));
  }
}

// ───────────────────────── probe（控制台「检测」按钮）─────────────────────────

/**
 * 探前 PROBE_MAX_DOMAINS 个候选域名的 /album?id=350234，总预算 PROBE_BUDGET_MS。
 * 只读：不写域名记忆（诊断不该改状态）。
 * 回执 { ok:true, preferred, checks:[{domain, ok, status, ms, error?|skipped?}], note, ms }。
 */
export async function probeDomains(ctx) {
  const startedAt = Date.now();
  if (!ctx.deadline) ctx.deadline = startedAt + PROBE_BUDGET_MS;
  await prepareDomains(ctx);
  const stored = ctx.preferred;
  // 只真探前 PROBE_MAX_DOMAINS 个域名：控制台的检测按钮等不了十几秒
  const probed = ctx.domainList.slice(0, PROBE_MAX_DOMAINS);
  const checks = await Promise.all(probed.map(async (domain) => {
    const left = Math.max(0, PROBE_BUDGET_MS - (Date.now() - startedAt));
    const t0 = Date.now();
    const got = await fetchOne(ctx, domain, '/album', { id: PROBE_ALBUM_ID }, Math.min(PER_REQUEST_MS, left));
    const ms = Date.now() - t0;
    if (!got.ok) {
      const why = got.truncated
        ? '响应被截断（httpMaxBytes 不够）'
        : (safeSlice(got.error || '请求失败', 120) + (got.code && got.code !== 'E_CAP_TIMEOUT' ? '（' + got.code + '）' : ''));
      return { domain, ok: false, status: got.status || 0, ms, error: why };
    }
    try {
      decodeApiEnvelope(got.body, got.ts);
    } catch (error) {
      // 带上响应开头：「响应不是 JSON」十有八九是被挡成了一个网页，看开头就能分辨
      const head = safeSlice(String(got.body || '').replace(/\s+/g, ' ').trim(), 60);
      return {
        domain,
        ok: false,
        status: got.status,
        ms,
        error: '响应解不开：' + safeSlice(String(error?.message || error), 100) + (head ? '（开头 ' + head + '）' : '')
      };
    }
    return { domain, ok: true, status: got.status, ms };
  }));
  for (const domain of ctx.domainList.slice(PROBE_MAX_DOMAINS)) {
    checks.push({ domain, ok: false, status: 0, ms: 0, skipped: true, error: '预算只有 ' + PROBE_BUDGET_MS + 'ms，本次没有探这个域名' });
  }
  const firstOk = checks.find((c) => c.ok);
  const preferred = firstOk ? firstOk.domain : (stored || null);
  const okCount = checks.filter((c) => c.ok).length;
  const note = firstOk
    ? okCount + '/' + checks.length + ' 域名可用，首选 ' + firstOk.domain
    : '没有探到可用域名（共 ' + checks.length + ' 个）' + (stored ? '；记忆里上次成功的是 ' + stored : '') + '，请在设置里填一个当前可用的域名';
  return { ok: true, preferred, checks, note, ms: Date.now() - startedAt };
}

// ───────────────────────── stdio NDJSON 协议 ─────────────────────────

/** 只有被当主模块跑时才进协议循环；被 import（单测/其它脚本）时什么都不做。 */
function isMainModule() {
  try {
    const argv1 = process.argv[1];
    if (typeof argv1 !== 'string' || !argv1) return false;
    const here = import.meta.url;
    const ran = pathToFileURL(path.resolve(argv1)).href;
    return process.platform === 'win32' ? here.toLowerCase() === ran.toLowerCase() : here === ran;
  } catch {
    return false;
  }
}

function main() {
  const write = (msg) => { try { process.stdout.write(JSON.stringify(msg) + '\n'); } catch { /* 管道断了也没别的办法 */ } };
  // level 只给 uncaughtException 用：普通 warn 的前缀与旧版逐字节一致
  const warn = (text, level = 'warn') => { try { process.stderr.write('[jm-album]' + (level === 'warn' ? '' : '[' + level + ']') + ' ' + text + '\n'); } catch { /* ignore */ } };
  /**
   * 统一回执：只有带 id 的请求才回话。宿主退出时发的是**不带 id** 的 shutdown，
   * 那种请求回话会变成一条 {"result":{}} 垃圾消息（宿主侧 protocolErrors +1）。
   */
  const respond = (msg, result) => {
    if (msg.id === undefined || msg.id === null) return;
    write({ id: msg.id, result });
  };

  let seq = 0;
  const pending = new Map();
  let settings = null;
  let settingsFromInit = {};

  /**
   * 调宿主能力：成功 resolve(result)，失败 reject（带 code 的 Error）。
   * id 用 'cap-N' 字符串：宿主发来的 callTool/probe 请求用的是数字 id，用数字会撞键
   * （把宿主的请求当成回执吃掉，整条链路静默卡死）。
   */
  const capCall = (method, params, timeoutMs) => new Promise((resolve, reject) => {
    const limit = Math.max(300, Number(timeoutMs) || CAP_TIMEOUT_MS);
    const id = 'cap-' + (++seq);
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(Object.assign(new Error('宿主没有回话（' + method + ' 超时 ' + limit + 'ms）'), { code: 'E_CAP_TIMEOUT' }));
    }, limit);
    pending.set(id, { resolve, reject, timer });
    write({ id, method, params });
  });

  const readSettings = async () => {
    if (settings) return settings;
    try {
      const result = await capCall('cap.config.get', {}, STORAGE_TIMEOUT_MS);
      const fromHost = isPlainObject(result) && isPlainObject(result.settings) ? result.settings : null;
      settings = fromHost || (isPlainObject(settingsFromInit) ? settingsFromInit : {});
    } catch {
      settings = isPlainObject(settingsFromInit) ? settingsFromInit : {};
    }
    return settings;
  };

  /**
   * probe 专用取配置：先用 init 快照（零 cap 调用，控制台检测按钮必须秒回），
   * 只在快照为空时才补一次 cap.config.get。
   */
  const readSettingsForProbe = async () => {
    if (isPlainObject(settingsFromInit) && Object.keys(settingsFromInit).length) return settingsFromInit;
    return readSettings();
  };

  const makeCtx = async (msg, useSnapshot = false) => {
    const config = useSnapshot ? await readSettingsForProbe() : await readSettings();
    const ctx = makeContext(config, {
      cap: capCall,
      context: isPlainObject(msg.params?.context) ? msg.params.context : {}
    });
    ctx.deadline = Date.now() + BUDGET_MS;
    return ctx;
  };

  const handleCallTool = async (msg) => {
    let result;
    try {
      const ctx = await makeCtx(msg);
      const args = isPlainObject(msg.params?.args) ? msg.params.args : {};
      result = await runTool(ctx, msg.params?.name, args);
    } catch (error) {
      result = fail('E_NETWORK', '插件内部出错（不是域名问题）：' + safeSlice(String(error?.message || error), 200));
    }
    respond(msg, result);
  };

  const handleProbe = async (msg) => {
    let payload;
    try {
      const ctx = await makeCtx(msg, true);
      ctx.deadline = Date.now() + PROBE_BUDGET_MS;
      payload = await probeDomains(ctx);
    } catch (error) {
      payload = fail('E_NETWORK', '自检失败：' + safeSlice(String(error?.message || error), 200));
    }
    respond(msg, payload);
  };

  const onMessage = (msg) => {
    if (!msg || typeof msg !== 'object') return;
    if (typeof msg.id === 'string' && pending.has(msg.id)) {
      const entry = pending.get(msg.id);
      pending.delete(msg.id);
      clearTimeout(entry.timer);
      if (msg.error) {
        entry.reject(Object.assign(new Error(String(msg.error.message || '能力调用失败')), { code: String(msg.error.code || 'E_CAP') }));
      } else {
        entry.resolve(msg.result ?? null);
      }
      return;
    }
    switch (msg.method) {
      case 'init':
        if (isPlainObject(msg.params?.settings)) settingsFromInit = msg.params.settings;
        settings = null; // 重新握手就重读配置
        respond(msg, { ok: true });
        return;
      case 'ping':
        respond(msg, { ok: true });
        return;
      case 'probe':
        void handleProbe(msg);
        return;
      case 'shutdown':
        // 宿主退出时发的是**不带 id** 的 shutdown；respond 替我们守住「没有 id 就不回话」。
        respond(msg, { ok: true });
        setTimeout(() => process.exit(0), 30);
        return;
      case 'callTool':
        void handleCallTool(msg);
        return;
      default:
        return; // 未声明/不认识的方法忽略，不回话
    }
  };

  let buffer = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (chunk) => {
    buffer += chunk;
    let index = buffer.indexOf('\n');
    while (index !== -1) {
      const line = buffer.slice(0, index).trim();
      buffer = buffer.slice(index + 1);
      if (line) {
        let parsed = null;
        try { parsed = JSON.parse(line); } catch { parsed = null; }
        if (parsed) onMessage(parsed);
      }
      index = buffer.indexOf('\n');
    }
    if (buffer.length > 1048576) { // 一直没换行（或对端塞垃圾）：丢掉，别把内存吃光
      warn('stdin 缓冲超过 1048576 字符，已整段丢弃');
      buffer = '';
    }
  });
  process.stdout.on('error', () => process.exit(0)); // 管道断了（EPIPE）就别再撑着
  process.stdin.on('error', (error) => warn('stdin 出错：' + (error?.message || error)));
  process.on('uncaughtException', (error) => warn('未捕获异常（已忽略，进程继续）：' + (error?.stack || error?.message || error), 'error'));
  process.on('unhandledRejection', (error) => warn('未处理的 Promise 拒绝（已忽略）：' + (error?.stack || error?.message || error), 'error'));
}

if (isMainModule()) main();
