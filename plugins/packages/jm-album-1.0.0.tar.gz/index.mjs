// 禁漫漫画查询（jm-album）—— 把技能 jm-suomingor（异步下载整本 → 还原竖切 → 合成 PDF → 上传）
// 降级成「只查不发」：只发只读请求，取文字元数据 + 拼几个直链，不下载图片、不合成、不上传、不发图。
//
// ── 为什么只剩「移动端加密 API」这一条路 ────────────────────────────────
// 网页版（https://18comic.vip/album/<id>、/search/photos）实测被 Cloudflare 挡住，
// 一律 403 "Just a moment..."，所以**没有**网页兜底。可用的是 App 自己调的那套接口：
//   · ts = 秒级时间戳；token = md5(ts + '185Hcomic3PAPP7R')；tokenparam = "<ts>,2.1.7"
//   · UA 必须是 App 的 UA —— 实测桌面 Chrome UA 会被判 "Not legal request"（code 401）
//   · 响应体 = AES-256-ECB(base64)，key = md5(ts + 密钥) 的 32 字节；自己去 PKCS#7 填充
//
// ── 单文件、零依赖 ──────────────────────────────────────────────────────
// 只 import node: 内置模块（node:crypto / node:url / node:path），请求用 globalThis.fetch 直连。
// 插件进程没有写权限、不能起子进程，所以这里不写文件、不 spawn、不读插件目录外的文件。
// manifest 里声明了 http 能力只是为了说清「它会联网」，请求由插件进程自己发出，
// **不走** cap.http.request（那条路有内网拦截与体积上限，对这套加密接口没用，见 README）。
//
// ── 时间预算 ────────────────────────────────────────────────────────────
// 宿主对一次工具调用的硬超时是 20 秒。这里给自己 15 秒总预算：每个域名/章节请求都带
// AbortSignal.timeout，且被剩余预算二次裁剪；预算用尽就带着已取到的部分 + notes 返回。
import crypto from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

export const UA_APP =
  'Mozilla/5.0 (Linux; Android 9; V1938CT Build/PQ3A.190705.11211812; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Safari/537.36';

const APP_VERSION = '2.1.7';
const APP_TOKEN_SECRET = '185Hcomic3PAPP7R'; // 与 jmcomic 2.7.7 的移动端一致：token = md5(ts + 它)
const WEB_BASE = 'https://18comic.vip';

/** 内置 API 域名池（四个都实测过 code 200）。会换，所以配置里可以额外填。 */
export const DEFAULT_API_DOMAINS = ['www.cdnhjk.net', 'www.cdngwc.cc', 'www.cdngwc.net', 'www.cdngwc.club'];

/** 图片 CDN 池，只用来拼封面直链（拼完就扔给模型/人，插件自己不下载）。 */
export const IMAGE_DOMAINS = [
  'cdn-msp.jmapiproxy1.cc',
  'cdn-msp.jmapiproxy2.cc',
  'cdn-msp2.jmapiproxy2.cc',
  'cdn-msp3.jmapiproxy2.cc',
  'cdn-msp.jmapinodeudzn.net',
  'cdn-msp3.jmapinodeudzn.net'
];

const PAGE_SIZE = 80;          // 搜索接口每页固定 80 条（实测）
const TOTAL_CAP = 10000;       // 搜索接口的 total 上限值（实测常驻 10000，别当真数）
const BUDGET_MS = 15000;       // 单次工具调用总预算（宿主硬超时 20 秒）
const RESERVE_MS = 400;        // 留给序列化/写回响应的余量
const MAX_DESC = 800;          // description 截断长度
const MAX_COUNT = 20;          // search_album 的 count 硬上限
const MAX_CHAPTERS_CAP = 20;   // maxChapters 的硬上限
const CHAPTER_CONCURRENCY = 4; // 同时取几话的页数

export const DEFAULTS = Object.freeze({
  enabled: true,
  timeoutMs: 12000,
  maxChapters: 6,
  maxResults: 8,
  includeCover: true,
  domains: ''
});

// ───────────────────────── 纯函数（导出，便于单测） ─────────────────────────

const md5hex = (s) => crypto.createHash('md5').update(String(s), 'utf8').digest('hex');
const isPlainObject = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v);

/** 取第一个像样的字符串（数字也认），否则空串。 */
function firstString(...vals) {
  for (const v of vals) {
    if (typeof v === 'string' && v.trim()) return v.trim();
    if (typeof v === 'number' && Number.isFinite(v)) return String(v);
  }
  return '';
}

function asArray(v) {
  if (Array.isArray(v)) return v;
  if (v === null || v === undefined || v === '') return [];
  return [v];
}

/** 去掉孤立代理项（半个 emoji）—— 孤立代理项会让整个模型请求 400。 */
function stripLoneSurrogates(value) {
  const s = String(value ?? '');
  let out = '';
  for (let i = 0; i < s.length; i++) {
    const code = s.charCodeAt(i);
    if (code >= 0xd800 && code <= 0xdbff) {
      const next = s.charCodeAt(i + 1);
      if (next >= 0xdc00 && next <= 0xdfff) { out += s[i] + s[i + 1]; i += 1; }
      continue;
    }
    if (code >= 0xdc00 && code <= 0xdfff) continue;
    out += s[i];
  }
  return out;
}

/** 安全截断：按 UTF-16 码元切，且不在结尾留半个 emoji。 */
function safeSlice(value, max) {
  const s = String(value ?? '');
  const limit = Math.max(0, Math.floor(Number(max)) || 0);
  return stripLoneSurrogates(limit >= s.length ? s : s.slice(0, limit));
}

/** 去重 + 丢掉空串与 'N/A'（禁漫的作者/标签字段里这两种占位很常见）。 */
function uniqClean(list) {
  const out = [];
  const seen = new Set();
  for (const raw of asArray(list)) {
    const s = firstString(raw);
    if (!s) continue;
    if (/^n\/?a$/i.test(s)) continue;
    const key = s.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(s);
  }
  return out;
}

function clampInt(value, fallback, lo, hi) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(hi, Math.max(lo, Math.trunc(n)));
}

function num(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.trunc(n)) : 0;
}

/** 布尔读取：模型有时把 true 写成字符串 "true"/"false"，别让 "false" 变成 true。 */
function toBool(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'boolean') return value;
  const s = String(value).trim().toLowerCase();
  if (['true', '1', 'yes', 'on', '是', '开'].includes(s)) return true;
  if (['false', '0', 'no', 'off', '否', '关'].includes(s)) return false;
  return fallback;
}

/**
 * 车牌号归一化：从 "jm123456" / "JM-123456" / "/album/123456/x" 里取出纯数字。
 * ⚠️ 必须带数字边界断言（(?<!\d)…(?!\d)）：否则 "123456789012" 会被截成 "123456789"
 * 当成合法车牌号去联网 —— 白白轮询一圈域名，还查出一本毫不相干的本子。
 * 认不出来（包括那种超长数字串）一律返回空串，让上层报 E_ARGS。
 */
export function normalizeAlbumId(raw) {
  const s = String(raw ?? '').trim();
  if (!s) return '';
  const pick = (digits) => {
    const d = String(digits || '').replace(/^0+(?=\d)/, '');
    return d.length >= 2 && d.length <= 9 ? d : ''; // 超长不截断，直接算认不出
  };
  // ① 链接里的 /album/<id> 或 /photo/<id> —— 最可靠（18comic.vip/album/350234/
  //    里还有个 "18" 会被裸数字匹配先撞上，所以这一步必须在兜底之前）。
  const inUrl = s.match(/\/(?:album|photo)\/(\d{1,12})(?!\d)/i);
  if (inUrl) { const got = pick(inUrl[1]); if (got) return got; }
  // ② jm123456 / JM-123456 / JM 123456 这类前缀写法。
  const prefixed = s.match(/(?:^|[^a-z0-9])jm[-\s]?(\d{1,12})(?!\d)/i);
  if (prefixed) { const got = pick(prefixed[1]); if (got) return got; }
  // ③ 兜底：整串里就一个数字（或长短很明显的几个数字取最长的那个）。必须带数字边界，
  //    否则 "123456789012" 会被截成 "123456789" 当成合法车牌号去联网。
  const runs = s.match(/(?<!\d)\d{2,9}(?!\d)/g) || [];
  if (!runs.length) return '';
  return pick(runs.reduce((best, cur) => (cur.length >= best.length ? cur : best), ''));
}

/**
 * {code, data(base64 密文)} → AES-256-ECB 解密 → JSON。
 * setAutoPadding(false) + 自己按 PKCS#7 去填充：个别响应会让 node 的自动去填充抛 bad decrypt。
 * 解不出来就抛带中文原因的 Error，由调用方决定这是「换个域名再试」还是「直接报错」。
 */
export function decodeApiEnvelope(text, ts) {
  let envelope;
  try {
    envelope = JSON.parse(String(text));
  } catch {
    throw new Error('响应不是 JSON（域名可能已失效或被挡出一个网页）');
  }
  if (!isPlainObject(envelope)) throw new Error('响应形状不认识（不是对象）');
  if (envelope.code !== undefined && Number(envelope.code) !== 200) {
    const detail = firstString(envelope.error_msg, envelope.message, envelope.msg);
    throw new Error(`接口返回 code=${envelope.code}${detail ? `（${safeSlice(detail, 80)}）` : ''}`);
  }
  if (typeof envelope.data !== 'string' || !envelope.data) throw new Error('响应里没有密文 data');

  const key = Buffer.from(md5hex(`${ts}${APP_TOKEN_SECRET}`), 'utf8');
  const decipher = crypto.createDecipheriv('aes-256-ecb', key, null);
  decipher.setAutoPadding(false);
  const plain = Buffer.concat([decipher.update(Buffer.from(envelope.data, 'base64')), decipher.final()]);
  const pad = plain.length ? plain[plain.length - 1] : 0;
  const body = pad > 0 && pad <= 16 && pad <= plain.length ? plain.subarray(0, plain.length - pad) : plain;
  try {
    return JSON.parse(body.toString('utf8'));
  } catch {
    throw new Error('解密后的内容不是 JSON（密钥或时间戳对不上）');
  }
}

/** 秒级时间戳 → UTC+8 的 YYYY-MM-DD。禁漫返回的都是秒（不是毫秒）。 */
export function formatDate(seconds) {
  const n = Number(seconds);
  if (!Number.isFinite(n) || n <= 0) return '';
  const d = new Date((n + 8 * 3600) * 1000);
  return Number.isNaN(d.getTime()) ? '' : d.toISOString().slice(0, 10);
}

/** 拼图片直链：https://<cdn>/media/photos/<chapterId>/<fileName>[?v=ts]。 */
export function buildImageUrl(imageDomain, chapterId, fileName, stamp) {
  const domain = String(imageDomain || IMAGE_DOMAINS[0]).trim()
    .replace(/^https?:\/\//i, '').replace(/\/.*$/, '');
  const chapter = String(chapterId ?? '').trim();
  const name = String(fileName ?? '').split('?')[0].split('/').pop();
  if (!domain || !chapter || !name) return null;
  const v = Number(stamp) > 0 ? `?v=${Math.trunc(Number(stamp))}` : '';
  return `https://${domain}/media/photos/${encodeURIComponent(chapter)}/${encodeURIComponent(name)}${v}`;
}

/**
 * 域名候选：用户填的排最前（他填的是「这台机器上已知可用」），随后是内置池。
 * 填错没有额外代价 —— 失败会继续试内置池，只是慢一点。
 */
export function domainCandidates(userDomains = '') {
  const extra = String(userDomains || '')
    .split(/[\s,;]+/)
    .map((s) => s.trim().replace(/^https?:\/\//i, '').replace(/\/.*$/, ''))
    .filter(Boolean);
  const out = [];
  const seen = new Set();
  for (const d of [...extra, ...DEFAULT_API_DOMAINS]) {
    const key = d.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(d);
  }
  return out;
}

/** 搜到的一条 → 契约形状。category 是对象 {id,title}，别直接 firstString 上去。 */
export function normalizeSearchItem(raw) {
  const item = isPlainObject(raw) ? raw : {};
  const id = firstString(item.id, item.album_id);
  return {
    id,
    title: firstString(item.name, item.title) || (id ? `JM${id}` : ''),
    authors: uniqClean(item.author ?? item.authors),
    category: firstString(item.category?.title, item.category, item.category_sub),
    updatedAt: formatDate(firstString(item.update_at, item.adddate, item.update_date)),
    pageUrl: id ? `${WEB_BASE}/album/${id}/` : ''
  };
}

// ───────────────────────── 上下文与错误 ─────────────────────────

function fail(code, message) {
  return { ok: false, error: { code, message: safeSlice(message, 400) } };
}

/** 把配置收成一次调用用的上下文。deadline 由调用方在开头设。 */
export function makeContext(settings = {}) {
  const merged = { ...DEFAULTS };
  for (const [k, v] of Object.entries(isPlainObject(settings) ? settings : {})) {
    if (v !== undefined && v !== null) merged[k] = v;
  }
  return {
    settings: merged,
    enabled: toBool(merged.enabled, DEFAULTS.enabled),
    timeoutMs: clampInt(merged.timeoutMs, DEFAULTS.timeoutMs, 1000, 20000),
    maxChapters: clampInt(merged.maxChapters, DEFAULTS.maxChapters, 0, MAX_CHAPTERS_CAP),
    maxResults: clampInt(merged.maxResults, DEFAULTS.maxResults, 1, MAX_COUNT),
    includeCover: toBool(merged.includeCover, DEFAULTS.includeCover),
    domains: domainCandidates(merged.domains),
    deadline: 0
  };
}

const REJECTED_RE = /^接口返回 code=/;

function buildHeaders(domain, ts) {
  return {
    'user-agent': UA_APP,
    accept: 'application/json, text/plain, */*',
    'accept-language': 'zh-CN,zh;q=0.9',
    referer: `https://${domain}/`,
    origin: `https://${domain}`,
    token: md5hex(`${ts}${APP_TOKEN_SECRET}`),
    tokenparam: `${ts},${APP_VERSION}`
  };
}

/**
 * 打一次加密接口，按域名池依次重试。
 * 返回 {ok:true, data, domain} 或 {ok:false, kind:'network'|'timeout'|'rejected', message}。
 */
async function apiGet(ctx, pathname, query) {
  const search = query ? `?${new URLSearchParams(query).toString()}` : '';
  let lastMessage = '';
  let sawTimeout = false;
  let sawRejected = false;

  for (const domain of ctx.domains) {
    const left = ctx.deadline - Date.now() - RESERVE_MS;
    if (left < 400) { sawTimeout = true; lastMessage = lastMessage || '整体预算已用完'; break; }
    const perRequest = Math.min(ctx.timeoutMs, left);
    const ts = Math.floor(Date.now() / 1000);
    try {
      const res = await fetch(`https://${domain}${pathname}${search}`, {
        method: 'GET',
        headers: buildHeaders(domain, ts),
        redirect: 'follow',
        signal: AbortSignal.timeout(perRequest)
      });
      if (!res.ok) { lastMessage = `${domain} HTTP ${res.status}`; continue; }
      const text = await res.text();
      return { ok: true, domain, data: decodeApiEnvelope(text, ts) };
    } catch (error) {
      const name = String(error?.name || '');
      const message = String(error?.message || error);
      if (name === 'TimeoutError' || name === 'AbortError') {
        sawTimeout = true;
        lastMessage = `${domain} 超时（${perRequest}ms）`;
      } else if (REJECTED_RE.test(message)) {
        sawRejected = true;
        lastMessage = `${domain} ${message}`;
        break; // 签名/UA 被拒，换域名也没用
      } else {
        lastMessage = `${domain} ${safeSlice(message, 80)}`;
      }
    }
  }

  if (sawRejected) return { ok: false, kind: 'rejected', message: lastMessage };
  if (sawTimeout) return { ok: false, kind: 'timeout', message: lastMessage };
  return { ok: false, kind: 'network', message: lastMessage };
}

/** 网络类失败 → 可照做的中文。代码只能是 E_NETWORK / E_TIMEOUT（契约里就这几个）。 */
function netFail(kind, message, domains) {
  if (kind === 'timeout') {
    return fail('E_TIMEOUT', `查询超时：15 秒预算内没拿到完整结果（${message || '预算用尽'}）。可以在插件设置里把 timeoutMs 调小一点、或把 maxChapters 调小，让每次请求更快收场。`);
  }
  if (kind === 'rejected') {
    return fail('E_NETWORK', `禁漫接口拒绝了请求（${message}）。多半是接口域名改版或被风控：把当前可用的域名填进插件设置 domains（一行一个，例如 www.cdngwc.cc）后重试。`);
  }
  return fail('E_NETWORK', `所有接口域名都不通（已试过 ${(domains || []).join(' / ') || '（空）'}；最后错误：${message || '无'}）。请在插件设置 domains 里填入当前可用的域名（一行一个，例如 www.cdngwc.cc）后重试。`);
}

// ───────────────────────── 两个工具 ─────────────────────────

async function searchAlbum(ctx, args) {
  const kw = firstString(args?.kw);
  if (!kw) return fail('E_ARGS', 'kw 不能为空：请给出要搜的关键词（例如 熟女、作者名、作品名片段）。');
  const page = clampInt(args?.page, 1, 1, 100);
  const count = clampInt(args?.count, ctx.maxResults, 1, MAX_COUNT);

  const got = await apiGet(ctx, '/search', { search_query: kw, page });
  if (!got.ok) return netFail(got.kind, got.message, ctx.domains);
  if (!isPlainObject(got.data)) return fail('E_NETWORK', '搜索接口返回的形状不认识（不是对象）。多半是域名被换成了别的东西。');

  const items = asArray(got.data.content).filter(isPlainObject).map(normalizeSearchItem).filter((x) => x.id);
  const total = num(got.data.total);
  const results = items.slice(0, count);
  const hasMore = items.length > count || page * PAGE_SIZE < total;

  let advise;
  if (!results.length) {
    advise = `没有搜到「${safeSlice(kw, 40)}」的条目。换一个更短、更常见的关键词再试（例如只留作品名里的两三个字），或者用作者名搜。`;
  } else {
    const capped = total >= TOTAL_CAP ? `（接口的 total 有 ${TOTAL_CAP} 上限，实际远多于这个数，只能靠翻页往后看）` : '';
    advise = `要把某一本看得更细，调用 album_detail 并把 id 传 ${results[0].id}（纯数字即可）${capped}。本插件只查不下载，不要承诺发图或下载文件。`;
  }

  return { ok: true, query: kw, page, count, total, hasMore, results, advise };
}

async function albumDetail(ctx, args) {
  const rawId = args?.id;
  const id = normalizeAlbumId(rawId);
  if (!id) {
    return fail(
      'E_ARGS',
      `id 认不出车牌号：收到的是「${safeSlice(String(rawId ?? ''), 40)}」。请给纯数字（如 350234）、jm350234、JM-350234，或整条 /album/350234 链接。`
    );
  }
  const withChapters = toBool(args?.withChapters, true);
  const notes = [];

  const got = await apiGet(ctx, '/album', { id });
  if (!got.ok) return netFail(got.kind, got.message, ctx.domains);
  const album = got.data;
  if (!isPlainObject(album) || (!firstString(album.id) && !firstString(album.name) && !asArray(album.series).length)) {
    return fail('E_NOT_FOUND', `没查到 JM${id}：接口没返回这本的内容。车牌号可能写错了，或者这本已被删/被隐藏。`);
  }

  let chapters = asArray(album.series)
    .filter(isPlainObject)
    .map((ch) => ({ id: firstString(ch.id, ch.chapter_id), name: firstString(ch.name), sort: num(ch.sort) }))
    .filter((ch) => ch.id)
    .sort((a, b) => a.sort - b.sort || Number(a.id) - Number(b.id))
    .map((ch, index) => ({
      // 接口偶尔不给章节名（实测 350234 的第一话 name 为空串），补一个位置占位名，
      // 「」比空串有用得多，而且一眼能看出这是话数而不是书名。
      id: ch.id,
      name: ch.name || `第${ch.sort || index + 1}话`,
      sort: ch.sort,
      pages: null
    }));

  if (!chapters.length) {
    // 单话本子：接口有时不给 series，本子 ID 本身就是那一话的章节 ID。
    chapters = [{ id, name: firstString(album.name) || `JM${id}`, sort: 0, pages: null }];
    notes.push('接口没给章节列表，按本子 ID 当唯一一话处理。');
  }

  let coverUrl = null;
  let budgetExhausted = false;

  if (!withChapters) {
    notes.push('withChapters=false：没有请求章节接口，pages 一律为 null，因此也没有封面图链。');
  } else if (ctx.maxChapters <= 0) {
    notes.push('maxChapters=0：按设置不取每话页数，pages 一律为 null，也没有封面图链。');
  } else {
    const limit = Math.min(chapters.length, ctx.maxChapters);
    if (limit < chapters.length) {
      notes.push(`共 ${chapters.length} 话，只检查了前 ${limit} 话的页数（受设置 maxChapters=${ctx.maxChapters} 限制），其余 pages 为 null。`);
    }
    const firstImages = new Map();
    const failed = [];
    for (let i = 0; i < limit; i += CHAPTER_CONCURRENCY) {
      if (ctx.deadline - Date.now() - RESERVE_MS < 400) { budgetExhausted = true; break; }
      const batch = chapters.slice(i, Math.min(limit, i + CHAPTER_CONCURRENCY));
      await Promise.all(batch.map(async (ch) => {
        const gotChapter = await apiGet(ctx, '/chapter', { id: ch.id });
        if (!gotChapter.ok) { failed.push(ch.id); return; }
        const images = asArray(gotChapter.data?.images).map((x) => firstString(x)).filter(Boolean);
        ch.pages = images.length;
        if (images[0]) firstImages.set(ch.id, images[0]);
      }));
      if (ctx.deadline - Date.now() - RESERVE_MS < 400) { budgetExhausted = true; break; }
    }
    if (failed.length) {
      notes.push(`第 ${failed.map((x) => chapters.findIndex((c) => c.id === x) + 1).filter((n) => n > 0).join('、')} 话的页数没取到（章节接口失败），pages 为 null。`);
    }
    if (budgetExhausted) notes.push('15 秒预算用尽，后面的章节没有再请求，pages 为 null。');

    const first = chapters[0];
    const firstImage = first ? firstImages.get(first.id) : '';
    if (ctx.includeCover) {
      if (firstImage) coverUrl = buildImageUrl(IMAGE_DOMAINS[0], first.id, firstImage, Math.floor(Date.now() / 1000));
      else notes.push('封面图链拼不出来：没拿到第一话的图片列表。');
    } else {
      notes.push('includeCover=false：按设置没有生成封面图链。');
    }
  }

  const pagesReported = chapters.filter((c) => typeof c.pages === 'number').length;
  const totalPages = chapters.reduce((sum, c) => sum + (typeof c.pages === 'number' ? c.pages : 0), 0);
  if (pagesReported > 0 && pagesReported < chapters.length) {
    notes.push(`totalPages=${totalPages} 只是已检查的 ${pagesReported} 话之和，不是整本的总页数。`);
  }

  return {
    ok: true,
    id,
    title: firstString(album.name, album.title) || `JM${id}`,
    authors: uniqClean(album.author ?? album.authors),
    tags: uniqClean(album.tags),
    works: uniqClean(album.works),
    actors: uniqClean(album.actors),
    description: safeSlice(firstString(album.description, album.desc), MAX_DESC),
    chapters,
    chapterCount: chapters.length,
    pagesReported,
    totalPages,
    stats: {
      views: num(firstString(album.total_views, album.views)),
      likes: num(album.likes),
      comments: num(firstString(album.total_comment, album.comment_total))
    },
    addedAt: formatDate(firstString(album.addtime, album.adddate)),
    pageUrl: `${WEB_BASE}/album/${id}/`,
    coverUrl,
    notes
  };
}

/**
 * 工具总入口：永远返回一个纯 JSON 对象（成功对象或 {ok:false, error}），不抛异常。
 * 契约里 code 只有 E_ARGS / E_NOT_FOUND / E_NETWORK / E_TIMEOUT / E_UNKNOWN_TOOL 五种，
 * 所以「插件自己出了意外」也只能落到 E_NETWORK，message 里写明不是域名问题，便于排查。
 */
export async function runTool(ctx, name, args) {
  const tool = String(name || '');
  try {
    if (!ctx.enabled) return fail('E_ARGS', '这个功能在插件设置里被关掉了（enabled=false），先在宿主控制台的插件设置里打开。');
    if (tool === 'search_album') return await searchAlbum(ctx, args);
    if (tool === 'album_detail') return await albumDetail(ctx, args);
    return fail('E_UNKNOWN_TOOL', `本插件没有工具「${safeSlice(tool, 40)}」，只有 search_album 与 album_detail。`);
  } catch (error) {
    return fail('E_NETWORK', `插件内部出错（不是域名问题）：${safeSlice(String(error?.message || error), 200)}`);
  }
}

// ───────────────────────── stdio NDJSON 协议 ─────────────────────────

/** 只有被当主模块跑时才进协议循环；被 import（单测/其它脚本）时什么都不做。 */
function isMainModule() {
  try {
    const argv1 = process.argv[1];
    if (typeof argv1 !== 'string' || !argv1) return false;
    const here = import.meta.url;
    const ran = pathToFileURL(path.resolve(argv1)).href;
    return process.platform === 'win32' ? here.toLowerCase() === ran.toLowerCase() : here === ran;
  } catch {
    return false;
  }
}

function main() {
  const write = (msg) => { try { process.stdout.write(`${JSON.stringify(msg)}\n`); } catch { /* 管道断了也没别的办法 */ } };
  const warn = (text) => { try { process.stderr.write(`[jm-album] ${text}\n`); } catch { /* ignore */ } };

  let seq = 0;
  const pending = new Map();
  let settingsFromInit = {};
  let settings = null;

  /** 调宿主能力；超时/被拒都返回 null，调用方走默认值 —— 绝不能让配置读取把工具调用挂住。 */
  const capCall = (method, params, timeoutMs = 2000) => new Promise((resolve) => {
    const id = `cap-${++seq}`;
    const timer = setTimeout(() => { pending.delete(id); resolve(null); }, timeoutMs);
    pending.set(id, (result) => { clearTimeout(timer); resolve(result); });
    write({ id, method, params });
  });

  const readSettings = async () => {
    if (settings) return settings;
    const result = await capCall('cap.config.get', {});
    const fromHost = isPlainObject(result) && isPlainObject(result.settings) ? result.settings : null;
    settings = fromHost || (isPlainObject(settingsFromInit) ? settingsFromInit : {}) || {};
    return settings;
  };

  const handleCallTool = async (msg) => {
    let result;
    try {
      const config = await readSettings();
      const ctx = makeContext(config);
      ctx.deadline = Date.now() + BUDGET_MS;
      const args = isPlainObject(msg.params?.args) ? msg.params.args : {};
      result = await runTool(ctx, msg.params?.name, args);
    } catch (error) {
      result = fail('E_NETWORK', `插件内部出错（不是域名问题）：${safeSlice(String(error?.message || error), 200)}`);
    }
    let payload;
    try {
      payload = JSON.parse(JSON.stringify(result));
    } catch {
      payload = fail('E_NETWORK', '结果没法序列化成 JSON（插件内部错误）。');
    }
    write({ id: msg.id, result: payload });
  };

  const onMessage = (msg) => {
    if (!msg || typeof msg !== 'object') return;
    if (typeof msg.id === 'string' && pending.has(msg.id)) {
      const done = pending.get(msg.id);
      pending.delete(msg.id);
      done(msg.result);
      return;
    }
    switch (msg.method) {
      case 'init':
        if (isPlainObject(msg.params?.settings)) settingsFromInit = msg.params.settings;
        settings = null; // 重新握手就重读配置
        write({ id: msg.id, result: { ok: true } });
        return;
      case 'ping':
        write({ id: msg.id, result: { ok: true } });
        return;
      case 'shutdown':
        // 宿主退出时发的是**不带 id** 的 shutdown；此时回执会变成 {"result":{}}，
        // 宿主侧记成一条无法识别的消息（protocolErrors +1）。没有 id 就不回话，只退出。
        if (msg.id !== undefined && msg.id !== null) write({ id: msg.id, result: { ok: true } });
        setTimeout(() => process.exit(0), 30);
        return;
      case 'callTool':
        void handleCallTool(msg);
        return;
      default:
        return; // 未声明/不认识的方法忽略，不回话
    }
  };

  let buffer = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (chunk) => {
    buffer += chunk;
    let index = buffer.indexOf('\n');
    while (index !== -1) {
      const line = buffer.slice(0, index).trim();
      buffer = buffer.slice(index + 1);
      if (line) {
        let parsed = null;
        try { parsed = JSON.parse(line); } catch { parsed = null; }
        if (parsed) onMessage(parsed);
      }
      index = buffer.indexOf('\n');
    }
  });
  process.stdin.on('error', (error) => warn(`stdin 出错：${error?.message || error}`));
  process.on('uncaughtException', (error) => warn(`未捕获异常（已忽略，进程继续）：${error?.message || error}`));
  process.on('unhandledRejection', (error) => warn(`未处理的 Promise 拒绝（已忽略）：${error?.message || error}`));
}

if (isMainModule()) main();
