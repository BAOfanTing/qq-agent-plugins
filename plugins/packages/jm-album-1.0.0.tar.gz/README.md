# 禁漫漫画查询（jm-album）

给机器人加两个**只读**工具：按关键词搜禁漫（JMComic）本子、按车牌号查一本的详情。

这是把技能 jm-suomingor（异步下载整本 → 还原竖切 → 合成 PDF → 上传群文件）
**降级移植**成「只查不发」：不下载图片、不合 PDF、不上传文件、不发图。
返回的是**文字元数据**，外加两条直链（封面图、网页）——链接是给人点开看的，插件自己不去取那些图。

> 成人向内容。插件不会主动发任何东西（v1 也没有发言能力），只是被人问到时给模型一份可读的元数据。

## 装

把整个 `jm-album/` 目录放进 `$DATA_DIR/plugins/jm-album/`（或按宿主的方式打包安装），
在控制台「插件」页启用 + 授权。依赖为零：一个 `index.mjs`、一个 `plugin.json`、这份 README，
没有 `package.json`、没有 `node_modules`、没有 TypeScript。

```bash
# 手工打包（ustar；包内是扁平的三个文件，与仓库里 plugins/packages/ 的其它包一致）
tar --format=ustar -czf jm-album-1.0.0.tar.gz -C jm-album README.md index.mjs plugin.json
```

## 模型会看到什么

两个工具，返回的都是纯 JSON。

### `search_album({ kw, page?, count? })`

| 参数 | 说明 |
| --- | --- |
| `kw` | **必填**，关键词。中文/日文/作者名/作品名片段都能搜，越短命中越多 |
| `page` | 页码，从 1 开始，默认 1。接口每页 80 条 |
| `count` | 要几条，1–20，默认取插件设置 `maxResults` |

成功返回：

```json
{ "ok": true, "query": "熟女", "page": 1, "count": 3, "total": 10000, "hasMore": true,
  "results": [ { "id": "1483728", "title": "…", "authors": ["pyroxtra"], "category": "同人",
                 "updatedAt": "2026-10-18", "pageUrl": "https://18comic.vip/album/1483728/" } ],
  "advise": "要把某一本看得更细，调用 album_detail 并把 id 传 1483728…" }
```

`total` 是接口给的数，**它自己封顶 10000**（实测每次都返回 10000），所以别当成真实总数；
往后翻页靠 `hasMore`。搜不到时 `total=0`、`results` 是空数组，`advise` 里会提示换个词 ——
**空结果要说成「没搜到」，不要说成「没有这本」**。

### `album_detail({ id, withChapters? })`

| 参数 | 说明 |
| --- | --- |
| `id` | **必填**，车牌号。纯数字 `350234`、`jm350234`、`JM-350234`、整条 `/album/350234` 链接都认 |
| `withChapters` | 默认 `true`：逐话再请求一次拿每话页数。传 `false` 只列章节名与话数，`pages` 全 `null`，也**没有封面图链** |

成功返回（字段与顺序都是定稿）：

```json
{ "ok": true, "id": "350234", "title": "董卓 上+下",
  "authors": ["孫笑川", "…"], "tags": ["中文", "…"], "works": ["…"], "actors": ["…"],
  "description": "（最多 800 字）",
  "chapters": [ { "id": "350234", "name": "第1话", "sort": 1, "pages": 25 },
                { "id": "350235", "name": "下", "sort": 2, "pages": 25 } ],
  "chapterCount": 2, "pagesReported": 2, "totalPages": 50,
  "stats": { "views": 1765376, "likes": 92808, "comments": 9792 },
  "addedAt": "2022-06-15", "pageUrl": "https://18comic.vip/album/350234/",
  "coverUrl": "https://cdn-msp.jmapiproxy1.cc/media/photos/350234/00001.webp?v=1792415473",
  "notes": [] }
```

- `pages` 来自 `/chapter` 的 `images.length`；只有前 `maxChapters` 话会被请求，其余是 `null`
  并在 `notes` 里说明；`totalPages` 只是**已检查那些话之和**，不是整本页数（部分取到时 `notes` 也会写明）。
- `authors` / `tags` / `works` / `actors` 都去过重，并滤掉空串与 `N/A`。
- 日期一律按 **UTC+8** 格式化成 `YYYY-MM-DD`（接口给的是秒级时间戳）。
- `coverUrl` 用第一话第一张图拼 `https://<图片CDN>/media/photos/<chapterId>/<fileName>`，
  可以 `null`（没取到章节图时）；它是给模型/人看的链接，**插件不下载它**。

### 失败

`{ "ok": false, "error": { "code": "...", "message": "中文、可照做" } }`，code 只有五种：

| code | 什么时候 | 该怎么说 |
| --- | --- | --- |
| `E_ARGS` | `kw` 空 / `id` 认不出车牌号 / 插件在设置里被关掉 | 让对方面把车牌号给全 |
| `E_NOT_FOUND` | 接口没返回这本的内容 | 车牌号可能错了，或这本已删/已隐藏 —— 如实说 |
| `E_NETWORK` | 所有接口域名都不通，或接口拒绝请求（code 401 等） | 把可用域名填进设置 `domains`；不要编造结果 |
| `E_TIMEOUT` | 15 秒总预算用完 | 少查几话（`withChapters:false`）或稍后重试 |
| `E_UNKNOWN_TOOL` | 调了不存在的工具名 | 插件只有这两个工具 |

## 设置

| 键 | 默认 | 说明与代价 |
| --- | --- | --- |
| `enabled` | `true` | 关掉后模型看不到这两个工具 |
| `timeoutMs` | `12000` | **单个域名上的一次请求**最多等多久。整次调用另有 15 秒总预算，调大不会突破它 |
| `maxChapters` | `6` | 逐话取页数的上限。**代价**：每多查一话多一次请求，一本 20 话全查会吃掉预算；设 `0` = 完全不取每话页数 |
| `maxResults` | `8` | `search_album` 不指定 `count` 时返回几条（1–20）。返回太多会占提示词预算 |
| `includeCover` | `true` | 关掉则 `coverUrl` 恒为 `null` |
| `domains` | 空 | 一行一个**额外优先域名**。先试这些、再试内置池。填错没有额外代价（失败会继续试内置池），只是变慢 |

## 网络是怎么走的（重要）

**请求由插件进程自己用 `globalThis.fetch` 发出，不走宿主的 `cap.http.request`。**
manifest 里的 `http` 能力只是把「它会联网」这件事如实写在安装界面上，宿主不会收到任何 `cap.http.*` 调用。

为什么不用 `cap.http.request`：这套接口要求精确的 App UA、`token`/`tokenparam` 签名头和
`referer`/`origin`，响应还是 AES-256-ECB 密文；走宿主那条通用代理，任何一处被改写都会变成
`code=401 Not legal request`，排查成本远高于直连。

代价必须说清楚：

- **Linux 上如果宿主启用了网络隔离**（`plugins.networkIsolation`/`requireNetworkIsolation`，
  Linux 默认用 `unshare --net`），插件进程根本没有网卡，本插件会一律返回
  `E_NETWORK`（`fetch failed` / `ENETUNREACH`）。这类机器要跑它，只能放宽网络隔离，
  或者等一个能透传任意请求头的 `cap.http` 版本。Windows / macOS 拦不住网络，不受影响。
- 插件进程没有写权限、不能起子进程，所以这里不写文件、不 spawn：**所有状态都在内存里**，
  每次调用重新联网。

### 接口本身（实测结论）

- 只有**移动端加密 API** 可用。网页版 `18comic.vip/album/<id>` 与 `/search/photos` 被 Cloudflare
  挡住（403 `Just a moment...`），**所以本插件没有网页兜底**，第一句正文的注释也写了这条。
- 签名：`ts` = 秒级时间戳，`token` = `md5(ts + '185Hcomic3PAPP7R')`，`tokenparam` = `"<ts>,2.1.7"`；
  桌面 Chrome UA 会被判 `Not legal request`（`code 401`）。
- 响应 `{code:200, data:"<base64>"}`：AES-256-ECB，key = 32 字节的 `md5(ts + 密钥)`，
  自己按 PKCS#7 去填充（`setAutoPadding(false)` + 1..16 边界检查）。
- 内置 API 域名池：`www.cdnhjk.net` / `www.cdngwc.cc` / `www.cdngwc.net` / `www.cdngwc.club`；
  图片 CDN 池见 `IMAGE_DOMAINS`。**域名会换**，换的时候把新域名填进设置 `domains` 即可，不用改代码。

## 已知限制

1. `pageUrl` 指向 `https://18comic.vip/album/<id>/`，那是**给人类浏览器点开**的；机器人去抓是 403。
   这是已知边界，不是 bug。
2. 搜索接口的 `total` 封顶 10000，不是真实总数。
3. `withChapters=false` 时没有封面图链（封面要第一话的图片列表，那需要发章节请求）。
4. 章节页数只查前 `maxChapters` 话；`totalPages` 在部分取到时只是已查话数之和，`notes` 会写明。
5. 15 秒总预算用尽时**带着已取到的部分返回**并写进 `notes`，不硬等（宿主硬超时 20 秒）。
6. 没有网页兜底 —— 接口域名全挂时只能等域名池更新或手工填 `domains`。
7. 「插件自己出意外」也只能报 `E_NETWORK`（契约里 code 就那五种），`message` 会写明「不是域名问题」。

## 本地怎么验

```bash
# 单个工具调用（真协议 + 假宿主；宿主那边 cap.config.get 返回这份 settings）
node scripts/plugin-dev.mjs ./jm-album --call search_album --args '{"kw":"熟女","count":3}'
node scripts/plugin-dev.mjs ./jm-album --call album_detail --args '{"id":"jm350234"}'

# 只验纯函数（不联网，也不需要宿主）
node -e "import('./jm-album/index.mjs').then(m=>{
  console.log(m.normalizeAlbumId('https://18comic.vip/album/123456/x'), m.formatDate(1655254028));
})"
```

导出的纯函数：`normalizeAlbumId` / `decodeApiEnvelope` / `formatDate` / `buildImageUrl` /
`domainCandidates` / `normalizeSearchItem` / `makeContext` / `runTool`（`runTool(ctx, name, args)`
是协议层用的同一个入口，单测可以直接喂假 fetch）。作为主模块运行时才会启动 stdin 的 NDJSON 循环；
被 `import` 时什么都不跑。
