// e926 寻图（e926-search）· 插件 API v2 —— 搜 e926/e621 的作品、查作者有没有更新、随机来一张、按作品号直查。
// 默认全年龄（强制 rating:s）；只有「站点=e621 且打开成人开关」才放开 rating 过滤。
//
// 四条硬约束（都是实测踩出来的，改代码前先看）：
//  ① 一切请求走宿主 cap.http.request（Linux 上插件在独立 netns 里，自己 fetch 一律 E_NETWORK）。
//     宿主算 limit = min(maxChars, httpMaxBytes)，所以 maxChars 必须【等于】524288：传小一点会把
//     JSON 尾部静默切掉且 truncated=false，最后表现成「响应不是 JSON」。
//  ② UA 必须自带且非浏览器：e621/e926 明令禁止冒充浏览器（宿主默认 UA 是 Mozilla，沿用它会被封）。
//     这里发 e926-search/<version> (qq-agent plugin; by <username|anonymous>)，并在 query 带 _client；
//     UA 只用 ASCII —— 中文用户名塞进头里就是乱码字节，等于「无法识别的 UA」。
//  ③ 限流 2 req/s（超了回 503/429）：模块级 lastRequestAt 保证相邻请求间隔 ≥ throttleMs（默认 1000），
//     被限流等 2500ms 重试一次，仍失败报 E_RATE_LIMIT 并写清这条规则。
//  ④ 预算：工具 timeoutMs 20000，这里自己给 15000 总预算、单请求 8000、cap 调用 9000 兜底，留 400 余量；
//     超时带已取到的部分 + notes 返回，而不是整个失败。
//  ⑤ 出口被 Cloudflare 挑战（部署在服务器上的常见故障）：403 重试 3 次（1.5s / 4s，各 ±30% 抖动，仍受
//     15 秒预算约束）；仍失败就自动换另一个站再试一次（fallbackSite，默认开，e926↔e621 是同一批 post id）。
//     ⚠️ rating 锁按「配置站点 + 成人开关」判，换站绝不改锁；水位线 wm:v1 / 去重键 seen:v1 一律用配置
//     站点（用实际取数站点会把状态劈成两份，回退一次就让「作者更新」误报全是新的）。
//     每次 403 / 连接失败 / 回退都把「上次出口状态」写进 storage 的 diag:v1，probe 只读快照（零 cap）。
//
// 发图的三条现实：只发群聊（cap.send.file 只认 group:<数字>）；协议端与宿主不同容器时 cap.send.file
// 必失败（ENOENT/realpath/retcode=100）→ 结果里给 forward:{tool:'send_group_file',url,name} 让模型一步
// 转发，并把降级记进 storage（30 分钟起翻倍、封顶 12 小时、成功清零）；cap.media.download 会把 404 页
// 当文件写下来，回执 contentType 不是 image/ 一律当「这张没了」。e926 的图床还会间歇性回 Cloudflare
// 的 403 挑战页（text/html），实测同一 URL 隔 2 秒再取就 200，所以下载也重试一次。
//
// 单文件零依赖：只 import node: 内置，不写文件、不 spawn。被 import 时只导出纯函数（单测用），
// 只有主模块运行才起 stdin NDJSON 循环。
import { Buffer } from 'node:buffer';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

export const PLUGIN_ID = 'e926-search';
export const PLUGIN_VERSION = '1.0.7';

/** ⚠️ 必须等于 plugin.json 的 httpMaxBytes：宿主算的是 min(maxChars, httpMaxBytes)。 */
export const HTTP_MAX_CHARS = 524288;

export const SITES = Object.freeze({ e926: 'e926.net', e621: 'e621.net' });
const IMAGE_QUALITIES = ['sample', 'original', 'preview'];
const SEND_MODES = ['auto', 'forward', 'host'];
const TRANSPORTS = ['auto', 'host', 'direct'];

/** 与 plugin.json settings.groups 的 default 逐项一致（防止两处漂移）。 */
export const DEFAULTS = Object.freeze({
  site: 'e926',
  allowAdult: false,
  fallbackSite: true,
  transport: 'auto',
  sendImages: true,
  imageQuality: 'sample',
  maxImageMb: 8,
  sendMode: 'auto',
  sendHostRetryMinutes: 30,
  defaultCount: 5,
  excludeTags: '',
  throttleMs: 1000,
  username: '',
  apiKey: ''
});

const BUDGET_MS = 15000;        // 单次工具调用总预算
const RESERVE_MS = 400;         // 留给序列化/写回响应的余量
const PER_REQUEST_MS = 8000;    // 单请求上限
const CAP_TIMEOUT_MS = 9000;    // 能力调用兜底（宿主没回话就别挂着）
const STORAGE_TIMEOUT_MS = 2500;
const RETRY_WAIT_MS = 2500;     // 503/429 的退避
const BLOCKED_ATTEMPTS = 3;     // 403（挑战页）：首发 + 2 次重试
const RETRY_ATTEMPTS = 2;       // 502/504/ECONNRESET/429：首发 + 1 次重试
const BLOCKED_RETRY_MS = [1500, 4000]; // 403 两次重试的基准退避（各带 ±30% 抖动）
const FALLBACK_ATTEMPTS = 1;    // 换站只再试一次（预算留给「配置站点都试过」之后）
const DIAG_KEY = 'diag:v1';     // 上次出口状态（probe 只读快照，零 cap）
const RANDOM_DRAWS = 3;         // 随机命中去重时最多重抽几次
const SEEN_CAP = 200;           // 会话内「发过的」环形数组长度
const WM_CONTEXT_POSTS = 3;     // 首次查作者时放几条当上下文
const MAX_TAGS = 12;            // 每个 post 带几个 general 标签
const MIN_IMAGE_BYTES = 1024;   // 小于这个体积一律当错误页（e621 的 404 页只有几十到几百字节）
const MAX_DESC = 300;           // post 详情的简介截断
const MAX_TITLE = 60;           // synthTitle 上限
const SEND_HOST_MAX_MS = 12 * 3600 * 1000;

// UA 与 _client 都从 PLUGIN_VERSION 派生：升版本只改上面那一处
const UA_TAG = PLUGIN_ID + '/' + PLUGIN_VERSION;
const CLIENT_TAG = 'qq-agent-' + UA_TAG;
const GROUP_KEY_RE = /^group:[0-9]+$/;
// 协议端读不到宿主给的绝对路径时 NapCat 报的就是这些词；原始报错带宿主路径，只进日志
const HOST_FILE_BROKEN_RE = /ENOENT|realpath|retcode=100/i;
const HOST_BROKEN_HUMAN = '本部署的协议端读不到宿主给的文件路径，已改成让协议端自己去取图（细节见插件日志）';
const E621_BLOCKED_HUMAN = '这台机器连不上 e621.net；该站在部分网络下直连被重置。可以把站点切回 e926，或在能访问的网络里部署';
// 图床也能被按 HTTP 版本挑战：宿主 ≤0.9.9 的 cap.media.download 只有 HTTP/1.1，拿不到字节就不能 cap.send.file。
// 0.9.10+ 起宿主优先 HTTP/2，所以这里的文案要版本感知 —— 别再把「本机只有 HTTP/1.1」说死。
// 宿主侧永久性失败（写不进媒体目录 / 磁盘满 / 没有发送队列）：部署配置问题，重试与转发都没意义
const HOST_FS_ERROR_RE = /EACCES|EPERM|ENOSPC|EDQUOT|permission denied|no space left|read-only file system/i;
const HOST_FS_NOTE = '宿主写不进自己的媒体目录（EACCES / ENOSPC 一类）：这是部署配置问题，不是网络或站点问题，重试无用。请让管理员把 data/plugin-data/' + PLUGIN_ID + '/media 的属主与权限设成宿主进程用户（正常是 drwx------ <宿主用户>:<宿主用户>）。';
const HOST_FS_ADVISE = '这张图别让用户转发、也别重试：宿主侧的媒体目录不可写（或磁盘已满），是部署配置问题。请管理员先修好 data/plugin-data/' + PLUGIN_ID + '/media 的属主与权限。';
const NO_SENDER_NOTE = '宿主没有可用的发送队列（E_NO_SENDER），插件暂时发不了文件：这是宿主侧问题，不是图片或站点的问题。';
const NO_SENDER_ADVISE = '这张图别让用户转发、也别重试：宿主没有发送队列（E_NO_SENDER），让管理员检查协议端是否在线、是否已连上宿主。';
// cap.send.file 的超时不是失败：宿主自己允许 120 秒（sender.groupFile → onebot.call(..., 120000)），
// 我们只等到 15 秒预算里的 ~12 秒。此时**绝不能给 forward** —— 宿主那边可能还在传，再转发就是发两张。
const SEND_TIMEOUT_RE = /超时|timeout|没有回话|E_TIMEOUT/i;
const SEND_TIMEOUT_NOTE = '已经交给宿主发送，但 12 秒内没等到回执（QQ 上传可能更慢，宿主自己允许 120 秒）。这张图可能稍后仍然会到，不要再触发转发，否则会发两次。';
const SEND_TIMEOUT_ADVISE = '这张图别再转发、也别重试：宿主那边可能还在传（它自己允许 120 秒），再发一次就会重复。告诉用户图可能要稍等一下；如果一直没到，让用户再问一次。';
const FORWARD_RISK_NOTE = '转发＝让协议端自己去下载；协议端只支持 HTTP/1.1 时，遇到 Cloudflare 挑战会 403。能下载就别用 forward。';
const FORWARD_AUTO_HINT = '这次数据是宿主（或插件自有）HTTP/2 通道取到的，说明本机下载是通的：建议把「发图方式」改回 auto，让插件直接发图，别让协议端去下载。';
const IMAGE_CHALLENGE_NOTE = '图床被 Cloudflare 挑战（宿主拿到的是 403 / HTML 挑战页，不是图片字节）：宿主 0.9.10 起的 cap.media.download 已优先走 HTTP/2，还能碰到这条通常说明宿主更老、或这个部署的请求被限制在 HTTP/1.1；已改让协议端自己去取（见 image.forward）。';
const IMAGE_CHALLENGE_HINT = '建议把「发图方式」设成 forward（只转发）；把宿主升级到 0.9.10+ 后可以改回 auto（那时图床走 HTTP/2，不会再这么被挡）。';

// ───────────────────────── 通用小工具 ─────────────────────────

const isPlainObject = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v);
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, Math.max(0, Math.floor(ms))));
const num = (value) => {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.trunc(n)) : 0;
};

function asArray(v) {
  if (Array.isArray(v)) return v;
  if (v === null || v === undefined || v === '') return [];
  return [v];
}

function firstString(...vals) {
  for (const v of vals) {
    if (typeof v === 'string' && v.trim()) return v.trim();
    if (typeof v === 'number' && Number.isFinite(v)) return String(v);
  }
  return '';
}

function clampInt(value, fallback, lo, hi) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(hi, Math.max(lo, Math.trunc(n)));
}

/** 模型有时把 true 写成字符串 "true"/"false"，别让 "false" 变成 true。 */
function toBool(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'boolean') return value;
  const s = String(value).trim().toLowerCase();
  if (['true', '1', 'yes', 'on', '是', '开'].includes(s)) return true;
  if (['false', '0', 'no', 'off', '否', '关'].includes(s)) return false;
  return fallback;
}

/** 去掉孤立代理项（半个 emoji）—— 孤立代理项会让整个模型请求 400。 */
function stripLoneSurrogates(value) {
  const s = String(value ?? '');
  let out = '';
  for (let i = 0; i < s.length; i++) {
    const code = s.charCodeAt(i);
    if (code >= 0xd800 && code <= 0xdbff) {
      const next = s.charCodeAt(i + 1);
      if (next >= 0xdc00 && next <= 0xdfff) { out += s[i] + s[i + 1]; i += 1; }
      continue;
    }
    if (code >= 0xdc00 && code <= 0xdfff) continue;
    out += s[i];
  }
  return out;
}

/** 按 UTF-16 码元安全截断（不留半个 emoji）。 */
function safeSlice(value, max) {
  const s = String(value ?? '');
  const limit = Math.max(0, Math.floor(Number(max) || 0));
  return stripLoneSurrogates(limit >= s.length ? s : s.slice(0, limit));
}

/** 按码点截断（emoji 不会被切成两个坏码元）。 */
function sliceByCodePoints(value, max) {
  const s = String(value ?? '');
  const limit = Math.max(0, Math.floor(Number(max) || 0));
  if (limit <= 0) return '';
  return stripLoneSurrogates(s.length <= limit ? s : Array.from(s).slice(0, limit).join(''));
}

/** 去重 + 丢空串（标签数组里这两种占位都很常见）。 */
function uniqClean(list) {
  const out = [];
  const seen = new Set();
  for (const raw of asArray(list)) {
    const s = firstString(raw);
    if (!s) continue;
    const key = s.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(s);
  }
  return out;
}

const mbText = (bytes) => (Math.max(0, Number(bytes) || 0) / 1048576).toFixed(1);

// ───────────────────────── 纯函数（单测直接 import 这些）─────────────────────────

/**
 * 最终 tags 查询串：调用方给的标签 + 排除项（自动加 - 前缀）+ 强制 rating:s。
 * rating 锁：只有 site=e621 且 allowAdult=true 才放开；其余一律追加 rating:s。
 * 调用方塞进来的 rating:* 一律丢掉 —— 这条约束归插件管，不信任模型。
 */
export function buildSearchTags({ tags = '', site = 'e926', allowAdult = false, excludeTags = '' } = {}) {
  const locked = !(String(site || '').toLowerCase() === 'e621' && allowAdult === true);
  const out = [];
  const seen = new Set();
  const push = (token) => {
    const t = String(token || '').trim();
    if (!t) return;
    const key = t.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    out.push(t);
  };
  for (const raw of String(tags ?? '').split(/[\s,]+/)) {
    const t = raw.trim();
    if (!t) continue;
    if (/^-?rating:/i.test(t)) continue;
    push(t);
  }
  for (const raw of String(excludeTags ?? '').split(/[\s,]+/)) {
    const t = raw.trim().replace(/^[-\s]+/, '');
    if (!t) continue;
    push('-' + t);
  }
  if (locked) push('rating:s');
  return out.join(' ');
}

/**
 * 选一张可发的图：先按设置里的档位，再按 sample → original → preview 依次回退。
 * sample.has=false（站点不给采样图）就必须换档，别发一个不存在的 URL。
 * 返回 { url, bytes, kind } 或 null；bytes 未知（sample/preview 没体积字段）时为 0。
 */
export function pickImageVariant(post, quality = 'sample') {
  const p = isPlainObject(post) ? post : {};
  const wanted = IMAGE_QUALITIES.includes(String(quality || '')) ? String(quality) : DEFAULTS.imageQuality;
  const order = [wanted, ...IMAGE_QUALITIES.filter((x) => x !== wanted)];
  for (const kind of order) {
    if (kind === 'sample') {
      const sample = p.sample;
      if (isPlainObject(sample) && sample.has === true && firstString(sample.url)) {
        return { url: firstString(sample.url), bytes: num(sample.size), kind };
      }
      continue;
    }
    if (kind === 'original') {
      const url = firstString(p.file?.url);
      if (url) return { url, bytes: num(p.file?.size), kind };
      continue;
    }
    const url = firstString(p.preview?.url);
    if (url) return { url, bytes: num(p.preview?.size), kind };
  }
  return null;
}

// 认不出来就返回空串，**不是** 's'：门控点只放行严格 === 's'，未知值必须当「不能看」，
// 否则没有 rating 的条目会被当成全年龄放过去（fail-open 让 rating 锁形同虚设）。
const ratingOf = (post) => {
  const raw = String(post?.rating ?? '').trim().toLowerCase();
  return raw === 's' || raw === 'q' || raw === 'e' ? raw : '';
};
const siteKeyOf = (site) => (SITES[String(site || '').toLowerCase()] ? String(site).toLowerCase() : 'e926');

/**
 * 一条 post → 契约里的紧凑结构。image 恒为 null：投递结果由工具层回填
 * （列表本身不发图，要发图走 random / post）。键名是契约的一部分，别改。
 */
export function compactPost(post, options = {}) {
  const p = isPlainObject(post) ? post : {};
  const opts = isPlainObject(options) ? options : {};
  const site = siteKeyOf(opts.site);
  const id = num(p.id);
  const tags = isPlainObject(p.tags) ? p.tags : {};
  const file = isPlainObject(p.file) ? p.file : {};
  return {
    id,
    pageUrl: id ? 'https://' + SITES[site] + '/posts/' + id : '',
    title: synthTitle(p),
    artists: uniqClean(tags.artist).slice(0, 8),
    tags: uniqClean(tags.general).slice(0, MAX_TAGS),
    rating: ratingOf(p),
    score: num(p.score?.total ?? p.score),
    size: { w: num(file.width), h: num(file.height), bytes: num(file.size) },
    createdAt: String(p.created_at ?? ''),
    image: null
  };
}

const BBCODE_RE = /\[\/?\s*(?:b|i|u|s|sup|sub|spoiler|quote|code|section|color|size|url|img|list|\*|table|tr|td|th|hr|br|indent|columns?|center|left|right)(?:\s*=[^\]\n]{0,140})?\]/gi;
const HTML_TAG_RE = /<\/?[a-z][^>\n]{0,200}>/gi;
const NAMED_ENTITIES = Object.freeze({
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', ndash: '\u2013',
  mdash: '\u2014', hellip: '\u2026', lsquo: '\u2018', rsquo: '\u2019', ldquo: '\u201c', rdquo: '\u201d'
});

/** 去 BBCode / HTML 标签、解实体，**保留换行**（synthTitle 要拿首行）。 */
function markupToPlain(value) {
  let s = String(value ?? '');
  if (!s) return '';
  s = s.replace(/\[br\s*\/?\]/gi, '\n');
  s = s.replace(BBCODE_RE, ' ');
  s = s.replace(HTML_TAG_RE, ' ');
  s = s.replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (match, body) => {
    const key = String(body).toLowerCase();
    if (key[0] === '#') {
      const code = key[1] === 'x' ? parseInt(key.slice(2), 16) : parseInt(key.slice(1), 10);
      if (Number.isFinite(code) && code > 0 && code <= 0x10ffff) {
        try { return String.fromCodePoint(code); } catch { return ' '; }
      }
      return ' ';
    }
    return Object.prototype.hasOwnProperty.call(NAMED_ENTITIES, key) ? NAMED_ENTITIES[key] : match;
  });
  return s.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, ' ');
}

/**
 * 去过标记的纯文本：压空白 + 按码点截断。
 * e926 的 description 是 BBCode 与 HTML 混排，可能几千字，直接进提示词会爆掉。
 */
export function stripMarkup(text, max = MAX_DESC) {
  const flat = markupToPlain(text).replace(/\s+/g, ' ').trim();
  return sliceByCodePoints(flat, clampInt(max, MAX_DESC, 0, 100000));
}

/**
 * 可读标题（≤60 字）。e926 的 post **没有作品名字段**，所以这个标题是插件拼的：
 * 简介首行 → 否则 character / copyright → 否则前 3 个 general 标签 → 否则 #id。
 * 转述时不能当成站方官方标题。
 */
export function synthTitle(post) {
  const p = isPlainObject(post) ? post : {};
  const tags = isPlainObject(p.tags) ? p.tags : {};
  const firstLine = markupToPlain(p.description)
    .split('\n')
    .map((line) => line.replace(/\s+/g, ' ').trim())
    .find(Boolean);
  if (firstLine) return sliceByCodePoints(firstLine, MAX_TITLE);
  const head = [];
  const character = uniqClean(tags.character);
  const copyright = uniqClean(tags.copyright);
  if (character.length) head.push(character[0]);
  if (copyright.length && copyright[0] !== character[0]) head.push(copyright[0]);
  if (head.length) return sliceByCodePoints(head.join(' \u00b7 '), MAX_TITLE);
  const general = uniqClean(tags.general);
  if (general.length) return sliceByCodePoints(general.slice(0, 3).join(' '), MAX_TITLE);
  const id = num(p.id);
  return id ? '#' + id : '无标题作品';
}

/**
 * 作品号：6806819 / https://e926.net/posts/6806819 / …/posts/6806819.json?x=1 / "post 6806819"。
 * 认不出返回 null（上层报 E_ARGS），绝不猜一个数字去联网。
 */
export function parsePostId(input) {
  const s = String(input ?? '').trim();
  if (!s) return null;
  const pick = (digits) => {
    const n = Number(String(digits || '').replace(/^0+(?=\d)/, ''));
    return Number.isSafeInteger(n) && n > 0 ? n : null;
  };
  const inUrl = s.match(/\/posts?\/(\d{1,12})(?!\d)/i);
  if (inUrl) return pick(inUrl[1]);
  if (/^\d{1,12}$/.test(s)) return pick(s);
  const loose = s.match(/(?<!\d)(\d{1,12})(?!\d)/);
  if (loose) return pick(loose[1]);
  return null;
}

/** 环形数组：去重后追加，保留尾部 cap 个（会话内「发过的」清单）。 */
export function ringUpdate(list, id, cap = SEEN_CAP) {
  const limit = Math.max(1, Math.floor(Number(cap) || SEEN_CAP));
  const out = [];
  const seen = new Set();
  for (const raw of asArray(list)) {
    const n = Number(raw);
    if (!Number.isSafeInteger(n) || n <= 0 || seen.has(n)) continue;
    seen.add(n);
    out.push(n);
  }
  const target = Number(id);
  if (Number.isSafeInteger(target) && target > 0) {
    const at = out.indexOf(target);
    if (at >= 0) out.splice(at, 1);
    out.push(target);
  }
  return out.slice(Math.max(0, out.length - limit));
}

/** 宽松解析：不是 JSON（HTML 错误页 / 被截断）就返回 null，绝不抛。 */
export function parseJsonLoose(text) {
  let raw = String(text ?? '');
  if (!raw) return null;
  if (raw.charCodeAt(0) === 0xfeff) raw = raw.slice(1);
  const trimmed = raw.trim();
  if (!trimmed) return null;
  try {
    const value = JSON.parse(trimmed);
    return isPlainObject(value) ? value : null;
  } catch {
    return null;
  }
}

/**
 * 描述性 UA。只用 ASCII：中文用户名进去就是乱码字节，等于「无法识别的 UA」。
 * 版本段按契约固定成 1.0（不是 PLUGIN_VERSION 的 1.0.0）—— 站点侧看到的是稳定标识。
 */
export function userAgentFor(username) {
  const ascii = String(username ?? '').replace(/[^\x20-\x7e]/g, '').replace(/[()\\"]/g, '').trim();
  const who = sliceByCodePoints(ascii, 40) || 'anonymous';
  return UA_TAG + ' (qq-agent plugin; by ' + who + ')';
}

/** 作者名 → e621 标签形式（小写、空格换下划线、去掉 artist: 前缀）。 */
export function normalizeArtistTag(input) {
  return String(input ?? '')
    .trim()
    .toLowerCase()
    .replace(/^artist:/, '')
    .replace(/[\s]+/g, '_')
    .replace(/[^a-z0-9_.~-]/g, '')
    .replace(/^_+|_+$/g, '');
}

/** 会话键：从 callTool 的 context 里取 chatKey（宿主的写法是 group:<群号> / private:<QQ号>）。 */
export function sessionKeyOf(chatKey) {
  const raw = String(chatKey ?? '').trim();
  if (!raw) return 'console';
  return safeSlice(raw.replace(/[^A-Za-z0-9:_-]/g, '_'), 64) || 'console';
}

// ───────────────────────── 错误与上下文 ─────────────────────────

function fail(code, message) {
  return { ok: false, error: { code, message: safeSlice(message, 400) } };
}

/** 没注入宿主能力时的兜底：明确报错，别假装查到了什么。 */
async function missingCap() {
  throw Object.assign(new Error('这个上下文没有宿主能力（单测请注入 cap）'), { code: 'E_CAP' });
}

export function makeContext(settings = {}, options = {}) {
  const merged = { ...DEFAULTS };
  for (const [k, v] of Object.entries(isPlainObject(settings) ? settings : {})) {
    if (v !== undefined && v !== null) merged[k] = v;
  }
  const site = siteKeyOf(merged.site);
  const allowAdult = toBool(merged.allowAdult, DEFAULTS.allowAdult);
  const quality = String(merged.imageQuality ?? '').trim().toLowerCase();
  const mode = String(merged.sendMode ?? '').trim().toLowerCase();
  const context = isPlainObject(options.context) ? options.context : {};
  const chatKey = String(context.chatKey ?? '').trim();
  return {
    settings: merged,
    site,
    host: SITES[site],
    // 换站目标：配置站点的「另一个」。⚠️ 只是请求目标，不参与 rating 锁与 storage 键的判定
    altSite: site === 'e926' ? 'e621' : 'e926',
    fallbackSite: toBool(merged.fallbackSite, DEFAULTS.fallbackSite),
    // 传输三态：auto（先宿主，403 挑战再用自有 HTTP/2）/ host（只走宿主）/ direct（只走自有通道）
    transport: TRANSPORTS.includes(String(merged.transport ?? '').trim().toLowerCase())
      ? String(merged.transport).trim().toLowerCase()
      : DEFAULTS.transport,
    allowAdult,
    // rating 锁：只有「站点 e621 + 成人开关」都满足才放开（回退到另一个站也沿用这个原判）
    ratingLocked: !(site === 'e621' && allowAdult === true),
    sendImages: toBool(merged.sendImages, DEFAULTS.sendImages),
    imageQuality: IMAGE_QUALITIES.includes(quality) ? quality : DEFAULTS.imageQuality,
    maxImageMb: clampInt(merged.maxImageMb, DEFAULTS.maxImageMb, 1, 80),
    sendMode: SEND_MODES.includes(mode) ? mode : DEFAULTS.sendMode,
    sendHostRetryMinutes: clampInt(merged.sendHostRetryMinutes, DEFAULTS.sendHostRetryMinutes, 1, 720),
    defaultCount: clampInt(merged.defaultCount, DEFAULTS.defaultCount, 1, 10),
    excludeTags: String(merged.excludeTags ?? ''),
    throttleMs: clampInt(merged.throttleMs, DEFAULTS.throttleMs, 500, 3000),
    username: String(merged.username ?? '').trim(),
    // apiKey 正常来自宿主凭据库（init 时经 cap.secrets.get 读一次）；merged.apiKey 只是兜底，
    // 让单测/假宿主能直接注入 —— 真宿主永远不会把 secret 字段放进 settings。
    apiKey: firstString(options.apiKey) || String(merged.apiKey ?? '').trim(),
    userAgent: userAgentFor(merged.username),
    chatKey,
    isGroup: GROUP_KEY_RE.test(chatKey),
    sessionKey: sessionKeyOf(chatKey),
    cap: typeof options.cap === 'function' ? options.cap : missingCap,
    // 自有通道的接缝：单测注入假 channel；生产用 directExchangeReal（node:http2）
    directExchange: typeof options.directExchange === 'function' ? options.directExchange : directExchangeReal,
    directSessions: new Map(),  // host → http2 session（一次工具调用内复用，见 runTool 的 finally）
    directTriedSites: new Set(), // 一次工具调用里每个站只试一次自有通道（别把预算烧在重复尝试上）
    context,
    deadline: Number(options.deadline) || 0
  };
}

const remaining = (ctx) => Math.max(0, (ctx.deadline || 0) - Date.now() - RESERVE_MS);

/** 认证只对私有数据必需；错的凭据在只读端点上会被站点静默忽略。 */
function authHeaders(ctx) {
  if (!ctx.apiKey || !ctx.username) return {};
  const token = Buffer.from(ctx.username + ':' + ctx.apiKey, 'utf8').toString('base64');
  return { authorization: 'Basic ' + token };
}

// ───────────────────────── 能力调用（storage / log）─────────────────────────
// storage 失败一律当成「没记住」，绝不阻断查询。

async function storageGet(ctx, key) {
  try {
    const result = await ctx.cap('cap.storage.get', { key }, STORAGE_TIMEOUT_MS);
    return isPlainObject(result) ? result.value : null;
  } catch {
    return null;
  }
}

async function storageSet(ctx, key, value) {
  try {
    await ctx.cap('cap.storage.set', { key, value }, STORAGE_TIMEOUT_MS);
    return true;
  } catch {
    return false;
  }
}

/** 日志失败不该影响主流程；原始报错（带宿主路径）只进日志，不进结果。 */
async function logWarn(ctx, message) {
  try {
    await ctx.cap('cap.log.write', { level: 'warn', message: safeSlice(message, 400) }, STORAGE_TIMEOUT_MS);
  } catch { /* 记不下来也照常返回 */ }
}

// ───────────────────────── 节流 + HTTP（只走宿主）─────────────────────────

/** 模块级：保证相邻两次请求间隔 ≥ throttleMs（跨工具调用也算）。 */
let lastRequestAt = 0;

async function throttleGate(ctx, extraMs = 0) {
  const gap = clampInt(ctx.throttleMs, DEFAULTS.throttleMs, 500, 3000);
  // ⚠️ 先原子占位再等：以前是先算 wait、await 之后再写 lastRequestAt，两个并发请求会读到同一个
  // 旧值、算出同一个发送时刻（等于节流失效）。现在 at 一算出来立刻写进 lastRequestAt，各自占位。
  const prev = lastRequestAt;
  const at = Math.max(prev + gap, Date.now() + (Number(extraMs) || 0));
  lastRequestAt = at;
  const wait = Math.max(0, at - Date.now());
  if (wait > 0) {
    // ⚠️ 绝不截短睡眠：sleep(min(wait, remaining)) 会让相邻两次请求的实际间隔 < throttleMs，
    // 直接违反「模块级 ≥ throttleMs」这条契约。
    // 预算不够就干脆不发这次请求，把判定交回调用方（带已取到的部分返回），并把占位还回去。
    if (remaining(ctx) < wait) { lastRequestAt = prev; return false; }
    await sleep(wait);
  }
  return true;
}

/** 路径 + 查询串（含 _client）。宿主通道与自有通道共用同一份拼装，避免两条路发出不同请求。 */
function apiPath(pathname, query) {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(isPlainObject(query) ? query : {})) {
    if (value === undefined || value === null || value === '') continue;
    params.set(key, String(value));
  }
  params.set('_client', CLIENT_TAG);
  return pathname + '?' + params.toString();
}

function apiUrl(site, pathname, query) {
  return 'https://' + SITES[siteKeyOf(site)] + apiPath(pathname, query);
}

// ───────────────── 403 响应体 → 挑战页 / 硬封页 / 认不出来（出口诊断）─────────────────

const CF_CHALLENGE_MARKS = ['just a moment', 'cf-chl', 'enable javascript and cookies', 'challenge-platform'];
const CF_HARD_BLOCK_MARKS = ['you have been blocked'];

/** 响应体去标签 + 压空白，截前 max 字。只给人看，绝不参与判定。 */
export function bodyExcerpt(body, max = 120) {
  const plain = String(body ?? '')
    .replace(/<!doctype[^>]*>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[!a-z\/][^>]{0,2000}>/gi, ' ')  // 错误页里的 meta/属性很长，这里比 HTML_TAG_RE 更宽松
    .replace(/&nbsp;/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return sliceByCodePoints(plain, Math.max(1, num(max) || 120));
}

/**
 * 403 的分类。标记看**原始**体（cf-chl / challenge-platform 都在属性值里，去标签就没了），
 * Ray ID 看去标签的全文（Cloudflare 把它包在 span 里）。kind 只有 challenge/blocked/none。
 */
export function classifyBlocked(body) {
  const raw = String(body ?? '');
  const lower = raw.toLowerCase();
  const plain = bodyExcerpt(raw, 4000);
  const rayMatch = plain.match(/ray\s*id\s*[:#]?\s*([0-9a-z]{8,40})/i);
  const excerpt = bodyExcerpt(raw, 120);
  const rayId = rayMatch ? rayMatch[1] : '';
  if (CF_CHALLENGE_MARKS.some((mark) => lower.includes(mark))) {
    return { kind: 'challenge', label: 'Cloudflare 挑战页（JS 挑战）', excerpt, rayId };
  }
  if (CF_HARD_BLOCK_MARKS.some((mark) => lower.includes(mark))) {
    return { kind: 'blocked', label: 'Cloudflare 硬封页（整段 IP/ASN 被封）', excerpt, rayId };
  }
  return { kind: 'none', label: '403，但响应里没有可识别的 Cloudflare 标记', excerpt, rayId };
}

/** 403 第 n 次重试前的等待：基准 1500 / 4000，各带 ±30% 抖动。 */
function blockedBackoffMs(retryIndex) {
  const base = BLOCKED_RETRY_MS[Math.min(Math.max(0, num(retryIndex) - 1), BLOCKED_RETRY_MS.length - 1)];
  return Math.round(base * (0.7 + Math.random() * 0.6));
}

/** 某类失败总共允许几次尝试：403 三次，其余（502/504/ECONNRESET/429）两次。 */
function attemptsFor(kind) {
  return String(kind) === 'blocked' ? BLOCKED_ATTEMPTS : RETRY_ATTEMPTS;
}

/** 第 attempt+1 次尝试前的额外等待。只叠加在 throttleMs 之上，绝不压缩节流间隔。 */
function retryDelayFor(got, attempt) {
  if (!got || !got.retry) return 0;
  if (String(got.kind) === 'blocked') return blockedBackoffMs(attempt);
  return Math.max(0, Number(got.retryWait) || 0);
}

/** 状态码 + 响应体 → 统一结果（宿主通道与自有通道共用，两条路的判定不许有第二套）。 */
function classifyResponse(status, body, ms, opts = {}) {
  // 截断的 JSON 必然解不开；先认出来，别让它变成「不是 JSON」
  if (opts.truncated === true) {
    return { ok: false, ms, status, kind: 'truncated', truncated: true, message: '响应被截断（超过 httpMaxBytes=' + HTTP_MAX_CHARS + '）' };
  }
  if (status >= 200 && status < 300) {
    const data = parseJsonLoose(body);
    if (!data) {
      const head = body.replace(/\s+/g, ' ').trim().slice(0, 80);
      return { ok: false, ms, status, kind: 'parse', message: '响应不是 JSON（开头：' + head + '）' };
    }
    return { ok: true, ms, status, data };
  }
  if (status === 401) return { ok: false, ms, status, kind: 'auth', message: 'HTTP 401' };
  // 403 大多是 Cloudflare 的 "Just a moment..." 挑战页：实测同一 URL 隔 1-2 秒再打就 200，
  // 所以给两次带抖动的重试（1.5s / 4s）；响应体一起带回去，报错时才能分清「挑战页」和「硬封页」。
  if (status === 403) {
    return { ok: false, ms, status, kind: 'blocked', retry: true, blocked: classifyBlocked(body), body: safeSlice(body, 600), message: 'HTTP 403' };
  }
  if (status === 404) return { ok: false, ms, status, kind: 'notfound', message: 'HTTP 404' };
  if (status === 410) return { ok: false, ms, status, kind: 'paging', message: 'HTTP 410' };
  if (status === 429 || status === 503) {
    return { ok: false, ms, status, kind: 'rate', retry: true, retryWait: RETRY_WAIT_MS, message: 'HTTP ' + status };
  }
  if (status === 502 || status === 504) return { ok: false, ms, status, kind: 'server', retry: true, message: 'HTTP ' + status };
  return { ok: false, ms, status, kind: 'server', message: 'HTTP ' + (status || '?') };
}

/** 宿主通道打一次。不抛异常，把「为什么没成」分类带回去：kind / status / retry / retryWait。 */
async function requestOnce(ctx, url) {
  const startedAt = Date.now();
  // 预算真的用完就不发这次请求（remaining 为 0 时，旧写法的 "remaining(ctx) || PER_REQUEST_MS"
  // 会被假地板补成 8 秒，等于预算形同虚设）。否则超时取 min(上限, 剩余)。
  const left = remaining(ctx);
  if (left < 300) return { ok: false, ms: 0, status: 0, kind: 'budget', message: '15 秒预算已用完，这次请求没有发出' };
  let result;
  try {
    result = await ctx.cap('cap.http.request', {
      url,
      method: 'GET',
      headers: { 'user-agent': ctx.userAgent, accept: 'application/json', ...authHeaders(ctx) },
      maxChars: HTTP_MAX_CHARS,
      decompress: true
    }, Math.min(PER_REQUEST_MS, CAP_TIMEOUT_MS, left));
  } catch (error) {
    const code = String(error?.code || '');
    const message = String(error?.message || error);
    const ms = Date.now() - startedAt;
    if (code === 'E_DOMAIN') return { ok: false, ms, status: 0, kind: 'config', message };
    if (code === 'E_CAP' || /没有宿主能力/.test(message)) return { ok: false, ms, status: 0, kind: 'cap', message };
    if (code === 'E_CAP_TIMEOUT') return { ok: false, ms, status: 0, kind: 'timeout', message: '请求超时（' + ms + 'ms）' };
    const reset = /ECONNRESET|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|socket hang up|other side closed/i.test(code + ' ' + message);
    return { ok: false, ms, status: 0, code, kind: reset ? 'reset' : 'network', retry: reset, message };
  }
  const ms = Date.now() - startedAt;
  return classifyResponse(Number(result?.status) || 0, String(result?.body ?? ''), ms, { truncated: result?.truncated === true });
}

// ─────────────── 插件自有 HTTP/2 通道（宿主通道被 Cloudflare 按 HTTP 版本挑战时的兜底）───────────────
//
// 为什么需要它：宿主 ≤0.9.9 的 src/llm/safe-fetch.js 走 node:https = 只有 HTTP/1.1，而某些机房出口的 Cloudflare
// 只放行 HTTP/2（实测：同一 URL H1→403 挑战页，H2→200）。这条通道用 node:http2 直接连，插件进程本身有网。
// ⚠️ 宿主 0.9.10+ 的 safe-fetch 已按 ALPN 优先 HTTP/2（服务端不支持才回落 H1），那种版本上 auto 会一直走宿主通道，
//    这条自有通道只是老宿主的兜底 —— 别因为「现在没用到」就删掉，0.9.5–0.9.9 还在 minVersion 范围内。
//
// ⚠️ 安全边界（改代码前先看，别把它改成 SSRF 跳板）：
//   · 只允许 SITES 里的两个 API 域名（e926.net / e621.net），**不接受任意 URL**、不代理、不跟随重定向；
//   · 只用 node: 内置（http2），不读文件、不写文件、不 spawn；
//   · 会话只在一次工具调用内复用，调用结束一律 destroy（runTool 的 finally）。

export const DIRECT_HOSTS = Object.freeze(['e926.net', 'e621.net']);
const DIRECT_CONNECT_MS = 10000;  // 连接（与流）各自的上限，两段都再按 15 秒预算夹一次
const DIRECT_NOTE = '本次走的是插件自有 HTTP/2 通道（宿主通道被 Cloudflare 挑战页拦下）。';
const DIRECT_NOTE_FORCED = '本次走的是插件自有 HTTP/2 通道（transport=direct，没走宿主通道）。';
const directNoteFor = (ctx) => (ctx.transport === 'direct' ? DIRECT_NOTE_FORCED : DIRECT_NOTE);

const isDirectHost = (host) => DIRECT_HOSTS.includes(String(host || '').toLowerCase());

/** 真通道：http2.connect → 一个 GET 流。抛带 code 的错，让上层分类（不在这里下结论）。 */
async function directExchangeReal(ctx, host, requestPath, headers, timeoutMs) {
  const http2 = await import('node:http2');
  // 连接与流各留一段：先给连接留 2 秒余量，握手完再按剩余预算夹流的上限（总时长不越 15 秒预算）
  const limit = Math.max(1000, Math.min(num(timeoutMs) || DIRECT_CONNECT_MS, Math.max(2000, remaining(ctx) - 2000)));
  let session = ctx.directSessions.get(host);
  if (!session || session.destroyed || session.closed) {
    session = http2.connect('https://' + host);
    session.on('error', () => { try { session.destroy(); } catch { /* ignore */ } });
    session.on('goaway', () => { try { session.destroy(); } catch { /* ignore */ } });
    ctx.directSessions.set(host, session);
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => { reject(Object.assign(new Error('自有通道连接超时（' + limit + 'ms）'), { code: 'E_DIRECT_TIMEOUT' })); }, limit);
      const onConnect = () => { clearTimeout(timer); resolve(); };
      const onError = (error) => { clearTimeout(timer); ctx.directSessions.delete(host); reject(error); };
      session.once('connect', onConnect);
      session.once('error', onError);
      session.once('close', () => { ctx.directSessions.delete(host); onError(Object.assign(new Error('自有通道连接被关闭'), { code: 'E_DIRECT_CLOSED' })); });
    });
  }
  // 同上：预算不足就别发（本函数契约是「抛带 code 的错让上层分类」，所以这里只能抛）
  const left = remaining(ctx);
  if (left < 300) throw Object.assign(new Error('15 秒预算已用完（自有通道这次没有发请求）'), { code: 'E_DIRECT_TIMEOUT' });
  const streamLimit = Math.min(DIRECT_CONNECT_MS, left);
  return await new Promise((resolve, reject) => {
    let settled = false;
    const finish = (fn, value) => { if (settled) return; settled = true; clearTimeout(timer); fn(value); };
    const timer = setTimeout(() => {
      try { req.close(http2.constants.NGHTTP2_CANCEL); } catch { /* ignore */ }
      finish(reject, Object.assign(new Error('自有通道请求超时（' + streamLimit + 'ms）'), { code: 'E_DIRECT_TIMEOUT' }));
    }, streamLimit);
    const req = session.request({ ':method': 'GET', ':path': requestPath, ...headers }, { endStream: true });
    let status = 0;
    const chunks = [];
    let total = 0;
    req.on('response', (responseHeaders) => { status = Number(responseHeaders[':status']) || 0; });
    req.on('data', (chunk) => {
      if (total > HTTP_MAX_CHARS) return; // 已经超了：继续读完丢掉，最后按 truncated 报
      chunks.push(chunk);
      total += chunk.length;
    });
    req.on('end', () => {
      const truncated = total > HTTP_MAX_CHARS;
      finish(resolve, { status, body: truncated ? Buffer.concat(chunks).subarray(0, HTTP_MAX_CHARS).toString('utf8') : Buffer.concat(chunks).toString('utf8'), truncated });
    });
    req.on('error', (error) => finish(reject, error));
    req.setTimeout(streamLimit, () => { try { req.close(http2.constants.NGHTTP2_CANCEL); } catch { /* ignore */ } finish(reject, Object.assign(new Error('自有通道请求超时（' + streamLimit + 'ms）'), { code: 'E_DIRECT_TIMEOUT' })); });
  });
}

/** 自有通道 GET 一次。域名硬白名单 + 复用会话（ctx.directSessions）+ 统一分类。 */
async function directRequest(ctx, site, pathname, query) {
  const host = SITES[siteKeyOf(site)];
  if (!isDirectHost(host)) {
    return { ok: false, kind: 'direct', status: 0, message: '自有通道只允许 ' + DIRECT_HOSTS.join(' / ') + '，拒绝 ' + host };
  }
  const requestPath = apiPath(pathname, query);
  const left = remaining(ctx);
  if (left < 300) return { ok: false, kind: 'budget', status: 0, message: '15 秒预算已用完，这次没发自有通道请求' };
  const timeoutMs = Math.min(DIRECT_CONNECT_MS, left);
  const headers = { 'user-agent': ctx.userAgent, accept: 'application/json', ...authHeaders(ctx) };
  const startedAt = Date.now();
  let response;
  try {
    response = await ctx.directExchange(ctx, host, requestPath, headers, timeoutMs);
  } catch (error) {
    const code = String(error?.code || '');
    const message = String(error?.message || error);
    const negotiation = code === 'E_DIRECT_NEGO' || /ERR_HTTP2|NGHTTP2|Protocol error|ALPN|h2/i.test(code + ' ' + message);
    return {
      ok: false,
      kind: 'direct',
      status: 0,
      negotiation,
      message: '插件自有通道连不上 ' + host + '（' + safeSlice(message, 80) + '）'
    };
  }
  return classifyResponse(num(response?.status), String(response?.body ?? ''), Date.now() - startedAt, { truncated: response?.truncated === true });
}

/** 一次尝试 = 按 transport 选通道。auto 先宿主，宿主被挑战/回 HTML 再用自有通道重试同一请求一次。 */
async function attemptOnce(ctx, site, pathname, query) {
  const url = apiUrl(site, pathname, query);
  const transport = ctx.transport;
  if (transport === 'direct') {
    const direct = await directRequest(ctx, site, pathname, query);
    // h2 协商失败（对端不支持 / 中间设备掐 ALPN）→ 回落宿主通道，并说明
    if (!direct.ok && direct.negotiation) {
      const hosted = await requestOnce(ctx, url);
      return { ...hosted, notes: [(hosted.ok ? '自有通道 HTTP/2 协商失败，' : '') + '这次改走宿主通道。'] };
    }
    // ⚠️ 走了自有通道就必须让人知道（用户以为一切照旧就错了）
    return direct.ok ? { ...direct, usedDirect: true, notes: [directNoteFor(ctx)] } : direct;
  }
  const hosted = await requestOnce(ctx, url);
  if (transport !== 'auto') return hosted;
  if (!(hosted.kind === 'blocked' || hosted.kind === 'parse')) return hosted;
  if (ctx.directTriedSites.has(site)) return hosted;
  ctx.directTriedSites.add(site);
  // 自有通道也是真请求，同样要过模块级节流（站点硬限流 2 req/s）；预算不够就不发
  const ready = await throttleGate(ctx, 0);
  if (!ready) return { ...hosted, directFailed: { kind: 'budget', message: '预算不够，没试自有通道' } };
  const direct = await directRequest(ctx, site, pathname, query);
  if (direct.ok) return { ...direct, usedDirect: true, hostFailure: hosted, notes: [directNoteFor(ctx)] };
  return { ...hosted, directFailed: { kind: direct.kind, message: direct.message } };
}

/** 一次调用结束时销毁自有通道会话（别泄漏 socket / 让进程挂住）。 */
function closeDirectSessions(ctx) {
  if (!ctx || !ctx.directSessions) return;
  for (const session of ctx.directSessions.values()) {
    try { session.destroy(); } catch { /* ignore */ }
  }
  ctx.directSessions.clear();
}

/**
 * 对**一个站点**做带节流与重试的 GET。
 * opts.single=true 表示只打一次（换站回退那次：预算只够再试一发）。
 * 返回里带 site / tries；失败对象沿用 requestOnce 的 kind（blocked/network/reset/...）。
 */
async function fetchSite(ctx, site, pathname, query, opts = {}) {
  const single = opts.single === true;
  let last = null;
  for (let attempt = 0; ; attempt++) {
    if (remaining(ctx) < 600) {
      // 预算不够就干脆不发（F2）：绝不压缩节流间隔。已经拿到真实失败原因就报它，比报「预算」有用
      if (last) return { ...last, site, tries: attempt };
      return { ok: false, kind: 'budget', site, tries: 0, message: '15 秒预算已用完' };
    }
    const ready = await throttleGate(ctx, attempt === 0 ? 0 : retryDelayFor(last, attempt));
    if (!ready) {
      if (last) return { ...last, site, tries: attempt };
      return { ok: false, kind: 'budget', site, tries: 0, message: '节流等待会超出剩余预算，这次请求没有发出' };
    }
    const got = await attemptOnce(ctx, site, pathname, query);
    if (got.ok) return { ...got, site, tries: attempt + 1 };
    last = got;
    // 宿主通道 + 自有通道都试过还是被挡：再重试宿主的 403 没有意义（直接交给换站回退）
    if (got.directFailed) return { ...got, site, tries: attempt + 1 };
    // e621 的连接被重置是这个站的常态，不硬试（别拖满 20 秒）：交给换站逻辑
    if (got.kind === 'reset' && SITES[site] === 'e621.net') return { ...got, site, tries: attempt + 1 };
    if (!got.retry) return { ...got, site, tries: attempt + 1 };
    const cap = single ? FALLBACK_ATTEMPTS : attemptsFor(got.kind);
    if (attempt + 1 >= cap) return { ...got, site, tries: attempt + 1 };
  }
}

// ───────────────────── 换站回退（配置站点被挡就换另一个站）─────────────────────

const EGRESS_KINDS = new Set(['blocked', 'network', 'reset', 'timeout']);
/** 出口类失败（403 挑战 / 连不上）才值得换站；限流、服务端、解析、凭据换站也没意义。 */
const isEgressKind = (kind) => EGRESS_KINDS.has(String(kind || ''));

function canFallback(ctx, got) {
  if (ctx.fallbackSite !== true) return false;
  if (!ctx.altSite || ctx.altSite === ctx.site) return false;
  return isEgressKind(got?.kind);
}

function fallbackReasonOf(got) {
  if (String(got?.kind) === 'blocked') {
    const kind = got?.blocked?.kind;
    const short = kind === 'challenge' ? '挑战页' : (kind === 'blocked' ? '硬封页' : '认不出标记');
    return '回了 403（' + short + '）';
  }
  return '连不上（' + safeSlice(String(got?.message || got?.kind || '网络错误'), 60) + '）';
}

/**
 * 带节流/重试 + 换站回退的 GET。
 * 返回里 site 是**实际取数**的站点（pageUrl 与图床域名都跟着它走）；
 * 但 storage 键（wm:v1 / seen:v1）由调用方一律用 ctx.site —— 两个站是同一批 post id，
 * 用实际站点会把状态劈成两份，回退一次就让「作者更新」误报全是新的。
 */
async function fetchJson(ctx, pathname, query) {
  const primary = await fetchSite(ctx, ctx.site, pathname, query);
  if (primary.ok) {
    // 宿主通道被挑战、改走自有通道才成功：这也是「出口状态」，照样记进 diag。
    // ⚠️ 必须带 hostFailure（auto 才有）：transport=direct 的正常成功没有任何失败事件，
    //    写成 diag 会让 probe 里出现一条假的「上次 neterr」。
    if (primary.usedDirect && primary.hostFailure) await rememberDiag(ctx, diagRecordOf(ctx, primary.hostFailure, null, true));
    return primary;
  }
  if (!canFallback(ctx, primary)) {
    if (isEgressKind(primary.kind)) await rememberDiag(ctx, diagRecordOf(ctx, primary, null));
    return primary;
  }
  if (remaining(ctx) < 600) return primary;
  const altSite = ctx.altSite;
  const second = await fetchSite(ctx, altSite, pathname, query, { single: true });
  const other = { site: altSite, status: num(second.status) };
  await rememberDiag(ctx, diagRecordOf(ctx, primary, other));
  if (second.ok) {
    return {
      ...second,
      site: altSite,
      fellBack: { from: ctx.site, to: altSite },
      notes: ['配置站点 ' + SITES[ctx.site] + ' ' + fallbackReasonOf(primary) + '，这次是从 ' + SITES[altSite]
        + ' 取的（两个站是同一批作品号，作品一一对应）。']
    };
  }
  return { ok: false, kind: 'both', site: altSite, primarySite: ctx.site, altSite, tries: num(primary.tries), primary, secondary: second, message: 'both' };
}

// ──────────────── 「上次出口状态」：init 异步读一次，失败事件写回，probe 只读快照 ────────────────

let diagCache = null; // 模块级快照。⚠️ probe 只读它，绝不为 diag 发任何 cap

export function setDiagSnapshot(value) {
  diagCache = isPlainObject(value) ? value : null;
  return diagCache;
}

export function currentDiag() {
  return isPlainObject(diagCache) ? diagCache : null;
}

function diagKindOf(got) {
  if (String(got?.kind || '') !== 'blocked') return 'neterr';
  return got?.blocked?.kind === 'challenge' ? 'challenge' : 'blocked';
}

function diagRecordOf(ctx, got, other, usedDirect) {
  return {
    at: Date.now(),
    site: String(ctx.site),
    kind: diagKindOf(got),
    otherSite: other ? { site: String(other.site), status: num(other.status) } : null,
    rayId: String(got?.blocked?.rayId || ''),
    usedDirect: usedDirect === true
  };
}

/** 写回 diag:v1：先更新快照（storage 失败也照样能在 probe 里看见），storage 失败忽略。 */
async function rememberDiag(ctx, record) {
  diagCache = record;
  await storageSet(ctx, DIAG_KEY, record);
}

function blockedAdvice(kind) {
  if (kind === 'challenge') return '下一步：等十几秒到几分钟再试一次，或换另一个站（fallbackSite 开着会自动换）；持续出现说明出口 IP 被 edge 盯上了——把宿主升级到 0.9.10+ 后宿主会优先用 HTTP/2，这类按 HTTP 版本触发的挑战就不会再出现。';
  if (kind === 'blocked') return '下一步：换出口 IP / 换机器，重试和等待都没用；另一个站通常一起被封，也可以试一次。';
  return '下一步：稍后再试或换另一个站；持续出现请把上面的响应开头带给运维确认。';
}

/** 单站点被 403：分类 + 响应开头（≤120 字）+ Ray ID + 按分类给的下一步。 */
function blockedMessage(got) {
  const c = isPlainObject(got?.blocked) ? got.blocked : classifyBlocked('');
  const tries = num(got?.tries) || BLOCKED_ATTEMPTS;
  const head = '站点回了 403（试了 ' + tries + ' 次都失败）：' + c.label + '。'
    + '不是 UA 或 API Key 的问题（认证发生在 Cloudflare 之后的源站）。';
  const direct = got?.directFailed
    ? '插件自有 HTTP/2 通道也没成（' + safeSlice(String(got.directFailed.message || got.directFailed.kind), 60) + '）。'
    : '';
  const ray = c.rayId ? 'Ray ID: ' + c.rayId + '。' : '';
  const tail = ray + blockedAdvice(c.kind);
  // 契约：message ≤ 400 字。超了先缩响应摘录，再丢掉自有通道那句话（它的细节还在 diag:v1 里）
  const build = (max, withDirect) => head + (c.excerpt ? '响应开头「' + bodyExcerpt(got?.body, max) + '」。' : '') + (withDirect ? direct : '') + tail;
  let out = build(120, true);
  if (out.length > 400) out = build(80, true);
  if (out.length > 400) out = build(60, false);
  return out;
}

function siteFailureLine(site, got) {
  const host = SITES[siteKeyOf(site)];
  const kind = String(got?.kind || 'network');
  if (kind === 'blocked') {
    const c = isPlainObject(got?.blocked) ? got.blocked : classifyBlocked('');
    const head = bodyExcerpt(got?.body, got?.directFailed ? 40 : 48);
    const direct = got?.directFailed ? '，自有 HTTP/2 通道也没成' : '';
    return host + '：403 ' + c.label + (c.rayId ? '（Ray ID ' + c.rayId + '）' : '') + direct + (head ? '，响应开头「' + head + '」' : '');
  }
  if (kind === 'network' || kind === 'reset' || kind === 'timeout') {
    return host + '：连接级失败（' + safeSlice(String(got?.message || kind), 48) + '）';
  }
  return host + '：' + safeSlice(String(got?.message || kind), 48);
}

/** 两个站点都没成：两条站点状态都给出来（哪个挑战、哪个硬封、哪个连不上）。 */
function bothFailMessage(got) {
  const primarySite = siteKeyOf(got?.primarySite);
  const altSite = siteKeyOf(got?.altSite);
  const second = isPlainObject(got?.secondary) ? got.secondary : { kind: 'network', message: '没取到' };
  const hardBlock = [got?.primary, second].some((g) => String(g?.kind) === 'blocked' && g?.blocked?.kind === 'blocked');
  let out = '两个站点都没拿到数据：· ' + siteFailureLine(primarySite, got?.primary) + ' · ' + siteFailureLine(altSite, second) + '。';
  out += hardBlock
    ? '下一步：硬封页只有换出口 IP / 换机器才有用，重试没用。'
    : '下一步：两个站都没成时重试通常也没用，稍后再试或换出口 IP / 换机器部署。';
  return out;
}

/** 网络类失败 → 可照做的中文。code 只从契约的 8 个里挑。 */
function httpFail(ctx, got) {
  const kind = String(got?.kind || 'network');
  const detail = safeSlice(String(got?.message || ''), 160);
  const retried = '/ 已退避 ' + RETRY_WAIT_MS + 'ms 重试一次仍失败';
  if (kind === 'config') {
    return fail('E_CONFIG', '宿主的域名白名单没放行 ' + ctx.host + '（manifest 的 httpDomains 少了它）。这是插件配置问题，不是网络问题：' + detail + '。');
  }
  if (kind === 'auth') {
    return fail('E_CONFIG', '站点说凭据不对（401）。请检查设置里的用户名与 API Key：两个都留空就是匿名访问（能看公开作品）。');
  }
  if (kind === 'both') {
    // 两边都不是 403（纯连接失败）报 E_NETWORK：E_BLOCKED 只留给「被站点挡了」
    const anyBlocked = [got?.primary, got?.secondary].some((one) => String(one?.kind) === 'blocked');
    return fail(anyBlocked ? 'E_BLOCKED' : 'E_NETWORK', bothFailMessage(got));
  }
  if (kind === 'blocked') {
    return fail('E_BLOCKED', blockedMessage(got));
  }
  // e621 的连接级失败（status=0：fetch failed / ECONNRESET / DNS）统一说成人话：
  // 宿主的 cap.http 是直连、不吃系统代理，这个站在部分网络下就是这样，重试也没用。
  if (ctx.host === 'e621.net' && (kind === 'network' || kind === 'reset') && !got?.status) {
    return fail('E_BLOCKED', E621_BLOCKED_HUMAN);
  }
  if (kind === 'reset') {
    // 剩下的是 e926 的临时网络故障
    return fail('E_NETWORK', '连不上 ' + ctx.host + '（连接被重置 / DNS 失败）：' + detail + '。可能是临时网络问题，过一会儿再试。');
  }
  if (kind === 'direct') {
    return fail('E_NETWORK', '插件自有通道也连不上 ' + ctx.host + '（' + detail + '）。某些部署把插件关进独立网络命名空间（netns），那种情况下这条通道不可用：把传输方式改成 auto 或 host。');
  }
  if (kind === 'cap') {
    return fail('E_CAP', '这个上下文没有宿主能力（cap 没注入）：请确认插件是装在宿主里跑的，而不是被单独 import。');
  }
  if (kind === 'truncated') {
    return fail('E_TRUNCATED', '响应被截断（超过 512KB 上限），没法解析。把 count 调小（比如 3-5）或翻页再试。');
  }
  if (kind === 'parse') {
    return fail('E_NETWORK', '站点回的不是 JSON（可能被挡成了一个网页）：' + detail + '。稍后再试；持续出现请在插件日志里看原始响应。');
  }
  if (kind === 'rate') {
    return fail('E_RATE_LIMIT', 'e621/e926 硬限流 2 req/s：这次被限流了（' + detail + ' ' + retried + '）。等几秒再问，或把设置里的 throttleMs 调大（现在是 ' + ctx.throttleMs + 'ms）。');
  }
  if (kind === 'notfound') {
    return fail('E_NOT_FOUND', '站点回 404：这个作品号或标签组合下没有内容（标签是英文，作者名要走 artist_updates）。');
  }
  if (kind === 'paging') {
    return fail('E_ARGS', '页码不合法（410）。e926 只允许翻有限的页数：换个小一点的 page，或把 tags 写精确一点。');
  }
  if (kind === 'budget' || kind === 'timeout') {
    return fail('E_NETWORK', '15 秒预算内没拿到结果（' + detail + '）。把 count 调小或翻页会快很多。');
  }
  return fail('E_NETWORK', '请求 ' + ctx.host + ' 失败（' + detail + '）。稍后再试；持续失败换回 e926 看看。');
}

// ───────────────────────── 「宿主发文件在这个部署里能不能用」──────────────────────

const SEND_HOST_KEY = 'sendhost:v1';

export function sendHostWindowMs(failures, baseMinutes) {
  const count = Math.max(1, Math.floor(Number(failures) || 1));
  const base = Math.max(1, Number(baseMinutes) || DEFAULTS.sendHostRetryMinutes);
  return Math.min(SEND_HOST_MAX_MS, base * 60 * 1000 * Math.pow(2, count - 1));
}

async function readSendHost(ctx) {
  const value = await storageGet(ctx, SEND_HOST_KEY);
  if (!isPlainObject(value)) return null;
  const brokenAt = Number(value.brokenAt) || 0;
  if (!brokenAt) return null;
  return { brokenAt, failures: Math.max(0, Math.floor(Number(value.failures) || 0)), reason: String(value.reason || '') };
}

export function sendHostActive(record, cfg) {
  return Boolean(record && record.brokenAt
    && (Date.now() - record.brokenAt) <= sendHostWindowMs(record.failures, cfg.sendHostRetryMinutes));
}

async function markSendHostBroken(ctx, reason, previousFailures) {
  const record = {
    brokenAt: Date.now(),
    failures: Math.max(1, Math.floor(Number(previousFailures) || 0) + 1),
    reason: safeSlice(reason, 200)
  };
  await storageSet(ctx, SEND_HOST_KEY, record);
  return record;
}

// ───────────────────────── 发图（只在群聊、只在设置允许时）─────────────────────────

function imageFileName(id, url) {
  const matched = String(url || '').split('?')[0].match(/\.(jpe?g|png|gif|webp|bmp)$/i);
  const ext = matched ? matched[1].toLowerCase() : 'jpg';
  return 'e926-' + (num(id) || 'post') + (ext === 'jpeg' ? '.jpg' : '.' + ext);
}

/**
 * 下载一次图，失败重试一次。
 * e926 的图片主机也会间歇性回 Cloudflare 的 "Just a moment..." 403（text/html）：实测同一个
 * URL 隔 2 秒再取就 200 + image/jpeg，所以这里必须重试，否则「看着有图却发不出去」。
 * 只有 E_TOO_LARGE / E_DOMAIN 是确定性失败，不重试。
 */
async function downloadImage(ctx, variant, name, maxBytes, postId) {
  let last = '下载失败';
  let outcome = 'transient'; // transient（网络抖动，值得转发兜底） / unconfirmed / not_image
  let challenge = false;     // 图床回了 Cloudflare 挑战（HTML / 403）：这台机器的宿主通道走 H1 就会被挡
  for (let attempt = 0; attempt < 2; attempt++) {
    if (attempt > 0) await sleep(Math.max(0, Math.min(2000, remaining(ctx))));
    // 预算不够就别再发下载（旧写法的 "remaining(ctx) || 1500" 会在预算耗尽时补出 1.5 秒的假地板）；
    // 带着已有结论返回，调用方按 transient 降级成转发兜底。
    const left = remaining(ctx);
    if (left < 300) {
      last = '15 秒预算已用完，图没有下载';
      return { ok: false, outcome, message: last, challenge };
    }
    let got;
    try {
      got = await ctx.cap('cap.media.download', {
        url: variant.url,
        name,
        maxBytes,
        headers: { 'user-agent': ctx.userAgent, accept: 'image/*,*/*;q=0.8' }
      }, Math.min(10000, left));
    } catch (error) {
      const code = String(error?.code || '');
      const message = String(error?.message || error);
      await logWarn(ctx, 'image download failed id=' + num(postId) + ' kind=' + variant.kind + ' try=' + (attempt + 1) + ': ' + message);
      if (code === 'E_TOO_LARGE' || /too large|maxBytes/i.test(message)) return { ok: false, fatal: 'too_large', message };
      if (code === 'E_DOMAIN') return { ok: false, fatal: 'domain', message };
      // 宿主写不进自己的媒体目录 / 磁盘满 / 只读挂载：部署配置的永久性错误，重试不会有别的结果
      if (HOST_FS_ERROR_RE.test(code + ' ' + message)) return { ok: false, outcome: 'hostfs', message };
      if (/403|cloudflare|just a moment|challenge/i.test(message)) challenge = true;
      // 网络抖动/超时：把 outcome 拉回 transient，让「最后一次尝试的真实原因」决定最终文案
      // （否则第 1 次空 contentType、第 2 次网络错会对着用户说「没有 content-type」）
      outcome = 'transient';
      last = message;
      continue;
    }
    const contentType = String(got?.contentType || '').trim().toLowerCase();
    const bytes = num(got?.bytes);
    // ① 空 contentType 必须先判：宿主 capabilities.js:341 就是 `fetched.contentType || ''`，
    //    上游不给头时这里只能是空串 —— 那种响应极可能是 404 的 HTML 页，直接发进群等于对用户撒谎。
    //    插件读不到宿主媒体目录里的字节，没法自己 sniff，所以只能「不发 + 给转发兜底」。
    if (!contentType) {
      last = '取回来的响应没有 content-type，无法确认是图片';
      outcome = 'unconfirmed';
      await logWarn(ctx, 'image contentType missing id=' + num(postId) + ' bytes=' + bytes + ' try=' + (attempt + 1));
      continue;
    }
    // ② 明确不是图片（text/html 等）：这张没有，不发也不转发（转过去也是一张错误页）
    if (!contentType.startsWith('image/')) {
      last = '取回来的不是图片（contentType=' + contentType + '）';
      if (/text\/html/i.test(contentType)) challenge = true; // Cloudflare 挑战页被当成文件写下来了
      outcome = 'not_image';
      await logWarn(ctx, 'image is not an image id=' + num(postId) + ' contentType=' + contentType + ' try=' + (attempt + 1));
      continue;
    }
    // ③ 体积下限：站点错误页只有几十到几百字节，真图不会这么小
    if (bytes < MIN_IMAGE_BYTES) {
      last = '内容太小（' + bytes + ' 字节），疑似错误页';
      outcome = 'not_image';
      await logWarn(ctx, 'image too small id=' + num(postId) + ' bytes=' + bytes + ' try=' + (attempt + 1));
      continue;
    }
    return { ok: true, file: String(got?.file || name), bytes, contentType };
  }
  return { ok: false, outcome, message: last, challenge };
}

/**
 * 投递一张图，结果只写进 compact.image，**任何失败都不影响元数据返回**。
 * image: { delivered, url, forward? }；forward 非空时模型照抄去调宿主内置 send_group_file。
 */
async function deliverImage(ctx, raw, compact, options = {}) {
  const notes = [];
  const variant = pickImageVariant(raw, ctx.imageQuality);
  if (!variant) {
    notes.push('这个作品没有可用的图片直链（站点没给 file/sample/preview），只能给作品页。');
    return { image: { delivered: false, url: null }, notes };
  }
  const image = { delivered: false, url: variant.url };
  const forward = { tool: 'send_group_file', url: variant.url, name: imageFileName(compact?.id, variant.url) };
  const maxBytes = ctx.maxImageMb * 1024 * 1024;

  if (!ctx.sendImages) {
    notes.push('设置里关掉了「把作品图发到群里」（sendImages=false），这次只给链接。');
    return { image, notes };
  }
  if (!ctx.isGroup) {
    notes.push('当前会话不是群聊（chatKey=' + (ctx.chatKey || '空') + '），插件不发文件，只给链接。');
    return { image, notes };
  }
  if (variant.bytes > maxBytes) {
    notes.push('图片约 ' + mbText(variant.bytes) + ' MB，超过设置上限 ' + ctx.maxImageMb + ' MB，按规则不发、只给链接。');
    return { image, notes };
  }

  const record = await readSendHost(ctx);
  const broken = sendHostActive(record, ctx);
  const mode = ctx.sendMode === 'forward' ? 'forward'
    : ctx.sendMode === 'host' ? 'host'
      : (broken ? 'forward' : 'host');
  if (mode === 'forward') {
    image.forward = forward;
    notes.push(broken ? HOST_BROKEN_HUMAN + '。' : '按设置只走转发（省一次下载）。');
    // forward = 让协议端自己去下载：它只有 HTTP/1.1 时照样被 Cloudflare 挑战（真机踩过）
    if (ctx.sendMode === 'forward') {
      notes.push(FORWARD_RISK_NOTE);
      // 本次数据是自有/宿主 HTTP/2 通道取到的 → 本机下载是通的，该劝回 auto（不新增任何请求，只看已有信息）
      if (options.usedDirect === true) return { image, notes, hint: FORWARD_AUTO_HINT };
    }
    return { image, notes };
  }

  const downloaded = await downloadImage(ctx, variant, forward.name, maxBytes, compact?.id);
  if (!downloaded.ok) {
    if (downloaded.fatal === 'too_large') {
      notes.push('图片超过设置上限 ' + ctx.maxImageMb + ' MB，按规则不发、只给链接。');
      return { image, notes };
    }
    if (downloaded.fatal === 'domain') {
      notes.push('图片域名不在 httpDomains 白名单里（插件配置错误），只给链接。');
      return { image, notes };
    }
    if (downloaded.outcome === 'hostfs') {
      // 宿主写不进自己的媒体目录：部署配置问题。转发也救不了 —— 协议端读的是同一个目录，所以不给 forward
      notes.push(HOST_FS_NOTE + '（原始报错：' + safeSlice(downloaded.message, 60) + '）');
      return { image, notes, advise: HOST_FS_ADVISE };
    }
    // 图床被 Cloudflare 挑战（宿主 cap.media.download 也走 HTTP/1.1，字节拿不到就没法交给 cap.send.file）：
    // 三种失败形态（无 content-type / 不是图片 / 直接抛 403）都必须落到这句，否则这台机器上永远看不到真正原因
    const challengeFallback = () => {
      image.forward = forward;
      notes.push(IMAGE_CHALLENGE_NOTE);
      return { image, notes, hint: IMAGE_CHALLENGE_HINT };
    };
    if (downloaded.outcome === 'unconfirmed') {
      // 无法确认是图片：不直接发（可能是站点的错误页），但保留转发兜底
      image.forward = forward;
      if (downloaded.challenge) return challengeFallback();
      notes.push('取回来的响应没有 content-type，无法确认是图片（可能是站点的错误页），所以没有直接发；已给出转发指令，让协议端自己去取。');
      return { image, notes };
    }
    if (downloaded.outcome === 'not_image') {
      if (downloaded.challenge) return challengeFallback();
      // 明确取不到图（非 image 的 contentType / 体积过小）：不直接发，但保留转发兜底，
      // 并在 note 里说清「这个链接大概率已经不是图片」—— 让模型自己决定转发还是只给链接。
      image.forward = forward;
      notes.push('这张取不到图（' + safeSlice(downloaded.message, 80) + '），没有直接发。'
        + '已给出转发指令作为最后兜底；不想冒发错文件的风险就只把 pageUrl 给用户。');
      return { image, notes };
    }
    // 走到这里的是 transient / 其他（典型：cap.media.download 直接抛 HTTP 403）
    if (downloaded.challenge) return challengeFallback();
    image.forward = forward;
    notes.push('这张图没下载下来（' + safeSlice(downloaded.message, 80) + '），已给出转发指令作为兜底。');
    return { image, notes };
  }
  const bytes = downloaded.bytes;
  if (bytes > maxBytes) {
    notes.push('图片 ' + mbText(bytes) + ' MB，超过设置上限 ' + ctx.maxImageMb + ' MB，按规则不发、只给链接。');
    return { image, notes };
  }

  const file = String(downloaded?.file || forward.name);
  // 预算不够就别发（旧写法的 "remaining(ctx) || 1500" 会在预算耗尽时补出 1.5 秒的假地板）；
  // 这时一个字节都没发出去，safe 的做法是给转发兜底（不会变成发两张）。
  const sendLeft = remaining(ctx);
  if (sendLeft < 300) {
    image.forward = forward;
    notes.push('15 秒预算已用完，这张图还没交给宿主发送；已给出转发指令作为兜底。');
    return { image, notes };
  }
  try {
    // name 只给纯文件名：传绝对路径时协议端会把它当成目标名（那是宿主自己的目录路径）
    await ctx.cap('cap.send.file', { chatKey: ctx.chatKey, file, name: forward.name }, Math.min(15000, sendLeft));
  } catch (error) {
    const code = String(error?.code || '');
    const message = String(error?.message || error);
    // 宿主没有发送队列：宿主侧问题，转发也救不了（不是路径/权限的事）
    if (code === 'E_NO_SENDER' || /E_NO_SENDER/i.test(message)) {
      await logWarn(ctx, 'send.file no sender id=' + num(compact?.id) + ': ' + message);
      notes.push(NO_SENDER_NOTE);
      return { image, notes, advise: NO_SENDER_ADVISE };
    }
    // 超时 ≠ 失败：宿主可能还在传（它允许 120 秒）。不给 forward，别让用户收到两张
    if (code === 'E_CAP_TIMEOUT' || SEND_TIMEOUT_RE.test(code + ' ' + message)) {
      await logWarn(ctx, 'send.file ack timeout id=' + num(compact?.id) + ': ' + message);
      notes.push(SEND_TIMEOUT_NOTE);
      return { image, notes, advise: SEND_TIMEOUT_ADVISE };
    }
    if (HOST_FILE_BROKEN_RE.test(message)) {
      await markSendHostBroken(ctx, message, record && record.failures);
      await logWarn(ctx, 'cap.send.file unusable id=' + num(compact?.id) + ': ' + message);
      image.forward = forward;
      notes.push(HOST_BROKEN_HUMAN + '；首次发图报一次错属正常探路，这次已给出转发指令。');
      return { image, notes };
    }
    await logWarn(ctx, 'send.file failed id=' + num(compact?.id) + ': ' + message);
    image.forward = forward;
    notes.push('发文件失败（' + safeSlice(message, 80) + '），已给出转发指令。');
    return { image, notes };
  }
  if (record) await storageSet(ctx, SEND_HOST_KEY, null); // 成了一次就清零，下次继续先试宿主
  image.delivered = true;
  return { image, notes };
}

/** 按「这次到底能不能发」给人话下一步 —— 别写死「发不了图」（设置一开就翻车）。 */
function imageAdvise(ctx, image) {
  if (!image) return '这次没有图：把 pageUrl 给用户点开。';
  if (image.delivered) return '图已经直接发到这个群了（image.delivered=true），不要再贴链接、也不要再调 send_group_file 重复转发。';
  if (image.forward) return '这张走转发：立刻用宿主内置 send_group_file，把 image.forward.url 与 image.forward.name 原样传进去，不要自己拼参数，也不要让用户复制链接。';
  if (!ctx.sendImages) return '设置里 sendImages 是关的，插件不发图：把 image.url 或 pageUrl 原样给用户点开。想直接发图，让管理员在插件设置里打开「把作品图发到群里」（只对群聊生效）。';
  if (!ctx.isGroup) return '当前不是群聊，插件只给链接：把 image.url 原样给用户。';
  return '这次没有能发的图（链接失效或超过体积上限）：把 pageUrl 给用户点开。';
}

const TITLE_CAUTION = 'title 是插件拼的可读名（简介首行 / 角色 / 前三个标签），不是站方官方标题，转述时别写成「官方标题」。';

// ───────────────────────── 四个工具 ─────────────────────────

async function toolSearch(ctx, args) {
  const rawTags = firstString(args?.tags);
  if (!rawTags) {
    return fail('E_ARGS', 'tags 不能为空：给一个英文标签（如 fox、dragon、wolf），多个标签用空格分隔。中文描述要先翻成 e926 的英文标签。');
  }
  const count = clampInt(args?.count, ctx.defaultCount, 1, 10);
  const page = clampInt(args?.page, 1, 1, 20);
  const finalTags = buildSearchTags({ tags: rawTags, site: ctx.site, allowAdult: ctx.allowAdult, excludeTags: ctx.excludeTags });
  const notes = [];
  if (ctx.ratingLocked) {
    notes.push('已强制 rating:s（站点=' + ctx.site + '，成人开关=' + (ctx.allowAdult ? '开' : '关') + '），结果里 rating≠s 的条目会被丢掉。');
  }

  const got = await fetchJson(ctx, '/posts.json', { tags: finalTags, limit: count, page });
  // 「没搜到」是合法结果，不是故障：与空 posts 数组同样对待（404 也不例外）
  if (!got.ok && got.kind !== 'notfound') return httpFail(ctx, got);
  // 回退过一次的话，notes 里要说清「配置站点没成、这次是从哪个站取的」
  const tookSite = siteKeyOf(got.site || ctx.site);
  for (const line of asArray(got.notes)) notes.push(line);

  const raws = asArray(got.data?.posts).filter(isPlainObject);
  const kept = [];
  let dropped = 0;
  for (const raw of raws) {
    // 站点不一定会听话：本地再兜一层 rating 过滤，绝不放行成人条目
    if (ctx.ratingLocked && ratingOf(raw) !== 's') { dropped += 1; continue; }
    kept.push(raw);
  }
  if (dropped) notes.push('站点返回了 ' + dropped + ' 条非全年龄结果，已在本地丢弃（rating 锁开着）。');

  const posts = kept.slice(0, count).map((raw) => {
    const item = compactPost(raw, { quality: ctx.imageQuality, sendImages: ctx.sendImages, site: tookSite });
    const variant = pickImageVariant(raw, ctx.imageQuality);
    item.image = { delivered: false, url: variant ? variant.url : null };
    return item;
  });

  let advise;
  if (!posts.length) {
    advise = '没搜到「' + safeSlice(rawTags, 40) + '」的作品。e926 的标签是英文，换成更短更常见的（fox / wolf / dragon / canine / solo）再试；也可以去掉限定标签。别编造作品号。';
  } else {
    const canSend = ctx.sendImages && ctx.isGroup;
    advise = '列表只给链接、本身不发图（每张都下载会吃满 15 秒预算）。想看某一张的详情就调 post 传 id（例如 ' + posts[0].id + '）；'
      + (canSend
        ? '想要一张能直接发到群的图就调 random —— 设置里 sendImages 开着，random / post 在群聊里会把图直接发出来。'
        : (ctx.sendImages
          ? '当前不是群聊，random / post 也只会给链接。'
          : '设置里 sendImages 关着，random / post 也只会给链接。'))
      + TITLE_CAUTION;
  }
  return { ok: true, site: tookSite, query: rawTags, tags: finalTags, page, count, posts, notes, advise };
}

async function toolArtistUpdates(ctx, args) {
  const rawArtist = firstString(args?.artist, args?.name);
  const artist = normalizeArtistTag(rawArtist);
  if (!artist) {
    return fail('E_ARGS', 'artist 认不出来：给作者的英文名或标签形式（如 kenuwu、kenu_wu）。e621 的作者标签是 artist:<名字>，中文名要先找到它的英文标签。');
  }
  const count = clampInt(args?.count, ctx.defaultCount, 1, 10);
  // ⚠️ 实测：e926 不吃 artist: 前缀（artist:kenuwu 回 0 条，裸标签 kenuwu 回 5 条），所以按裸标签查，
  // 再在本地按 tags.artist 精确筛一遍 —— 否则「查作者」永远 0 条，看着像作者没作品。
  const finalTags = buildSearchTags({ tags: artist, site: ctx.site, allowAdult: ctx.allowAdult, excludeTags: ctx.excludeTags });
  const notes = [];
  if (ctx.ratingLocked) notes.push('已强制 rating:s（站点=' + ctx.site + '，成人开关=' + (ctx.allowAdult ? '开' : '关') + '）。');

  const got = await fetchJson(ctx, '/posts.json', { tags: finalTags, limit: count, page: 1 });
  if (!got.ok && got.kind !== 'notfound') return httpFail(ctx, got);
  // 取数站点可能与配置站点不同（回退），但下面的水位线键仍用 ctx.site
  const tookSite = siteKeyOf(got.site || ctx.site);
  for (const line of asArray(got.notes)) notes.push(line);

  let raws = asArray(got.data?.posts).filter(isPlainObject)
    .filter((raw) => !(ctx.ratingLocked && ratingOf(raw) !== 's'));
  // 站点是按裸标签匹配的（可能命中同名的角色/作品标签）：精确匹配为空时**不能**拿这批未匹配
  // 的条目去算 newCount 或推进水位线 —— 那会把别人的作品算成他的新作品。
  const byArtist = raws.filter((raw) => uniqClean(raw?.tags?.artist).some((name) => normalizeArtistTag(name) === artist));
  if (raws.length && !byArtist.length) {
    return fail('E_NOT_FOUND', '站点没有「' + artist + '」这个作者标签的作品：这次返回的都是别人的条目（可能命中了同名的角色或作品标签）。'
      + '本站没有 artist: 元标签，作者名要写成站点的裸标签（如 kenuwu、kenu_wu），确认拼写后再问一次。水位线没有改动。');
  }
  if (byArtist.length) raws = byArtist;
  // 条数上界与 toolSearch 的 slice(0, count) 对齐：水位线、newCount、posts 都只从这 ≤count 条里算
  raws = raws.slice(0, count);
  const ids = raws.map((raw) => num(raw.id)).filter((n) => n > 0);
  const topId = ids.length ? Math.max(...ids) : 0;
  const topRaw = raws.find((raw) => num(raw.id) === topId) || null;

  // ⚠️ 水位线键用**配置站点**：e926/e621 是同一批 post id，用实际取数站点会把状态劈成两份
  const key = 'wm:v1:' + ctx.site + ':' + artist;
  const prev = await storageGet(ctx, key);
  const seenIds = [];
  let baseline = false;
  let newCount = 0;

  const buildPost = (raw) => {
    const item = compactPost(raw, { quality: ctx.imageQuality, sendImages: ctx.sendImages, site: tookSite });
    const variant = pickImageVariant(raw, ctx.imageQuality);
    item.image = { delivered: false, url: variant ? variant.url : null };
    return item;
  };

  let posts = [];
  if (!isPlainObject(prev)) {
    baseline = true;
    posts = raws.slice(0, WM_CONTEXT_POSTS).map(buildPost);
    notes.push('首次查这位作者：只建水位线（baseline=true、newCount=0）。posts 里是最近 ' + posts.length + ' 条，用来当上下文，不是「新作品」。');
  } else {
    const lastId = num(prev.lastId);
    for (const raw of raws) {
      const id = num(raw.id);
      if (id > lastId) { newCount += 1; seenIds.push(id); }
    }
    posts = raws.map(buildPost);
    const when = Number(prev.at) ? new Date(Number(prev.at)).toISOString().slice(0, 16).replace('T', ' ') : '上次';
    if (newCount > 0) notes.push('比水位线（lastId=' + lastId + '）新的作品有 ' + newCount + ' 条；水位线是' + when + '（UTC）记下的。');
    else notes.push('自水位线（lastId=' + lastId + '，' + when + ' UTC）以来没有新作品。');
    if (newCount >= count) notes.push('这次只翻了最新 ' + count + ' 条，实际新增可能多于 ' + newCount + ' 条（要更多就调大 count）。');
  }

  // 任何情况下都更新水位线；这批一条都没有时保留原 lastId，别把水位线拉回 0
  const prevLastId = isPlainObject(prev) ? num(prev.lastId) : 0;
  const wm = {
    lastId: topId > 0 ? Math.max(topId, prevLastId) : prevLastId,
    lastCreatedAt: firstString(topRaw?.created_at, isPlainObject(prev) ? prev.lastCreatedAt : '') || '',
    total: raws.length,
    at: Date.now()
  };
  await storageSet(ctx, key, wm);
  if (!topId && isPlainObject(prev)) notes.push('这次没查到作品（标签可能写错），水位线保持原值不动。');
  else if (!topId) notes.push('这位作者在这台站点的全年龄区没有可见作品（或名字拼错），水位线已记为 0。');

  let advise;
  if (baseline) {
    advise = '这是首次查询，只建了水位线（baseline=true、newCount=0）：把 posts 里这几条当参考回给用户，并告诉他下次问「' + artist + ' 有没有更新」才会给出真正的新增数。';
  } else if (newCount > 0) {
    advise = '有 ' + newCount + ' 条新作品（比上次水位线新）：把最新的几条列出来，并说清是「自上次查询以来」新增的，不要夸大成作者的总作品数。';
  } else {
    advise = '这位作者自上次查询以来没有新作品（newCount=0）：如实告诉用户，别编造更新，也别承诺「有更新会通知」（插件不会主动推送，只能靠问）。';
  }
  advise += ' 列表本身不发图，想看某一张就调 post 传 id；要一张能直接发的就调 random。' + TITLE_CAUTION;

  return {
    ok: true,
    site: tookSite,
    artist,
    artistTag: artist,
    query: finalTags,
    baseline,
    newCount,
    newIds: seenIds.slice(0, count),
    checkedAt: new Date().toISOString(),
    watermark: wm,
    posts,
    notes,
    advise
  };
}

async function toolRandom(ctx, args) {
  const rawTags = firstString(args?.tags);
  const finalTags = buildSearchTags({ tags: rawTags, site: ctx.site, allowAdult: ctx.allowAdult, excludeTags: ctx.excludeTags });
  const notes = [];
  if (ctx.ratingLocked) notes.push('已强制 rating:s（站点=' + ctx.site + '，成人开关=' + (ctx.allowAdult ? '开' : '关') + '）。');
  if (!rawTags) notes.push('没给 tags：从整站随机抽一张（仍然受 rating 锁约束）。');

  // ⚠️ 去重键用**配置站点**（两站同一批 post id：用实际站点会把「发过的」劈成两份）
  const seenKey = 'seen:v1:' + ctx.site + ':' + ctx.sessionKey;
  const seen = asArray(await storageGet(ctx, seenKey)).map((x) => num(x)).filter((n) => n > 0);
  const seenSet = new Set(seen);
  let post = null;
  let duplicates = 0;
  let tookSite = ctx.site;
  let fallbackNoted = false;
  let usedDirectNow = false;

  for (let draw = 0; draw < RANDOM_DRAWS; draw++) {
    const got = await fetchJson(ctx, '/posts/random.json', { tags: finalTags });
    if (!got.ok) {
      // 已经抽到一张就带着它回去（预算/限流不该让整次调用白跑）
      if (post) {
        const why = got.kind === 'both' ? '两个站点都没拿到数据' : safeSlice(got.message, 60);
        notes.push('后面几次重抽失败（' + why + '），用的是已经抽到的那张。');
        break;
      }
      // 没抽到是合法结果（标签太冷 / 站点回 404），按契约给 ok:true + 空数组，不要说成故障
      if (got.kind === 'notfound') {
        notes.push('随机接口在这个标签组合下没抽到作品。');
        return {
          ok: true, site: tookSite, tags: finalTags, post: null, posts: [], notes,
          advise: '这个标签组合下没抽到作品：e926 的标签是英文，换成更短更常见的（fox / wolf / dragon / dog / solo）再试，或者干脆不带 tags 整站随机。别编造作品号。'
        };
      }
      return httpFail(ctx, got);
    }
    // 回退过一次就记下实际取数站点，并把「为什么换了站」写进 notes（只写一次）
    tookSite = siteKeyOf(got.site || ctx.site);
    usedDirectNow = got.usedDirect === true;
    if (!fallbackNoted && asArray(got.notes).length) {
      for (const line of asArray(got.notes)) notes.push(line);
      fallbackNoted = true;
    }
    const cand = got.data?.post;
    if (!isPlainObject(cand)) {
      if (post) break;
      notes.push('随机接口没有返回作品对象。');
      return { ok: true, site: tookSite, tags: finalTags, post: null, posts: [], notes, advise: '随机接口没返回作品：换个更常见的英文标签再试一次。' };
    }
    post = cand;
    // 站点理论上会听话；万一返回成人条目，locked 时必须重抽
    if (ctx.ratingLocked && ratingOf(cand) !== 's') { post = null; continue; }
    const id = num(cand.id);
    if (!seenSet.has(id)) break;
    duplicates += 1;
  }

  if (!post) {
    // 连抽 3 次全是 rating≠s：rating 锁生效、站点没听话，按「没抽到」返回，别报成故障
    notes.push('连着 ' + RANDOM_DRAWS + ' 次抽到的都是非全年龄条目，按 rating 锁全部丢掉了。');
    return {
      ok: true, site: tookSite, tags: finalTags, post: null, posts: [], notes,
      advise: '这个标签下抽到的都是成人向作品，当前设置（站点=' + ctx.site + '，成人开关=' + (ctx.allowAdult ? '开' : '关') + '）不允许发：换个标签，或让管理员把站点切成 e621 并打开成人开关再试。'
    };
  }
  if (duplicates > 0 && seenSet.has(num(post.id))) {
    notes.push('这张（id=' + num(post.id) + '）在本会话之前已经发过 ' + duplicates + ' 次重抽仍重复，按规则照发一次；想要新的就再调一次 random。');
  }

  const item = compactPost(post, { quality: ctx.imageQuality, sendImages: ctx.sendImages, site: tookSite });
  const delivered = await deliverImage(ctx, post, item, { usedDirect: usedDirectNow });
  item.image = delivered.image;
  for (const line of delivered.notes) notes.push(line);
  await storageSet(ctx, seenKey, ringUpdate(seen, num(post.id), SEEN_CAP));

  // delivered.advise 是「宿主侧永久性失败」时的整句覆盖（别让模型去让用户重试/转发）
  const advise = (delivered.advise || (imageAdvise(ctx, item.image) + (delivered.hint ? ' ' + delivered.hint : '')))
    + ' 再要一张就再调一次 random（插件会自动避开这个会话最近发过的 200 个作品）。' + TITLE_CAUTION;
  return { ok: true, site: tookSite, tags: finalTags, post: item, notes, advise };
}

async function toolPost(ctx, args) {
  const rawInput = firstString(args?.id) || firstString(args?.url);
  const id = parsePostId(rawInput);
  if (!id) {
    return fail('E_ARGS', 'id 认不出作品号：收到的是「' + safeSlice(String(rawInput ?? ''), 40) + '」。给纯数字（如 6806819）、整条 https://e926.net/posts/6806819 链接，或带 .json 的地址都行。');
  }
  const got = await fetchJson(ctx, '/posts/' + id + '.json', {});
  if (!got.ok) {
    if (got.kind === 'notfound') {
      return fail('E_NOT_FOUND', 'e926/e621 上没有 ' + id + ' 这个作品号。号码可能写错了，或这个作品已经被删/被隐藏。');
    }
    return httpFail(ctx, got);
  }
  const raw = got.data?.post;
  if (!isPlainObject(raw) || !num(raw.id)) {
    return fail('E_NOT_FOUND', '接口没返回 ' + id + ' 的内容（这个作品可能已删除或被隐藏）。');
  }
  const notes = [];
  const tookSite = siteKeyOf(got.site || ctx.site);
  for (const line of asArray(got.notes)) notes.push(line);
  if (ctx.ratingLocked && ratingOf(raw) !== 's') {
    notes.push('这个作品是成人向（rating=' + ratingOf(raw) + '），在当前设置下不给内容。');
    return fail('E_NOT_FOUND', '这个作品在 ' + ctx.host + ' 上不存在：成人向内容只在 e621。想让插件看它，请管理员把站点切成 e621 并打开成人开关。');
  }
  if (ctx.ratingLocked) notes.push('rating 锁开着（站点=' + ctx.site + '，成人开关=' + (ctx.allowAdult ? '开' : '关') + '）。');

  const item = compactPost(raw, { quality: ctx.imageQuality, sendImages: ctx.sendImages, site: tookSite });
  item.description = stripMarkup(String(raw.description ?? ''), MAX_DESC);
  item.sources = uniqClean(asArray(raw.sources).map((s) => (typeof s === 'string' ? s : firstString(s?.url)))).slice(0, 3);

  const delivered = await deliverImage(ctx, raw, item, { usedDirect: got.usedDirect === true });
  item.image = delivered.image;
  for (const line of delivered.notes) notes.push(line);

  const advise = (delivered.advise || (imageAdvise(ctx, item.image) + (delivered.hint ? ' ' + delivered.hint : '')))
    + ' description 与 sources 都来自站点（简介已去标记并截到 300 字）；' + TITLE_CAUTION;
  return { ok: true, site: tookSite, post: item, notes, advise };
}

/** 工具总入口：永远返回纯 JSON 对象，不抛异常。 */
export async function runTool(ctx, name, args) {
  const tool = String(name || '');
  try {
    if (!['search', 'artist_updates', 'random', 'post'].includes(tool)) {
      return fail('E_ARGS', '本插件没有工具「' + safeSlice(tool, 40) + '」，只有 search / artist_updates / random / post。');
    }
    if (!ctx.deadline) ctx.deadline = Date.now() + BUDGET_MS;
    const input = isPlainObject(args) ? args : {};
    if (tool === 'search') return await toolSearch(ctx, input);
    if (tool === 'artist_updates') return await toolArtistUpdates(ctx, input);
    if (tool === 'random') return await toolRandom(ctx, input);
    return await toolPost(ctx, input);
  } catch (error) {
    const code = String(error?.code || '');
    if (code === 'E_CAP') return fail('E_CAP', '这个上下文没有宿主能力（cap 没注入）：请确认插件是装在宿主里跑的，而不是被单独 import。');
    return fail('E_NETWORK', '插件内部出错（不是站点问题）：' + safeSlice(String(error?.message || error), 200));
  } finally {
    closeDirectSessions(ctx); // 自有通道会话只在一次调用内存活，别泄漏
  }
}

// ───────────────────────── probe（控制台「检测登录」）─────────────────────────
//
// 形状照作者自己的 bilibili 插件（examples/plugins/bilibili/index.mjs 的 probeStatus）对齐：
//   每个 probe 都真测一次（只做 10 秒防抖，不做长缓存），结论 = 「这一次」的；
//   login / uname / mid / owner / writable / configured / note 是界面认的字段。
// ⚠️ 绝不设 apiOk：宿主 ui/pages/plugin-settings.js 把它硬编码成「B 站接口不可达」，对我们是错的 ——
//    失败信息一律走 note。

const PROBE_DEDUPE_MS = 10 * 1000;         // 10 秒内重复 probe 复用上一次结论（只防抖，不做长缓存）
const PROBE_LOGIN_BUDGET_MS = 1200;        // 单次实测的总预算（设置页点「检测登录」能等这么久）
const PROBE_NO_CRED_NOTE = '未配置凭据（只读公开作品不需要；要看私有数据才需要用户名 + API Key）';
let probeLoginCache = null; // { key, at, value:{login,uname,note} }

/** 有「用户名 + Key」才算配了凭据；只有其中一个等于没配（Basic 头拼不出来）。 */
const credentialReady = (ctx) => Boolean(ctx && ctx.username && ctx.apiKey);

function probeKeyOf(ctx) {
  try {
    return createHash('sha1').update(String(ctx.username) + '\u0000' + String(ctx.apiKey)).digest('hex').slice(0, 12) + '|' + ctx.site;
  } catch {
    return ctx.site + '|' + ctx.username;
  }
}

function cachedLogin(ctx) {
  if (!probeLoginCache || probeLoginCache.key !== probeKeyOf(ctx)) return null;
  if (Date.now() - probeLoginCache.at >= PROBE_DEDUPE_MS) return null;
  return probeLoginCache.value;
}

/**
 * 凭据实测一次（有界）。**没配置凭据时不发任何 cap**。
 * 只走宿主通道、只打一次：这是「凭据能不能用」的检查，不是取数据 —— 换站/自有通道会把时间拖长且答非所问。
 * 200 = 登录有效；401 = Key 无效；超时 / 网络错 / 挑战页 = 「没连上」（login:false，但 note 说清不是凭据失效）。
 */
export async function checkCredentials(ctx, options = {}) {
  if (!credentialReady(ctx)) return { login: false, uname: '', note: PROBE_NO_CRED_NOTE };
  const uname = sliceByCodePoints(String(ctx.username), 24);
  const host = SITES[ctx.site];
  const want = num(options.budgetMs) || PROBE_LOGIN_BUDGET_MS;
  // deadline 没设（0）＝这一次没有外层预算，用本次上限；设了就必须按剩余收敛 ——
  // 旧写法 "remaining(ctx) || want" 在剩余为 0 时又补回一整份预算，等于没有预算。
  const outer = ctx.deadline ? remaining(ctx) : want;
  if (outer < 300) return { login: false, uname: '', note: '这次没有预算做凭据自检（可以在设置页再点一次「检测登录」）' };
  const budget = Math.min(PROBE_LOGIN_BUDGET_MS, want, outer);
  const probeCtx = { ...ctx, transport: 'host', fallbackSite: false, deadline: Date.now() + budget + RESERVE_MS };
  let got;
  try {
    got = await fetchJson(probeCtx, '/posts.json', { limit: 1 });
  } catch (error) {
    got = { ok: false, kind: 'network', message: String(error?.message || error) };
  } finally {
    closeDirectSessions(probeCtx);
  }
  if (got.ok) return { login: true, uname, note: '登录有效（API Key 已通过 ' + host + ' 接口实测）' };
  if (got.kind === 'auth') return { login: false, uname: '', note: 'API Key 无效（401）：请确认用户名与 Key 成对，且该账号已在 e926 设置里启用 API 访问' };
  return { login: false, uname: '', note: '凭据已配置，但这次自检没连上 ' + host + '（网络问题，不代表凭据失效）' };
}

/** 回执形状（与 bilibili 插件的 probeStatus 对齐）。⚠️ 永远不出现 apiOk。 */
function probePayload(ctx, identity, extra = {}) {
  const ready = credentialReady(ctx);
  return {
    ok: true,
    plugin: PLUGIN_ID,
    version: PLUGIN_VERSION,
    site: ctx.site,
    allowAdult: ctx.allowAdult,
    transport: ctx.transport,
    fallbackSite: ctx.fallbackSite,
    auth: ready ? 'configured' : 'anonymous',
    login: identity.login === true,
    uname: String(identity.uname || '').slice(0, 24),
    mid: '',
    owner: { configured: '', matches: null }, // e926 没有「主人 UID」概念
    writable: false,                          // 本插件不做写操作
    configured: { username: Boolean(ctx.username), apiKey: Boolean(ctx.apiKey) },
    note: firstString(identity.note) || PROBE_NO_CRED_NOTE,
    enabled: extra && extra.enabled !== false,
    lastDiag: currentDiag()
  };
}

/** 同步回执（不实测）：未配置凭据时这就是最终结论，一次 cap 都不发。 */
export function probeInfo(settings = {}, extra = {}) {
  const ctx = makeContext(settings, { apiKey: extra?.apiKey });
  const cached = credentialReady(ctx) ? cachedLogin(ctx) : null;
  const identity = cached || {
    login: false,
    uname: '',
    note: credentialReady(ctx) ? '凭据已配置（还没实测过：点一次「检测登录」会实测一次）' : PROBE_NO_CRED_NOTE
  };
  return probePayload(ctx, identity, extra);
}

/**
 * probe 的完整流程：未配置凭据 → 零 cap 秒回；配置了凭据 → 每次真测一次（预算 1200ms，10 秒内防抖复用）。
 * 协议循环用 void handleProbe(msg) 调它，绝不在 stdin 读循环里 await。
 */
export async function probeInfoAsync(settings = {}, extra = {}) {
  const ctx = makeContext(settings, { apiKey: extra?.apiKey, cap: extra?.cap });
  const cached = credentialReady(ctx) ? cachedLogin(ctx) : null;
  if (!credentialReady(ctx)) return probePayload(ctx, { login: false, uname: '', note: PROBE_NO_CRED_NOTE }, extra);
  if (cached) return probePayload(ctx, cached, extra);                    // 10 秒防抖：直接复用
  if (typeof extra?.cap !== 'function') return probeInfo(settings, extra); // 没注入 cap（纯单测）
  const identity = await checkCredentials(ctx, { budgetMs: extra?.budgetMs });
  probeLoginCache = { key: probeKeyOf(ctx), at: Date.now(), value: identity };
  return probePayload(ctx, identity, extra);
}

// ───────────────────────── stdio NDJSON 协议 ─────────────────────────

/** 只有被当主模块跑时才进协议循环；被 import（单测/其它脚本）时什么都不做。 */
function isMainModule() {
  try {
    const argv1 = process.argv[1];
    if (typeof argv1 !== 'string' || !argv1) return false;
    const here = import.meta.url;
    const ran = pathToFileURL(path.resolve(argv1)).href;
    return process.platform === 'win32' ? here.toLowerCase() === ran.toLowerCase() : here === ran;
  } catch {
    return false;
  }
}

function main() {
  const write = (msg) => { try { process.stdout.write(JSON.stringify(msg) + '\n'); } catch { /* 管道断了也没别的办法 */ } };
  const warn = (text) => { try { process.stderr.write('[e926-search] ' + text + '\n'); } catch { /* ignore */ } };
  // stdout 断了（宿主先退出）不该变成未捕获异常把进程卡在半死状态
  process.stdout.on('error', () => process.exit(0));
  /** 回执统一走这里：宿主发来的 shutdown 之类**没有 id**，不能写 { result }（会被记成 protocolError）。 */
  const reply = (msg, payload) => {
    if (msg.id === undefined || msg.id === null) return;
    write({ id: msg.id, result: payload });
  };

  let seq = 0;
  const pending = new Map();
  let settings = null;
  let settingsFromInit = {};
  let enabled = true;
  // 凭据：apiKey 只经 cap.secrets.get 拿（宿主加密落盘；不进 settings / 日志 / 结果 / storage）
  let secretApiKey = '';
  let secretPromise = null;
  let initParams = null;

  /**
   * 调宿主能力：成功 resolve(result)，失败 reject（带 code 的 Error）。
   * id 用 'cap-N' 字符串：宿主发来的 callTool/probe 用的是数字 id，用数字会撞键
   * （把宿主的请求当成回执吃掉，整条链路静默卡死）。
   */
  const capCall = (method, params, timeoutMs) => new Promise((resolve, reject) => {
    const limit = Math.max(300, Number(timeoutMs) || CAP_TIMEOUT_MS);
    const id = 'cap-' + (++seq);
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(Object.assign(new Error('宿主没有回话（' + method + ' 超时 ' + limit + 'ms）'), { code: 'E_CAP_TIMEOUT' }));
    }, limit);
    pending.set(id, { resolve, reject, timer });
    write({ id, method, params });
  });

  /**
   * init 之后读一次凭据库。E_CAP（没声明/宿主未实现）、超时、空值一律降级成匿名：
   * 读公开作品不需要 Key，绝不能因为凭据问题让查询失败或卡住。
   * 一个进程只读一次；probe 更是一次都不读（那是控制台设置页卡 3 秒的根因）。
   */
  // 只在「宿主声明了 secrets + 填了用户名」时才碰凭据库：
  //   · 宿主没声明 → 问了也是一条 denied，白白浪费一次往返；
  //   · 没用户名 → Basic 头拼不出来（username:apiKey），Key 单独没有意义。
  const secretsWanted = () => {
    const caps = Array.isArray(initParams?.capabilities) ? initParams.capabilities : null;
    if (caps && caps.length && !caps.includes('secrets')) return false;
    return String(settingsFromInit?.username ?? '').trim() !== '';
  };

  const loadApiKey = () => {
    if (secretPromise) return secretPromise;
    secretPromise = (async () => {
      if (!secretsWanted()) return '';
      try {
        const result = await capCall('cap.secrets.get', {}, STORAGE_TIMEOUT_MS);
        const values = isPlainObject(result?.values) ? result.values : (isPlainObject(result) ? result : {});
        const key = firstString(values.apiKey);
        if (key) secretApiKey = key;
      } catch {
        secretApiKey = ''; // 降级匿名，不报错
      }
      return secretApiKey;
    })();
    return secretPromise;
  };

  /**
   * init 之后异步读一次 diag:v1（上次是挑战页还是硬封、另一个站那次多少）。
   * 只写模块快照，probe 之后同步读快照 —— 控制台点「检测」不许再等任何 cap。
   */
  const loadDiag = async () => {
    try {
      const result = await capCall('cap.storage.get', { key: DIAG_KEY }, STORAGE_TIMEOUT_MS);
      setDiagSnapshot(isPlainObject(result) ? result.value : null);
    } catch { /* 读不到就当没有上次记录 */ }
  };

  const readSettings = async (budgetMs) => {
    if (settings) return settings;
    // 读配置也算在 15 秒预算里：给了剩余预算就按它收敛，别一律用满 2500ms
    const want = Number(budgetMs);
    const limit = Number.isFinite(want) && want > 0 ? Math.min(STORAGE_TIMEOUT_MS, Math.max(300, want)) : STORAGE_TIMEOUT_MS;
    try {
      const result = await capCall('cap.config.get', {}, limit);
      const fromHost = isPlainObject(result) && isPlainObject(result.settings) ? result.settings : null;
      settings = fromHost || (isPlainObject(settingsFromInit) ? settingsFromInit : {});
    } catch {
      settings = isPlainObject(settingsFromInit) ? settingsFromInit : {};
    }
    return settings;
  };

  /**
   * 设置页「检测登录」：未配置凭据 = 零 cap 秒回；配置了凭据 = 有界实测一次（≤1200ms，结果缓存 10 分钟）。
   * 凭据是从共享凭据库异步读的：只在这时等最多 250ms，且这段时间算在 1200ms 预算里（总时长仍然有界）。
   */
  const handleProbe = async (msg) => {
    const startedAt = Date.now();
    let payload;
    try {
      if (secretsWanted()) await Promise.race([loadApiKey(), sleep(250)]);
      payload = await probeInfoAsync(settingsFromInit, {
        enabled,
        apiKey: secretApiKey,
        cap: capCall,
        budgetMs: Math.max(400, PROBE_LOGIN_BUDGET_MS - (Date.now() - startedAt))
      });
    } catch (error) {
      payload = fail('E_CAP', '自检失败：' + safeSlice(String(error?.message || error), 200));
    }
    reply(msg, payload);
  };

  const handleCallTool = async (msg) => {
    let result;
    // ⚠️ 预算从这一行开始算：读设置（≤2500ms）与读凭据（≤1500ms）也在 15 秒里。
    // 以前 deadline 在 preamble 之后才设，等于把 preamble 花掉的时间白送给工具调用。
    const deadline = Date.now() + BUDGET_MS;
    const preambleLeft = () => Math.max(0, deadline - Date.now() - RESERVE_MS);
    try {
      // preamble 两步各自按剩余预算收敛；预算耗尽就带降级结果返回，不再发请求
      const config = preambleLeft() > 0 ? await readSettings(preambleLeft()) : {};
      // 凭据读取有上限：宿主没回话也照常匿名查询，别把工具调用拖死
      if (preambleLeft() > 0) await Promise.race([loadApiKey(), sleep(Math.min(1500, preambleLeft()))]);
      const ctx = makeContext(config, {
        cap: capCall,
        apiKey: secretApiKey,
        context: isPlainObject(msg.params?.context) ? msg.params.context : {}
      });
      ctx.deadline = deadline;
      result = preambleLeft() > 0
        ? await runTool(ctx, msg.params?.name, isPlainObject(msg.params?.args) ? msg.params.args : {})
        : fail('E_NETWORK', '15 秒预算在读设置/读凭据时就用完了（宿主没有回话）：这次没有发请求，稍后再试，或把 count 调小。');
    } catch (error) {
      result = fail('E_CAP', '插件内部出错：' + safeSlice(String(error?.message || error), 200));
    }
    reply(msg, result);
  };

  const onMessage = (msg) => {
    if (!msg || typeof msg !== 'object') return;
    if (typeof msg.id === 'string' && pending.has(msg.id)) {
      const entry = pending.get(msg.id);
      pending.delete(msg.id);
      clearTimeout(entry.timer);
      if (msg.error) {
        entry.reject(Object.assign(new Error(String(msg.error.message || '能力调用失败')), { code: String(msg.error.code || 'E_CAP') }));
      } else {
        entry.resolve(msg.result ?? null);
      }
      return;
    }
    switch (msg.method) {
      case 'init':
        settingsFromInit = isPlainObject(msg.params?.settings) ? msg.params.settings : {};
        initParams = isPlainObject(msg.params) ? msg.params : null;
        if (msg.params?.enabled !== undefined) enabled = msg.params.enabled !== false;
        else enabled = true;
        settings = null; // 重新握手就重读配置
        secretApiKey = '';
        secretPromise = null;
        reply(msg, { ok: true });
        void loadApiKey(); // 只读一次；失败/无凭据 = 匿名，不报错不阻塞
        void loadDiag();   // 异步读一次「上次出口状态」；不阻塞 init 回执，读不到就当没有
        return;
      case 'ping':
        reply(msg, { ok: true });
        return;
      case 'probe':
        // ⚠️ 不在这里 await：stdin 读循环必须立刻返回，实测放到 handleProbe 里跑
        void handleProbe(msg);
        return;
      case 'shutdown':
        // 宿主退出时发的是**不带 id** 的 shutdown；无条件回执会序列化成 {"result":{}}，
        // 宿主侧记一条无法识别的消息（protocolErrors +1）。没有 id 就不回话，只退出。
        reply(msg, { ok: true });
        setTimeout(() => process.exit(0), 30);
        return;
      case 'callTool':
        void handleCallTool(msg);
        return;
      default:
        return; // 未声明/不认识的方法忽略，不回话
    }
  };

  const MAX_STDIN_BUFFER = 8 * 1024 * 1024; // 单行上限：宿主不可能发 8MB 的一行，超了就是脏数据
  let buffer = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (chunk) => {
    buffer += chunk;
    let index = buffer.indexOf('\n');
    while (index !== -1) {
      const line = buffer.slice(0, index).trim();
      buffer = buffer.slice(index + 1);
      if (line) {
        let parsed = null;
        try { parsed = JSON.parse(line); } catch { parsed = null; }
        if (parsed) onMessage(parsed);
      }
      index = buffer.indexOf('\n');
    }
    if (buffer.length > MAX_STDIN_BUFFER) {
      // 没有换行的残行会无限增长（宿主异常时整条流会灌进来），到上限就丢弃并留一条日志
      warn('stdin 缓冲超过 ' + MAX_STDIN_BUFFER + ' 字节还没收到换行，已丢弃这段残行');
      buffer = '';
    }
  });
  process.stdin.on('error', (error) => warn('stdin 出错：' + (error?.message || error)));
  process.on('uncaughtException', (error) => warn('未捕获异常（已忽略，进程继续）：' + (error?.message || error)));
  process.on('unhandledRejection', (error) => warn('未处理的 Promise 拒绝（已忽略）：' + (error?.message || error)));
}

if (isMainModule()) main();
