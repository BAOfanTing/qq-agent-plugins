# 热点（hot-topics）

抓科技圈当下的热帖榜，整理成"标题 + 链接 + 热度"几行，模型可以直接照着念给群里听。

- 工具：`hot-topics.list`
  - 参数：`source`（可选，`v2ex` 默认 / `hn`）、`limit`（可选，默认 5，最多 20）
- 数据源（**两个都不需要 Key**）：
  - V2EX 热帖：`https://www.v2ex.com/api/topics/hot.json`
  - Hacker News 头条：`https://hacker-news.firebaseio.com/v0/topstories.json`
    （先取 id 榜，再逐条取 `item/<id>.json` 详情；这些详情是并行取的）

## 装

控制台左侧「插件」→ 目录里点安装 → 点启用（装上 ≠ 授权）。

## 配置（可选，主要给测试/镜像用）

```json
{
  "plugins": {
    "settings": {
      "hot-topics": {
        "v2exUrl": "https://www.v2ex.com/api/topics/hot.json",
        "hnApiBase": "https://hacker-news.firebaseio.com/v0"
      }
    }
  }
}
```

- `v2exUrl`：覆盖 V2EX 热帖地址。
- `hnApiBase`：覆盖 HN 接口根（`/topstories.json` 与 `/item/<id>.json` 会拼在它后面）。

**把这两个值指到内网地址会被宿主的网络守卫拦下**（`cap.http.request` 禁内网/本机），
这是有意的：插件不许绕过宿主自己上网。

## 它不做什么

- 只读查询，不写任何东西，也不能在群里发言（`capabilities` 里没有 `send`）。
- 不做全文抓取、不做摘要、不做定时播报：只把榜单整理好给模型，**怎么写由模型决定**
  （想每天固定播报要等 v1.1 的 `send` 能力）。
- 不保证时效排名与 V2EX/HN 页面完全一致：读的是它们的公开接口。
- 上游挂了/改接口了会返回可读错误（例如"HN 的条目详情一条都没取到"），不会静默给一个空榜。
