# 热点（hot-topics）

科技圈当时在聊什么 —— 抓 V2EX 或 Hacker News 的热帖榜，整理成「标题 + 链接 + 热度」几行，
模型可以直接念给群里听。两个源都**不需要 Key**。

## 群里可以这么问

- 「今天有啥热点」
- 「V2EX 现在在聊什么」
- 「HN 头条前五条」

模型会调 `hot-topics__list`（`source` 可选 `v2ex` 默认 / `hn`，`limit` 默认 5、最多 20）。

## 它给出什么

每一条：标题、链接、热度（回复数 / 分数）。不会抓正文，也不会替你写摘要 —— 怎么念由模型决定。

## 配置（可选，主要给测试 / 镜像用）

```json
{
  "plugins": {
    "settings": {
      "hot-topics": {
        "v2exUrl": "https://www.v2ex.com/api/topics/hot.json",
        "hnApiBase": "https://hacker-news.firebaseio.com/v0"
      }
    }
  }
}
```

- `v2exUrl`：覆盖 V2EX 热帖地址
- `hnApiBase`：覆盖 HN 接口根（`/topstories.json` 与 `/item/<id>.json` 会拼在它后面）

**指到内网地址会被宿主的网络守卫拦下** —— 这是有意的：插件不许绕过宿主自己上网。

## 边界

- **只读**，不写任何东西，也不能在群里发言（没有 `send`）。
- 不做全文抓取、不做摘要、不做定时播报（想每天固定播报要等 v1.1 的 `send`）。
- 排序与 V2EX / HN 页面不一定逐条一致：读的是它们的公开接口。
- 上游挂了或改接口会返回可读错误（例如「HN 的条目详情一条都没取到」），不会静默给一个空榜。

## 装

控制台左侧「插件」→ 目录里点安装 → 点启用（装上 ≠ 授权）。手工的话把本目录拷到
`$DATA_DIR/plugins/hot-topics/`。
