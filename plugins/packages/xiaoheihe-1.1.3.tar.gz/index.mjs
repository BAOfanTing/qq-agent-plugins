// 小黑盒 · qq-agent-plus 插件（apiVersion 2）· 单文件、零第三方依赖、不写文件、不 spawn
//
// 三层，从上到下：
//   createTransport —— stdin/stdout 行协议、init/probe/ping/schedule/shutdown 分发、cap 调用回执配对
//   createRouter    —— 参数守卫 + 错误码映射 + 工具表（每个工具=一次预算内的编排）
//   业务纯函数      —— hkey 签名、响应分类、feedRow/linkRow/userRow/commentRow、htmlToText（可直接单测）
//
// 关于小黑盒的三个真实事实（抓包核对过，别再推翻）：
//   1) www.xiaoheihe.cn 是纯 SPA，没有 SSR；数据一律走 https://api.xiaoheihe.cn。
//   2) 每个请求都要 hkey / _time / nonce 三件套。hkey 的 7 位（5 位映射 + 2 位校验和）
//      已从站点 bundle 里还原，三份真实抓包逐字节一致（见 hkeyChecksum 的向量单测）。
//   3) 失败有三种形态，必须分开：45-52 字节「非法请求」= 服务端不接受这次请求（签名不对，
//      或这台 IP 被临时限流）；92 字节「验证参数错误」= 签名已过、是参数不对；
//      {"status":"show_captcha"} = 腾讯验证码。合成一个「网络错误」就是骗模型。
//
// 关于「限流」：这是预防性设置，不是已知故障。1.0.1 及更早版本的 hkey 校验和算错，服务端一律回
// 「非法请求」，那被误当成了产品限制；签名修好后 feeds / 帖子详情 / 搜索 / 用户主页在真机上都能用。
// 现在仍然进程内串行 + 间隔 >= 1200ms（settings 可调 500-5000）+ feeds 缓存 60s（可调），
// 只是让请求节奏贴近手刷，别把正常流程打成高频调用。
import crypto from 'node:crypto';
import process from 'node:process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const PLUGIN_ID = 'xiaoheihe';
export const PLUGIN_VERSION = '1.1.3';

const API_BASE = 'https://api.xiaoheihe.cn';
const SITE = 'https://www.xiaoheihe.cn';
// 宿主对一次 callTool 的硬超时是 20s；自留 15s，第一行就设，早于任何 await。
const CALL_BUDGET_MS = 15000;
// 宿主算 min(maxChars, httpMaxBytes)。传小值会静默切尾且 truncated=false，所以传满。
const HTTP_MAX_CHARS = 524288;
// 图片双判的下限：错误页常见 162 字节 text/html，也可能 0 字节。
const MEDIA_MIN_BYTES = 1024;
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
const DEVICE_KEY = 'deviceId';
const DEGRADE_KEY = 'sendDegrade';
const DEGRADE_BASE_MS = 30 * 60 * 1000;
const DEGRADE_MAX_MS = 12 * 60 * 60 * 1000;

export const XHH_CODES = Object.freeze({
  GATED: 'XHH_GATED',
  CAPTCHA: 'XHH_CAPTCHA',
  BAD_PARAM: 'XHH_BAD_PARAM',
  RATE: 'XHH_RATE',
  NO_LOGIN: 'XHH_NO_LOGIN',
  UPSTREAM: 'XHH_UPSTREAM',
  TRUNCATED: 'XHH_TRUNCATED',
  BUDGET: 'XHH_BUDGET',
  BAD_ARG: 'XHH_BAD_ARG',
  STORAGE: 'XHH_STORAGE',
  // 登录态失效（restore_login 的 status:"relogin"），与「没配 cookie」分开
  RELOGIN: 'XHH_RELOGIN',
  // 权限不足（只有管理员能扫码登录；群聊里不许发起）
  DENIED: 'XHH_DENIED'
});

export function xhhError(code, message) {
  const error = new Error(String(message || code));
  error.code = String(code || XHH_CODES.UPSTREAM);
  return error;
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// ════════════════════════════════════════════════════════════════════════
// 一、签名（纯函数）：hkey = hkeyPrefix(digest) + hkeyChecksum(digest)
// ════════════════════════════════════════════════════════════════════════
const CS = 'AB45STUVWZEFGJ6CH01D237IXYPQRKLMN89';

function fieldMul(byte) {
  return (byte & 128) ? (255 & ((byte << 1) ^ 27)) : (byte << 1);
}
function f1(byte) { return fieldMul(byte) ^ byte; }
function f2(byte) { return f1(fieldMul(byte)); }
function f3(byte) { return f2(f1(fieldMul(byte))); }
function f4(byte) { return f3(byte) ^ f2(byte) ^ f1(byte); }

/** 末校验和用的四路混合（与参考实现同构）。 */
export function mixBytes(bytes) {
  const src = Array.isArray(bytes) ? bytes : [];
  const out = [0, 0, 0, 0];
  out[0] = f4(src[0]) ^ f3(src[1]) ^ f2(src[2]) ^ f1(src[3]);
  out[1] = f1(src[0]) ^ f4(src[1]) ^ f3(src[2]) ^ f2(src[3]);
  out[2] = f2(src[0]) ^ f1(src[1]) ^ f4(src[2]) ^ f3(src[3]);
  out[3] = f3(src[0]) ^ f2(src[1]) ^ f1(src[2]) ^ f4(src[3]);
  return out;
}

/** 把一个字符串按字符码映射进 CS；width 为负表示 CS.slice(0, width)。 */
function mapChars(text, width) {
  const alphabet = width < 0 ? CS.slice(0, width) : CS;
  let out = '';
  for (const ch of String(text)) out += alphabet[ch.charCodeAt(0) % alphabet.length];
  return out;
}

/** 路径归一化：去空段 + 补尾斜杠（"/bbs/app/feeds" -> "/bbs/app/feeds/"）。 */
export function normalizePath(pathname) {
  const raw = String(pathname == null ? '' : pathname).split('?')[0];
  const segments = raw.split('/').filter(Boolean);
  if (!segments.length) throw xhhError(XHH_CODES.BAD_ARG, '签名路径不能为空');
  return '/' + segments.join('/') + '/';
}

/**
 * 三段交织后取前 20 字符做 md5（小写 hex）——完全照抄已验证的参考实现。
 *
 * 一个必须知道的性质：时间戳 10 字符 + 路径 + nonce 32 字符交织时，前 20 字符只覆盖到
 * 第 7 列，也就是「时间戳前 7 位 + 路径前 7 字符 + nonce 前 7 字符」。所以 /bbs/app/ 下
 * 各端点在同一个 nonce 下 hkey 相同，而改时间戳末位不会改变 hkey。这是站点 bundle 里 Tr()
 * 的真实行为（被真实服务端接受过，/bbs/app/feeds 返回 91KB 真数据），不是近似。
 */
export function hkeyDigest(pathname, ts, nonce) {
  const target = normalizePath(pathname);
  const parts = [mapChars(String(ts), -2), mapChars(target, 0), mapChars(nonce, 0)];
  const widest = Math.max(...parts.map((item) => item.length));
  let interleaved = '';
  for (let col = 0; col < widest; col += 1) {
    for (const part of parts) if (col < part.length) interleaved += part[col];
  }
  return crypto.createHash('md5').update(interleaved.slice(0, 20)).digest('hex');
}

/** hkey 的前 5 位：与浏览器抓包逐字节一致（SZ21D / SDU23 / 2PT1X）。 */
export function hkeyPrefix(digest) {
  return mapChars(String(digest == null ? '' : digest).slice(0, 5), -4);
}

/**
 * hkey 的末 2 位校验和 —— 站点 bundle 里 Tr() 的最后一步。
 *
 * 关键细节：四路混合（mixBytes）只就地改写前 4 个元素，但求和要遍历**整条 6 元素数组**，
 * 即第 5、6 个 hex 字符的 charCode 原样参与相加。只把 4 个改写值相加会得到错的校验和
 * （旧实现 82 / 66 / 74，浏览器是 31 / 20 / 71，于是所有请求被判「非法请求」）。
 *
 * 三条真实抓包向量（selftest 逐条断言）：
 *   /bbs/app/link/tree             ts=1793106243 nonce=3B389C30B51878A699BDA08E9B3C687F -> SZ21D31
 *   /bbs/app/api/general/search/v1 ts=1793106281 nonce=1804B3125724785F4B74DCB003E4E033 -> SDU2320
 *   /bbs/app/feeds                 ts=1793106367 nonce=972D0954DC003EBC582B9C614D1CE565 -> 2PT1X71
 */
export function hkeyChecksum(digest) {
  const tail = Array.from(String(digest == null ? '' : digest).slice(-6)).map((ch) => ch.charCodeAt(0));
  const sum = mixBytes(tail.slice(0, 4)).concat(tail.slice(4)).reduce((acc, item) => acc + item, 0) % 100;
  return String(sum).padStart(2, '0');
}

export function hkey(pathname, ts, nonce) {
  const digest = hkeyDigest(pathname, ts, nonce);
  return hkeyPrefix(digest) + hkeyChecksum(digest);
}

/** 32 位大写 hex。 */
export function mkNonce() {
  return crypto.createHash('md5')
    .update(String(Date.now()) + ':' + crypto.randomBytes(12).toString('hex'))
    .digest('hex')
    .toUpperCase();
}

/** 32 位小写 hex 的设备号；不写死任何别人的常量。 */
export function mkDeviceId() {
  return crypto.randomBytes(16).toString('hex');
}

/** 公共 Query（真实抓包照抄）；heybox_id 只有登录后才知道，未知时留空。 */
export function buildQuery(options) {
  const spec = options || {};
  const pathname = String(spec.path || '');
  const ts = Number(spec.ts) || Math.floor(Date.now() / 1000);
  const nonce = String(spec.nonce || mkNonce());
  const extra = spec.params && typeof spec.params === 'object' && !Array.isArray(spec.params) ? spec.params : {};
  const pairs = [];
  const push = (key, value) => {
    if (value === undefined || value === null) return;
    pairs.push([key, String(value)]);
  };
  // 实测：扫码取码/轮询的 app=web，restore_login 的 app=heybox —— 别混
  push('app', spec.app || 'heybox');
  push('heybox_id', spec.uid || '');
  push('os_type', 'web');
  push('x_app', 'heybox_website');
  push('x_client_type', 'web');
  push('x_os_type', 'Windows');
  push('x_client_version', '');
  push('client_type', 'web');
  push('web_version', '3.0');
  push('version', '999.0.4');
  if (spec.deviceId) push('device_id', spec.deviceId);
  for (const [key, value] of Object.entries(extra)) push(key, value);
  push('hkey', hkey(pathname, ts, nonce));
  push('_time', ts);
  push('nonce', nonce);
  // 只有评论接口要 _rnd；它和 hkey/_time/nonce 同级，放在最后
  if (spec.rnd === true) push('_rnd', rndSignature(nonce, ts));
  return pairs.map(([key, value]) => encodeURIComponent(key) + '=' + encodeURIComponent(value)).join('&');
}

// ── 二维码：移植自 kazuhikoarase/qrcode-generator（MIT）──────────────
// 只保留字节模式 + L/M 纠错 + 自动版本；不引第三方、不落文件。
// 参照实现见 .work/xhh/qrcode.js（同一份 MIT 代码），selftest 逐位比对模块矩阵。
const QR_PATTERN_POSITION = [
      [],
      [6, 18],
      [6, 22],
      [6, 26],
      [6, 30],
      [6, 34],
      [6, 22, 38],
      [6, 24, 42],
      [6, 26, 46],
      [6, 28, 50],
      [6, 30, 54],
      [6, 32, 58],
      [6, 34, 62],
      [6, 26, 46, 66],
      [6, 26, 48, 70],
      [6, 26, 50, 74],
      [6, 30, 54, 78],
      [6, 30, 56, 82],
      [6, 30, 58, 86],
      [6, 34, 62, 90],
      [6, 28, 50, 72, 94],
      [6, 26, 50, 74, 98],
      [6, 30, 54, 78, 102],
      [6, 28, 54, 80, 106],
      [6, 32, 58, 84, 110],
      [6, 30, 58, 86, 114],
      [6, 34, 62, 90, 118],
      [6, 26, 50, 74, 98, 122],
      [6, 30, 54, 78, 102, 126],
      [6, 26, 52, 78, 104, 130],
      [6, 30, 56, 82, 108, 134],
      [6, 34, 60, 86, 112, 138],
      [6, 30, 58, 86, 114, 142],
      [6, 34, 62, 90, 118, 146],
      [6, 30, 54, 78, 102, 126, 150],
      [6, 24, 50, 76, 102, 128, 154],
      [6, 28, 54, 80, 106, 132, 158],
      [6, 32, 58, 84, 110, 136, 162],
      [6, 26, 54, 82, 110, 138, 166],
      [6, 30, 58, 86, 114, 142, 170]
    ];

const QR_RS_BLOCK = [

      // L
      // M
      // Q
      // H

      // 1
      [1, 26, 19],
      [1, 26, 16],
      [1, 26, 13],
      [1, 26, 9],

      // 2
      [1, 44, 34],
      [1, 44, 28],
      [1, 44, 22],
      [1, 44, 16],

      // 3
      [1, 70, 55],
      [1, 70, 44],
      [2, 35, 17],
      [2, 35, 13],

      // 4
      [1, 100, 80],
      [2, 50, 32],
      [2, 50, 24],
      [4, 25, 9],

      // 5
      [1, 134, 108],
      [2, 67, 43],
      [2, 33, 15, 2, 34, 16],
      [2, 33, 11, 2, 34, 12],

      // 6
      [2, 86, 68],
      [4, 43, 27],
      [4, 43, 19],
      [4, 43, 15],

      // 7
      [2, 98, 78],
      [4, 49, 31],
      [2, 32, 14, 4, 33, 15],
      [4, 39, 13, 1, 40, 14],

      // 8
      [2, 121, 97],
      [2, 60, 38, 2, 61, 39],
      [4, 40, 18, 2, 41, 19],
      [4, 40, 14, 2, 41, 15],

      // 9
      [2, 146, 116],
      [3, 58, 36, 2, 59, 37],
      [4, 36, 16, 4, 37, 17],
      [4, 36, 12, 4, 37, 13],

      // 10
      [2, 86, 68, 2, 87, 69],
      [4, 69, 43, 1, 70, 44],
      [6, 43, 19, 2, 44, 20],
      [6, 43, 15, 2, 44, 16],

      // 11
      [4, 101, 81],
      [1, 80, 50, 4, 81, 51],
      [4, 50, 22, 4, 51, 23],
      [3, 36, 12, 8, 37, 13],

      // 12
      [2, 116, 92, 2, 117, 93],
      [6, 58, 36, 2, 59, 37],
      [4, 46, 20, 6, 47, 21],
      [7, 42, 14, 4, 43, 15],

      // 13
      [4, 133, 107],
      [8, 59, 37, 1, 60, 38],
      [8, 44, 20, 4, 45, 21],
      [12, 33, 11, 4, 34, 12],

      // 14
      [3, 145, 115, 1, 146, 116],
      [4, 64, 40, 5, 65, 41],
      [11, 36, 16, 5, 37, 17],
      [11, 36, 12, 5, 37, 13],

      // 15
      [5, 109, 87, 1, 110, 88],
      [5, 65, 41, 5, 66, 42],
      [5, 54, 24, 7, 55, 25],
      [11, 36, 12, 7, 37, 13],

      // 16
      [5, 122, 98, 1, 123, 99],
      [7, 73, 45, 3, 74, 46],
      [15, 43, 19, 2, 44, 20],
      [3, 45, 15, 13, 46, 16],

      // 17
      [1, 135, 107, 5, 136, 108],
      [10, 74, 46, 1, 75, 47],
      [1, 50, 22, 15, 51, 23],
      [2, 42, 14, 17, 43, 15],

      // 18
      [5, 150, 120, 1, 151, 121],
      [9, 69, 43, 4, 70, 44],
      [17, 50, 22, 1, 51, 23],
      [2, 42, 14, 19, 43, 15],

      // 19
      [3, 141, 113, 4, 142, 114],
      [3, 70, 44, 11, 71, 45],
      [17, 47, 21, 4, 48, 22],
      [9, 39, 13, 16, 40, 14],

      // 20
      [3, 135, 107, 5, 136, 108],
      [3, 67, 41, 13, 68, 42],
      [15, 54, 24, 5, 55, 25],
      [15, 43, 15, 10, 44, 16],

      // 21
      [4, 144, 116, 4, 145, 117],
      [17, 68, 42],
      [17, 50, 22, 6, 51, 23],
      [19, 46, 16, 6, 47, 17],

      // 22
      [2, 139, 111, 7, 140, 112],
      [17, 74, 46],
      [7, 54, 24, 16, 55, 25],
      [34, 37, 13],

      // 23
      [4, 151, 121, 5, 152, 122],
      [4, 75, 47, 14, 76, 48],
      [11, 54, 24, 14, 55, 25],
      [16, 45, 15, 14, 46, 16],

      // 24
      [6, 147, 117, 4, 148, 118],
      [6, 73, 45, 14, 74, 46],
      [11, 54, 24, 16, 55, 25],
      [30, 46, 16, 2, 47, 17],

      // 25
      [8, 132, 106, 4, 133, 107],
      [8, 75, 47, 13, 76, 48],
      [7, 54, 24, 22, 55, 25],
      [22, 45, 15, 13, 46, 16],

      // 26
      [10, 142, 114, 2, 143, 115],
      [19, 74, 46, 4, 75, 47],
      [28, 50, 22, 6, 51, 23],
      [33, 46, 16, 4, 47, 17],

      // 27
      [8, 152, 122, 4, 153, 123],
      [22, 73, 45, 3, 74, 46],
      [8, 53, 23, 26, 54, 24],
      [12, 45, 15, 28, 46, 16],

      // 28
      [3, 147, 117, 10, 148, 118],
      [3, 73, 45, 23, 74, 46],
      [4, 54, 24, 31, 55, 25],
      [11, 45, 15, 31, 46, 16],

      // 29
      [7, 146, 116, 7, 147, 117],
      [21, 73, 45, 7, 74, 46],
      [1, 53, 23, 37, 54, 24],
      [19, 45, 15, 26, 46, 16],

      // 30
      [5, 145, 115, 10, 146, 116],
      [19, 75, 47, 10, 76, 48],
      [15, 54, 24, 25, 55, 25],
      [23, 45, 15, 25, 46, 16],

      // 31
      [13, 145, 115, 3, 146, 116],
      [2, 74, 46, 29, 75, 47],
      [42, 54, 24, 1, 55, 25],
      [23, 45, 15, 28, 46, 16],

      // 32
      [17, 145, 115],
      [10, 74, 46, 23, 75, 47],
      [10, 54, 24, 35, 55, 25],
      [19, 45, 15, 35, 46, 16],

      // 33
      [17, 145, 115, 1, 146, 116],
      [14, 74, 46, 21, 75, 47],
      [29, 54, 24, 19, 55, 25],
      [11, 45, 15, 46, 46, 16],

      // 34
      [13, 145, 115, 6, 146, 116],
      [14, 74, 46, 23, 75, 47],
      [44, 54, 24, 7, 55, 25],
      [59, 46, 16, 1, 47, 17],

      // 35
      [12, 151, 121, 7, 152, 122],
      [12, 75, 47, 26, 76, 48],
      [39, 54, 24, 14, 55, 25],
      [22, 45, 15, 41, 46, 16],

      // 36
      [6, 151, 121, 14, 152, 122],
      [6, 75, 47, 34, 76, 48],
      [46, 54, 24, 10, 55, 25],
      [2, 45, 15, 64, 46, 16],

      // 37
      [17, 152, 122, 4, 153, 123],
      [29, 74, 46, 14, 75, 47],
      [49, 54, 24, 10, 55, 25],
      [24, 45, 15, 46, 46, 16],

      // 38
      [4, 152, 122, 18, 153, 123],
      [13, 74, 46, 32, 75, 47],
      [48, 54, 24, 14, 55, 25],
      [42, 45, 15, 32, 46, 16],

      // 39
      [20, 147, 117, 4, 148, 118],
      [40, 75, 47, 7, 76, 48],
      [43, 54, 24, 22, 55, 25],
      [10, 45, 15, 67, 46, 16],

      // 40
      [19, 148, 118, 6, 149, 119],
      [18, 75, 47, 31, 76, 48],
      [34, 54, 24, 34, 55, 25],
      [20, 45, 15, 61, 46, 16]
    ];

const QR_LEVEL_OFFSET = { L: 0, M: 1, Q: 2, H: 3 };
const QR_LEVEL_BITS = { L: 1, M: 0, Q: 3, H: 2 };

const QR_EXP = new Array(256);
const QR_LOG = new Array(256);
(() => {
  let x = 1;
  for (let i = 0; i < 255; i += 1) { QR_EXP[i] = x; QR_LOG[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; }
  QR_EXP[255] = QR_EXP[0];
})();
function qrGexp(n) { while (n < 0) n += 255; while (n >= 255) n -= 255; return QR_EXP[n]; }
function qrGlog(n) { if (n < 1) throw new Error('qr glog(' + n + ')'); return QR_LOG[n]; }

class QrPoly {
  constructor(num, shift) {
    let offset = 0;
    while (offset < num.length && num[offset] === 0) offset += 1;
    this.num = new Array(num.length - offset + shift).fill(0);
    for (let i = 0; i < num.length - offset; i += 1) this.num[i] = num[i + offset];
  }
  get(i) { return this.num[i]; }
  getLength() { return this.num.length; }
  multiply(e) {
    const num = new Array(this.getLength() + e.getLength() - 1).fill(0);
    for (let i = 0; i < this.getLength(); i += 1) {
      for (let j = 0; j < e.getLength(); j += 1) num[i + j] ^= qrGexp(qrGlog(this.get(i)) + qrGlog(e.get(j)));
    }
    return new QrPoly(num, 0);
  }
  mod(e) {
    if (this.getLength() - e.getLength() < 0) return this;
    const ratio = qrGlog(this.get(0)) - qrGlog(e.get(0));
    const num = new Array(this.getLength());
    for (let i = 0; i < this.getLength(); i += 1) num[i] = this.get(i);
    for (let i = 0; i < e.getLength(); i += 1) num[i] ^= qrGexp(qrGlog(e.get(i)) + ratio);
    return new QrPoly(num, 0).mod(e);
  }
}

class QrBuffer {
  constructor() { this.buffer = []; this.length = 0; }
  get(i) { return ((this.buffer[Math.floor(i / 8)] >>> (7 - (i % 8))) & 1) === 1; }
  put(num, length) { for (let i = 0; i < length; i += 1) this.putBit(((num >>> (length - i - 1)) & 1) === 1); }
  getLengthInBits() { return this.length; }
  putBit(bit) {
    const index = Math.floor(this.length / 8);
    if (this.buffer.length <= index) this.buffer.push(0);
    if (bit) this.buffer[index] |= 0x80 >>> (this.length % 8);
    this.length += 1;
  }
}

function qrRsBlocks(typeNumber, level) {
  const table = QR_RS_BLOCK[(typeNumber - 1) * 4 + QR_LEVEL_OFFSET[level]];
  if (!table) throw new Error('qr 没有 typeNumber=' + typeNumber + ' / level=' + level + ' 的 RS 块');
  const list = [];
  for (let i = 0; i < table.length / 3; i += 1) {
    list.push({ totalCount: table[i * 3 + 1], dataCount: table[i * 3 + 2], count: table[i * 3] });
  }
  const out = [];
  for (const block of list) for (let n = 0; n < block.count; n += 1) out.push(block);
  return out;
}

function qrBchDigit(data) { let digit = 0; while (data !== 0) { digit += 1; data >>>= 1; } return digit; }
const QR_G15 = (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | 1;
const QR_G18 = (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | 1;
const QR_G15_MASK = (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1);
function qrBchTypeInfo(data) {
  let d = data << 10;
  while (qrBchDigit(d) - qrBchDigit(QR_G15) >= 0) d ^= QR_G15 << (qrBchDigit(d) - qrBchDigit(QR_G15));
  return ((data << 10) | d) ^ QR_G15_MASK;
}
function qrBchTypeNumber(data) {
  let d = data << 12;
  while (qrBchDigit(d) - qrBchDigit(QR_G18) >= 0) d ^= QR_G18 << (qrBchDigit(d) - qrBchDigit(QR_G18));
  return (data << 12) | d;
}
function qrMask(pattern, i, j) {
  switch (pattern) {
    case 0: return (i + j) % 2 === 0;
    case 1: return i % 2 === 0;
    case 2: return j % 3 === 0;
    case 3: return (i + j) % 3 === 0;
    case 4: return (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0;
    case 5: return ((i * j) % 2) + ((i * j) % 3) === 0;
    case 6: return (((i * j) % 2) + ((i * j) % 3)) % 2 === 0;
    case 7: return (((i * j) % 3) + ((i + j) % 2)) % 2 === 0;
    default: throw new Error('bad maskPattern:' + pattern);
  }
}
function qrLengthInBits(mode, type) {
  if (type >= 1 && type < 10) return mode === 'byte' ? 8 : 0;
  if (type < 27) return mode === 'byte' ? 16 : 0;
  return mode === 'byte' ? 16 : 0;
}
function qrErrorCorrectPoly(count) {
  let poly = new QrPoly([1], 0);
  for (let i = 0; i < count; i += 1) poly = poly.multiply(new QrPoly([1, qrGexp(i)], 0));
  return poly;
}

/** 文本 -> UTF-8 字节（二维码一律按字节模式编码）。 */
function qrBytes(text) {
  return Array.from(Buffer.from(String(text), 'utf8'));
}

function qrCreateData(typeNumber, level, bytes) {
  const rsBlocks = qrRsBlocks(typeNumber, level);
  const buffer = new QrBuffer();
  buffer.put(4, 4);
  buffer.put(bytes.length, qrLengthInBits('byte', typeNumber));
  for (const b of bytes) buffer.put(b, 8);
  let totalDataCount = 0;
  for (const block of rsBlocks) totalDataCount += block.dataCount;
  if (buffer.getLengthInBits() > totalDataCount * 8) throw new Error('qr 数据超长(' + buffer.getLengthInBits() + '>' + totalDataCount * 8 + ')');
  if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) buffer.put(0, 4);
  while (buffer.getLengthInBits() % 8 !== 0) buffer.putBit(false);
  for (;;) {
    if (buffer.getLengthInBits() >= totalDataCount * 8) break;
    buffer.put(0xec, 8);
    if (buffer.getLengthInBits() >= totalDataCount * 8) break;
    buffer.put(0x11, 8);
  }
  return qrCreateBytes(buffer, rsBlocks);
}

function qrCreateBytes(buffer, rsBlocks) {
  let offset = 0;
  let maxDc = 0;
  let maxEc = 0;
  const dcdata = new Array(rsBlocks.length);
  const ecdata = new Array(rsBlocks.length);
  for (let r = 0; r < rsBlocks.length; r += 1) {
    const dcCount = rsBlocks[r].dataCount;
    const ecCount = rsBlocks[r].totalCount - dcCount;
    maxDc = Math.max(maxDc, dcCount);
    maxEc = Math.max(maxEc, ecCount);
    dcdata[r] = new Array(dcCount);
    for (let i = 0; i < dcCount; i += 1) dcdata[r][i] = 0xff & buffer.buffer[i + offset];
    offset += dcCount;
    const rsPoly = qrErrorCorrectPoly(ecCount);
    const rawPoly = new QrPoly(dcdata[r], rsPoly.getLength() - 1);
    const modPoly = rawPoly.mod(rsPoly);
    ecdata[r] = new Array(rsPoly.getLength() - 1);
    for (let i = 0; i < ecdata[r].length; i += 1) {
      const index = i + modPoly.getLength() - ecdata[r].length;
      ecdata[r][i] = index >= 0 ? modPoly.get(index) : 0;
    }
  }
  let totalCodeCount = 0;
  for (const block of rsBlocks) totalCodeCount += block.totalCount;
  const data = new Array(totalCodeCount);
  let index = 0;
  for (let i = 0; i < maxDc; i += 1) for (let r = 0; r < rsBlocks.length; r += 1) if (i < dcdata[r].length) { data[index] = dcdata[r][i]; index += 1; }
  for (let i = 0; i < maxEc; i += 1) for (let r = 0; r < rsBlocks.length; r += 1) if (i < ecdata[r].length) { data[index] = ecdata[r][i]; index += 1; }
  return data;
}

function qrBestMask(typeNumber, level, data) {
  let best = 0;
  let min = null;
  for (let pattern = 0; pattern < 8; pattern += 1) {
    const model = qrBuildModules(typeNumber, level, data, true, pattern);
    const lost = qrLostPoint(model.modules, model.moduleCount);
    if (min === null || min > lost) { min = lost; best = pattern; }
  }
  return best;
}

function qrLostPoint(modules, moduleCount) {
  let lost = 0;
  for (let row = 0; row < moduleCount; row += 1) {
    for (let col = 0; col < moduleCount; col += 1) {
      let sameCount = 0;
      const dark = modules[row][col];
      for (let r = -1; r <= 1; r += 1) {
        if (row + r < 0 || moduleCount <= row + r) continue;
        for (let c = -1; c <= 1; c += 1) {
          if (col + c < 0 || moduleCount <= col + c) continue;
          if (r === 0 && c === 0) continue;
          if (dark === modules[row + r][col + c]) sameCount += 1;
        }
      }
      if (sameCount > 5) lost += 3 + sameCount - 5;
    }
  }
  for (let row = 0; row < moduleCount - 1; row += 1) {
    for (let col = 0; col < moduleCount - 1; col += 1) {
      let count = 0;
      if (modules[row][col]) count += 1;
      if (modules[row + 1][col]) count += 1;
      if (modules[row][col + 1]) count += 1;
      if (modules[row + 1][col + 1]) count += 1;
      if (count === 0 || count === 4) lost += 3;
    }
  }
  for (let row = 0; row < moduleCount; row += 1) {
    for (let col = 0; col < moduleCount - 6; col += 1) {
      if (modules[row][col] && !modules[row][col + 1] && modules[row][col + 2] && modules[row][col + 3]
        && modules[row][col + 4] && !modules[row][col + 5] && modules[row][col + 6]) lost += 40;
    }
  }
  for (let col = 0; col < moduleCount; col += 1) {
    for (let row = 0; row < moduleCount - 6; row += 1) {
      if (modules[row][col] && !modules[row + 1][col] && modules[row + 2][col] && modules[row + 3][col]
        && modules[row + 4][col] && !modules[row + 5][col] && modules[row + 6][col]) lost += 40;
    }
  }
  let darkCount = 0;
  for (let row = 0; row < moduleCount; row += 1) for (let col = 0; col < moduleCount; col += 1) if (modules[row][col]) darkCount += 1;
  lost += (Math.abs((100 * darkCount) / moduleCount / moduleCount - 50) / 5) * 10;
  return lost;
}

function qrBuildModules(typeNumber, level, data, test, maskPattern) {
  const moduleCount = typeNumber * 4 + 17;
  const modules = new Array(moduleCount);
  for (let row = 0; row < moduleCount; row += 1) modules[row] = new Array(moduleCount).fill(null);
  const setupProbe = (row, col) => {
    for (let r = -1; r <= 7; r += 1) {
      if (row + r <= -1 || moduleCount <= row + r) continue;
      for (let c = -1; c <= 7; c += 1) {
        if (col + c <= -1 || moduleCount <= col + c) continue;
        modules[row + r][col + c] = (r >= 0 && r <= 6 && (c === 0 || c === 6))
          || (c >= 0 && c <= 6 && (r === 0 || r === 6))
          || (r >= 2 && r <= 4 && c >= 2 && c <= 4);
      }
    }
  };
  setupProbe(0, 0);
  setupProbe(moduleCount - 7, 0);
  setupProbe(0, moduleCount - 7);
  const pos = QR_PATTERN_POSITION[typeNumber - 1];
  for (let i = 0; i < pos.length; i += 1) {
    for (let j = 0; j < pos.length; j += 1) {
      const row = pos[i];
      const col = pos[j];
      if (modules[row][col] !== null) continue;
      for (let r = -2; r <= 2; r += 1) {
        for (let c = -2; c <= 2; c += 1) {
          modules[row + r][col + c] = r === -2 || r === 2 || c === -2 || c === 2 || (r === 0 && c === 0);
        }
      }
    }
  }
  for (let r = 8; r < moduleCount - 8; r += 1) {
    if (modules[r][6] !== null) continue;
    modules[r][6] = r % 2 === 0;
  }
  for (let c = 8; c < moduleCount - 8; c += 1) {
    if (modules[6][c] !== null) continue;
    modules[6][c] = c % 2 === 0;
  }
  const bits = qrBchTypeInfo((QR_LEVEL_BITS[level] << 3) | maskPattern);
  for (let i = 0; i < 15; i += 1) {
    const mod = !test && ((bits >> i) & 1) === 1;
    if (i < 6) modules[i][8] = mod;
    else if (i < 8) modules[i + 1][8] = mod;
    else modules[moduleCount - 15 + i][8] = mod;
  }
  for (let i = 0; i < 15; i += 1) {
    const mod = !test && ((bits >> i) & 1) === 1;
    if (i < 8) modules[8][moduleCount - i - 1] = mod;
    else if (i < 9) modules[8][15 - i - 1 + 1] = mod;
    else modules[8][15 - i - 1] = mod;
  }
  modules[moduleCount - 8][8] = !test;
  if (typeNumber >= 7) {
    const tbits = qrBchTypeNumber(typeNumber);
    for (let i = 0; i < 18; i += 1) {
      const mod = !test && ((tbits >> i) & 1) === 1;
      modules[Math.floor(i / 3)][(i % 3) + moduleCount - 8 - 3] = mod;
      modules[(i % 3) + moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
    }
  }
  let inc = -1;
  let row = moduleCount - 1;
  let bitIndex = 7;
  let byteIndex = 0;
  for (let col = moduleCount - 1; col > 0; col -= 2) {
    if (col === 6) col -= 1;
    for (;;) {
      for (let c = 0; c < 2; c += 1) {
        if (modules[row][col - c] !== null) continue;
        let dark = false;
        if (byteIndex < data.length) dark = ((data[byteIndex] >>> bitIndex) & 1) === 1;
        if (qrMask(maskPattern, row, col - c)) dark = !dark;
        modules[row][col - c] = dark;
        bitIndex -= 1;
        if (bitIndex === -1) { byteIndex += 1; bitIndex = 7; }
      }
      row += inc;
      if (row < 0 || moduleCount <= row) { row -= inc; inc = -inc; break; }
    }
  }
  return { moduleCount, modules };
}

/** 文本 -> 模块矩阵（boolean[row][col]），自动选版本 1..39；level 取 L / M。 */
export function qrMatrix(text, level) {
  const ecLevel = level === 'M' ? 'M' : 'L';
  const bytes = qrBytes(text);
  let typeNumber = 1;
  for (; typeNumber < 40; typeNumber += 1) {
    const blocks = qrRsBlocks(typeNumber, ecLevel);
    let totalDataCount = 0;
    for (const block of blocks) totalDataCount += block.dataCount;
    if (qrLengthInBits('byte', typeNumber) + 4 + bytes.length * 8 <= totalDataCount * 8) break;
  }
  const data = qrCreateData(typeNumber, ecLevel, bytes);
  const mask = qrBestMask(typeNumber, ecLevel, data);
  return qrBuildModules(typeNumber, ecLevel, data, false, mask).modules;
}

/** 矩阵 -> 半块字符（█ ▀ ▄ 空格），默认留 2 模块静区，两个模块行合成一行文字。 */
export function qrText(matrix, quiet) {
  const border = quiet === undefined ? 2 : quiet;
  const size = matrix.length + border * 2;
  const dark = (r, c) => r >= border && c >= border && r - border < matrix.length && c - border < matrix.length
    && matrix[r - border][c - border] === true;
  const lines = [];
  for (let r = 0; r < size; r += 2) {
    let line = '';
    for (let c = 0; c < size; c += 1) {
      const top = dark(r, c);
      const bottom = r + 1 < size ? dark(r + 1, c) : false;
      line += top && bottom ? '█' : (top ? '▀' : (bottom ? '▄' : ' '));
    }
    lines.push(line);
  }
  return lines.join('\n');
}

/** 矩阵 -> SVG data URL（控制台 <img> 用）。 */
export function qrSvgDataUrl(matrix, quiet, cellSize) {
  const border = quiet === undefined ? 4 : quiet;
  const cell = cellSize || 4;
  const size = (matrix.length + border * 2) * cell;
  let path = '';
  for (let r = 0; r < matrix.length; r += 1) {
    for (let c = 0; c < matrix.length; c += 1) {
      if (matrix[r][c]) path += 'M' + ((c + border) * cell) + ',' + ((r + border) * cell) + 'h' + cell + 'v' + cell + 'h-' + cell + 'z';
    }
  }
  const svg = '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 ' + size + ' ' + size + '" shape-rendering="crispEdges">'
    + '<rect width="100%" height="100%" fill="#ffffff"/><path d="' + path + '" fill="#000000"/></svg>';
  return 'data:image/svg+xml;base64,' + Buffer.from(svg, 'utf8').toString('base64');
}

// ════════════════════════════════════════════════════════════════════════
// 二、响应分类（纯函数）：三种失败形态分别映射，绝不合并
// ════════════════════════════════════════════════════════════════════════
export function gatedMessage(bytes) {
  return '小黑盒拒绝了这次请求（服务端原文：非法请求，' + (bytes || 0) + ' 字节）。'
    + '这个形状的意思是「服务端不接受这次请求的签名或身份」，不是网络错误，用同样的参数重试不会有不同结果。'
    + '按顺序排查：① 先确认插件是 1.0.2 或更新 —— hkey 校验和从 1.0.2 起才与浏览器逐字节一致，'
    + '旧版是所有端点（含 feeds/详情/搜索）一起失败；② 已是最新版、且每个端点都这样：这台机器的 IP 多半被临时限流，'
    + '隔几分钟再试，换出口网络更快；③ 只有个别端点这样：跑 account(what=doctor) 看是哪几个，把回执原话转告维护者。';
}

export function badParamMessage(serverMessage) {
  return '小黑盒接口参数校验失败（服务端原文：' + (serverMessage || '验证参数错误')
    + '）。这说明签名已经通过、是插件这边传的参数不对 —— 是插件 bug，重试同样的调用不会有不同结果；'
    + '请把这条原话转告维护者，并改用别的工具继续（例如 feeds 看帖）。';
}

/**
 * 把一次 HTTP 回执判成 { ok, data } 或 { ok:false, code, message }。
 * meta = { httpStatus, truncated }
 */
export function classifyBody(rawBody, meta) {
  const info = meta && typeof meta === 'object' ? meta : {};
  const body = String(rawBody == null ? '' : rawBody);
  const bytes = Buffer.byteLength(body, 'utf8');
  const status = Number(info.httpStatus) || 0;

  if (info.truncated === true) {
    return {
      ok: false,
      code: XHH_CODES.TRUNCATED,
      message: '响应被截断：已拿到 ' + bytes + ' 字节就到达上限，后面的内容不在手里，这份结果不能当成完整列表。'
        + '请把 limit / commentLimit 调小后重试。'
    };
  }
  if (status === 429) {
    return {
      ok: false,
      code: XHH_CODES.RATE,
      message: '小黑盒在限速（HTTP 429）。等一会儿再试；本插件已经做了串行 + 间隔限速，出现这条通常说明设置里的间隔太小或短时间内被多次调用。'
    };
  }
  if (status && status !== 200) {
    return {
      ok: false,
      code: XHH_CODES.UPSTREAM,
      message: '小黑盒接口返回 HTTP ' + status + '（' + bytes + ' 字节）。可能是服务端临时故障，稍后重试。'
    };
  }

  let data = null;
  try { data = JSON.parse(body); } catch { data = null; }
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    return {
      ok: false,
      code: XHH_CODES.UPSTREAM,
      message: '小黑盒返回的不是 JSON（HTTP ' + (status || '?') + '，' + bytes + ' 字节）。'
        + '常见原因是出口被中间设备改写，或接口地址变了。'
    };
  }

  const serverMessage = typeof data.msg === 'string' ? data.msg
    : (typeof data.message === 'string' ? data.message : '');
  const state = typeof data.status === 'string' ? data.status : '';

  if (state === 'show_captcha' || /show_captcha|captcha/i.test(serverMessage)) {
    return {
      ok: false,
      code: XHH_CODES.CAPTCHA,
      message: '小黑盒弹出了腾讯验证码挑战（' + (serverMessage || state) + '）：插件没法替你拖滑块，'
        + '这次调用只能放弃。请在浏览器里打开一次 https://www.xiaoheihe.cn 手动过验证，或等一段时间再试。'
    };
  }
  // restore_login 的「没登录/过期」形状：{"status":"relogin","msg":"请重新登录","result":{}}
  if (state === 'relogin') {
    return {
      ok: false,
      code: XHH_CODES.RELOGIN,
      message: '小黑盒说登录态已失效（' + (serverMessage || 'relogin') + '）：'
        + '用 login(action="start") 扫码登录，或把网页版 cookie 粘进来（login(action="set", cookie=...)）。'
    };
  }
  if (state === 'failed') {
    if (/非法请求/.test(serverMessage)) {
      return { ok: false, code: XHH_CODES.GATED, message: gatedMessage(bytes) };
    }
    if (/验证参数/.test(serverMessage)) {
      return { ok: false, code: XHH_CODES.BAD_PARAM, message: badParamMessage(serverMessage) };
    }
    if (/频繁|太快|限速|too many/i.test(serverMessage)) {
      return {
        ok: false,
        code: XHH_CODES.RATE,
        message: '小黑盒说请求太频繁（' + serverMessage + '）。等一会儿再试，或把设置里的请求间隔调大。'
      };
    }
    return {
      ok: false,
      code: XHH_CODES.UPSTREAM,
      message: '小黑盒接口报错：' + (serverMessage || '(没有 msg)') + '（' + bytes + ' 字节）。'
    };
  }

  const result = data.result;
  const hasResult = result !== undefined && result !== null
    && !(typeof result === 'object' && !Array.isArray(result) && Object.keys(result).length === 0);
  if (state === 'ok' || hasResult || Array.isArray(data)) return { ok: true, data };
  return {
    ok: false,
    code: XHH_CODES.UPSTREAM,
    message: '小黑盒返回了空结果（' + bytes + ' 字节，既没有 status:ok 也没有 result）。'
      + '如果反复出现，用 account(what=doctor) 看各端点的实测状态。'
  };
}

// ════════════════════════════════════════════════════════════════════════
// 三、行整形（纯函数）
// ════════════════════════════════════════════════════════════════════════
export function pick(source, keys) {
  if (!source || typeof source !== 'object') return undefined;
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      const value = source[key];
      if (value !== undefined && value !== null && value !== '') return value;
    }
  }
  return undefined;
}

export function asTextOf(value) {
  if (value === undefined || value === null) return '';
  if (typeof value === 'string') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  if (typeof value === 'boolean') return value ? '1' : '';
  return '';
}

export function asNumberOf(value) {
  const n = Number(asTextOf(value));
  return Number.isFinite(n) ? n : 0;
}

/** 计数类字段：响应里没有就返回 undefined（JSON 序列化后直接消失），绝不写 0 冒充真实值。 */
export function maybeCount(value) {
  if (value === undefined || value === null || value === '') return undefined;
  const n = Number(asTextOf(value));
  return Number.isFinite(n) ? n : undefined;
}

/** 小黑盒的时间戳是秒；也兼容已经是毫秒的情况。 */
export function asTimeOf(value) {
  const n = Number(asTextOf(value));
  if (!Number.isFinite(n) || n <= 0) return 0;
  return n < 1e11 ? Math.round(n * 1000) : Math.round(n);
}

export function isoOf(ms) {
  return ms > 0 ? new Date(ms).toISOString() : '';
}

export function asUrl(value) {
  const raw = String(value == null ? '' : value).trim();
  if (!raw) return '';
  if (raw.startsWith('//')) return 'https:' + raw;
  if (raw.startsWith('/')) return SITE + raw;
  if (/^https?:\/\//i.test(raw)) return raw;
  return '';
}

/** 帖子正文是 HTML：去标签、去 [img] 块、保留段落换行。 */
export function htmlToText(input) {
  let text = String(input == null ? '' : input);
  if (!text) return '';
  text = text.replace(/<\s*br\s*\/?>/gi, '\n');
  text = text.replace(/<\s*\/\s*(p|div|li|h[1-6]|tr)\s*>/gi, '\n');
  text = text.replace(/<[^>]*>/g, '');
  text = text.replace(/\[img\][\s\S]*?\[\/img\]/gi, '');
  text = text
    .replace(/&nbsp;/gi, ' ')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&amp;/gi, '&');
  text = text.replace(/\r\n/g, '\n').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n');
  return text.trim();
}

export function clip(text, max) {
  const raw = String(text == null ? '' : text);
  const limit = Number(max) > 0 ? Number(max) : 0;
  if (!limit || raw.length <= limit) return raw;
  return raw.slice(0, limit) + '…（已截断，原文 ' + raw.length + ' 字）';
}

/** 在 payload 里按深度 <= 2 找第一个数组：结构在不同端点之间并不统一。 */
export function firstArray(source, depth) {
  const level = Number(depth) || 0;
  if (Array.isArray(source)) return source;
  if (!source || typeof source !== 'object') return [];
  const keys = ['links', 'link_list', 'list', 'items', 'feeds', 'comments', 'comment_list', 'users', 'games', 'topics', 'data', 'result', 'rows'];
  for (const key of keys) {
    if (!Object.prototype.hasOwnProperty.call(source, key)) continue;
    const value = source[key];
    if (Array.isArray(value)) return value;
    if (level < 2 && value && typeof value === 'object') {
      const inner = firstArray(value, level + 1);
      if (inner.length) return inner;
    }
  }
  if (level < 2 && source.data && typeof source.data === 'object' && source.data !== source) {
    const inner = firstArray(source.data, level + 1);
    if (inner.length) return inner;
  }
  return [];
}

export function resultOf(payload) {
  if (!payload || typeof payload !== 'object') return {};
  const result = payload.result;
  if (result && typeof result === 'object' && !Array.isArray(result)) return result;
  return payload;
}

export function extractLinks(payload) {
  return firstArray(resultOf(payload), 0);
}

export function extractLink(payload) {
  const root = resultOf(payload);
  const candidates = ['link', 'link_info', 'post', 'detail', 'article'];
  for (const key of candidates) {
    const value = root[key];
    if (value && typeof value === 'object' && !Array.isArray(value)) return value;
  }
  if (root.linkid !== undefined || root.link_id !== undefined || root.title !== undefined) return root;
  return {};
}

/**
 * 实测 /bbs/app/link/tree 的评论就在同一个响应里：result.comments 是**楼层数组**，
 * 每层形如 { comment: [ { commentid, text, userid, user:{username}, create_at, up, imgs, floor_num … } ] }。
 * 这里把楼层摊平成评论数组，顺带给出楼层数 / 总楼层数，供 post 的文案使用。
 */
export function commentFloors(payload) {
  const root = resultOf(payload);
  const bag = root.comments;
  const floors = Array.isArray(bag) ? bag : (bag && Array.isArray(bag.comments) ? bag.comments : []);
  const items = [];
  for (const floor of floors) {
    if (!floor || typeof floor !== 'object') continue;
    const inner = floor.comment;
    if (Array.isArray(inner)) {
      for (const one of inner) if (one && typeof one === 'object') items.push(one);
      continue;
    }
    if (inner && typeof inner === 'object') { items.push(inner); continue; }
    if (floor.commentid !== undefined || floor.comment_id !== undefined || floor.text !== undefined) items.push(floor);
  }
  return {
    items,
    floors: floors.length,
    totalFloor: asNumberOf(pick(root, ['total_floor_num', 'total_floor', 'comment_num'])),
    hasMore: Boolean(asNumberOf(pick(root, ['has_more_floors', 'has_more'])))
  };
}

export function extractComments(payload) {
  const flat = commentFloors(payload);
  if (flat.items.length) return flat.items;
  const root = resultOf(payload);
  const bag = root.comments;
  if (Array.isArray(bag)) return bag;
  if (bag && typeof bag === 'object') {
    const inner = firstArray(bag, 1);
    if (inner.length) return inner;
  }
  return firstArray(root, 1).filter((item) => item && typeof item === 'object'
    && (item.comment_id !== undefined || item.text !== undefined || item.commentid !== undefined));
}

export function topicNames(source) {
  const list = Array.isArray(source) ? source : (source && Array.isArray(source.topics) ? source.topics : []);
  const out = [];
  for (const item of list.slice(0, 6)) {
    if (typeof item === 'string') { if (item.trim()) out.push(item.trim().slice(0, 40)); continue; }
    if (item && typeof item === 'object') {
      const name = asTextOf(pick(item, ['name', 'topic_name', 'title']));
      if (name) out.push(name.trim().slice(0, 40));
    }
  }
  return out;
}

/** 取列表字段里第一个可用图片地址（thumbs / imgs 这类字符串数组，也兼容对象元素）。 */
function firstImageUrl(source, keys) {
  const bag = pick(source, keys);
  const take = (value) => {
    if (typeof value === 'string') return asUrl(value);
    if (value && typeof value === 'object') return asUrl(pick(value, ['url', 'src', 'img', 'image', 'link']));
    return '';
  };
  if (Array.isArray(bag)) {
    for (const value of bag) {
      const url = take(value);
      if (url) return url;
    }
    return '';
  }
  if (typeof bag === 'string') return asUrl(bag.split(',')[0]);
  return '';
}

/**
 * 实测 link.text 是 JSON 数组字符串（不是 HTML）：
 *   [{"text":"太有才了老师们","type":"text"},{"height":"1025.0","type":"img","url":"https://…"}]
 * 认不出来就返回 null，调用方回退到 HTML 剥离。
 */
export function richTextBlocks(raw) {
  const src = String(raw == null ? '' : raw).trim();
  if (!src.startsWith('[')) return null;
  let parsed;
  try { parsed = JSON.parse(src); } catch { return null; }
  if (!Array.isArray(parsed)) return null;
  const parts = [];
  const images = [];
  for (const block of parsed) {
    if (typeof block === 'string') { if (block.trim()) parts.push(block.trim()); continue; }
    if (!block || typeof block !== 'object') continue;
    if (typeof block.text === 'string' && block.text.trim()) parts.push(block.text.trim());
    const url = asUrl(pick(block, ['url', 'src', 'img']));
    if (url && !images.includes(url)) images.push(url);
  }
  return { text: htmlToText(parts.join('\n')), images };
}

/** 动态流 / 帖子列表的一行。 */
export function feedRow(item) {
  const source = item && typeof item === 'object' ? item : {};
  const linkId = String(asTextOf(pick(source, ['linkid', 'link_id', 'id'])));
  const title = htmlToText(asTextOf(pick(source, ['title', 'link_title'])));
  const summary = htmlToText(asTextOf(pick(source, ['description', 'desc', 'summary'])));
  const createdAt = asTimeOf(pick(source, ['create_at', 'create_time', 'created_at', 'publish_time', 'time']));
  const user = source.user && typeof source.user === 'object' ? source.user : {};
  // 实测 feeds 条目没有 thumb/cover 这类单值字段：图在 thumbs[]（带 thumbnail/540x921）与 imgs[]（原图）。
  // 缩略图优先（AGENT.md F4），缺了再退原图。
  const cover = asUrl(asTextOf(pick(source, ['thumb', 'image', 'cover', 'share_image', 'poster', 'thumbnail'])))
    || firstImageUrl(source, ['thumbs', 'thumb_list'])
    || firstImageUrl(source, ['imgs', 'images', 'pics', 'pictures', 'image_list', 'img_list']);
  const videoUrl = asUrl(asTextOf(pick(source, ['video_url', 'videoUrl'])));
  return {
    linkId,
    title: title.slice(0, 160),
    summary: summary.slice(0, 300),
    // 实测作者名只在 item.user.username（条目自身的 userid 也在，但规范来源是 user.userid）。
    authorId: String(asTextOf(pick(user, ['userid', 'user_id', 'uid'])) || asTextOf(pick(source, ['userid', 'user_id', 'uid']))),
    author: (asTextOf(pick(user, ['username', 'nickname', 'user_name']))
      || asTextOf(pick(source, ['username', 'nickname', 'user_name']))).slice(0, 40),
    // feeds 响应里没有点赞字段（只有 comment_num / up / down / forward_num），up/down 语义未证实、
    // 不当作点赞数；拿不到就不输出（undefined 被 JSON 丢掉），绝不写 0 冒充。
    likeCount: maybeCount(pick(source, ['like_num', 'like_count', 'likes'])),
    commentCount: asNumberOf(pick(source, ['comment_num', 'comment_count', 'comments'])),
    favoriteCount: maybeCount(pick(source, ['favour_count', 'fav_num', 'favour_num', 'collect_num'])),
    createdAt: isoOf(createdAt),
    cover,
    hasVideo: Boolean(videoUrl) || Boolean(asNumberOf(pick(source, ['has_video']))),
    videoUrl,
    topics: topicNames(source),
    // 实测：SITE + '/bbs/link/<id>' 是 404（19 字节），加 /app 前缀才 200。
    url: linkId ? SITE + '/app/bbs/link/' + linkId : ''
  };
}

export function pickImages(link) {
  const source = link && typeof link === 'object' ? link : {};
  const bag = pick(source, ['imgs', 'images', 'pics', 'pictures', 'image_list', 'img_list']);
  const out = [];
  const push = (value) => {
    const url = asUrl(value);
    if (url && !out.includes(url)) out.push(url);
  };
  if (Array.isArray(bag)) {
    for (const item of bag) {
      if (typeof item === 'string') push(item);
      else if (item && typeof item === 'object') {
        push(pick(item, ['url', 'src', 'img', 'image', 'link']));
        const full = pick(item, ['origin_url', 'original', 'big']);
        if (typeof full === 'string') push(full);
      }
    }
  } else if (typeof bag === 'string') {
    for (const piece of bag.split(',')) push(piece);
  }
  // 实测纯文字/带图帖没有 imgs，图片在正文的 JSON 块里（type:'img'）
  const rich = richTextBlocks(pick(source, ['text', 'html', 'content', 'body']));
  if (rich) for (const url of rich.images) push(url);
  return out;
}

/**
 * 实测（link_id=195106926 真视频帖）link/tree 的字段：
 *   has_video=1、video_url（签名直链）、video_thumb、video_duration=77（秒）、video_width/video_height=2560×1336
 * ⚠️ video_url 里有两个 auth、两个 sign（重复查询键，签名对，约 2 小时过期）：
 *    这里**只做原样字符串透传**，不要用 URLSearchParams 重新序列化（会去重 / 改顺序，签名立刻失效）。
 */
export function pickVideos(link) {
  const source = link && typeof link === 'object' ? link : {};
  const out = [];
  const push = (url, cover, meta) => {
    const target = asUrl(url);
    if (!target || out.some((item) => item.url === target)) return;
    const bag = meta && typeof meta === 'object' ? meta : {};
    out.push({
      url: target,
      cover: asUrl(cover),
      duration: maybeCount(bag.duration),
      width: maybeCount(bag.width),
      height: maybeCount(bag.height)
    });
  };
  const directMeta = {
    duration: pick(source, ['video_duration', 'duration']),
    width: pick(source, ['video_width', 'width']),
    height: pick(source, ['video_height', 'height'])
  };
  const direct = pick(source, ['video_url', 'videoUrl', 'video_src', 'mp4']);
  if (typeof direct === 'string') push(direct, pick(source, ['video_thumb', 'thumb']), directMeta);
  const bag = pick(source, ['videos', 'video_list', 'video']);
  if (Array.isArray(bag)) {
    for (const item of bag) {
      if (typeof item === 'string') push(item, '', null);
      else if (item && typeof item === 'object') {
        push(pick(item, ['url', 'src', 'video_url', 'mp4']), pick(item, ['cover', 'thumb', 'image']), {
          duration: pick(item, ['duration', 'video_duration']),
          width: pick(item, ['width', 'video_width']),
          height: pick(item, ['height', 'video_height'])
        });
      }
    }
  } else if (bag && typeof bag === 'object') {
    push(pick(bag, ['url', 'src', 'video_url']), pick(bag, ['cover', 'thumb']), {
      duration: pick(bag, ['duration', 'video_duration']),
      width: pick(bag, ['width', 'video_width']),
      height: pick(bag, ['height', 'video_height'])
    });
  }
  return out;
}

/** 人类可读的视频规格："77 秒 / 2560×1336"。 */
export function describeVideo(video) {
  const bag = video && typeof video === 'object' ? video : {};
  const parts = [];
  if (bag.duration !== undefined && bag.duration !== null) parts.push(bag.duration + ' 秒');
  if (bag.width !== undefined && bag.width !== null && bag.height !== undefined && bag.height !== null) {
    parts.push(bag.width + '×' + bag.height);
  }
  return parts.join(' / ');
}

/** 视频直链是签名 URL、会过期：回执文案统一用这一句，别让用户把旧链接存起来。 */
export const VIDEO_URL_NOTE = '视频是签名直链，约 2 小时内有效（auth/sign 会过期）：要发就这次发，过期了重新 post/watch 拿新链接。';

/** 帖子详情（正文纯文本 + 图 + 视频 + 互动数）。 */
export function linkRow(link) {
  const source = link && typeof link === 'object' ? link : {};
  const row = feedRow(source);
  const rich = richTextBlocks(pick(source, ['text', 'html', 'content', 'body']));
  const body = rich ? rich.text : htmlToText(asTextOf(pick(source, ['text', 'html', 'content', 'body'])));
  const images = pickImages(source);
  const videos = pickVideos(source);
  return {
    ...row,
    summary: clip(row.summary, 400),
    // 实测纯文字帖没有 imgs/thumbs：封面只能是正文第一个图片块
    cover: row.cover || images[0] || '',
    text: body,
    textChars: body.length,
    imageCount: images.length,
    images: images.slice(0, 12),
    videos: videos.slice(0, 5)
  };
}

export function commentRow(item) {
  const source = item && typeof item === 'object' ? item : {};
  const user = source.user && typeof source.user === 'object' ? source.user : {};
  const createdAt = asTimeOf(pick(source, ['create_at', 'create_time', 'created_at', 'time']));
  const imgs = pick(source, ['imgs', 'images']);
  return {
    commentId: String(asTextOf(pick(source, ['commentid', 'comment_id', 'id']))),
    text: htmlToText(asTextOf(pick(source, ['text', 'content', 'comment']))).slice(0, 600),
    // 实测：作者名在 comment.user.username，楼主的楼层用 is_link_owner=1 标出来
    authorId: String(asTextOf(pick(user, ['userid', 'user_id', 'uid'])) || asTextOf(pick(source, ['userid', 'user_id', 'uid']))),
    author: (asTextOf(pick(user, ['username', 'nickname', 'user_name']))
      || asTextOf(pick(source, ['username', 'nickname', 'user_name']))).slice(0, 40),
    // up/down 语义未证实，不当作点赞数（E4）
    likeCount: maybeCount(pick(source, ['like_num', 'like_count', 'likes'])),
    isAuthor: Boolean(asNumberOf(pick(source, ['is_link_owner', 'is_author', 'author'])) || asNumberOf(pick(source, ['is_up']))),
    floorNum: asNumberOf(pick(source, ['floor_num', 'floor'])),
    imageCount: Array.isArray(imgs) ? imgs.length : 0,
    createdAt: isoOf(createdAt),
    replyCount: asNumberOf(pick(source, ['child_num', 'reply_num', 'sub_comment_num', 'children_num']))
  };
}

/** 依次取第一个能用的计数；全都没有就 undefined（不写 0）。 */
function firstCount(...values) {
  for (const value of values) {
    const n = maybeCount(value);
    if (n !== undefined) return n;
  }
  return undefined;
}

/**
 * 实测 /bbs/app/profile/user/profile 的资料在 result.account_detail：
 *   userid / username / signature / avatar / ip_location / medals[]
 * 等级在 level_info（**对象**，{level, status}，不是数字），统计量在 bbs_info
 *   （fan_num 粉丝 / follow_num 关注 / post_link_num 投稿数 / be_favoured_num 被收藏数…）。
 * 主页链接：/bbs/user/<id> 实测 404，/app/user/profile/<id> 才是 200。
 */
export function userRow(payload) {
  const root = resultOf(payload);
  const user = root.account_detail && typeof root.account_detail === 'object' ? root.account_detail
    : (root.user && typeof root.user === 'object' ? root.user
      : (root.user_info && typeof root.user_info === 'object' ? root.user_info : root));
  const levelInfo = user.level_info && typeof user.level_info === 'object' ? user.level_info : {};
  const bbs = user.bbs_info && typeof user.bbs_info === 'object' ? user.bbs_info : {};
  const userId = String(asTextOf(pick(user, ['userid', 'user_id', 'uid', 'heybox_id', 'id'])));
  const ipLocation = asTextOf(pick(user, ['ip_location'])).replace(/^IP:\s*/i, '');
  return {
    userId,
    userName: asTextOf(pick(user, ['username', 'nickname', 'user_name', 'name'])).slice(0, 40),
    avatar: asUrl(asTextOf(pick(user, ['avatar', 'avatar_url', 'headimg', 'head_img']))),
    level: firstCount(pick(levelInfo, ['level', 'lv']), pick(user, ['level', 'user_level', 'lv'])),
    signature: htmlToText(asTextOf(pick(user, ['signature', 'desc', 'description', 'bio', 'intro']))).slice(0, 200),
    ipLocation,
    followerCount: firstCount(bbs.fan_num, bbs.follower_num, pick(user, ['follower_num', 'fans_num', 'fans', 'follower'])),
    followingCount: firstCount(bbs.follow_num, pick(user, ['following_num', 'follow_num', 'follow'])),
    postCount: firstCount(bbs.post_link_num, bbs.post_num, pick(user, ['link_num', 'post_num', 'article_num'])),
    favouredByCount: firstCount(bbs.be_favoured_num),
    followed: Boolean(asNumberOf(pick(user, ['is_follow', 'followed', 'is_followed']))),
    url: userId ? SITE + '/app/user/profile/' + userId : ''
  };
}

/**
 * 实测 /bbs/app/profile/user/link/list_v2 的投稿在 result.post_links（与 feeds 条目同构，直接 feedRow），
 * 而作者名只在 result.user.username 里 —— 条目本身不带 user 对象。
 */
export function userPostRows(payload) {
  const root = resultOf(payload);
  const bag = Array.isArray(root.post_links) ? root.post_links
    : (Array.isArray(root.links) ? root.links : extractLinks(payload));
  const listUser = root.user && typeof root.user === 'object' ? root.user : {};
  const listAuthor = asTextOf(pick(listUser, ['username', 'nickname', 'user_name']));
  const listAuthorId = String(asTextOf(pick(listUser, ['userid', 'user_id', 'uid'])));
  return bag.map((item) => feedRow(item)).map((row) => ({
    ...row,
    author: row.author || listAuthor,
    authorId: row.authorId || listAuthorId
  })).filter((row) => row.linkId || row.title);
}

/**
 * 实测 GET /bbs/app/user/message?message_type=16&list_type=0&offset=0&limit=20：
 * result.messages[]（当前账号没有 @ 消息时是空数组，空数组是正常结果不是错误）。
 * 元素有 message_id / message_type / text / timestamp / user_a / user_b / state / link / link_tag；
 * link 里通常有 linkid / link_tag / title / description / share_url。
 * 链接统一用实测 200 的 /app/bbs/link/<linkid>（/bbs/link/ 是 404）。
 */
export function messageRows(payload) {
  const root = resultOf(payload);
  const list = Array.isArray(root.messages) ? root.messages : firstArray(root, 1);
  const out = [];
  for (const item of list) {
    if (!item || typeof item !== 'object') continue;
    const link = item.link && typeof item.link === 'object' ? item.link : {};
    const from = item.user_a && typeof item.user_a === 'object' ? item.user_a
      : (item.from_user && typeof item.from_user === 'object' ? item.from_user : {});
    const linkId = String(asTextOf(pick(link, ['linkid', 'link_id', 'id'])) || asTextOf(pick(item, ['linkid', 'link_id'])));
    out.push({
      messageId: String(asTextOf(pick(item, ['message_id', 'messageid', 'id']))),
      type: maybeCount(pick(item, ['message_type', 'type'])),
      text: htmlToText(asTextOf(pick(item, ['text', 'content']))).slice(0, 300),
      at: isoOf(asTimeOf(pick(item, ['timestamp', 'create_at', 'time']))),
      from: {
        userid: String(asTextOf(pick(from, ['userid', 'user_id', 'uid']))),
        username: asTextOf(pick(from, ['username', 'nickname'])).slice(0, 40)
      },
      state: maybeCount(pick(item, ['state'])),
      linkId,
      title: htmlToText(asTextOf(pick(link, ['title']) || asTextOf(pick(item, ['title'])))).slice(0, 120),
      url: linkId ? SITE + '/app/bbs/link/' + linkId : ''
    });
  }
  return out;
}

export function gameRow(item) {
  const source = item && typeof item === 'object' ? item : {};
  const gameId = String(asTextOf(pick(source, ['game_id', 'gameid', 'id'])));
  return {
    gameId,
    name: asTextOf(pick(source, ['game_name', 'name', 'title'])).slice(0, 80),
    icon: asUrl(asTextOf(pick(source, ['icon', 'logo', 'image', 'thumb']))),
    score: asNumberOf(pick(source, ['score', 'rating', 'grade'])),
    url: gameId ? SITE + '/bbs/game/' + gameId : ''
  };
}

/**
 * 实测 /bbs/app/topic/categories 的话题在 recommend_for_user_topics / latest_hot_topics /
 * subscribed_topics 三组的 children 里，元素形如：
 *   { name, extra_desc, topic_id, pic_url, small_pic_url, hot:{raw_hot_value,desc,level}, game:{app_id}, valid }
 * result.categories 是空数组（正常，不代表没返回话题）。
 * 这里不输出话题页链接：站点的话题页路径没有实测过，而 /bbs/… 那套已证实会 404，别给死链。
 */
export function topicRow(item) {
  const source = item && typeof item === 'object' ? item : {};
  const topicId = String(asTextOf(pick(source, ['topic_id', 'topicid', 'id'])));
  const hotBag = pick(source, ['hot', 'hot_value', 'hot_value_v2']);
  const hotValue = hotBag && typeof hotBag === 'object'
    ? firstCount(pick(hotBag, ['raw_hot_value', 'value', 'hot']))
    : maybeCount(hotBag);
  const gameBag = pick(source, ['game', 'game_info']);
  const appId = gameBag && typeof gameBag === 'object' ? String(asTextOf(pick(gameBag, ['app_id', 'game_id', 'appid']))) : '';
  return {
    topicId,
    name: asTextOf(pick(source, ['topic_name', 'name', 'title'])).slice(0, 60),
    description: htmlToText(asTextOf(pick(source, ['extra_desc', 'description', 'desc', 'intro']))).slice(0, 160),
    icon: asUrl(asTextOf(pick(source, ['pic_url', 'small_pic_url', 'icon', 'image', 'avatar', 'thumb']))),
    hot: hotValue,
    gameAppId: appId,
    valid: Boolean(asNumberOf(pick(source, ['valid']))),
    followerCount: firstCount(pick(source, ['follower_num', 'follow_num', 'fans']))
  };
}

/** 把 topic/categories 的三组 children 摊平成 [{…topicRow, group}]，并按 topicId 去重。 */
export function topicGroups(payload) {
  const root = resultOf(payload);
  const groups = [];
  const rows = [];
  const seen = new Set();
  for (const key of ['recommend_for_user_topics', 'latest_hot_topics', 'subscribed_topics']) {
    const group = root[key];
    if (!group || typeof group !== 'object' || Array.isArray(group)) continue;
    const children = Array.isArray(group.children) ? group.children : [];
    if (!children.length) continue;
    const name = asTextOf(pick(group, ['name', 'title'])) || key;
    groups.push({ key, name, count: children.length });
    for (const child of children) {
      const row = topicRow(child);
      if (!row.topicId || seen.has(row.topicId)) continue;
      seen.add(row.topicId);
      rows.push({ ...row, group: name });
    }
  }
  return { groups, rows };
}

/**
 * 实测 /bbs/app/api/general/search/v1 的形状是 result.items: [{ report_id, info, type }]，
 * info 的字段随 type 变化：link -> 帖子本体，new_game_list -> { game_list: [...] }，
 * topic -> { topic: {...} }，space / filter_tag / relevant_search 是页面装饰，要丢掉。
 */
export function searchRows(payload, kind) {
  const root = resultOf(payload);
  if (Array.isArray(root.items)) {
    const infos = [];
    for (const item of root.items) {
      if (!item || typeof item !== 'object') continue;
      const type = String(item.type || '');
      const info = item.info;
      if (!info || typeof info !== 'object') continue;
      if (kind === 'post' && type === 'link') infos.push(info);
      else if (kind === 'game' && Array.isArray(info.game_list)) infos.push(...info.game_list);
      else if (kind === 'user' && /user|author|account/i.test(type)) infos.push(info);
    }
    if (infos.length) {
      const mapper = kind === 'user' ? userRow : (kind === 'game' ? gameRow : feedRow);
      return infos.map((info) => mapper(info)).filter((row) => {
        const id = row.linkId || row.userId || row.gameId;
        return Boolean(id) || Boolean(row.title || row.name || row.userName);
      });
    }
  }
  const bag = kind === 'user'
    ? pick(root, ['users', 'user_list', 'accounts'])
    : kind === 'game'
      ? pick(root, ['games', 'game_list'])
      : pick(root, ['links', 'link_list', 'posts', 'items']);
  const list = Array.isArray(bag) ? bag : firstArray(root, 1);
  const mapper = kind === 'user' ? userRow : (kind === 'game' ? gameRow : feedRow);
  return list.map((item) => mapper(item)).filter((row) => {
    const id = row.linkId || row.userId || row.gameId;
    return Boolean(id) || Boolean(row.title || row.name || row.userName);
  });
}

// ════════════════════════════════════════════════════════════════════════
// 四、参数守卫与 cookie（纯函数）
// ════════════════════════════════════════════════════════════════════════
const BAD_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

export function safeKey(raw) {
  const key = String(raw == null ? '' : raw).trim().slice(0, 120);
  if (!key || BAD_KEYS.has(key)) return 'k_' + crypto.createHash('md5').update(key).digest('hex').slice(0, 12);
  return key;
}

export function argText(value, name, options) {
  const spec = options || {};
  if (value === undefined || value === null || value === '') {
    if (spec.required) throw xhhError(XHH_CODES.BAD_ARG, '缺少参数 ' + name + (spec.hint ? '：' + spec.hint : ''));
    return '';
  }
  if (typeof value !== 'string' && typeof value !== 'number') {
    throw xhhError(XHH_CODES.BAD_ARG, name + ' 必须是字符串，收到的是 ' + typeof value);
  }
  const text = String(value).trim();
  if (spec.required && !text) throw xhhError(XHH_CODES.BAD_ARG, name + ' 不能是空字符串' + (spec.hint ? '：' + spec.hint : ''));
  if (text.includes('\u0000')) throw xhhError(XHH_CODES.BAD_ARG, name + ' 含有非法控制字符');
  const max = Number(spec.max) > 0 ? Number(spec.max) : 200;
  if (text.length > max) throw xhhError(XHH_CODES.BAD_ARG, name + ' 太长了（上限 ' + max + ' 字，实际 ' + text.length + ' 字）');
  const min = Number(spec.min) > 0 ? Number(spec.min) : 0;
  if (min && text.length < min) throw xhhError(XHH_CODES.BAD_ARG, name + ' 太短了（至少 ' + min + ' 字）');
  if (spec.pattern && !spec.pattern.test(text)) {
    throw xhhError(XHH_CODES.BAD_ARG, name + ' 格式不对' + (spec.hint ? '：' + spec.hint : ''));
  }
  return text;
}

/** link_id / userid 这类纯数字标识。 */
export function argId(value, name, options) {
  return argText(value, name, {
    required: options && options.required === false ? false : true,
    max: 24,
    pattern: /^[0-9]{1,24}$/,
    hint: (options && options.hint) || '纯数字'
  });
}

export function argInt(value, name, fallback, min, max) {
  if (value === undefined || value === null || value === '') return fallback;
  const n = Number(value);
  if (!Number.isFinite(n)) throw xhhError(XHH_CODES.BAD_ARG, name + ' 必须是数字');
  return Math.max(min, Math.min(max, Math.floor(n)));
}

export function argBool(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'boolean') return value;
  const text = String(value).trim().toLowerCase();
  if (['true', '1', 'yes', 'on'].includes(text)) return true;
  if (['false', '0', 'no', 'off'].includes(text)) return false;
  return fallback;
}

export function argEnum(value, name, allowed, fallback) {
  const text = value === undefined || value === null ? '' : String(value).trim();
  if (!text) {
    if (fallback) return fallback;
    throw xhhError(XHH_CODES.BAD_ARG, '缺少参数 ' + name + '，可选：' + allowed.join(' / '));
  }
  if (!allowed.includes(text)) {
    throw xhhError(XHH_CODES.BAD_ARG, name + ' 只能是 ' + allowed.join(' / ') + '，收到的是 ' + text);
  }
  return text;
}

/** 扫码登录用到的三个端点（实测）：取码/轮询 app=web，restore_login app=heybox。 */
export const QR_LOGIN_COOKIE_NAMES = Object.freeze(['user_pkey', 'user_heybox_id']);

/** /account/get_qrcode_url 的 result -> { qrUrl, qr, expiresIn }。qr 是 qr_url 里的 uuid。 */
export function qrLoginCode(payload) {
  const root = resultOf(payload);
  const qrUrl = asTextOf(pick(root, ['qr_url', 'qrUrl']));
  const expiresIn = maybeCount(pick(root, ['expire', 'expires_in'])) || 120;
  let qr = '';
  if (qrUrl) {
    try { qr = new URL(qrUrl).searchParams.get('qr') || ''; } catch { qr = ''; }
  }
  return { qrUrl, qr, expiresIn };
}

/**
 * /account/qr_state 的 result -> 扫码状态。
 * 未扫：{error:'wait'}；已确认：result.account_detail / result.profile 有 userid；
 * 其它 error（过期/已扫未确认）原样返回，由调用方决定要不要清 pending。
 */
export function qrLoginState(payload) {
  const root = resultOf(payload);
  const detail = root.account_detail && typeof root.account_detail === 'object' ? root.account_detail : {};
  const profile = root.profile && typeof root.profile === 'object' ? root.profile : {};
  const levelInfo = detail.level_info && typeof detail.level_info === 'object' ? detail.level_info : {};
  const userid = String(asTextOf(pick(detail, ['userid', 'user_id', 'uid'])) || asTextOf(pick(profile, ['userid', 'user_id'])));
  const nickname = asTextOf(pick(detail, ['username', 'nickname'])) || asTextOf(pick(profile, ['nickname', 'username']));
  const error = asTextOf(pick(root, ['error']));
  const errorMsg = asTextOf(pick(root, ['error_msg', 'msg']));
  if (userid) return { state: 'confirmed', userid, nickname, level: firstCount(pick(levelInfo, ['level'])), error, errorMsg };
  if (!error || error === 'ok') return { state: 'wait', error, errorMsg };
  if (error === 'wait') return { state: 'wait', error, errorMsg };
  // 只按字面 token 映射「已扫未确认」；服务端给不出来就不猜
  if (error === 'scanned') return { state: 'scanned', error, errorMsg };
  return { state: 'failed', error, errorMsg, userid: '', nickname: '', level: undefined };
}

/**
 * 从 cap.http.request 的 setCookies 里只挑扫码登录那两条，拼成 cookie 串。
 * 只认 user_pkey / user_heybox_id（实测就这两条，约 7 天），别的 Set-Cookie 一律丢掉。
 * 返回值只在内存里传给 cap.secrets.set，不上日志、不进回执。
 */
export function cookieFromSetCookies(setCookies) {
  const list = Array.isArray(setCookies) ? setCookies : [];
  const jar = Object.create(null);
  for (const entry of list) {
    const first = String(entry == null ? '' : entry).split(';')[0];
    const index = first.indexOf('=');
    if (index <= 0) continue;
    const name = first.slice(0, index).trim();
    const value = first.slice(index + 1).trim();
    if (!QR_LOGIN_COOKIE_NAMES.includes(name) || !value) continue;
    if (!Object.prototype.hasOwnProperty.call(jar, name)) jar[name] = value;
  }
  const pairs = [];
  for (const name of QR_LOGIN_COOKIE_NAMES) {
    if (Object.prototype.hasOwnProperty.call(jar, name)) pairs.push(name + '=' + jar[name]);
  }
  return pairs.join('; ');
}

/** 登录通道：console = 宿主控制台扫码面板；chat = 群聊/私聊里发文字二维码。 */
export const LOGIN_CHANNELS = Object.freeze(['chat', 'console']);

/**
 * 判定这次登录调用走哪个通道 —— **只看本次调用的显式声明 + context 形状**：
 *   ① args.channel === 'console' → console；'chat' → chat；
 *   ② 没声明时：context 为空（!chatKey 且 senderIsOwner === undefined，即 registry.js 的
 *      callConsoleTool 传的 {}）→ console；其余（带 chatKey 的聊天调用）→ chat。
 *
 * ⚠️ 不要看 pending.channel：控制台 start 过一次之后 pending.channel 会一直是 'console'，
 * 那样之后任何渠道的调用都会被当成控制台，直接绕过 assertLoginAllowed 的主人与群聊校验
 * （1.1.1 实测漏洞：CHAT_NO_OWNER / GROUP_START 都被放行）。pending.channel 只用于
 * 「聊天渠道 poll 时校验 chatKey 一致」和文案，不参与通道判定。
 */
export function loginChannelOf(args, context) {
  const ctx = context && typeof context === 'object' ? context : {};
  const requested = String((args && args.channel) || '').trim().toLowerCase();
  if (requested === 'console') return 'console';
  if (requested === 'chat') return 'chat';
  if (!ctx.chatKey && ctx.senderIsOwner === undefined) return 'console';
  return 'chat';
}

/**
 * 控制台扫码面板的契约（qq-agent-plus/ui/pages/plugin-settings.js 的 startQrLogin）：
 * 成功必须同时满足 result.ok === true 且 result.channel === 'console'，图片读的是 result.qrcodeDataUrl ——
 * 少一个就是「插件没返回控制台渠道」。
 */
export function consoleStartPayload(qrUrl) {
  const matrix = qrMatrix(qrUrl, 'L');
  return {
    ok: true,
    action: 'start',
    channel: 'console',
    qrcodeDataUrl: qrSvgDataUrl(matrix),
    note: '用手机小黑盒 App 扫这个码并在手机上确认，然后点「查扫码结果」（120 秒内有效）。'
  };
}

/**
 * 宿主控制台轮询认这四个 state：waiting（继续轮询）/ scanned（等手机确认）/
 * done（停止轮询 + 刷新登录徽标，**必须带 account**）/ unverified（显示 note）。
 */
export function qrPollPayload(status, info) {
  const bag = info && typeof info === 'object' ? info : {};
  const nickname = String(bag.nickname || '');
  const uid = String(bag.uid || '');
  const account = String(bag.account || nickname || uid || '');
  if (status === 'wait') {
    return {
      ok: true,
      action: 'poll',
      state: 'waiting',
      note: String(bag.note || '还没扫码（服务端 error=wait）：用手机小黑盒 App 扫这个码并在手机上确认。')
    };
  }
  if (status === 'scanned') {
    return { ok: true, action: 'poll', state: 'scanned', note: '已扫码：请在手机上点确认。' };
  }
  if (status === 'confirmed' || status === 'done') {
    return {
      ok: true,
      action: 'poll',
      state: 'done',
      account,
      uid,
      nickname,
      note: '登录成功，已安全保存并立即生效。'
    };
  }
  return {
    ok: true,
    action: 'poll',
    state: 'unverified',
    note: String(bag.note || '凭据已保存，但回校验没通过：稍后用 login(action="status") 再确认一次。')
  };
}

/**
 * 扫码登录的权限门（在任何请求之前抛，保证「拒绝 = 零请求」）：
 *   · action=status：只读，任何渠道都能调；
 *   · channel=console：宿主控制台本身就是已鉴权通道，不再额外判定；
 *   · 其它（chat）：必须 senderIsOwner === true，且不允许在群聊里发起 —— 群成员会扫走二维码绑到别人账号；
 *     poll 时还要与发起时同一个 chatKey（pendingChatKey）。
 */
export function assertLoginAllowed(action, channel, context, pendingChatKey) {
  if (action === 'status' || channel === 'console') return;
  const ctx = context && typeof context === 'object' ? context : {};
  if (ctx.senderIsOwner !== true) {
    throw xhhError(XHH_CODES.DENIED,
      '只有管理员可以扫码登录（这次调用的 senderIsOwner 不是 true）。'
      + '请管理员在 控制台 → 插件 → 小黑盒 的扫码面板里操作，或由管理员本人私聊发起。');
  }
  if (/^group:[0-9]+$/.test(String(ctx.chatKey || ''))) {
    throw xhhError(XHH_CODES.DENIED,
      '群聊里不能发起扫码登录：二维码会被群成员扫走、把登录态绑到别人的账号上。'
      + '请在控制台的扫码面板或私聊里做。');
  }
  if (pendingChatKey !== undefined && String(ctx.chatKey || '') !== String(pendingChatKey || '')) {
    throw xhhError(XHH_CODES.DENIED, '扫码流程要在发起它的同一个会话里完成：这次的 chatKey 与发起时不一致，重新 login(action="start")。');
  }
}
/** /account/restore_login 的 result -> { userid, nickname, level }（account_detail 是权威来源）。 */
export function restoreLoginInfo(payload) {
  const root = resultOf(payload);
  const detail = root.account_detail && typeof root.account_detail === 'object' ? root.account_detail : {};
  const profile = root.profile && typeof root.profile === 'object' ? root.profile : {};
  const levelInfo = detail.level_info && typeof detail.level_info === 'object' ? detail.level_info : {};
  return {
    userid: String(asTextOf(pick(detail, ['userid', 'user_id', 'uid'])) || asTextOf(pick(profile, ['userid', 'user_id']))),
    nickname: asTextOf(pick(detail, ['username', 'nickname'])) || asTextOf(pick(profile, ['nickname', 'username'])),
    level: firstCount(pick(levelInfo, ['level']))
  };
}
export const INTERACT_ACTIONS = Object.freeze(['favorite', 'follow']);

/**
 * 实测（1.0.3，测试账号真机验过）：这套 web 接口**没有「给帖子点赞」这一步** ——
 * 端点清单里只有 /bbs/app/link/favour（收藏）、/bbs/app/link/vote（投票）、
 * /bbs/app/comment/support（评论点赞）。所以 action=like 必须明确报不支持，
 * 不能像以前那样偷偷映射成收藏。
 */
export function normalizeInteractAction(raw) {
  const action = raw === undefined || raw === null ? '' : String(raw).trim().toLowerCase();
  if (action === 'like' || action === 'vote' || action === 'upvote' || action === 'up') {
    throw xhhError(XHH_CODES.BAD_ARG,
      '小黑盒的 web 接口不提供「给帖子点赞」：只有收藏（/bbs/app/link/favour）、投票（/bbs/app/link/vote）'
      + '和评论点赞（/bbs/app/comment/support）。帖子请用 interact(action="favorite")（收藏）；'
      + '评论点赞的参数本次没有核对过，暂不支持。');
  }
  return argEnum(action, 'action', INTERACT_ACTIONS, 'favorite');
}

/**
 * 实测（测试账号真机验过，验完已还原 is_favour/favour_count）：收藏 / 取消收藏是
 * POST /bbs/app/link/favour，参数必须放 **form body**：
 *   link_id=<id>&favour_type=1   收藏
 *   link_id=<id>&favour_type=0   取消收藏
 * 把 link_id 放 query 而不是 body → {"status":"failed","msg":"该帖子不存在"}。
 */
export function favourRequest(linkId, undo) {
  return {
    method: 'POST',
    path: '/bbs/app/link/favour',
    params: { link_id: String(linkId), favour_type: undo ? '0' : '1' }
  };
}

/**
 * 实测（1.0.4，测试账号真机验过并已还原 follow_status 0→1→0）：
 *   关注  POST /bbs/app/profile/follow/user
 *   取关  POST /bbs/app/profile/follow/user/cancel
 * 两者都必须把参数放 form body：following_id=<目标 UID>&follower_id=<自己 UID>。
 * 只传 userid 会得到 {"status":"failed","msg":"both following id and follower id is required"}。
 */
export function followRequest(targetUid, selfUid, undo) {
  return {
    method: 'POST',
    path: undo ? '/bbs/app/profile/follow/user/cancel' : '/bbs/app/profile/follow/user',
    params: { following_id: String(targetUid), follower_id: String(selfUid) }
  };
}

/** 关注/取关必须带 follower_id（=登录账号自己的 UID）；拿不到就明确报错，不要瞎发请求。 */
export function requireSelfUid(auth) {
  const uid = String((auth && auth.uid) || '');
  if (!/^[0-9]{1,24}$/.test(uid)) {
    throw xhhError(XHH_CODES.NO_LOGIN,
      '关注/取关要带 follower_id（自己是谁），当前 cookie 里没有可用的 heybox_id：'
      + '请在 控制台 → 插件 → 小黑盒 填网页版 cookie，或用 login(action="set", cookie=...)，再重试。');
  }
  return uid;
}

/**
 * 评论接口的 _rnd 签名（站点 bundle 的 Kwe()，与 CEe() 的 rnd==='15' 分支一致）：
 *   HMAC-SHA256(key = RND_KEY, message = RND_KEY + nonce + _time + ':' + nonce) 的 hex（小写）
 *   _rnd = '15:' + hmac，放进 URL query，与 hkey / _time / nonce 同级。
 * 实测：不带 _rnd → {"msg":"缺失参数"}；带错 _rnd → {"msg":"评论功能暂不可用"}；
 *       带对 _rnd → 参数契约通过（用 link_id=1 会回「该内容已被删除」）。
 */
export const RND_KEY = 'Z7mFG4tQp9Ws2LxB8H';

export function rndSignature(nonce, ts) {
  const n = String(nonce == null ? '' : nonce);
  const t = String(ts == null ? '' : ts);
  const hmac = crypto.createHmac('sha256', RND_KEY).update(RND_KEY + n + t + ':' + n).digest('hex');
  return '15:' + hmac;
}

/**
 * 发评论的请求形态（实测三段验过签名与参数契约，但**没有真的在真实帖子下发过**）：
 *   POST /bbs/app/comment/create?…&_rnd=15:…（form body）
 *   body: is_cy=0&link_id=<id>&reply_id=<主评论 -1 或目标评论 id>&root_id=<楼中楼根评论 id 或 -1>&text=<urlencoded>
 */
export function commentRequest(linkId, text, replyTo, rootId) {
  return {
    method: 'POST',
    path: '/bbs/app/comment/create',
    rnd: true,
    params: {
      is_cy: '0',
      link_id: String(linkId),
      reply_id: replyTo ? String(replyTo) : '-1',
      root_id: rootId ? String(rootId) : '-1',
      text: String(text)
    }
  };
}

/**
 * feeds 各分支的真实请求契约（1.1.3 实测，别再按猜的键发）：
 *   kind=topic  GET /bbs/app/topic/feeds        —— **必须同时带 topic_id 与 limit**
 *               只带 topic_id+offset → {"status":"failed","msg":"请求参数 \"limit\" 缺失"}
 *               带 topic_id+limit+offset → 200 / result.links 20 条
 *   kind=news   GET /bbs/app/topic/feeds/news   —— **同样必须带 topic_id**（这是话题新闻，不是全站新闻）
 *               不带 topic_id → {"status":"failed","msg":"请求参数 \"topic_id\" 缺失"}
 *               带 topic_id+limit+offset → 200 / result.links 19 条
 *   kind=banner 不需要 topicId；kind=recommend 保持 pull/offset/dw。
 * 两分支的 items 与 recommend 同构（linkid/title/description/thumbs/imgs/comment_num/user/has_video/topics），
 * 所以统一走 feedRow。
 */
export function feedsSpec(kind, options) {
  const bag = options && typeof options === 'object' ? options : {};
  const offset = String(bag.offset === undefined || bag.offset === null ? 0 : bag.offset);
  const limit = String(bag.limit === undefined || bag.limit === null ? 10 : bag.limit);
  if (kind === 'banner') return { path: '/bbs/app/feeds/banner', params: {} };
  if (kind === 'recommend') {
    return { path: '/bbs/app/feeds', params: { pull: '0', offset, dw: '604' }, cache: true };
  }
  const topicId = String(bag.topicId === undefined || bag.topicId === null ? '' : bag.topicId);
  if (!/^[0-9]{1,24}$/.test(topicId)) {
    throw xhhError(XHH_CODES.BAD_ARG,
      'feeds(kind="' + kind + '") 需要 topicId（纯数字话题 id）：先调 topics 工具拿一个（topics(limit=5) 的 topicId）。'
      + 'kind="' + kind + '" 不带 topicId 服务端会直接回「请求参数 topic_id 缺失」。');
  }
  return {
    path: kind === 'news' ? '/bbs/app/topic/feeds/news' : '/bbs/app/topic/feeds',
    params: { topic_id: topicId, limit, offset }
  };
}

/** POST 的 form body（request() 与单测共用这一套编码）。 */
export function formEncode(params) {
  const extra = params && typeof params === 'object' ? params : {};
  const pairs = [];
  for (const [key, value] of Object.entries(extra)) {
    if (value === undefined || value === null) continue;
    pairs.push(encodeURIComponent(key) + '=' + encodeURIComponent(String(value)));
  }
  return pairs.join('&');
}

/** cookie 串 -> 空原型字典（拒绝原型链键，同名只取第一次出现）。 */
export function parseCookie(text) {
  const jar = Object.create(null);
  for (const part of String(text == null ? '' : text).split(';')) {
    const index = part.indexOf('=');
    if (index <= 0) continue;
    const key = part.slice(0, index).trim();
    if (!key || key.length > 64 || BAD_KEYS.has(key)) continue;
    if (Object.prototype.hasOwnProperty.call(jar, key)) continue;
    jar[key] = part.slice(index + 1).trim();
  }
  return jar;
}

/** 从 cookie 里取身份；uid 只认纯数字，nickname 做 URL 解码后再截断。 */
export function cookieIdentity(text) {
  const raw = String(text == null ? '' : text);
  const jar = parseCookie(raw);
  const uidRaw = String(jar.heybox_id || jar.user_heybox_id || jar.userid || '').trim();
  let nickname = String(jar.nickname || '');
  // 实测小黑盒的 nickname 用的是 JS 的 %uXXXX 转义（例如 %u98D8%u4E86），不是标准百分号编码。
  nickname = nickname.replace(/%u([0-9a-fA-F]{4})/g, (whole, hex) => String.fromCharCode(parseInt(hex, 16)));
  if (/%[0-9a-f]{2}/i.test(nickname)) {
    try { nickname = decodeURIComponent(nickname); } catch { /* 保持原样 */ }
  }
  return {
    uid: /^[0-9]{1,24}$/.test(uidRaw) ? uidRaw : '',
    nickname: nickname.trim().slice(0, 24),
    keyCount: Object.keys(jar).length
  };
}

// ════════════════════════════════════════════════════════════════════════
// 五、设置、限速、缓存、存储临界区
// ════════════════════════════════════════════════════════════════════════
export const DEFAULT_SETTINGS = Object.freeze({
  ownerUid: '',
  intervalMs: 1200,
  feedsCacheSec: 60,
  commentCount: 20,
  maxTextChars: 4000,
  sendImages: true,
  maxImages: 3,
  sendMode: 'auto',
  sendHostRetryMinutes: 30,
  sendVideos: false,
  maxFileMb: 40
});

function clampInt(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.floor(n)));
}

export function resolveSettings(raw) {
  const source = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const out = Object.create(null);
  out.ownerUid = typeof source.ownerUid === 'string' && /^[0-9]{1,24}$/.test(source.ownerUid.trim())
    ? source.ownerUid.trim() : '';
  out.intervalMs = clampInt(source.intervalMs, DEFAULT_SETTINGS.intervalMs, 500, 5000);
  out.feedsCacheSec = clampInt(source.feedsCacheSec, DEFAULT_SETTINGS.feedsCacheSec, 0, 600);
  out.commentCount = clampInt(source.commentCount, DEFAULT_SETTINGS.commentCount, 5, 50);
  out.maxTextChars = clampInt(source.maxTextChars, DEFAULT_SETTINGS.maxTextChars, 200, 20000);
  out.sendImages = source.sendImages === undefined ? DEFAULT_SETTINGS.sendImages : source.sendImages === true;
  out.maxImages = clampInt(source.maxImages, DEFAULT_SETTINGS.maxImages, 1, 9);
  out.sendMode = ['auto', 'forward', 'host'].includes(String(source.sendMode))
    ? String(source.sendMode) : DEFAULT_SETTINGS.sendMode;
  out.sendHostRetryMinutes = clampInt(source.sendHostRetryMinutes, DEFAULT_SETTINGS.sendHostRetryMinutes, 1, 720);
  out.sendVideos = source.sendVideos === true;
  out.maxFileMb = clampInt(source.maxFileMb, DEFAULT_SETTINGS.maxFileMb, 5, 80);
  return out;
}

/**
 * 进程内串行队列：同一时刻只有一个请求在飞，且相邻两次间隔 >= gap。
 * 排队要等的时间超过剩余预算时不发请求，直接抛 XHH_BUDGET（不补假地板）。
 */
export function createGate(getGapMs) {
  let chain = Promise.resolve();
  let lastAt = 0;
  return function enqueue(task, remaining) {
    const run = chain.then(async () => {
      const gap = Number(getGapMs()) || 0;
      const wait = Math.max(0, lastAt + gap - Date.now());
      if (wait > 0) {
        if (typeof remaining === 'function' && remaining() < wait + 250) {
          throw xhhError(XHH_CODES.BUDGET,
            '限速队列还要等 ' + wait + 'ms，但本轮预算只剩 ' + remaining() + 'ms：这次不发请求（避免把一次超时变成每次都超时）。'
            + '稍后再问一次即可。');
        }
        await sleep(wait);
      }
      lastAt = Date.now();
      return task();
    });
    chain = run.then(() => {}, () => {});
    return run;
  };
}

/** 存储读写：读+改+写全在同一条 promise 链里完成（无锁可释放，链不会因一次失败断掉）。 */
export function createStore(callHost) {
  let chain = Promise.resolve();
  const queue = (fn) => {
    const run = chain.then(fn, fn);
    chain = run.then(() => {}, () => {});
    return run;
  };
  return {
    read(key, capMs) {
      return queue(async () => {
        const reply = await callHost('cap.storage.get', { key }, capMs);
        const value = reply && reply.value;
        return value === undefined ? null : value;
      });
    },
    mutate(key, transform, capMs) {
      return queue(async () => {
        const reply = await callHost('cap.storage.get', { key }, capMs);
        const current = reply && reply.value !== undefined ? reply.value : null;
        const next = transform(current);
        await callHost('cap.storage.set', { key, value: next }, capMs);
        return next;
      });
    }
  };
}

// ════════════════════════════════════════════════════════════════════════
// 六、createRouter：参数守卫 + 错误码映射 + 工具表
// ════════════════════════════════════════════════════════════════════════
export function createRouter(options) {
  const boot = options || {};
  const callHost = boot.callHost;
  let gapMs = DEFAULT_SETTINGS.intervalMs;
  const gate = createGate(() => gapMs);
  const store = createStore(callHost);
  const cacheStore = new Map();

  function cacheGet(key, ttlSec) {
    const hit = cacheStore.get(key);
    if (!hit) return null;
    if (ttlSec <= 0 || Date.now() - hit.at >= ttlSec * 1000) {
      cacheStore.delete(key);
      return null;
    }
    return hit.data;
  }

  function cacheSet(key, data) {
    cacheStore.set(key, { at: Date.now(), data });
    if (cacheStore.size > 24) {
      const oldest = [...cacheStore.entries()].sort((a, b) => a[1].at - b[1].at)[0];
      if (oldest) cacheStore.delete(oldest[0]);
    }
  }

  /** 每个 cap 调用都带超时，上界来自剩余预算（不是固定值）。 */
  async function callCap(env, method, params, capMs) {
    const left = env.remaining();
    if (left < 300) {
      throw xhhError(XHH_CODES.BUDGET,
        '剩余预算只剩 ' + left + 'ms，不够再和宿主/小黑盒来回一次：这次不继续取数据，先用已拿到的部分回答。');
    }
    const ceiling = Number(capMs) > 0 ? Number(capMs) : 8000;
    return env.callHost(method, params, Math.min(ceiling, Math.max(300, left - 200)));
  }

  async function ensureDeviceId(env) {
    if (env.deviceId) return env.deviceId;
    let stored = null;
    try { stored = await store.read(DEVICE_KEY, Math.min(2000, Math.max(300, env.remaining() - 200))); } catch { stored = null; }
    if (typeof stored === 'string' && /^[0-9a-f]{32}$/.test(stored)) {
      env.deviceId = stored;
      return stored;
    }
    const fresh = mkDeviceId();
    try {
      await store.mutate(DEVICE_KEY, () => fresh, Math.min(3000, Math.max(300, env.remaining() - 200)));
    } catch { /* 存不下也不影响这次请求 */ }
    env.deviceId = fresh;
    return fresh;
  }

  async function getAuth(env) {
    if (env.auth) return env.auth;
    let values = null;
    try { values = await callCap(env, 'cap.secrets.get', {}, 3000); } catch { values = null; }
    const bag = values && values.values && typeof values.values === 'object' ? values.values : {};
    const cookie = typeof bag.cookie === 'string' ? bag.cookie.trim().slice(0, 8000) : '';
    const identity = cookieIdentity(cookie);
    const deviceId = await ensureDeviceId(env);
    env.auth = {
      cookie,
      uid: identity.uid,
      nickname: identity.nickname,
      keyCount: identity.keyCount,
      configured: Boolean(cookie),
      deviceId
    };
    return env.auth;
  }

  async function requireCookie(env, mode) {
    const auth = await getAuth(env);
    if (!auth.cookie) {
      throw xhhError(XHH_CODES.NO_LOGIN,
        '这个操作需要登录：小黑盒只有网页版 cookie，没有扫码登录接口。'
        + '请在 控制台 → 插件 → 小黑盒 里填网页版 cookie（浏览器 F12 → Network → 任一 api.xiaoheihe.cn 请求的 cookie 头），'
        + '或调用 login(action=set, cookie=...)。不需要登录也能用：feeds、search、read、post、watch、topics。');
    }
    if (mode === 'write') {
      const owner = env.settings.ownerUid;
      if (!owner) return auth;
      if (!auth.uid) {
        throw xhhError(XHH_CODES.NO_LOGIN,
          '设置里绑了主人 UID ' + owner + '，但这串 cookie 里没有 heybox_id，无法核对是谁在写：写操作已拒绝。'
          + '请换一串登录态完整的 cookie，或清空设置里的主人 UID。');
      }
      if (auth.uid !== owner) {
        throw xhhError(XHH_CODES.NO_LOGIN,
          '当前 cookie 属于 UID ' + auth.uid + '，不是设置里绑定的主人 UID ' + owner + '：写操作已拒绝（避免拿别人的账号点赞/关注/评论）。');
      }
    }
    return auth;
  }

  function buildUrl(spec, auth) {
    const query = buildQuery({
      path: spec.path,
      params: spec.params || {},
      uid: auth.uid,
      deviceId: auth.deviceId,
      app: spec.app,
      rnd: spec.rnd === true
    });
    return API_BASE + spec.path + '?' + query;
  }

  function baseHeaders(auth) {
    const headers = {
      accept: 'application/json, text/plain, */*',
      origin: SITE,
      referer: SITE + '/',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-site',
      'user-agent': UA
    };
    if (auth && auth.cookie) headers.cookie = auth.cookie;
    return headers;
  }

  /** 一次签名请求：串行排队 -> cap.http.request -> 三形态分类。 */
  async function request(env, spec) {
    const auth = await getAuth(env);
    const method = spec.method === 'POST' ? 'POST' : 'GET';
    const headers = baseHeaders(auth);
    const url = buildUrl(method === 'POST' ? { ...spec, params: {} } : spec, auth);
    let body;
    if (method === 'POST') {
      // 参数一律走 form body（实测 link/favour 把 link_id 放 query 会回「该帖子不存在」）
      body = formEncode(spec.params);
      headers['content-type'] = 'application/x-www-form-urlencoded';
    }
    const cacheKey = spec.cache ? safeKey(method + ' ' + spec.path + ' ' + JSON.stringify(spec.params || {})) : '';
    if (cacheKey) {
      const hit = cacheGet(cacheKey, env.settings.feedsCacheSec);
      if (hit) return { data: hit, cached: true };
    }
    const response = await gate(async () => {
      const left = env.remaining();
      if (left < 800) {
        throw xhhError(XHH_CODES.BUDGET,
          '剩余预算只剩 ' + left + 'ms，不够发一次请求（小黑盒单次往返通常 300-800ms）：这次不发请求，先用已拿到的部分回答。');
      }
      const payload = {
        url,
        method,
        headers,
        body,
        maxChars: HTTP_MAX_CHARS
      };
      // 扫码轮询的凭据在响应头里：v2 宿主支持 withSetCookies（要求插件声明 secrets）
      if (spec.withSetCookies === true) payload.withSetCookies = true;
      return callCap(env, 'cap.http.request', payload, 12000);
    }, env.remaining);

    const verdict = classifyBody(response && response.body, {
      httpStatus: response && response.status,
      truncated: response && response.truncated === true
    });
    if (!verdict.ok) throw xhhError(verdict.code, verdict.message);
    if (cacheKey) cacheSet(cacheKey, verdict.data);
    // setCookies 只在显式要求时存在；原文不上日志、不进回执，只交给调用方解析
    const setCookies = spec.withSetCookies === true && Array.isArray(response && response.setCookies)
      ? response.setCookies.map((item) => String(item)) : [];
    return { data: verdict.data, cached: false, setCookies };
  }

  // 扫码登录的 pending 只活在进程内（qr 本身不是凭据，但也没必要落盘）
  let qrPending = null;

  /**
   * 用 /account/restore_login 判登录态（实测这是最准的一条：已登录回 account_detail，
   * 失效回 {"status":"relogin","msg":"请重新登录","result":{}}）。app 必须是 heybox。
   */
  async function restoreLogin(env) {
    const auth = await getAuth(env);
    if (!auth.cookie) return { state: 'nologin' };
    try {
      const got = await request(env, { path: '/account/restore_login', app: 'heybox', params: {} });
      return { state: 'ok', ...restoreLoginInfo(got.data) };
    } catch (error) {
      if (error && error.code === XHH_CODES.RELOGIN) return { state: 'relogin' };
      throw error;
    }
  }

  /**
   * 上面那版的「软」版本：restore_login 自身失败（非法请求 / 网络 / 参数）时不让整个 status/whoami 挂掉，
   * 而是回 state:'unknown' 并把原因带上 —— 登录态未知 ≠ 未登录。
   */
  async function restoreLoginSoft(env) {
    try {
      return await restoreLogin(env);
    } catch (error) {
      return { state: 'unknown', message: String((error && error.message) || error).slice(0, 200) };
    }
  }

  // ── 发文件：主路 cap.send.file，命中跨容器错误才降级 forward ──────────
  async function degradeWindow(env) {
    let raw = null;
    try { raw = await store.read(DEGRADE_KEY, 2500); } catch { raw = null; }
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { until: 0, strikes: 0 };
    return { until: Number(raw.until) || 0, strikes: Number(raw.strikes) || 0 };
  }

  async function markDegrade(env) {
    try {
      await store.mutate(DEGRADE_KEY, (current) => {
        const base = current && typeof current === 'object' && !Array.isArray(current) ? current : {};
        const strikes = Math.min(6, (Number(base.strikes) || 0) + 1);
        const window = Math.min(DEGRADE_MAX_MS, DEGRADE_BASE_MS * Math.pow(2, strikes - 1));
        return { until: Date.now() + window, strikes, windowMs: window };
      }, 3000);
    } catch { /* 记不下就只是下次再探一次 */ }
  }

  async function clearDegrade(env) {
    try {
      const current = await degradeWindow(env);
      if (current.until || current.strikes) {
        await store.mutate(DEGRADE_KEY, () => ({ until: 0, strikes: 0, windowMs: 0 }), 3000);
      }
    } catch { /* 清不掉不影响本次发送 */ }
  }

  async function sendFileToChat(env, payload) {
    const chatKey = String((env.context && env.context.chatKey) || '');
    if (!/^group:[0-9]+$/.test(chatKey)) {
      return { sent: false, reason: 'not-group', forward: { tool: 'send_group_file', url: payload.url, name: payload.name } };
    }
    const mode = env.settings.sendMode;
    const window = await degradeWindow(env);
    const inDegrade = window.until > Date.now();
    if (mode === 'forward' || (mode === 'auto' && inDegrade)) {
      return {
        sent: false,
        reason: mode === 'forward' ? 'forward-only' : 'degrade-window',
        retryAt: inDegrade ? new Date(window.until).toISOString() : '',
        forward: { tool: 'send_group_file', url: payload.url, name: payload.name }
      };
    }
    try {
      await callCap(env, 'cap.send.file', { chatKey, file: payload.file, name: payload.name }, 15000);
      await clearDegrade(env);
      return { sent: true };
    } catch (error) {
      const text = String((error && error.message) || error);
      if (/ENOENT|realpath|retcode=100/i.test(text)) {
        env.log('send.file 跨容器失败（原始报错只记日志）：' + text.slice(0, 200));
        await markDegrade(env);
        return {
          sent: false,
          reason: 'cross-container',
          forward: { tool: 'send_group_file', url: payload.url, name: payload.name },
          note: '宿主把文件路径交给协议端时协议端读不到（容器隔离）。已降级为转发：用 forward 里的参数调用 send_group_file 把这张图发出去。首次发图报一次这个错属正常探路。'
        };
      }
      return { sent: false, reason: 'error', error: text.slice(0, 200) };
    }
  }

  /**
   * 写接口的参数名没有对着服务端核对过：真机验证会真的改动账号（点赞/收藏/关注/发评论），本次没做。
   * 2026-10-27 实测：/bbs/app/link/favour 返回 92 字节「验证参数错误」（签名已过、参数不对），
   * 所以被 XHH_BAD_PARAM 打回时要把这个结论写进文案，避免模型拿同样的参数反复重试。
   */
  function writeEndpointHint(message, path) {
    if (path === '/bbs/app/link/favour') {
      return message + ' 这条写接口（' + path + '）是**测试账号真机验过**的：POST form body = link_id=…&favour_type=1（收藏）/ 0（取消）。'
        + '它现在返回「验证参数错误」说明服务端契约变了，把原话转告维护者，不要换参数重试。';
    }
    if (path === '/bbs/app/profile/follow/user' || path === '/bbs/app/profile/follow/user/cancel') {
      return message + ' 这条写接口（' + path + '）是**测试账号真机验过**的：POST form body = following_id=<目标>&follower_id=<自己>'
        + '（取关走 /cancel）。它现在返回「验证参数错误」说明服务端契约变了，把原话转告维护者，不要换参数重试。';
    }
    if (path === '/bbs/app/comment/create') {
      return message + ' 具体到这条写接口（' + path + '）：签名（hkey + _rnd）与 body 参数契约已经用真实响应验过'
        + '（不带 _rnd→「缺失参数」，带错→「评论功能暂不可用」，带对→进入业务校验），但没有在真实帖子下真发过。'
        + '现在回「验证参数错误」说明服务端契约变了，把原话转告维护者，不要换参数重试。';
    }
    return message + ' 具体到这条写接口（' + path + '）：它的参数名还没有对着服务端核对过'
      + '（真机验证会真的改动账号，本次没做）。换参数重试同样是这个结果：请把原话转告维护者，不要重复调用。';
  }

  /** 下载一张图并做 contentType 白名单 + bytes 双判；失败即抛，调用方不得计入 seen。 */
  async function downloadImage(env, url, name) {
    const auth = await getAuth(env);
    const headers = { referer: SITE + '/', origin: SITE, 'user-agent': UA };
    if (auth.cookie) headers.cookie = auth.cookie;
    const reply = await callCap(env, 'cap.media.download', {
      url,
      name,
      maxBytes: Math.max(5, env.settings.maxFileMb) * 1024 * 1024,
      headers
    }, 12000);
    const contentType = String((reply && reply.contentType) || '');
    const bytes = Number((reply && reply.bytes) || 0);
    if (!/^image\//i.test(contentType)) {
      throw xhhError(XHH_CODES.UPSTREAM,
        '这张图下回来的不是图片（contentType=' + (contentType || '空') + '，' + bytes + ' 字节），已跳过、也没记为发过。');
    }
    if (bytes < MEDIA_MIN_BYTES) {
      throw xhhError(XHH_CODES.UPSTREAM,
        '这张图只有 ' + bytes + ' 字节，判定为错误页，已跳过、也没记为发过。');
    }
    return { file: String((reply && reply.file) || name), bytes, contentType };
  }

  // ── 工具实现 ─────────────────────────────────────────────────────────
  const handlers = Object.create(null);

  handlers.feeds = async (args, env) => {
    const kind = argEnum(args.kind, 'kind', ['recommend', 'news', 'topic', 'banner'], 'recommend');
    const offset = argInt(args.offset, 'offset', 0, 0, 100000);
    const limit = argInt(args.limit, 'limit', 10, 1, 50);
    // topic / news 都必须带 topicId：缺了在插件侧就报错，不把注定失败的请求发出去
    const topicId = kind === 'topic' || kind === 'news'
      ? argId(args.topicId, 'topicId', { hint: '话题 id，先用 topics 工具查（kind=' + kind + ' 必填）' })
      : '';
    const spec = feedsSpec(kind, { topicId, offset, limit });
    const got = await request(env, spec);
    const items = extractLinks(got.data).slice(0, limit).map((item) => feedRow(item))
      .filter((row) => row.linkId || row.title);
    return {
      ok: true,
      kind,
      offset,
      limit,
      topicId: topicId || undefined,
      count: items.length,
      cached: got.cached,
      items,
      advise: items.length
        ? '想看某一条的正文和评论：post(link_id="' + items[0].linkId + '")；只要正文：read(link_id="' + items[0].linkId + '")；'
          + '要图：watch(link_id="' + items[0].linkId + '", send=true)。feeds 不需要 cookie。'
          + '如果这次回的是「非法请求」（XHH_GATED）：先确认插件是 1.0.2 或更新（旧版签名错，所有端点都会这样失败），'
          + '再跑 account(what=doctor) 看是哪几个端点失败。'
        : '这个动态流这次没有条目。kind=recommend 是默认流（不需要 topicId）；'
          + 'kind="topic" 和 kind="news" 都必须给 topicId（先用 topics 工具拿，例如 topics(limit=5) 里的 topicId），'
          + '不给服务端会回「请求参数 topic_id 缺失」；kind=banner 不需要 topicId。'
          + '如果 ok=true 但一直为空，用 account(what=doctor) 看端点状态。'
    };
  };

  handlers.search = async (args, env) => {
    const keyword = argText(args.keyword, 'keyword', { required: true, max: 60, min: 1, hint: '要搜的词' });
    const page = argInt(args.page, 'page', 1, 1, 50);
    const kind = argEnum(args.kind, 'kind', ['post', 'game', 'user'], 'post');
    const offset = String((page - 1) * 30);
    const got = await request(env, {
      path: '/bbs/app/api/general/search/v1',
      params: {
        q: keyword,
        search_type: 'general',
        is_pull_down: '0',
        offset,
        limit: '30',
        dw: '628'
      }
    });
    const rows = searchRows(got.data, kind).slice(0, 20);
    const first = rows[0] || {};
    return {
      ok: true,
      keyword,
      kind,
      page,
      count: rows.length,
      results: rows,
      advise: rows.length
        ? (kind === 'post'
          ? '这些是帖子：读正文用 read(link_id="' + (first.linkId || '') + '")，正文+评论用 post(...)，发图用 watch(...)。'
          : (kind === 'user'
            ? '这些是用户：看资料用 user(userid="' + (first.userId || '') + '")。'
            : '这些是游戏条目：只有名字/图标/评分。小黑的搜索响应里没有可用的游戏 id（只有 steam_appid），本插件也没有游戏详情工具。'))
        : '没有搜到东西。换更短的关键词（2-4 个字）再试；小黑盒搜索对生僻词常返回空。'
    };
  };

  async function fetchLinkTree(env, linkId, commentLimit) {
    const wanted = argInt(commentLimit, 'commentLimit', env.settings.commentCount, 0, 50);
    const got = await request(env, {
      path: '/bbs/app/link/tree',
      params: {
        link_id: linkId,
        is_first: '1',
        page: '1',
        index: '1',
        limit: String(Math.max(1, wanted || 20)),
        owner_only: '0'
      }
    });
    const link = extractLink(got.data);
    const post = linkRow(link);
    // 评论就在这次响应里（result.comments 是楼层数组）：不再单打 /bbs/app/comment/sub/comments，
    // 那个端点还要 root_comment_id，多一次请求只多一份参数坑。
    const floors = commentFloors(got.data);
    const rows = floors.items.map((item) => commentRow(item)).filter((row) => row.text);
    return {
      post,
      comments: wanted ? rows.slice(0, wanted) : [],
      available: rows.length,
      floorCount: floors.floors,
      totalFloor: floors.totalFloor,
      hasMoreFloors: floors.hasMore
    };
  }

  handlers.post = async (args, env) => {
    const linkId = argId(args.link_id, 'link_id', { hint: '纯数字帖子 id，可从 feeds/search 的 linkId 取' });
    const withComments = argBool(args.withComments, true);
    const result = await fetchLinkTree(env, linkId, withComments ? (args.commentLimit === undefined ? env.settings.commentCount : args.commentLimit) : 0);
    const post = result.post;
    return {
      ok: true,
      post: {
        ...post,
        text: clip(post.text, env.settings.maxTextChars),
        images: post.images
      },
      // 楼层数=本次响应里的楼层数组长度（实测 total_floor_num 与它不一致，不当"总楼层数"承诺）
      floorCount: result.floorCount,
      hasMoreFloors: result.hasMoreFloors,
      video: post.videos[0]
        ? { ...post.videos[0], label: describeVideo(post.videos[0]), note: VIDEO_URL_NOTE }
        : null,
      commentCount: result.comments.length,
      commentTotal: post.commentCount,
      comments: withComments ? result.comments : [],
      advise: '这个 link_id 可以继续用 read(link_id="' + linkId + '") 只读正文纯文本，或 watch(link_id="' + linkId
        + '", send=true) 把帖子里的图发到群里。'
        + (withComments ? ' 评论就在这次响应里（共 ' + result.floorCount + ' 层，给了 ' + result.comments.length + ' 条）。' : ' 这次没带评论：要评论就设 withComments=true。')
        + (post.likeCount === undefined ? ' 小黑盒详情响应里没有点赞字段（只有 up/down，语义未证实），插件不给点赞数。' : '')
        + (post.videos.length ? ' 带视频（' + (describeVideo(post.videos[0]) || '规格未知') + '）：' + VIDEO_URL_NOTE : '')
    };
  };

  handlers.read = async (args, env) => {
    const linkId = argId(args.link_id, 'link_id', { hint: '纯数字帖子 id' });
    const withImages = argBool(args.withImages, false);
    const got = await request(env, {
      path: '/bbs/app/link/tree',
      params: { link_id: linkId, is_first: '1', page: '1', index: '1', limit: '20', owner_only: '0' }
    });
    const post = linkRow(extractLink(got.data));
    const text = String(post.text || '');
    return {
      ok: true,
      linkId,
      title: post.title,
      author: post.author,
      authorId: post.authorId,
      createdAt: post.createdAt,
      text: clip(text, env.settings.maxTextChars),
      textChars: post.textChars,
      textTruncated: text.length > env.settings.maxTextChars,
      imageCount: post.imageCount,
      images: withImages ? post.images.slice(0, 8) : [],
      videoUrls: post.videos.map((item) => item.url),
      videos: post.videos.slice(0, 3).map((item) => ({ ...item, label: describeVideo(item) })),
      // 只给真拿得到的：comment = comment_num，favorite = favour_count（实测字段）。
      // likeCount 在响应里没有对应字段时是 undefined，JSON 里直接消失，不写 0。
      stats: { like: post.likeCount, comment: post.commentCount, favorite: post.favoriteCount },
      url: post.url,
      advise: '正文已经是纯文本，可以直接朗读。'
        + (post.imageCount ? '帖子里有 ' + post.imageCount + ' 张图：要发到群里用 watch(link_id="' + linkId + '", send=true)。' : '这条没有图。')
        + (post.videos.length ? '带视频（' + (describeVideo(post.videos[0]) || '规格未知') + '）：watch(link_id="' + linkId
          + '") 会告诉你能不能发（需先在设置里打开「允许发视频」）。' + VIDEO_URL_NOTE : '')
        + '要看评论用 post(link_id="' + linkId + '")。'
    };
  };

  handlers.watch = async (args, env) => {
    const linkId = argId(args.link_id, 'link_id', { hint: '纯数字帖子 id' });
    const send = argBool(args.send, env.settings.sendImages);
    const quality = argEnum(args.quality, 'quality', ['thumb', 'origin'], 'thumb');
    const maxImages = argInt(args.maxImages, 'maxImages', env.settings.maxImages, 1, 9);
    const got = await request(env, {
      path: '/bbs/app/link/tree',
      params: { link_id: linkId, is_first: '1', page: '1', index: '1', limit: '20', owner_only: '0' }
    });
    const link = extractLink(got.data);
    const post = linkRow(link);
    const origin = pickImages(link);
    const cover = post.cover ? [post.cover] : [];
    const urls = quality === 'origin'
      ? (origin.length ? origin : cover)
      : (cover.length ? cover.concat(origin.filter((url) => url !== cover[0])) : origin);
    const wanted = urls.slice(0, maxImages);
    const items = [];
    let budgetHit = '';
    for (const url of wanted) {
      if (env.remaining() < 1400) { budgetHit = '预算不足，剩下的图这轮没下（下次再要一次更省）。'; break; }
      const name = 'xhh_' + (linkId || 'x') + '_' + crypto.createHash('md5').update(url).digest('hex').slice(0, 8) + '.jpg';
      try {
        const file = await downloadImage(env, url, name);
        const delivery = send ? await sendFileToChat(env, { file: file.file, name, url }) : { sent: false, reason: 'send-off' };
        items.push({ url, file: file.file, bytes: file.bytes, contentType: file.contentType, sent: delivery.sent === true, delivery });
      } catch (error) {
        // 取图失败不计入 seen（这里根本没有 seen 集合，也绝不写"已发过"）
        items.push({ url, sent: false, error: String((error && error.message) || error).slice(0, 220) });
      }
    }
    // 视频：只有「设置里打开允许发视频」+「send=true」+「群聊」三条同时成立才下载并发送；
    // 其余情况一律只给直链（下载几十 MB 会把 15 秒预算吃穿）。
    const videos = post.videos;
    let videoNote = '';
    let video = null;
    if (videos.length) {
      const chatKey = String((env.context && env.context.chatKey) || '');
      const canSendVideo = env.settings.sendVideos && send && /^group:[0-9]+$/.test(chatKey);
      const videoLabel = describeVideo(videos[0]) || '规格未知';
      if (!env.settings.sendVideos) {
        videoNote = '这条带视频（' + videoLabel + '）：设置里「允许发视频」是关的，插件不会下载。' + VIDEO_URL_NOTE;
      } else if (!send) {
        videoNote = '这条带视频（' + videoLabel + '）：send=false，插件不下载。' + VIDEO_URL_NOTE;
      } else if (!/^group:[0-9]+$/.test(chatKey)) {
        videoNote = '这条带视频（' + videoLabel + '）：宿主只允许向群聊发文件，私聊/控制台不发。' + VIDEO_URL_NOTE;
      } else if (env.remaining() < 4000) {
        videoNote = '这条带视频（' + videoLabel + '）：剩余预算不足 4 秒，视频没下载（图优先）。需要视频就单独再要一次（会重新拿一条新签名链接）。';
      } else {
        const videoName = 'xhh_' + (linkId || 'x') + '_video.mp4';
        try {
          const auth = await getAuth(env);
          const headers = { referer: SITE + '/', origin: SITE, 'user-agent': UA };
          if (auth.cookie) headers.cookie = auth.cookie;
          const reply = await callCap(env, 'cap.media.download', {
            url: videos[0].url,
            name: videoName,
            maxBytes: Math.max(5, env.settings.maxFileMb) * 1024 * 1024,
            headers
          }, 14000);
          const bytes = Number((reply && reply.bytes) || 0);
          if (bytes < MEDIA_MIN_BYTES) throw xhhError(XHH_CODES.UPSTREAM, '视频只下到 ' + bytes + ' 字节，判定为错误响应，没发。');
          const delivery = canSendVideo ? await sendFileToChat(env, { file: String((reply && reply.file) || videoName), name: videoName, url: videos[0].url }) : { sent: false };
          video = { url: videos[0].url, file: videoName, bytes, label: videoLabel, sent: delivery.sent === true, delivery };
          videoNote = delivery.sent === true ? '视频已发到本群（' + videoLabel + '）。' : '视频下载好了但没发出去，原因见 video.delivery。';
        } catch (error) {
          video = { url: videos[0].url, label: videoLabel, sent: false, error: String((error && error.message) || error).slice(0, 220) };
          // 签名直链约 2 小时过期：失败先怀疑过期，让用户重新拿链接，别建议存旧链接
          videoNote = '视频没发出去：' + video.error + '。这条链接是带签名的（约 2 小时有效），很可能是过期了 —— 重新 post/watch 一次会拿到新链接；别把旧链接存起来。';
        }
      }
    }
    const sentCount = items.filter((item) => item.sent).length;
    const forwards = items.filter((item) => item.delivery && item.delivery.forward).map((item) => item.delivery.forward);
    return {
      ok: true,
      linkId,
      title: post.title,
      quality,
      requested: wanted.length,
      count: items.length,
      sent: sentCount,
      images: items,
      video,
      forward: forwards.length ? forwards[0] : null,
      budgetHit,
      videoNote,
      advise: !wanted.length
        ? '这条帖子没有图：响应里 imgs / thumbs / 正文图片块都是空的，所以没什么可发（纯文字帖就是这样）。'
          + (videoNote ? ' ' + videoNote : '')
        : (sentCount
          ? '已把 ' + sentCount + ' 张图发到本群。'
          : (forwards.length
            ? '宿主这条路发不出去（协议端读不到宿主给的路径）。照抄 forward 的参数调 send_group_file，一张一张发。'
            : (send
              ? '没有图发出去：看 images[].error 里每一张的原因。'
              : 'send=false，只下载图没有发。要发就说 send=true（仅群聊）。')))
          + ' 首次发图可能报一次「跨容器」错，属正常探路，之后会走转发。'
          + (videoNote ? ' ' + videoNote : '')
    };
  };

  handlers.topics = async (args, env) => {
    const limit = argInt(args.limit, 'limit', 20, 1, 50);
    const got = await request(env, { path: '/bbs/app/topic/categories', params: {} });
    // 实测：话题不在 result.categories（那个一直是空数组），而在三组 children 里（见 topicGroups）
    const parsed = topicGroups(got.data);
    const rows = parsed.rows.slice(0, limit);
    return {
      ok: true,
      count: rows.length,
      groups: parsed.groups,
      topics: rows,
      advise: rows.length
        ? '拿 topicId 走 feeds：feeds(kind="topic", topicId="' + rows[0].topicId + '")（例如「' + rows[0].name + '」）；'
          + 'feeds(kind="news") 看话题新闻。result.categories 为空是正常现象，话题来自「为你推荐 / 近期热门 / 我的偏好」三组。'
        : '这次没拿到话题条目（三组 children 都为空）。先用 feeds(kind="recommend") 看帖，或跑 account(what=doctor) 看端点状态。'
    };
  };

  handlers.user = async (args, env) => {
    const raw = argText(args.userid, 'userid', { required: true, max: 24, hint: '数字 UID，或 me' });
    const withPosts = argBool(args.withPosts, true);
    const auth = await getAuth(env);
    const userid = raw === 'me' ? (auth.uid || '') : raw;
    if (!userid) {
      throw xhhError(XHH_CODES.NO_LOGIN,
        'userid=me 需要先登录（本账号 UID 从 cookie 的 heybox_id 里读）。没登录就传具体数字 UID，例如 user(userid="123456")。');
    }
    if (!/^[0-9]{1,24}$/.test(userid)) {
      throw xhhError(XHH_CODES.BAD_ARG, 'userid 只能是纯数字，或字符串 me；收到的是 ' + userid);
    }
    const got = await request(env, { path: '/bbs/app/profile/user/profile', params: { userid } });
    const profile = userRow(got.data);
    let posts = [];
    if (withPosts) {
      const list = await request(env, {
        path: '/bbs/app/profile/user/link/list_v2',
        params: { userid, offset: '0', limit: '20' }
      });
      // 实测投稿在 result.post_links（与 feeds 条目同构），作者名来自 result.user.username
      posts = userPostRows(list.data).slice(0, 12);
    }
    return {
      ok: true,
      userid,
      profile,
      count: posts.length,
      posts,
      advise: '看某条帖子的正文：post(link_id="' + ((posts[0] && posts[0].linkId) || '') + '")。'
        + '等级取 level_info、粉丝/关注/投稿数取 bbs_info；接口没给的计数直接不出现在结果里（不是 0）。'
        + (profile.postCount === 0 && posts.length === 0 ? ' 这个账号确实一条投稿都没有。' : '')
        + (withPosts ? '' : ' 这次没带投稿列表：要就设 withPosts=true。')
    };
  };

  handlers.account = async (args, env) => {
    const what = argEnum(args.what, 'what', ['whoami', 'doctor', 'messages', 'history', 'favorites', 'following'], 'whoami');
    const page = argInt(args.page, 'page', 1, 1, 50);
    const offset = String((page - 1) * 20);
    const auth = await getAuth(env);

    if (what === 'whoami') {
      if (!auth.cookie) {
        return {
          ok: true,
          loggedIn: false,
          configured: false,
          state: 'nologin',
          uid: '',
          nickname: '',
          advise: '还没登录：login(action="start") 扫码登录（首选，120 秒内有效），或 login(action="set", cookie=...) 粘贴网页版 cookie（兜底）。'
            + '不登录也能用 feeds/search/read/post/watch/topics/user。'
        };
      }
      // 实测：restore_login 的 account_detail 才是权威身份（nickname/userid/level），不再靠 cookie 里的 nickname
      const restore = await restoreLoginSoft(env);
      if (restore.state !== 'ok') {
        return {
          ok: true,
          loggedIn: false,
          configured: true,
          state: restore.state,
          uid: auth.uid,
          nickname: auth.nickname,
          level: undefined,
          cookieKeys: auth.keyCount,
          ownerUid: env.settings.ownerUid,
          advise: (restore.state === 'relogin'
            ? '登录态已失效（restore_login 回 relogin）：login(action="start") 扫码登录是首选；'
              + '也可以 login(action="set", cookie=...) 粘贴新的网页版 cookie。写操作现在会返回 XHH_NO_LOGIN。'
            : '登录态没法确认：restore_login 这次没成（' + (restore.message || '上游错误') + '）。'
              + 'cookie 还在、写操作仍会尝试；想确认真实身份就过一会儿再 account(what=whoami)。')
        };
      }
      return {
        ok: true,
        loggedIn: true,
        configured: true,
        state: 'ok',
        verified: Boolean(restore.userid),
        uid: restore.userid || auth.uid,
        nickname: restore.nickname || auth.nickname,
        level: restore.level,
        cookieKeys: auth.keyCount,
        ownerUid: env.settings.ownerUid,
        ownerMatches: env.settings.ownerUid ? ((restore.userid || auth.uid) === env.settings.ownerUid) : null,
        advise: env.settings.ownerUid && (restore.userid || auth.uid) !== env.settings.ownerUid
          ? '当前登录的 UID 与设置里的主人 UID 不一致：写操作会被拒绝，请改设置或换账号。'
          : '登录态有效（restore_login 回 account_detail）。要确认每个接口在这台机器上的真实状态，用 account(what=doctor)。'
      };
    }

    if (what === 'doctor') {
      const steps = [];
      const probe = async (label, spec, explain) => {
        const startedAt = Date.now();
        try {
          const got = await request(env, spec);
          steps.push({ label, path: spec.path, status: 'ok', ms: Date.now() - startedAt, note: explain || '' });
          return got.data;
        } catch (error) {
          steps.push({
            label,
            path: spec.path,
            status: 'fail',
            code: (error && error.code) || XHH_CODES.UPSTREAM,
            ms: Date.now() - startedAt,
            note: String((error && error.message) || error).slice(0, 260)
          });
          return null;
        }
      };

      // 登录态单独一步：正常回 account_detail（ok），失效回 status:"relogin"，这两者都不算「端点坏」
      const loginStarted = Date.now();
      let loginState = 'skipped';
      let loginNote = '没配 cookie：这一步没探测，登录态未知。';
      try {
        const restored = await restoreLogin(env);
        loginState = restored.state === 'ok' ? 'ok' : restored.state;
        loginNote = restored.state === 'ok'
          ? '已登录：' + (restored.nickname || '(无名)') + ' / UID ' + (restored.userid || '?')
          : (restored.state === 'relogin' ? 'restore_login 回 relogin：登录态已失效，要写操作就 login(action="start") 扫码。'
            : '没配 cookie，本轮没探测。');
      } catch (error) {
        loginState = 'fail';
        loginNote = String((error && error.message) || error).slice(0, 220);
      }
      steps.push({
        label: '登录态 /account/restore_login',
        path: '/account/restore_login',
        status: loginState === 'ok' ? 'ok' : (loginState === 'relogin' ? 'relogin' : loginState),
        code: loginState === 'relogin' ? XHH_CODES.RELOGIN : (loginState === 'fail' ? XHH_CODES.UPSTREAM : ''),
        ms: Date.now() - loginStarted,
        note: loginNote
      });

      const feedsData = await probe('动态流 /bbs/app/feeds', { path: '/bbs/app/feeds', params: { pull: '0', offset: '0', dw: '604' } });
      const feedList = extractLinks(feedsData).map((item) => feedRow(item));
      const seededLink = argText(args.link_id, 'link_id', { max: 24 }) || (feedList[0] && feedList[0].linkId) || '';
      const seededUser = argText(args.userid, 'userid', { max: 24 }) || auth.uid || (feedList[0] && feedList[0].authorId) || '';

      if (seededLink && /^[0-9]+$/.test(seededLink)) {
        await probe('帖子详情 /bbs/app/link/tree', {
          path: '/bbs/app/link/tree',
          params: { link_id: seededLink, is_first: '1', page: '1', index: '1', limit: '20', owner_only: '0' }
        }, '用 link_id=' + seededLink + '；评论随这个响应一起返回，插件不再单独打评论接口');
      } else {
        steps.push({
          label: '帖子详情 /bbs/app/link/tree',
          path: '/bbs/app/link/tree',
          status: 'skipped',
          code: '',
          ms: 0,
          note: '没有可用的 link_id（feeds 没返回条目，也没在参数里给 link_id）：这个端点本轮没探测，不能算通过。'
        });
      }

      await probe('搜索 /bbs/app/api/general/search/v1', {
        path: '/bbs/app/api/general/search/v1',
        params: { q: '小黑盒', search_type: 'general', is_pull_down: '0', offset: '0', limit: '5', dw: '628' }
      });

      if (seededUser && /^[0-9]+$/.test(seededUser)) {
        await probe('用户主页 /bbs/app/profile/user/profile', {
          path: '/bbs/app/profile/user/profile',
          params: { userid: seededUser }
        }, '用 userid=' + seededUser);
      } else {
        steps.push({
          label: '用户主页 /bbs/app/profile/user/profile',
          path: '/bbs/app/profile/user/profile',
          status: 'skipped',
          code: '',
          ms: 0,
          note: '没有可用 userid（既没登录、feeds 也没返回作者）：本轮没探测。'
        });
      }

      const byStatus = (value) => steps.filter((step) => step.status === value);
      const loginStep = steps.find((step) => step.path === '/account/restore_login') || null;
      const apiSteps = steps.filter((step) => step.path !== '/account/restore_login');
      const okSteps = apiSteps.filter((step) => step.status === 'ok');
      const gated = apiSteps.filter((step) => step.code === XHH_CODES.GATED);
      const captcha = apiSteps.filter((step) => step.code === XHH_CODES.CAPTCHA);
      const badParam = apiSteps.filter((step) => step.code === XHH_CODES.BAD_PARAM);
      const skipped = apiSteps.filter((step) => step.status === 'skipped');
      let conclusion;
      if (captcha.length) {
        conclusion = '这台机器现在被腾讯验证码挡住（' + captcha.map((step) => step.label).join('、') + '）：插件无法自动过验证，'
          + '请在浏览器里打开一次小黑盒手动过验证或换网络再试。';
      } else if (okSteps.length === 0 && gated.length > 0) {
        conclusion = '所有端点都返回「非法请求」：这种形状说明服务端不接受这次请求的签名或身份，不是网络错误。'
          + '先确认插件是 1.0.2 或更新（旧版 hkey 校验和算错，所有端点都会这样失败）；'
          + '已是最新版仍如此，则这台机器的 IP 多半被临时限流，隔几分钟再试或换出口网络。';
      } else if (okSteps.length === apiSteps.length) {
        conclusion = '全部端点可用：动态流、帖子详情（评论随详情一起返回）、搜索、用户主页都通。'
          + '写操作还要登录 + 管理员批准（收藏/关注已真机验过；发评论的 _rnd 签名与参数契约也已对照真实响应验过，但没在真实帖子下真发过）。'
          + (loginStep && loginStep.status === 'relogin' ? ' 注意：登录态已失效，写操作会返回 XHH_NO_LOGIN，要写就 login(action="start") 扫码。' : '');
      } else {
        const names = okSteps.map((step) => step.label).join('、');
        conclusion = '部分可用：' + (names || '（无）') + ' 通了；'
          + (gated.length ? gated.map((step) => step.label).join('、') + ' 返回「非法请求」（签名不被接受，或这台 IP 被临时限流）；' : '')
          + (badParam.length ? badParam.map((step) => step.label).join('、') + ' 是参数不对（说明签名已过）；' : '')
          + (skipped.length ? skipped.length + ' 个端点因为没有 id 本轮没探测；' : '')
          + '能用到哪一步以 ok 的那几个为准。';
      }
      return {
        ok: true,
        loggedIn: Boolean(auth.uid),
        uid: auth.uid,
        configured: auth.configured,
        steps,
        summary: {
          ok: okSteps.length,
          gated: gated.length,
          captcha: captcha.length,
          badParam: badParam.length,
          skipped: skipped.length,
          login: loginStep ? loginStep.status : 'skipped'
        },
        conclusion,
        advise: 'doctor 是唯一会真发请求的自检：它打 动态流 / 登录态(restore_login) / 帖子详情 / 搜索 / 用户主页，ok 的现在就能用；'
          + '登录态那一步回 relogin 表示 cookie 失效，用 login(action="start") 扫码即可。'
          + '「非法请求」的端点先核对版本是 1.0.2+'
          + '（旧版签名错），已是最新版则多半是这台 IP 被临时限流，隔几分钟再跑；'
          + 'XHH_BAD_PARAM 的是插件参数问题（把原话转告维护者）。别连跑 doctor：它每个端点都真发一次请求。'
      };
    }

    await requireCookie(env, 'read');
    if (what === 'messages') {
      const messageType = argInt(args.messageType, 'messageType', 16, 0, 999);
      const listType = argInt(args.listType, 'listType', 0, 0, 9);
      const limit = argInt(args.limit, 'limit', 20, 1, 50);
      const got = await request(env, {
        path: '/bbs/app/user/message',
        params: {
          message_type: String(messageType),
          list_type: String(listType),
          offset: String(offset),
          limit: String(limit)
        }
      });
      const rows = messageRows(got.data);
      return {
        ok: true,
        what,
        messageType,
        listType,
        offset,
        count: rows.length,
        messages: rows,
        advise: rows.length
          ? '这些是消息：' + (messageType === 16 ? '@我的' : '类型 ' + messageType) + '。要读某条对应的帖子就 post(link_id="'
            + (rows[0].linkId || '') + '")。'
          : '这类消息现在没有（接口回空数组是正常结果，不是错误）。换 messageType 或调大 offset 再看。'
      };
    }
    if (what === 'history') {
      const got = await request(env, { path: '/bbs/app/profile/history/visit', params: { offset, limit: '20' } });
      const rows = extractLinks(got.data).map((item) => feedRow(item)).filter((row) => row.linkId || row.title);
      return { ok: true, what, page, count: rows.length, items: rows, advise: '这是浏览历史：读正文用 read(link_id="' + ((rows[0] && rows[0].linkId) || '') + '")。' };
    }
    if (what === 'favorites') {
      const got = await request(env, { path: '/bbs/app/profile/fav/folders', params: { offset, limit: '20' } });
      const rows = firstArray(got.data, 1).map((item) => {
        const source = item && typeof item === 'object' ? item : {};
        return {
          folderId: String(asTextOf(pick(source, ['folder_id', 'id']))),
          name: asTextOf(pick(source, ['name', 'folder_name', 'title'])).slice(0, 60),
          count: asNumberOf(pick(source, ['link_num', 'count', 'num']))
        };
      }).filter((row) => row.folderId || row.name);
      return {
        ok: true,
        what,
        page,
        count: rows.length,
        folders: rows,
        advise: rows.length
          ? '这是收藏夹列表（本插件只列收藏夹；要读某个夹子里的帖子请在小黑盒网页里看，'
            + '插件没有做 /bbs/app/profile/fav/folder/v2/links 这一步）。'
          : '没读到收藏夹。确认 cookie 是登录态、且 account(what=doctor) 里 feeds 之外的分支至少有一个是 ok。'
      };
    }
    const got = await request(env, { path: '/bbs/app/profile/following/list', params: { offset, limit: '20' } });
    const rows = firstArray(got.data, 1).map((item) => userRow(item)).filter((row) => row.userId || row.userName);
    return {
      ok: true,
      what: 'following',
      page,
      count: rows.length,
      users: rows,
      advise: rows.length
        ? '这些是关注的人：看某个人的资料和投稿用 user(userid="' + rows[0].userId + '")。'
        : '没读到关注列表。确认 cookie 是登录态；空列表也可能意味着这个账号没关注人。'
    };
  };

  handlers.login = async (args, env) => {
    const action = argEnum(args.action, 'action', ['status', 'start', 'poll', 'set', 'clear'], 'status');
    const channel = loginChannelOf(args, env.context);
    // 权限门在任何请求之前：拒绝 = 零请求
    if (action !== 'poll') assertLoginAllowed(action, channel, env.context);
    if (action === 'start') {
      const got = await request(env, { path: '/account/get_qrcode_url', app: 'web', params: {} });
      const code = qrLoginCode(got.data);
      if (!code.qrUrl || !code.qr) {
        throw xhhError(XHH_CODES.UPSTREAM,
          '小黑盒没给二维码地址（qr_url / qr 都拿不到）。可以改用兜底方案：从浏览器复制网页版 cookie 后 login(action="set", cookie=...)。');
      }
      // pending 记住通道与 chatKey：控制台面板 poll 时不带 channel，只能靠这里
      const ctx = env.context && typeof env.context === 'object' ? env.context : {};
      qrPending = {
        qr: code.qr,
        expireAt: Date.now() + code.expiresIn * 1000,
        channel,
        chatKey: String(ctx.chatKey || '')
      };
      if (channel === 'console') return consoleStartPayload(code.qrUrl);
      const matrix = qrMatrix(code.qrUrl, 'L');
      return {
        ok: true,
        action,
        channel,
        qrUrl: code.qrUrl,
        expiresIn: code.expiresIn,
        text: qrText(matrix),
        image: qrSvgDataUrl(matrix),
        advise: '让用户用小黑盒 App 扫这个二维码（' + code.expiresIn + ' 秒内有效），扫完立刻调 login(action="poll") 收凭据。'
          + '二维码同时给了两种渲染：image（SVG data URL，控制台/网页里能直接显示）和 text（半块字符，图发不出去时贴这个）。'
          + '扫码只在用户明确要求登录时做，别在群里自动触发。'
      };
    }
    if (action === 'poll') {
      if (!qrPending) {
        throw xhhError(XHH_CODES.BAD_ARG, '还没有取二维码：先调 login(action="start") 拿到二维码，让用户扫，再来 poll。');
      }
      // 通道仍以本次调用的声明 + context 形状判定（控制台面板 poll 带的是空 context）；
      // pending.chatKey 只用来保证「聊天渠道要在同一个会话里完成」
      assertLoginAllowed(action, channel, env.context, qrPending.chatKey);
      if (Date.now() > qrPending.expireAt) {
        qrPending = null;
        throw xhhError(XHH_CODES.UPSTREAM, '二维码已过期（120 秒有效期到了），重新 login(action="start") 取一张新的。');
      }
      // 实测：这个端点必须带 withSetCookies，登录成功时凭据在 Set-Cookie 里（user_pkey / user_heybox_id）
      const got = await request(env, { path: '/account/qr_state', app: 'web', params: { qr: qrPending.qr }, withSetCookies: true });
      const state = qrLoginState(got.data);
      if (state.state === 'wait') {
        return qrPollPayload('wait', {
          note: '还没扫到（服务端 error=wait）。让用户用小黑盒 App 扫码并确认，再调一次 login(action="poll")；'
            + '这张二维码还剩约 ' + Math.max(0, Math.round((qrPending.expireAt - Date.now()) / 1000)) + ' 秒有效。'
        });
      }
      if (state.state === 'scanned') return qrPollPayload('scanned');
      if (state.state !== 'confirmed') {
        qrPending = null;
        throw xhhError(XHH_CODES.UPSTREAM,
          '扫码登录没成功：服务端回 error=' + (state.error || '(空)') + (state.errorMsg ? ' / ' + state.errorMsg : '')
          + '。pending 已清掉，重新 login(action="start") 取新二维码。');
      }
      const cookie = cookieFromSetCookies(got.setCookies);
      if (!cookie) {
        qrPending = null;
        throw xhhError(XHH_CODES.UPSTREAM,
          '扫码确认了，但响应里没有 user_pkey / user_heybox_id 这两条 cookie，所以这次没写任何凭据。'
          + '常见原因：宿主版本不支持 cap.http.request 的 withSetCookies（需要 ≥0.9.x 且插件声明 secrets 能力）。'
          + '兜底方案：从浏览器复制网页版 cookie，用 login(action="set", cookie=...)。');
      }
      await callCap(env, 'cap.secrets.set', { values: { cookie } }, 5000);
      env.auth = null;
      qrPending = null;
      // 落盘后再回校验一次（预算够就做）：过了回 done + account（控制台靠 account 显示「登录成功：xxx」）
      const restore = env.remaining() > 3000 ? await restoreLoginSoft(env) : { state: 'skipped' };
      const uid = restore.state === 'ok' ? restore.userid : state.userid;
      const nickname = restore.state === 'ok' ? restore.nickname : state.nickname;
      if (restore.state === 'ok' || restore.state === 'skipped') {
        return qrPollPayload('done', {
          uid,
          nickname,
          account: nickname || uid,
          note: '登录成功，已安全保存并立即生效。'
        });
      }
      return qrPollPayload('unverified', {
        uid,
        nickname,
        note: '凭据已保存（user_pkey + user_heybox_id），但回校验没通过（restore_login=' + restore.state
          + (restore.message ? '：' + restore.message : '') + '）。可以稍后 login(action="status") 再确认一次。'
      });
    }
    if (action === 'status') {
      const auth = await getAuth(env);
      const restore = await restoreLoginSoft(env);
      return {
        ok: true,
        action,
        configured: auth.configured,
        login: restore.state === 'ok',
        state: restore.state,
        uid: restore.state === 'ok' ? restore.userid : auth.uid,
        nickname: restore.state === 'ok' ? restore.nickname : auth.nickname,
        level: restore.state === 'ok' ? restore.level : undefined,
        cookieKeys: auth.keyCount,
        ownerUid: env.settings.ownerUid,
        note: restore.state === 'ok'
          ? '登录态有效（restore_login 回 account_detail）。'
          : (restore.state === 'relogin'
            ? '登录态已失效（restore_login 回 relogin）：用 login(action="start") 扫码登录是首选，'
              + '也可以把网页版 cookie 粘进来（login(action="set", cookie=...)）作为兜底。'
            : (restore.state === 'unknown'
              ? '登录态未知：restore_login 这次没成（' + (restore.message || '上游错误') + '）。这不等于未登录，隔一会儿再查一次。'
              : '还没配 cookie：用 login(action="start") 扫码登录（首选，120 秒内有效），'
                + '或 login(action="set", cookie=...) 粘贴网页版 cookie（兜底）。'))
      };
    }
    if (action === 'set') {
      const raw = argText(args.cookie, 'cookie', { required: true, max: 8000, min: 8, hint: '浏览器里 api.xiaoheihe.cn 请求的 cookie 头全文' });
      if (!raw.includes('=')) {
        throw xhhError(XHH_CODES.BAD_ARG, 'cookie 看起来不对：它应该是 a=b; c=d 这种形式。请复制请求头里的 cookie 整行。');
      }
      const identity = cookieIdentity(raw);
      await callCap(env, 'cap.secrets.set', { values: { cookie: raw } }, 5000);
      env.auth = null;
      return {
        ok: true,
        action,
        configured: true,
        uid: identity.uid,
        nickname: identity.nickname,
        cookieKeys: identity.keyCount,
        note: '已存进宿主的加密凭据库（AES-GCM，落 data/plugin-secrets/），回执与日志都不会回显 cookie 内容。'
          + (identity.uid ? '从 cookie 里认出 UID ' + identity.uid + '。' : '这串 cookie 里没有 heybox_id，写操作的主人不核对就没法做。')
      };
    }
    await callCap(env, 'cap.secrets.set', { values: { cookie: '' } }, 5000);
    env.auth = null;
    return {
      ok: true,
      action: 'clear',
      configured: false,
      note: '已清空 cookie（同样不回显任何内容）。清空后 feeds/search/read/post/watch/topics 仍然可用，写操作会返回 XHH_NO_LOGIN。'
    };
  };

  handlers.interact = async (args, env) => {
    // 先判登录：未登录的写操作一律 XHH_NO_LOGIN 且零请求（不因为参数对错改变结论）
    await requireCookie(env, 'write');
    // 再判 action：like 在这里明确报「web 接口不提供帖子点赞」，不会被悄悄映射成收藏
    const action = normalizeInteractAction(args.action);
    const undo = argBool(args.undo, false);
    if (action === 'follow') {
      const userid = argId(args.userid, 'userid', { hint: '要关注/取关的用户 UID' });
      const auth = await getAuth(env);
      const selfUid = requireSelfUid(auth);   // 拿不到自己的 UID 就当场报错，一个请求都不发
      if (selfUid === userid) throw xhhError(XHH_CODES.BAD_ARG, '不能关注自己（follower_id 与 following_id 相同）。');
      // 实测：POST …/follow/user（或 /cancel），body = following_id=<目标>&follower_id=<自己>
      const spec = followRequest(userid, selfUid, undo);
      const got = await request(env, spec).catch((error) => {
        if (error && error.code === XHH_CODES.BAD_PARAM) throw xhhError(XHH_CODES.BAD_PARAM, writeEndpointHint(error.message, spec.path));
        throw error;
      });
      // 回读 follow_status（0 未关注 / 1 已关注）；预算不够就跳过并注明
      let verified = null;
      if (env.remaining() > 3500) {
        try {
          const after = await request(env, { path: '/bbs/app/profile/user/profile', params: { userid } });
          const root = resultOf(after.data);
          const detail = root.account_detail && typeof root.account_detail === 'object' ? root.account_detail : {};
          const bbs = detail.bbs_info && typeof detail.bbs_info === 'object' ? detail.bbs_info : {};
          verified = { followStatus: maybeCount(pick(bbs, ['follow_status'])) };
        } catch { verified = null; }
      }
      return {
        ok: true,
        action,
        undo,
        userid,
        request: { method: spec.method, path: spec.path, body: formEncode(spec.params) },
        result: { status: String(asTextOf(pick(resultOf(got.data), ['status', 'msg'])) || 'sent') },
        verified,
        advise: (undo ? '已取消关注 ' : '已关注 ') + userid
          + '（POST ' + spec.path + '，body = ' + formEncode(spec.params) + '；这条是测试账号真机验过的可用路径，验完已还原）。'
          + '写操作由宿主把门（开关 → 管理员批准 → 当天配额），失败会把批准与配额退回。'
          + (verified ? '回读资料：follow_status=' + (verified.followStatus === undefined ? '（接口没给）' : verified.followStatus)
            + '（0 未关注 / 1 已关注）。' : '（这轮预算不够，没回读 follow_status。）')
      };
    }
    const linkId = argId(args.link_id, 'link_id', { hint: '要收藏/取消收藏的帖子 id' });
    // 实测：POST /bbs/app/link/favour，body = link_id=…&favour_type=1|0（见 favourRequest 的注释）
    const spec = favourRequest(linkId, undo);
    const got = await request(env, spec).catch((error) => {
      if (error && error.code === XHH_CODES.BAD_PARAM) throw xhhError(XHH_CODES.BAD_PARAM, writeEndpointHint(error.message, spec.path));
      throw error;
    });
    // 写完回读一次详情，把 is_favour 回执给模型（可选步骤：预算不够就跳过，不为此多花一轮）
    let verified = null;
    if (env.remaining() > 3500) {
      try {
        const after = await request(env, {
          path: '/bbs/app/link/tree',
          params: { link_id: linkId, is_first: '1', page: '1', index: '1', limit: '1', owner_only: '0' }
        });
        const link = extractLink(after.data);
        verified = {
          isFavour: Boolean(asNumberOf(pick(link, ['is_favour']))),
          favourCount: maybeCount(pick(link, ['favour_count']))
        };
      } catch { verified = null; }
    }
    return {
      ok: true,
      action,
      undo,
      linkId,
      request: { method: spec.method, path: spec.path, body: formEncode(spec.params) },
      result: { status: String(asTextOf(pick(resultOf(got.data), ['status', 'msg'])) || 'sent') },
      verified,
      advise: (undo ? '已取消收藏' : '已收藏') + ' link_id=' + linkId
        + '（POST /bbs/app/link/favour，body = ' + formEncode(spec.params) + '；这条是测试账号真机验过的可用路径）。'
        + '写操作由宿主把门（开关 → 管理员批准 → 当天配额），失败会把批准与配额退回。'
        + (verified ? '回读详情：is_favour=' + (verified.isFavour ? '1' : '0')
          + (verified.favourCount === undefined ? '' : '，favour_count=' + verified.favourCount) + '。' : '（这轮预算不够，没回读详情。）')
    };
  };

  handlers.comment = async (args, env) => {
    // 和其他写操作一样：未登录先 NO_LOGIN（零请求），再谈参数对错
    await requireCookie(env, 'write');
    const linkId = argId(args.link_id, 'link_id', { hint: '要评论的帖子 id' });
    const text = argText(args.text, 'text', { required: true, max: 900, min: 1, hint: '评论正文' });
    const replyTo = args.replyTo === undefined || args.replyTo === null || args.replyTo === ''
      ? '' : argId(args.replyTo, 'replyTo', { hint: '要回复的评论 id' });
    const rootId = args.rootId === undefined || args.rootId === null || args.rootId === ''
      ? '' : argId(args.rootId, 'rootId', { hint: '楼中楼根评论 id' });
    // 实测：评论必须带 _rnd（HMAC-SHA256 签名），否则服务端回「缺失参数」
    const spec = commentRequest(linkId, text, replyTo, rootId);
    const got = await request(env, spec).catch((error) => {
      if (error && error.code === XHH_CODES.BAD_PARAM) throw xhhError(XHH_CODES.BAD_PARAM, writeEndpointHint(error.message, spec.path));
      throw error;
    });
    const root = resultOf(got.data);
    const commentBag = root.comment && typeof root.comment === 'object' ? root.comment : {};
    const firstComment = Array.isArray(commentBag.comment) ? (commentBag.comment[0] || {}) : {};
    const commentId = String(asTextOf(pick(root, ['commentid', 'comment_id']))
      || asTextOf(pick(firstComment, ['commentid', 'comment_id', 'id'])));
    return {
      ok: true,
      linkId,
      replyTo,
      rootId,
      chars: text.length,
      commentId,
      floor: maybeCount(pick(root, ['floor'])),
      result: { status: String(asTextOf(pick(root, ['status', 'msg'])) || 'sent') },
      advise: commentId
        ? '评论已提交：commentId=' + commentId + (maybeCount(pick(root, ['floor'])) === undefined ? '' : '，楼层 ' + pick(root, ['floor'])) + '。'
          + '要确认就用 post(link_id="' + linkId + '") 看最新评论。'
        : '小黑盒返回 status=' + String(asTextOf(pick(root, ['status', 'msg'])) || '(空)') + '，但没给 commentid，所以不能确认真的发出去了；'
          + '用 post(link_id="' + linkId + '") 看有没有这条评论。'
    };
  };

  function normalizeError(error) {
    const code = String((error && error.code) || '');
    const message = String((error && error.message) || error || '未知错误');
    if (Object.values(XHH_CODES).includes(code)) return { code, message };
    if (code === 'E_TIMEOUT') return { code: XHH_CODES.BUDGET, message: '宿主/小黑盒这一跳超时了：' + message };
    return { code: XHH_CODES.UPSTREAM, message };
  }

  async function call(name, args, env) {
    gapMs = env.settings.intervalMs;
    const handler = handlers[name];
    if (!handler) {
      const known = Object.keys(handlers).join(' / ');
      return { ok: false, error: { code: XHH_CODES.BAD_ARG, message: '没有这个工具：' + String(name) + '。可用：' + known } };
    }
    try {
      return await handler(args && typeof args === 'object' ? args : {}, env);
    } catch (error) {
      return { ok: false, error: normalizeError(error) };
    }
  }

  return { call, names: () => Object.keys(handlers) };
}

// ════════════════════════════════════════════════════════════════════════
// 七、probe：同步、只用 init 快照、零 cap.*、零 await
// ════════════════════════════════════════════════════════════════════════
export function probeSnapshot(settings, meta) {
  const resolved = settings && typeof settings === 'object' ? settings : resolveSettings(null);
  const info = meta && typeof meta === 'object' ? meta : {};
  return {
    ok: true,
    plugin: PLUGIN_ID,
    version: PLUGIN_VERSION,
    enabled: info.enabled === undefined ? true : info.enabled !== false,
    // 登录态一律不在这里判断：probe 不允许碰 cap.*，也就读不到凭据库里的 cookie。
    login: null,
    apiOk: undefined,
    note: 'probe 只读启动快照、不发任何请求（0ms），所以这里不判断登录态与接口可用性：'
      + '用 account(what=doctor) 看这台机器上每个端点的实测状态，用 account(what=whoami) 核对登录。',
    request: {
      intervalMs: resolved.intervalMs,
      feedsCacheSec: resolved.feedsCacheSec
    },
    send: {
      sendImages: resolved.sendImages,
      sendMode: resolved.sendMode
    },
    owner: {
      configured: resolved.ownerUid,
      // null = 没有绑定主人 UID（不做限制）；true/false 要等真发请求才知道
      matches: null
    },
    configured: {
      ownerUid: Boolean(resolved.ownerUid),
      // cookie 是 secret：probe 不碰 cap.secrets，所以这里只能是 null（未知），不是 false
      cookie: null
    }
  };
}

// ════════════════════════════════════════════════════════════════════════
// 八、createTransport：行协议
// ════════════════════════════════════════════════════════════════════════
export function createTransport(io) {
  const stdout = (io && io.stdout) || process.stdout;
  const pending = new Map();
  let seq = 0;
  const state = { raw: Object.create(null), settings: resolveSettings(null) };

  const write = (message) => {
    try { stdout.write(JSON.stringify(message) + '\n'); } catch { /* 管道关了就算了 */ }
  };

  let logSeq = 9000000;
  const logHost = (message) => {
    logSeq += 1;
    write({ id: logSeq, method: 'cap.log.write', params: { level: 'info', message: String(message).slice(0, 300) } });
  };

  function callHost(method, params, timeoutMs) {
    return new Promise((resolve, reject) => {
      const id = ++seq;
      const ceiling = Number(timeoutMs) > 0 ? Number(timeoutMs) : 8000;
      const timer = setTimeout(() => {
        if (!pending.has(id)) return;
        pending.delete(id);
        reject(xhhError('E_TIMEOUT', '宿主能力调用超时（' + method + '，' + ceiling + 'ms）'));
      }, ceiling);
      pending.set(id, { resolve, reject, timer });
      write({ id, method, params });
    });
  }

  function settle(message) {
    const entry = pending.get(message.id);
    if (!entry) return false;
    pending.delete(message.id);
    clearTimeout(entry.timer);
    if (message.error) {
      entry.reject(Object.assign(new Error(String(message.error.message || '能力调用失败')), { code: message.error.code }));
    } else {
      entry.resolve(message.result === undefined ? null : message.result);
    }
    return true;
  }

  const router = createRouter({ callHost });

  /**
   * 一次工具调用。第一行设 deadline —— 早于任何 await，包括读设置。
   * 预算不足时各层返回降级结果，不补假地板。
   */
  async function handleCallTool(message) {
    const deadline = Date.now() + CALL_BUDGET_MS;
    const params = message && message.params && typeof message.params === 'object' ? message.params : {};
    const name = String(params.name || '');
    const args = params.args && typeof params.args === 'object' && !Array.isArray(params.args) ? params.args : {};
    const context = params.context && typeof params.context === 'object' && !Array.isArray(params.context) ? params.context : {};
    const env = {
      settings: state.settings,
      context,
      remaining: () => Math.max(0, deadline - Date.now()),
      callHost,
      log: logHost,
      auth: null,
      deviceId: ''
    };
    const result = await router.call(name, args, env);
    write({ id: message.id, result });
  }

  let chain = Promise.resolve();
  const enqueue = (fn) => {
    const run = chain.then(fn, fn);
    chain = run.then(() => {}, () => {});
    return run;
  };

  function handleMessage(message) {
    if (!message || typeof message !== 'object') return;
    const method = typeof message.method === 'string' ? message.method : '';
    if (!method) {
      if (message.id !== undefined && message.id !== null) settle(message);
      return;
    }
    if (method === 'init') {
      const raw = message.params && message.params.settings && typeof message.params.settings === 'object'
        ? message.params.settings : {};
      state.raw = raw;
      state.settings = resolveSettings(raw);
      write({ id: message.id, result: { ok: true } });
      return;
    }
    if (method === 'probe') {
      const enabled = message.params && message.params.enabled !== undefined ? message.params.enabled : undefined;
      write({ id: message.id, result: probeSnapshot(state.settings, { enabled }) });
      return;
    }
    if (method === 'callTool') {
      // 必须 await 或入队，禁止 void 裸并发：入队后整条链串行，回执顺序与请求顺序一致。
      enqueue(() => handleCallTool(message).catch((error) => {
        write({
          id: message.id,
          result: { ok: false, error: { code: XHH_CODES.UPSTREAM, message: String((error && error.message) || error) } }
        });
      }));
      return;
    }
    if (method === 'ping' || method === 'schedule') {
      if (message.id !== undefined && message.id !== null) write({ id: message.id, result: {} });
      return;
    }
    if (method === 'shutdown') {
      // 宿主退出时发的是不带 id 的 shutdown：无条件回执会序列化成 {"result":{}} 并记一条 protocolErrors。
      if (message.id !== undefined && message.id !== null) write({ id: message.id, result: { ok: true } });
      setTimeout(() => process.exit(0), 10);
      return;
    }
    if (message.id !== undefined && message.id !== null) {
      write({ id: message.id, error: { code: 'E_UNKNOWN_METHOD', message: '不支持的方法：' + method } });
    }
  }

  function start(input) {
    const stdin = input || (io && io.stdin) || process.stdin;
    process.stdout.on('error', () => process.exit(0));
    let buffer = '';
    stdin.setEncoding('utf8');
    stdin.on('data', (chunk) => {
      buffer += chunk;
      let index = buffer.indexOf('\n');
      while (index !== -1) {
        const line = buffer.slice(0, index).trim();
        buffer = buffer.slice(index + 1);
        if (line) {
          let message = null;
          try { message = JSON.parse(line); } catch { message = null; }
          if (message) {
            try { handleMessage(message); } catch (error) { logHost('分发失败：' + String((error && error.message) || error)); }
          }
        }
        index = buffer.indexOf('\n');
      }
    });
    stdin.on('error', () => process.exit(0));
  }

  return { handleMessage, start, state, router, callHost, probe: () => probeSnapshot(state.settings) };
}

// 只有被当作入口脚本运行时才起 stdin 循环：被 import 时不产生任何副作用。
function invokedDirectly() {
  const entry = process.argv[1];
  if (!entry) return false;
  try {
    return path.resolve(entry).toLowerCase() === path.resolve(fileURLToPath(import.meta.url)).toLowerCase();
  } catch {
    return false;
  }
}

if (invokedDirectly()) {
  createTransport({}).start();
}
