# 小黑盒 xiaoheihe

给 QQ 机器人接上**小黑盒**（xiaoheihe.cn）：看帖子正文与评论、刷动态流、搜帖子/游戏/用户、把帖子里的图发到群里；登录后还能点赞/收藏/关注/评论（每次都走管理员批准 + 当天配额）。

- 插件 id：`xiaoheihe`
- 版本：`1.1.3`（`plugin.json` 的 `version` / `index.mjs` 的 `PLUGIN_VERSION` / 本文件，三处一致）
- 需要宿主：`apiVersion 2`，`engines.minVersion >= 0.9.10`
- 包内是扁平三文件：`README.md` / `index.mjs` / `plugin.json`，无 `node_modules`、无构建、无 `package.json`

---

## 一、能做什么

- **刷动态流**：`feeds(kind="recommend")` 拿综合推荐（默认带 60 秒缓存，**不需要 topicId**）；`kind="topic"` 指定话题、`kind="news"` 话题新闻——这两个**都必须给 topicId**（先用 `topics` 拿），缺了插件在本地就报参数错误、不发请求；`kind="banner"` 是首屏 banner（不需要 topicId）。每条给 `linkId`、标题、摘要、`url`、`cover`（优先 `thumbs` 缩略图，没有就 `imgs` 原图）、`author`、评论数、`topics`。
- **看一条帖子**：`post(link_id="712345678")` 给标题、正文纯文本、图片数量、视频直链、作者、评论数/收藏数，以及这次响应里的评论楼层（`floorCount`）；`read(...)` 只读正文纯文本，适合直接朗读。**点赞数这条接口不给**（见「边界」第 9 条）。
- **搜**：`search(keyword="显卡", kind="post")` 搜帖子；`kind="game"` 搜游戏条目、`kind="user"` 搜用户。
- **看人**：`user(userid="71127268")` 或 `user(userid="me")` 给昵称、头像、等级、签名、IP 属地、粉丝/关注/投稿数，默认带最近投稿（`result.post_links`，与动态流条目同构）。字段来路见「边界」第 12 条。
- **列话题**：`topics(limit=20)` 把「为你推荐 / 近期热门 / 我的偏好」三组摊平成 `{name, topicId, hot, gameAppId, group}`；拿 `topicId` 就能 `feeds(kind="topic", topicId=...)`。`result.categories` 一直是空数组，那不代表没返回话题。
- **发图到群**：`watch(link_id="712345678", send=true)` 逐张下载、逐张发到当前群；宿主发不出去时给一条照抄就能用的 `forward` 转发指令。
- **扫码登录**：`login(action="start")` 出二维码（120 秒有效）→ 用户用小黑盒 App 扫 → `login(action="poll")` 收凭据；`login(action="set", cookie=...)` 保留为粘贴兜底。两条通道：**控制台面板**（`channel="console"`，回 `channel:'console'` + `qrcodeDataUrl`）和**聊天**（半块字符二维码 + `qrUrl`，仅管理员、群聊拒绝）。
- **自检**：`account(what="doctor")` 逐个真打 5 个端点（登录态 `restore_login` / 动态流 / 帖子详情（含评论）/ 搜索 / 用户主页），把每个的实测状态汇总成一句「这台机器能用到哪一步」——登录态那一步会明确区分 `ok` 与 `relogin`。
- **消息通知**：`account(what="messages", messageType=16)` 读 @我的（16）等消息，映射成 `{messageId, type, text, at, from, linkId, title, url}`；接口回空数组就是「没有这类消息」，不是错误。
- **写操作**：需要网页版 cookie + 宿主三层门（开关 → 管理员批准这个目标 → 当天配额）。
  - `interact(action="favorite", link_id=…, undo=false)` —— **收藏 / 取消收藏，已用测试账号真机验证可用**（`POST /bbs/app/link/favour`，form body `link_id + favour_type=1|0`）。
  - `interact(action="follow", userid=…, undo=false)` —— **关注 / 取关，也已用测试账号真机验证可用**（`POST /bbs/app/profile/follow/user`，取关走 `/cancel`，form body `following_id=<目标>&follower_id=<自己>`）。
  - `comment(link_id, text)` 发评论、给评论点赞（`comment/support`）—— **参数名尚未对着服务端核对，不承诺可用**（真机验证会真的发出评论，本次没做）。
  - **给帖子点赞在这套 web 接口里不存在**：传 `action="like"` 会直接回 `XHH_BAD_ARG` 说明不支持，不会被悄悄当成收藏。见「边界」第 3 条。

## 二、群里怎么问

- 「小黑盒今天有什么好玩的」→ 模型会调 `feeds`
- 「帮我看看小黑盒这条帖子」+ 链接或 link_id → `post`（读正文）/ `watch`（发图）
- 「小黑盒搜一下 4090 装机」→ `search(kind="post")`
- 「这条帖子里的图发群里」→ `watch(send=true)`
- 「小黑盒现在能不能用」→ `account(what="doctor")`

## 三、配置项与默认值

设置面板分成 4 组、共 12 个字段。cookie 是 `secret` 类型：交给宿主的加密凭据库（AES-256-GCM，落 `data/plugin-secrets/`），**不进 `config.json`、插件回执与日志都不回显**。

| 组 | 键 | 类型 | 默认 | 说明 |
| --- | --- | --- | --- | --- |
| 账号 | `cookie` | secret | 空 | 网页版 cookie。**首选扫码**（`login(action="start")` → 扫 → `poll`），这里或 `login(action="set", cookie=...)` 都是兜底；三处同一个存储位置 |
| 账号 | `ownerUid` | text | 空 | 纯数字。填了之后每次写操作前都用 cookie 里的 `heybox_id` 核对实际登录的是谁，不一致直接拒绝 |
| 请求节奏 | `intervalMs` | number | 1200 | 两次请求最小间隔（500-5000ms）。进程内串行；排队要等的时间超过剩余预算就不发请求。这是**预防性**节奏控制（贴近手刷），不是因为有已知故障 |
| 请求节奏 | `feedsCacheSec` | number | 60 | 动态流缓存（0-600s）。0 = 关闭 |
| 读内容 | `commentCount` | number | 20 | `post` 默认带几条评论（5-50） |
| 读内容 | `maxTextChars` | number | 4000 | 正文最多多少字（200-20000），超了截断并说明原文长度 |
| 发图 | `sendImages` | boolean | true | 关掉后 `watch` 只下载并返回链接 |
| 发图 | `maxImages` | number | 3 | `watch` 默认张数（1-9） |
| 发图 | `sendMode` | select | auto | `auto`（宿主发不出去就改转发）/ `forward`（只转发）/ `host`（只走宿主，调试用） |
| 发图 | `sendHostRetryMinutes` | number | 30 | 降级后多久再试宿主发送：连续失败翻倍、封顶 12 小时、成功一次清零 |
| 发图 | `sendVideos` | boolean | false | 关着时只给视频直链，不下载 |
| 发图 | `maxFileMb` | number | 40 | 单个文件上限（5-80MB），也是下载上限 |

## 四、工具清单与各端点的实测状态

端点一律 `https://api.xiaoheihe.cn`，每个请求都带 `hkey / _time / nonce` 三件套。

| 工具 | 端点 | 2026-10-27 实测 |
| --- | --- | --- |
| `feeds` | `GET /bbs/app/feeds`（recommend）、`/topic/feeds`（topic）、`/topic/feeds/news`（news）、`/feeds/banner`（banner） | **全部 200 真数据**：recommend 87KB / topic 87KB（`result.links` 20 条）/ news 45KB（19 条）。topic 与 news **必须同时带 `topic_id` + `limit`**（缺 limit → 「请求参数 limit 缺失」；news 缺 topic_id → 「topic_id 缺失」） |
| `post` / `read` / `watch` | `GET /bbs/app/link/tree` | **200 + 24KB 真数据**（正文、作者、评论楼层都在同一个响应里） |
| `post`（评论） | 不再单独请求 | 评论就在 `link/tree` 的 `result.comments` 楼层数组里，少一次请求少一份参数坑 |
| `search` | `GET /bbs/app/api/general/search/v1` | **200 + 65KB 真数据**（`result.items` 按 `type` 分派：`link` / `new_game_list` / `topic` …） |
| `topics` | `GET /bbs/app/topic/categories` | **200 真数据**：`recommend_for_user_topics` 8 条、`latest_hot_topics` 72 条、`subscribed_topics` 1 条（`categories` 为空是正常） |
| `user` | `GET /bbs/app/profile/user/profile` + `/profile/user/link/list_v2` | **200 真数据**：资料在 `result.account_detail`，等级在 `level_info`，统计在 `bbs_info`，投稿在 `result.post_links` |
| `account` | `/profile/history/visit`、`/profile/fav/folders`、`/profile/following/list` | 需要登录，这轮没打 |
| `interact`（收藏） | `POST /bbs/app/link/favour`，form body `link_id + favour_type=1|0` | **真机验证可用**（测试账号验完已还原）：`{"status":"ok"}`，随后 `GET link/tree` 的 `is_favour` 1↔0、`favour_count` 69→70→69 可复现 |
| `interact`（帖子点赞） | **没有这个接口** | 端点清单里只有 `link/favour`(收藏)、`link/vote`(投票)、`comment/support`(评论点赞)；插件直接回 `XHH_BAD_ARG` 说明不支持 |
| `interact`（关注 / 取关） | `POST /bbs/app/profile/follow/user`（取关 `/cancel`），form body `following_id + follower_id` | **真机验证可用**（测试账号验完已还原 `follow_status` 0→1→0）：只传 `userid` 会回「both following id and follower id is required」 |
| `comment` | `POST /bbs/app/comment/create`（额外带 `_rnd` 签名） | **契约已验证**：不带 `_rnd` → 「缺失参数」；带错 → 「评论功能暂不可用」；带对 → 进入业务校验。**但没有在真实帖子下真发过一条评论** |
| `account(messages)` | `GET /bbs/app/user/message?message_type=16&list_type=0&offset=&limit=` | **200 真数据**（该账号当前没有 @ 消息，`result.messages` 是空数组，属正常） |

1.0.2 起用自建 live 宿主（真网络、插件自己的代码路径）实测：init 59ms、probe 1ms、`feeds` 855ms ok / 3 条真数据、`post` 234ms ok（text「太有才了老师们」/ imageCount 1 / floorCount 4 / favoriteCount 7）、`search` 454ms ok / 10 条、`account(doctor)` 5058ms ok（feeds / link-tree / search / profile 全 ok）。

**1.0.1 及更早版本里所有端点都返回「非法请求」，原因是插件自己的 `hkey` 校验和算错**（见「边界」第 7 条），不是小黑盒限制了详情/搜索/评论。签名修好后这些接口在真机上全部正常；`account(what="doctor")` 的作用是某次调用失败时当场把每个端点分别打一遍，把「是哪几个端点、哪种失败形状」变成实测结论。

## 五、边界与已知限制（先看这一段）

**1）先说清一件容易误读的事：以前「详情/搜索不可用」是插件自己的 bug，不是小黑盒的限制。**

- 1.0.1 及更早版本里，**每一个**端点都返回 200 + 很小的 JSON `{"msg":"非法请求","result":{},"status":"failed"}`，看起来像是服务端在拒绝这台机器。真因是插件算错了 `hkey` 的末 2 位校验和（见「边界」第 7 条）。1.0.2 起签名与浏览器逐字节一致，动态流、帖子详情、搜索、用户主页在真机上都正常。
- 现在再看到这个形状，插件仍然单独映射成 `XHH_GATED`（**不会**说成「网络错误」，也不会拿同样参数重试）。它的意思是「服务端不接受这次请求的签名或身份」，按顺序排查：① 版本是不是 1.0.2+；② 已经是最新版且**每个**端点都这样 → 这台机器的 IP 多半被临时限流，隔几分钟再试或换出口网络；③ **只有个别**端点这样 → 跑 `account(what="doctor")` 看是哪几个，把回执原话转告维护者。
- **限流是预防性设置，不是已知故障。** 插件默认进程内串行、两次请求间隔 ≥1200ms、动态流缓存 60 秒，只是让请求节奏贴近手刷，避免正常使用被打成高频调用；排队要等的时间超过本轮剩余预算时**不发请求**，直接返回可读的降级结果。
- **别连跑 `doctor`**，它每个端点都真发一次请求。

**2）三种失败形状分别映射，不会混成一个错误码**

| 服务端返回 | 错误码 | 意思 |
| --- | --- | --- |
| `{"msg":"非法请求",...}` | `XHH_GATED` | 服务端不接受这次请求的签名或身份。先核对版本是 1.0.2+（旧版校验和错，所有端点都会这样）；仍如此则多半是该 IP 被临时限流，隔几分钟或换出口网络，并用 `account(what="doctor")` 看是哪几个端点 |
| `{"status":"failed","msg":"验证参数错误"}` | `XHH_BAD_PARAM` | 签名已过、是插件参数不对（插件 bug，重试无用） |
| `{"status":"show_captcha"}` | `XHH_CAPTCHA` | 腾讯验证码挑战，插件无法自动过 |
| HTTP 429 / 服务端说太频繁 | `XHH_RATE` | 限速 |
| 没配 cookie | `XHH_NO_LOGIN` | 写操作与账号类分支需要登录 |
| 不是管理员 / 在群里发起扫码 | `XHH_DENIED` | 权限不足：聊天渠道只有管理员能扫码登录，群聊一律拒绝（零请求） |
| `truncated=true` / 其他上游原因 | `XHH_TRUNCATED` / `XHH_UPSTREAM` | 响应被截断 / 其他上游原因 |
| 本轮 15 秒预算不够 | `XHH_BUDGET` | 没发请求，先用已有结果回答 |

`cap.http.request` 的 `maxChars` 传的是上限 524288；`truncated=true` 时明确报「响应被截断」，不会把半份列表当完整结果。

**3）写操作：收藏 / 取消收藏与关注 / 取关都已真机验证可用；「给帖子点赞」不存在；发评论未验证。**

- **收藏 / 取消收藏 —— 已用测试账号真机验过（验完已还原）**：`interact(action="favorite", link_id=…)` 打的是 `POST /bbs/app/link/favour`，**参数必须放 form body**：`link_id=<id>&favour_type=1`（收藏）/ `link_id=<id>&favour_type=0`（`undo=true`）。把 `link_id` 放 query 会得到 `{"status":"failed","msg":"该帖子不存在"}`。写完插件会再 `GET link/tree` 回读一次 `is_favour` / `favour_count`（预算够才做），成功与否一眼可见。
- **给帖子点赞在这套 web 接口里不存在**：只有 `link/favour`（收藏）、`link/vote`（投票）、`comment/support`（评论点赞）。所以 `action="like"` 直接回 `XHH_BAD_ARG` 并说明原因，**不会被映射成收藏**（那会让用户以为点了赞、其实收藏了）。
- **关注 / 取关 —— 也已用测试账号真机验过（验完已还原 `follow_status` 0→1→0，`fan_num` 无变化）**：`interact(action="follow", userid=…)` 打 `POST /bbs/app/profile/follow/user`，`undo=true` 打 `POST /bbs/app/profile/follow/user/cancel`；两者都**必须**把参数放 form body：`following_id=<目标 UID>&follower_id=<自己 UID>`（`follower_id` 就是登录账号的 `heybox_id`，插件从 cookie 里取；取不到就当场回 `XHH_NO_LOGIN`，一个请求都不发）。只传 `userid` 会得到 `{"status":"failed","msg":"both following id and follower id is required"}`。写完预算够就回读 `GET /profile/user/profile?userid=<目标>` 的 `account_detail.bbs_info.follow_status`（0 未关注 / 1 已关注）。
- **发评论（`comment/create`）：签名与参数契约已验证，但没有真发过。** 这个端点除了 `hkey/_time/nonce` 还要一个 `_rnd`（见「边界」第 14 条）。`body` 是 `is_cy=0&link_id=<id>&reply_id=<-1 或目标评论>&root_id=<-1 或楼中楼根评论>&text=<urlencoded>`。三段实测：不带 `_rnd` → `{"msg":"缺失参数"}`；带错 `_rnd` → `{"msg":"评论功能暂不可用"}`；带对 `_rnd` 且 `link_id=1` → `{"msg":"该内容已被删除"}`（说明签名与参数契约都过了，只是帖子不存在）。**我没有在真实帖子下发出过一条评论**，所以别承诺「一定发得出去」：用回执里的 `commentId`/`floor` 或 `post` 的最新评论确认。
- **给评论点赞（`comment/support`）仍然未验证**：真机验证会真的发出内容，本次没做，插件没有暴露这个动作。

**4）发图：首次可能报一次错，属正常探路。** 宿主把媒体目录的**绝对路径**交给协议端，容器化部署里 NapCat 读不到那个路径（`retcode=100 ENOENT ... realpath`）。插件命中这个错时降级成 `forward={tool:'send_group_file', url, name}`，并把降级窗写进 `cap.storage`（30 分钟起翻倍、封顶 12 小时、成功一次清零）。**第一次发图报这个错是正常的**，之后会直接走转发。根治办法是按相同绝对路径把 `data/plugin-data` 挂进协议端容器（见宿主文档）。

图要过两道检查才会发：`contentType` 必须匹配 `^image\/` **且** `bytes` 不小于 1KB。不通过的不发、也不记账（不会出现「发过了但用户没看到」）。私聊与控制台**永远不发文件**，只给链接与转发参数。

帖子带视频时是另一条路：只有「设置里打开允许下载视频」+「`send=true`」+「当前是群聊」三条同时成立，才会用同一个下载/发送通道发视频，且受单文件上限与 15 秒预算约束（剩余预算不足 4 秒不下载，只给直链）。三条里任一不成立就只返回 `video.url` 与一句说明。

**5）登录：首选扫码，粘贴 cookie 是兜底。**

```
login(action="start")  → 拿二维码（image = SVG data URL；text = 半块字符二维码），120 秒有效
login(action="poll")   → 用户扫完再调一次，成功后自动写进宿主加密凭据库
login(action="status") → 用 restore_login 当场判登录态（login true/false + 昵称/UID/等级）
login(action="set", cookie="...") / login(action="clear") → 兜底粘贴 / 清空
```

- **宿主控制台的扫码面板要求两个字段**：`start` 必须回 `{ ok:true, channel:'console', qrcodeDataUrl:'data:image/svg+xml;base64,…' }`（少 `channel` 面板就报「插件没返回控制台渠道」）；`poll` 的 `state` 只认 `waiting / scanned / done / unverified`，其中 `done` **必须带 `account`**（面板用它写「登录成功：xxx」）。控制台面板 `poll` 时**不带 `channel`、context 也是空的**，所以插件把发起时的通道记在 pending 里，并把「空 context」兜底当控制台。
- **权限**：聊天渠道发起 `start`/`poll` 要求 `senderIsOwner === true`，群聊一律拒绝（二维码会被群成员扫走绑到别人账号）；控制台通道本身已鉴权，不受这条限制。
- 真机实测的三个端点（`app` 参数不要混）：取码 `GET /account/get_qrcode_url?app=web` → `result.qr_url`（含 `qr` uuid）+ `expire=120`；轮询 `GET /account/qr_state?app=web&qr=<uuid>`（**必须带 `withSetCookies`**，未扫回 `{"error":"wait"}`，确认后 `Set-Cookie` 里有 `user_pkey` 与 `user_heybox_id` 两条）；校验 `GET /account/restore_login?app=heybox`（已登录回 `result.account_detail`，失效回 `{"status":"relogin"}`，插件映射成 `XHH_RELOGIN`）。
- 扫码成功后**只**把 `user_pkey` + `user_heybox_id` 这两条拼成 cookie 存进凭据库（别的 `Set-Cookie` 一律丢），回执与日志都只报「存了 2 条」，**不回显任何值**。
- `account(what="whoami")` 现在也以 `restore_login` 的 `account_detail` 为准（昵称 / UID / 等级），不再靠 cookie 里的 nickname。
- **扫码只在用户明确要求登录时做**（设置页里点、或用户说「登录小黑盒」）。模型不要在群里自动 `start`：那会弹二维码、还会占掉一次请求预算。
- cookie 本身仍是 `secret`：进宿主加密凭据库（AES-256-GCM，落 `data/plugin-secrets/`），不进 `config.json`。

**6）`probe` 不判断登录态，也不判断接口可用性。** 它是同步的、零 `cap.*`、实测 0.1-0.6ms，所以设置页只能显示「插件已装好 + 当前请求节奏」；登录态与端点状态要用 `account(what="whoami")`、`account(what="doctor")` 当场问。这是刻意的取舍：探针里发请求会让设置页卡十几秒。

**7）签名（`hkey`）是从站点 bundle 里还原出来的，与浏览器逐字节一致。** 三段交织后只取前 20 个字符做 md5，因此实际参与签名的是「时间戳前 7 位 + 路径前 7 字符 + nonce 前 7 字符」，`/bbs/app/` 下各端点在同一个 nonce 下 `hkey` 相同——这是 bundle 里 `Tr()` 本身的性质，不是缺陷。末 2 位校验和的算法要点：四路混合只改写前 4 个元素，但**求和要连同第 5、6 个元素的 charCode 一起算**（1.0.1 漏了这一点，得到的 82/66/74 与浏览器的 31/20/71 不同，这才是「非法请求」的真正原因）。三条真实抓包向量（`SZ21D31` / `SDU2320` / `2PT1X71`）逐条写成单测。

**8）拿不到的东西不承诺。** 收藏夹只列文件夹，不做「收藏夹里的帖子列表」（`/bbs/app/profile/fav/folder/v2/links` 没接）；游戏搜索结果只有名字/图标/评分（真实响应里只有 `steam_appid`，没有可用的游戏 id），本插件也没有游戏详情工具；楼中楼只统计条数，不展开。

**9）点赞数这条接口不给。** `feeds` 与 `link/tree` 响应里只有 `up` / `down` / `forward_num`，没有 `like_num` 这类字段；`up`/`down` 的确切语义没有证实（不排除是顶/踩或站内互动值），所以插件**不把 `up`/`down` 当点赞数**，拿不到就干脆不输出该字段（不是输出 0）。收藏数是真字段（`favour_count`），评论数是真字段（`comment_num`），这两个照给。

**10）帖子链接形态：`https://www.xiaoheihe.cn/app/bbs/link/<linkId>`。** 实测 `/bbs/link/<id>` 返回 404（19 字节），加 `/app` 前缀才 200。`feeds` / `search` / `post` 返回的 `url` 都是这一形态，别再自己拼 `/bbs/link/`。

**11）正文是 JSON 块，不是 HTML。** 长文帖的 `link.text` 是 `[{"type":"text","text":"…"},{"type":"img","url":"…"}]` 这样的数组字符串；插件把 `text` 块拼成纯文本、把 `img` 块的 url 并进 `images`（`watch` 因此也能发纯文字帖里的图）。纯文字帖**没有** `imgs`/`thumbs` 字段，这时 `watch` 会明确回「这条帖子没有图」，不是报错。

**11b）正文里的 `[cube_xxx]` 是站内表情标记。** 它不是乱码，也不是要删的东西：机器人不带图发时它就是纯文本，转述正文时原样保留（或换成对应的表情名）比删掉更忠实。

**12）`user` 的字段来路（实测，别按别的形状猜）。** 资料在 `result.account_detail`（`userid` / `username` / `avatar` / `signature` / `ip_location` / `medals`）；**等级是对象** `level_info.level`（不是顶层数字）；统计量在 `bbs_info`（`fan_num` 粉丝 / `follow_num` 关注 / `post_link_num` 投稿数 / `be_favoured_num` 被收藏数）。接口没给的统计量输出 `null`（`maybeCount`），不是 0。投稿列表在 `/profile/user/link/list_v2` 的 `result.post_links`（与动态流条目同构），作者名只在 `result.user.username` 里。主页链接实测 `/bbs/user/<id>` 是 404，`/app/user/profile/<id>` 才 200。

**13）`topics` 的话题在分组里，不在 `categories`。** `result.categories` 一直是空数组（正常）；话题在 `recommend_for_user_topics` / `latest_hot_topics` / `subscribed_topics` 三组的 `children` 里（实测 8 / 72 / 1 条），元素含 `name` / `topic_id` / `extra_desc` / `pic_url` / `hot.{raw_hot_value}` / `game.app_id`。插件摊平成 `{name, topicId, hot, gameAppId, group}` 并按 `topicId` 去重。话题页链接没有实测过（`/bbs/` 那一套已证实会 404），所以**不输出话题页 url**，避免给死链。

**14）评论要 `_rnd` 签名（`HMAC-SHA256`，1.1.0 起内置）。** 站点 bundle 里 `Kwe()` 的算法：
```
_rnd = '15:' + HMAC-SHA256(key = 'Z7mFG4tQp9Ws2LxB8H',
                            message = KEY + nonce + _time + ':' + nonce).hex()
```
它和 `hkey/_time/nonce` 同级，**放进 URL query**（body 里没有）。只有 `comment/create` 需要它，其它端点带了也无害但不带。固定 nonce/时间戳的向量写在 selftest 里（`15:e8c922f8…`）。

**15）`account(what="messages")` 的字段来路。** `GET /bbs/app/user/message?message_type=16&list_type=0&offset=&limit=`（16 = @我的），**不需要 `_rnd`**；响应是 `result.messages[]`，元素含 `message_id / message_type / text / timestamp / user_a / user_b / state / link / link_tag`，`link` 里通常有 `linkid / title / share_url`。空数组是正常结果（这个账号当前没有 @ 消息），插件如实回「这类消息现在没有」，不报错、也不编造。

**16）视频：字段在 link 上，直链是签名 URL、会过期。** 实测真视频帖（`link_id=195106926`）的 `result.link` 里：`has_video=1`、`video_url`（`videoheybox.max-c.com`，带两组 `auth=` 与两组 `sign=`，是续签对）、`video_thumb`、`video_duration=77`（秒）、`video_width/video_height=2560×1336`。插件把 `{url, cover, duration, width, height}` 一起带出来，回执里给人类可读的 `77 秒 / 2560×1336`。

**17）`feeds` 的 topic / news 两个分支必须带 `topic_id` + `limit`。** 实测：`kind=topic` 只发 `topic_id+offset` → `{"status":"failed","msg":"请求参数 \"limit\" 缺失"}`；`kind=news` 不发 `topic_id` → `{"msg":"请求参数 \"topic_id\" 缺失"}`（这是**话题新闻**，不是全站新闻）。带上之后两个端点分别回 200 / 20 条与 19 条，条目与 recommend 同构（`linkid/title/description/thumbs/imgs/comment_num/user/has_video/topics`），所以统一走 `feedRow`。插件现在：`feedsSpec(kind, {topicId, offset, limit})` 生成参数，缺 `topicId` 时**在本地就报 `XHH_BAD_ARG`、不发请求**；`limit` 原样透传（默认 10，夹在 1-50）。另外：news 分支的条目**没有 `user` 对象**（只有 `userid`），所以那种行的 `author` 是空、`authorId` 有值，这是数据事实不是 bug；个别帖子本来就没有标题，也如实留空。


- `video_url` **必须原样字符串透传**：用 `URLSearchParams` 重新序列化会把重复的 `auth/sign` 去重或改顺序，签名立刻失效。
- 链接**约 2 小时过期**：文案统一写成「签名直链，约 2 小时内有效，要发就这次发」；`watch` 下载失败时明确说「很可能是过期，重新 post/watch 拿新链接」，**不要**建议用户把旧链接存起来。
- 视频域名 `videoheybox.max-c.com` 已被 `httpDomains` 里的 `max-c.com` 父域覆盖，不需要改白名单。

## 六、联网范围（不联网声明）

- 只在**你调用工具时**联网，没有任何后台轮询、定时任务、自启动请求。
- 只联系两个域名：`api.xiaoheihe.cn`（数据）与 `*.max-c.com`（图片/视频 CDN，实际是 `imgheybox.max-c.com` 这类）。这两个域名写在 `plugin.json` 的 `httpDomains` 里，宿主据此做白名单与 SSRF 校验。
- 不向任何第三方上报、不发遥测、不加载远程脚本。
- 插件进程**不写文件、不 spawn 进程、不 import 第三方包**（只用 `node:` 内置）。它自己的状态（`device_id`、发图降级窗）走 `cap.storage`，凭据走 `cap.secrets`。
- 不带 cookie 也能用：`feeds`、`search`、`read`、`post`、`watch`、`topics`、`user`（传具体 userid；`userid="me"` 才需要登录）。写操作与账号类分支需要登录。

## 七、装

控制台左侧「插件」→ 安装 → 启用。手工：把本目录拷到 `$DATA_DIR/plugins/xiaoheihe/`，重启后在「插件」里启用。

装完建议按顺序试一遍：

1. `account(what="doctor")` —— 看这台机器上每个端点的真实状态；
2. `feeds(limit=3)` —— 动态流是最省事的入口（不需要 cookie；若回「非法请求」先看「边界」第 1 条）；
3. 要登录就 `login(action="start")` 扫码、再 `login(action="poll")`；之后 `account(what="whoami")` 核对是哪个账号（走 `restore_login`）；
4. 群里 `watch(link_id=..., send=true)` —— 第一次可能报一次跨容器错，属正常探路。

## 八、自测（开发用；脚本放 .work/，不进包）

```bash
node --check index.mjs                    # 语法
node -e "import('./index.mjs')"           # 被 import 时零副作用、不启 stdin 循环
```

工作区里的离线自测与假宿主放在 `.work/xhh/`（不在插件目录，因此不进包）：

```bash
node .work/xhh/selftest.mjs     # 255 条纯函数断言（签名向量/分类/整形/守卫/设置/probe/限速/收藏请求形态/6 份真实样本）
node .work/xhh/host.mjs --offline  # 13 条协议断言（init→probe→feeds→post→login→无 cookie 写→shutdown）
node .work/xhh/host.mjs         # 同上但走真实网络（会真的发请求、吃配额，别连跑）
```