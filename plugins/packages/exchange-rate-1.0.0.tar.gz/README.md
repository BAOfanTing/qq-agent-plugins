# 汇率 exchange-rate

**100 美元是多少人民币** —— 给出一个**可核对的数字**，附上汇率日期与来源。
主源是欧洲央行数据（Frankfurter），主源没有的币种自动换 open.er-api；两个都**不需要 Key**。

## 能做什么

- **换算两种货币**：金额 + 源币种 + 目标币种（三字母代码）
- **说清出处**：实际用了哪家源、汇率是哪一天的
- **同币种直接返回**，不打上游（有些源对 `base=symbols` 会直接报错）
- **主源缺币种时自动兜底**：例如 ECB 表里没有 TWD，会换 open.er-api

## 群里怎么问

- 「100 美元是多少人民币」
- 「这 50 欧元等于多少日元」
- 「2000 日元合多少人民币」

## 配置（可选）

- `frankfurterUrl` / `erApiUrl` —— 换成自建代理或镜像（给测试 / 内网部署用）

```json
{
  "plugins": {
    "settings": {
      "exchange-rate": {
        "frankfurterUrl": "https://api.frankfurter.dev/v1",
        "erApiUrl": "https://open.er-api.com/v6/latest"
      }
    }
  }
}
```

## 边界

- **不是成交价**：公开汇率表是参考中间价，真实成交价以银行 / 平台为准 —— 结果里会带这句
- 只做换算：不提供历史曲线、不做金融分析
- 两家源都取不到时返回可读错误，不会静默给空结果
- 只读，不能发言

## 装

控制台左侧「插件」→ 安装 → 启用。手工：把本目录拷到 `$DATA_DIR/plugins/exchange-rate/`。
