# 汇率（exchange-rate）

按实时汇率换算两种货币。群里问"100 美元是多少人民币""这 50 欧元等于多少日元"时，
模型可以用这个工具给出一个**可核对的数字**（而不是随口编一个看着像真的汇率）。

- 工具：`exchange-rate.convert`
  - 参数：`amount`（金额，正数）、`from`（原货币三字母代码，如 `USD`）、`to`（目标货币，如 `CNY`）
- 数据源（**两个都不需要 Key**）：
  - 主：[Frankfurter](https://frankfurter.dev/)（`https://api.frankfurter.dev/v1/latest`，欧洲央行数据）
  - 兜底：[open.er-api.com](https://open.er-api.com/)（`https://open.er-api.com/v6/latest/<BASE>`，币种更全）

主源不支持某个币种（例如 ECB 表里没有 TWD）或临时失败时自动换兜底；结果里会注明**实际用了哪家、
汇率是哪一天的**。

## 装

控制台左侧「插件」→ 目录里点安装 → 点启用（装上 ≠ 授权）。

## 配置（可选）

```json
{
  "plugins": {
    "settings": {
      "exchange-rate": {
        "frankfurterUrl": "https://api.frankfurter.dev/v1",
        "erApiUrl": "https://open.er-api.com/v6/latest"
      }
    }
  }
}
```

两个地址都可以换成自建代理/镜像（给测试或内网部署用）。**指到内网会被宿主的网络守卫拦下。**

## 它不做什么

- 只读查询，不写任何东西，也不能在群里发言（`capabilities` 里没有 `send`）。
- 不提供历史汇率曲线、不做换算以外的金融分析。
- 不给"成交价"承诺：公开汇率表是参考中间价，**真实成交价以银行/平台为准**，结果里会带这句提醒。
- 同币种（`USD` → `USD`）本地直接返回原金额，不去打上游（有些源对 `base=symbols` 会直接报错）。
- 上游取不到时返回可读错误（例如"两家汇率源都取不到：…"），不会静默给一个空结果。
