// Pixiv 来张图 · qq-agent-plus 插件 apiVersion 2
//
// ── 从 v1 升 v2 改了什么 ────────────────────────────────────────────────
// v1 时代这个插件只能「给图链」：send 只发纯文本、http 只回字符串、插件不许写文件。v2 补上了：
//   · cap.media.download({ url, name, maxBytes, headers }) —— 支持自定义头（Referer！），
//     把文件落进插件自己的 plugin-data/<id>/media/；
//   · cap.send.file({ chatKey, file, name }) —— 把那个文件发到 context.chatKey（只支持群聊）；
//   · callTool 带 context：{ chatKey, senderIsOwner }；
//   · 工具级 timeoutMs（这里 90s）—— 下载几 MB 原图不必再赌 20 秒。
//
// ── 三条实测过的坑（来自 AGENT.md / 爪上搜的踩坑记录，不是推测）──────────
// ① 协议端与宿主不同容器时 cap.send.file 不可用：宿主把 media 目录的绝对路径交给协议端，
//    NapCat 在另一个容器里读不到 -> retcode=100 ENOENT ... realpath '/mnt/data/...'。
//    所以除了「宿主发文件」，还要能退回「让协议端自己去取 URL」：结果里给 forward =
//    { tool: 'send_group_file', url, name }，由模型一步转发。降级记进 storage，
//    探测窗口 30 分钟起翻倍、封顶 12 小时（成功一次清零）。
// ② 下载成功不等于拿到图片：站点 404 页是 162 字节 text/html，宿主照样把它当文件写下来。
//    必须看回执的 contentType 是不是 image/ 才决定发不发 —— 否则会把一张错误页发进群。
// ③ shutdown 不带 id：无条件回执会序列化成 {"result":{}}，宿主记一条 protocolErrors。
//
// ── 图源顺序：先反代、再原站 ─────────────────────────────────────────────
// 先走 i.pixiv.re 反代（大陆可直连，实测 200）；反代挂了就把域名换成 i.pximg.net 并带 Referer
// 再试一次 —— i.pximg.net 强制校验 Referer（实测带 200 / 不带 403），v1 发不出自定义头所以走不通。
//
// ── 私聊为什么不发图 ───────────────────────────────────────────────────
// cap.send.file 与内置 send_group_file 都只支持群聊。私聊/控制台一律回落成「两条链接 + 复制提醒」。
import { pathToFileURL } from 'node:url';

const write = (message) => { process.stdout.write(JSON.stringify(message) + '\n'); };

let requestSeq = 0;
const pending = new Map();
const callHost = (method, params) => new Promise((resolve, reject) => {
  const id = ++requestSeq;
  pending.set(id, { resolve, reject });
  write({ id, method, params });
});

const DEFAULTS = {
  loliconApiUrl: 'https://api.lolicon.app/setu/v2',
  imageUrlTemplate: 'https://pixiv.re/{pid}.png',
  excludeAI: false,
  allowAdult: false,
  allowR18G: false,
  sendImages: true,
  sendMode: 'auto',
  sendHostRetryMinutes: 30,
  maxCount: 2,
  poolSize: 5,
  stateCap: 800,
  chatCap: 200,
  retryCandidates: 3,
  deadTtlDays: 7,
  probeTimeoutMs: 5000,
  downloadTimeoutMs: 25000,
  budgetMs: 75000,
  maxImageMb: 30
};

const SEND_MODES = ['auto', 'forward', 'host'];
const RATING_LABEL = { safe: '全年龄', r18: 'R18', r18g: 'R18G' };
const RATING_KEYS = Object.keys(RATING_LABEL);
const MAX_COUNT = 5;
const MAX_NUM = 20;
const DAY_MS = 24 * 60 * 60 * 1000;

// 协议端读不到宿主给的绝对路径时 NapCat 报的就是这些词；原始报错里带宿主路径，只进日志
const HOST_FILE_BROKEN_RE = /ENOENT|realpath|retcode=100/i;
const HOST_BROKEN_HUMAN = '本部署的协议端读不到宿主给的文件路径，已改成让协议端自己去取图（细节见插件日志）';

const PXIMG_REFERER = 'https://www.pixiv.net/';
const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

// QQ 端对机器人发出的链接基本不做成可点链接、也不渲染预览（2026-10-19 实测）。
const LINK_HINT = '⚠️ QQ 里这些链接通常点不开、也不会显示预览：回复时必须提醒用户「复制链接到自己的浏览器地址栏打开」。';
// 实测模型有时只给作品页、不给反代图链，用户反而看不到图（作品页在墙外）。要求两条一起给。
const TWO_LINKS = '两条链接一起给，按这个说法写：图在这里：【<imageUrl>】，图源挂了用这个试试：【<pageUrl>】。';
const SENT_ADVISE = '图已经直接发到群里了（sent=true），不要再贴链接、也不要再调 send_group_file 重复转发。'
  + '说一句「图发上面了」并带上标题/作者即可；用户问出处时给 pageUrl。';
const FORWARD_ADVISE = '这次没经过宿主发文件（sent=false）。结果里每个 item 都带 forward：立刻用宿主内置 send_group_file，'
  + '把 forward.url 与 forward.name 原样传进去，不要自己拼参数、也不要再让用户复制链接。';

let settings = {};

const num = (value, fallback, min, max) => {
  const n = Math.floor(Number(value));
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
};

const remaining = (deadline) => Math.max(0, deadline - Date.now());

/** 配置可能是面板/手改进来的：形状不对一律退回默认值，别让一个坏值把整次调用炸掉。 */
function config() {
  const s = settings && typeof settings === 'object' ? settings : {};
  const explicit = Array.isArray(s.ratings)
    ? s.ratings.map((r) => String(r).toLowerCase()).filter((r) => Object.prototype.hasOwnProperty.call(RATING_LABEL, r))
    : null;
  // 面板只能给布尔开关（select 是单选，撑不了多选），所以面板用 allowAdult / allowR18G；
  // 老配置里的 ratings 数组仍优先，allowR18（更老）当 allowAdult 用。
  const adult = s.allowAdult === true || s.allowR18 === true;
  const derived = s.allowR18G === true ? ['safe', 'r18', 'r18g'] : (adult ? ['safe', 'r18'] : ['safe']);
  return {
    apiUrl: String(s.loliconApiUrl || DEFAULTS.loliconApiUrl).trim(),
    imageTemplate: String(s.imageUrlTemplate || DEFAULTS.imageUrlTemplate).trim(),
    excludeAI: s.excludeAI === true,
    ratings: explicit && explicit.length ? explicit : derived,
    sendImages: s.sendImages !== false,
    sendMode: SEND_MODES.includes(String(s.sendMode || '').trim()) ? String(s.sendMode).trim() : DEFAULTS.sendMode,
    sendHostRetryMinutes: num(s.sendHostRetryMinutes, DEFAULTS.sendHostRetryMinutes, 1, 720),
    maxCount: num(s.maxCount, DEFAULTS.maxCount, 1, MAX_COUNT),
    poolSize: num(s.poolSize, DEFAULTS.poolSize, 1, 50),
    stateCap: num(s.stateCap, DEFAULTS.stateCap, 10, 2000),
    chatCap: num(s.chatCap, DEFAULTS.chatCap, 10, 500),
    retryCandidates: num(s.retryCandidates, DEFAULTS.retryCandidates, 0, 10),
    deadTtlDays: num(s.deadTtlDays, DEFAULTS.deadTtlDays, 0, 365),
    probeTimeoutMs: num(s.probeTimeoutMs, DEFAULTS.probeTimeoutMs, 500, 15000),
    downloadTimeoutMs: num(s.downloadTimeoutMs, DEFAULTS.downloadTimeoutMs, 1000, 60000),
    budgetMs: num(s.budgetMs, DEFAULTS.budgetMs, 5000, 85000),
    maxImageMb: num(s.maxImageMb, DEFAULTS.maxImageMb, 1, 80)
  };
}

const fail = (code, message) => Object.assign(new Error(message), { code });
const errorResult = (code, message) => ({ ok: false, error: { code, message } });

// ── 能力调用 ────────────────────────────────────────────────────────────

async function httpStatus(url) {
  try {
    const result = await callHost('cap.http.request', { url, maxChars: 512 });
    return { ok: Number(result?.status) === 200, status: Number(result?.status) || 0, reached: true };
  } catch (error) {
    return { ok: false, status: 0, reached: false, error: String(error?.message || error) };
  }
}

async function httpJson(url) {
  const result = await callHost('cap.http.request', { url, maxChars: 200000 });
  const status = Number(result?.status) || 0;
  if (status !== 200) throw fail(status === 429 ? 'E_RATE' : 'E_UPSTREAM', '内置检索接口返回 HTTP ' + (status || '?'));
  try {
    return JSON.parse(String(result?.body ?? ''));
  } catch {
    throw fail('E_BAD_JSON', '内置检索接口返回的不是 JSON（换个接口地址，或者稍后再试）');
  }
}

async function logWarn(text) {
  try { await callHost('cap.log.write', { level: 'warn', message: String(text).slice(0, 500) }); } catch { /* 记日志失败不该影响主流程 */ }
}

const TIMED_OUT = Symbol('timeout');
// 设置页点「测试」时等的是 probe 回执：这次请求必须秒回，超了就当没测到。
const PROBE_BUDGET_MS = 1200;

/** 给单次远程动作限时：超时只当「这次没成」，真报错照原样抛。 */
function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const done = (value) => { if (!settled) { settled = true; clearTimeout(timer); resolve(value); } };
    const failNow = (error) => { if (!settled) { settled = true; clearTimeout(timer); reject(error); } };
    const timer = setTimeout(() => { if (!settled) { settled = true; reject(TIMED_OUT); } }, Math.max(1, ms));
    if (typeof timer.unref === 'function') timer.unref();
    promise.then(done, failNow);
  });
}

// ── 状态（cap.storage）───────────────────────────────────────────────────

const STATE_READ_TIMEOUT_MS = 4000;
const STATE_WRITE_TIMEOUT_MS = 4000;
const STORAGE_BROKEN_HUMAN = '存档读坏了，这次没有写回，已保留原数据';

const isPlainObject = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value);
const hasOwn = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
const shapeOf = (value) => (Array.isArray(value) ? '数组' : typeof value);

let stateCache = null;
// 本轮存档不可信的原因（读失败 / 读坏了）。有值就一个字节都不回写：整键覆盖会把真实数据清零。
let stateBroken = '';

// 宿主的 storage 是整键读-改-写：两个 callTool 交错时，后写的会把先读到的旧值整份盖回去。
// 一条 promise 链只串存档读/写（HTTP、下载、发图都不排队），一次只放一个人进临界区。
let storageChain = Promise.resolve();

/** 排队取到临界区，返回放行函数（重复调用无副作用）。 */
function acquireStorage() {
  let open = null;
  const gate = new Promise((resolve) => { open = resolve; });
  const wait = storageChain;
  storageChain = gate;
  let released = false;
  return wait.then(() => () => { if (released) return; released = true; open(); });
}

/** 在临界区里跑一段存档动作；成功 / 失败 / 提前 return 都从这里放行，失败不断链。 */
async function inStorageSection(task) {
  const release = await acquireStorage();
  try { return await task(); } finally { release(); }
}

function markStateBroken(reason) {
  stateBroken = reason;
  void logWarn('存档不可用（本轮所有写回已关闭）：' + reason);
}

/** 把「这次没写回」那句话接在结果 note 后面；存档正常时原样返回。 */
function storageNote(note) {
  if (!stateBroken) return note;
  return [note, STORAGE_BROKEN_HUMAN].filter(Boolean).join('');
}

async function loadState() {
  if (stateCache) return stateCache;
  return inStorageSection(async () => {
    // 排队期间别人可能已经读好了：共用同一份，别再读一次（两份状态会互相覆盖）。
    if (stateCache) return stateCache;
    const state = { seen: [], dead: {}, chatRatings: Object.create(null) };
    let raw = null;
    try {
      raw = await withTimeout(callHost('cap.storage.get', { key: 'state' }), STATE_READ_TIMEOUT_MS);
    } catch (error) {
      markStateBroken(error === TIMED_OUT
        ? '读存档超时（宿主 ' + STATE_READ_TIMEOUT_MS + 'ms 没回话）'
        : '读存档失败：' + String(error?.message || error).slice(0, 120));
      stateCache = state;
      return stateCache;
    }
    // 首次使用：宿主没有这条存档 —— 正常初始化，允许写回。
    if (raw === null || raw === undefined) { stateCache = state; return stateCache; }
    // 读到了、但信封不是普通对象：分不清是真没有还是读坏了，一律按读坏处理（不写回）。
    if (!isPlainObject(raw)) {
      markStateBroken('存档信封是 ' + shapeOf(raw) + '，不是普通对象');
      stateCache = state;
      return stateCache;
    }
    const value = raw.value;
    if (value !== null && value !== undefined && !isPlainObject(value)) {
      markStateBroken('存档内容（envelope.value）是 ' + shapeOf(value) + '，不是普通对象');
      stateCache = state;
      return stateCache;
    }
    if (value) {
      if (Array.isArray(value.seen)) state.seen = value.seen.filter((p) => Number.isFinite(Number(p))).map(Number);
      if (isPlainObject(value.dead)) {
        for (const [pid, ts] of Object.entries(value.dead)) {
          if (Number.isFinite(Number(pid)) && Number.isFinite(Number(ts))) state.dead[pid] = Number(ts);
        }
      }
      if (isPlainObject(value.chatRatings)) {
        // 键来自会话上下文，可能是 __proto__ / toString：回填也必须落在无原型字典的自身键上。
        for (const key of Object.keys(value.chatRatings)) {
          if (!hasOwn(value.chatRatings, key)) continue;
          const list = value.chatRatings[key];
          const clean = Array.isArray(list) ? list.map((r) => String(r).toLowerCase()).filter((r) => RATING_KEYS.includes(r)) : [];
          if (clean.length) state.chatRatings[key] = clean;
        }
      }
    }
    stateCache = state;
    return stateCache;
  });
}

async function saveState() {
  if (!stateCache) return false;
  // 读失败 / 读坏了：这次一个字节都不写，真实数据原样留在宿主里。
  if (stateBroken) return false;
  return inStorageSection(async () => {
    try {
      await withTimeout(callHost('cap.storage.set', { key: 'state', value: stateCache }), STATE_WRITE_TIMEOUT_MS);
      return true;
    } catch (error) {
      void logWarn('写存档失败：' + (error === TIMED_OUT ? '超时' : String(error?.message || error).slice(0, 120)));
      return false;
    }
  });
}

/** 剪掉过期拉黑、裁 seen 与按会话覆盖（storage 单值只有 32KB）。 */
function prune(state, cfg) {
  const now = Date.now();
  const ttl = cfg.deadTtlDays * DAY_MS;
  if (ttl > 0) {
    for (const [pid, ts] of Object.entries(state.dead)) {
      if (now - Number(ts) > ttl) delete state.dead[pid];
    }
  }
  if (state.seen.length > cfg.stateCap) state.seen = state.seen.slice(state.seen.length - cfg.stateCap);
  const keys = Object.keys(state.chatRatings);
  if (keys.length > cfg.chatCap) {
    for (const key of keys.slice(0, keys.length - cfg.chatCap)) delete state.chatRatings[key];
  }
  return state;
}

/** 会话覆盖表的读取守卫：键来自会话上下文（可能是 __proto__、toString 这种），只认字典自己的键。 */
function ownRating(state, chatKey) {
  if (!chatKey || !hasOwn(state.chatRatings, chatKey)) return null;
  const list = state.chatRatings[chatKey];
  return Array.isArray(list) && list.length ? list : null;
}

function effectiveRatings(cfg, state, chatKey) {
  return ownRating(state, chatKey) || cfg.ratings;
}

// ── 「宿主发文件在这个部署里能不能用」─────────────────────────────────────
// 单独一个 storage 键：探测窗口 30 分钟起、连续失败翻倍、封顶 12 小时；成功一次清零。
const SEND_HOST_KEY = 'sendHost';
const SEND_HOST_MAX_MS = 12 * 60 * 60 * 1000;

function sendHostWindowMs(failures, baseMinutes) {
  const count = Math.max(1, Math.floor(Number(failures) || 1));
  const base = Math.max(1, Number(baseMinutes) || DEFAULTS.sendHostRetryMinutes);
  return Math.min(SEND_HOST_MAX_MS, base * 60 * 1000 * Math.pow(2, count - 1));
}

async function readSendHostRaw() {
  try {
    const raw = await callHost('cap.storage.get', { key: SEND_HOST_KEY });
    const value = raw && typeof raw === 'object' ? raw.value : null;
    if (!value || typeof value !== 'object') return null;
    return { brokenAt: Number(value.brokenAt) || 0, failures: Math.max(0, Math.floor(Number(value.failures) || 0)), reason: String(value.reason || '') };
  } catch {
    return null;
  }
}

const sendHostActive = (record, cfg) => Boolean(record && record.brokenAt && (Date.now() - record.brokenAt) <= sendHostWindowMs(record.failures, cfg.sendHostRetryMinutes));

async function markSendHostBroken(reason, previousFailures) {
  const record = { brokenAt: Date.now(), failures: Math.max(1, Math.floor(Number(previousFailures) || 0) + 1), reason: String(reason || '').slice(0, 200) };
  try { await callHost('cap.storage.set', { key: SEND_HOST_KEY, value: record }); } catch { /* 记不下来只是下次还得再探一次 */ }
  return record;
}

async function clearSendHost() {
  try { await callHost('cap.storage.set', { key: SEND_HOST_KEY, value: null }); } catch { /* 同上 */ }
}

// ── 作品 -> 分级 / 图链 / 文件名 ────────────────────────────────────────

/**
 * 分级：接口只给一个布尔 r18，分不出 R18 与 R18G，而且实测会漏判
 * （tags 带 R-18 但 r18=false 的作品真实存在）。默认档是全年龄（群聊），
 * 漏判的代价是往群里发成人图，远大于少出几张 —— 所以标签只升档、不降档。
 */
function ratingOf(item) {
  const tags = Array.isArray(item?.tags) ? item.tags.map((t) => String(t).toUpperCase().trim()) : [];
  const taggedR18G = tags.some((t) => t === 'R-18G' || t === 'R18G');
  const taggedR18 = taggedR18G || tags.some((t) => t === 'R-18' || t === 'R18');
  if (!taggedR18 && item?.r18 !== true) return 'safe';
  return taggedR18G ? 'r18g' : 'r18';
}

const pageUrlOf = (pid) => 'https://www.pixiv.net/artworks/' + pid;

function imageUrlOf(item, template) {
  const original = item?.urls?.original;
  if (original && /^https?:\/\//i.test(String(original))) return String(original);
  return template.replace('{pid}', String(item?.pid ?? '')).replace('{p}', String(item?.p ?? 0));
}

function extOf(url) {
  const match = String(url || '').split('?')[0].match(/[.](png|jpe?g|gif|webp|bmp|avif)$/i);
  if (!match) return 'jpg';
  const ext = match[1].toLowerCase();
  return ext === 'jpeg' ? 'jpg' : ext;
}

function buildItem(item, template) {
  const pid = Number(item?.pid) || 0;
  return {
    pid,
    p: Number(item?.p) || 0,
    title: String(item?.title || '').trim(),
    author: String(item?.author || '').trim(),
    uid: Number(item?.uid) || 0,
    tags: Array.isArray(item?.tags) ? item.tags.map((t) => String(t)).slice(0, 12) : [],
    rating: ratingOf(item),
    width: Number(item?.width) || 0,
    height: Number(item?.height) || 0,
    ai: Number(item?.aiType) === 1,
    pageUrl: pageUrlOf(pid),
    imageUrl: imageUrlOf(item, template)
  };
}

function fromPid(pid, template) {
  return {
    pid, p: 0, title: '', author: '', uid: 0, tags: [], rating: 'unknown',
    width: 0, height: 0, ai: false,
    pageUrl: pageUrlOf(pid),
    imageUrl: template.replace('{pid}', String(pid)).replace('{p}', '0')
  };
}

function pidFromUrl(raw) {
  const text = String(raw || '');
  const artwork = text.match(/artworks\/(\d+)/i);
  if (artwork) return Number(artwork[1]);
  const bare = text.match(/^\s*(\d{4,12})\s*$/);
  return bare ? Number(bare[1]) : 0;
}

// ── 发图 / 转发 ─────────────────────────────────────────────────────────

/** 宿主只接受 [A-Za-z0-9][A-Za-z0-9._-]{0,63}：名字由我们拼，不经过用户输入。 */
const mediaNameOf = (item) => 'pixiv-' + (Number(item.pid) || 0) + '.' + extOf(item.imageUrl);

function displayNameOf(item) {
  const clean = (text, limit) => String(text || '').replace(/[\\/:*?"<>|\r\n]/g, ' ').trim().slice(0, limit);
  const title = clean(item.title, 40);
  const author = clean(item.author, 20);
  return (title || 'pixiv') + (author ? ' - ' + author : '') + ' (' + item.pid + ').' + extOf(item.imageUrl);
}

/** 转发指令：让模型一步调用宿主内置 send_group_file（群聊限定），别自己拼参数。 */
function forwardOf(item, chatKey) {
  if (!chatKey || !item || !item.imageUrl) return null;
  return { tool: 'send_group_file', url: item.imageUrl, name: displayNameOf(item).slice(0, 60) };
}

/** 反代优先、原站兜底；原站必须带 Referer，否则 i.pximg.net 一律 403。 */
function imageSources(item) {
  const proxy = String(item.imageUrl || '');
  if (!proxy) return [];
  const list = [{ kind: 'i.pixiv.re', url: proxy, headers: {} }];
  if (/i\.pixiv\.re/i.test(proxy)) {
    list.push({ kind: 'i.pximg.net', url: proxy.replace(/i\.pixiv\.re/gi, 'i.pximg.net'), headers: { Referer: PXIMG_REFERER, 'User-Agent': BROWSER_UA } });
  }
  return list;
}

/**
 * 下载一张图。下载成功不等于拿到图片：404 页是 text/html，宿主照样写下来 ——
 * 所以必须校验 contentType 是 image/，否则按「这张没了」处理，绝不能把错误页发进群。
 */
async function downloadImage(item, cfg, deadline) {
  const sources = imageSources(item);
  if (!sources.length) return { ok: false, dead: false, error: '没有可用的图链' };
  const fileName = mediaNameOf(item);
  const maxBytes = cfg.maxImageMb * 1024 * 1024;
  let attempts = 0;
  let missing = 0;
  let untyped = 0;
  let budgetOut = false;
  let lastError = '';
  for (const source of sources) {
    if (remaining(deadline) < 1000) { budgetOut = true; lastError = '预算不够，跳过下载'; break; }
    attempts += 1;
    try {
      const result = await withTimeout(callHost('cap.media.download', {
        url: source.url, name: fileName, maxBytes, headers: source.headers
      }), Math.min(cfg.downloadTimeoutMs, remaining(deadline)));
      const contentType = String(result?.contentType || '').toLowerCase();
      if (!/^image\//i.test(contentType)) {
        if (contentType) {
          // 回执给了类型却不是图片：就是站点那张 404 / 错误页（text/html 之类），按「这张没了」处理。
          missing += 1;
          lastError = source.kind + '：下载到的不是图片（contentType=' + contentType + '）';
        } else {
          // 回执压根没给 contentType：判不了是不是图片，但也**不等于 404**，不能算进 dead / 拉黑。
          untyped += 1;
          lastError = source.kind + '：宿主回执没给 contentType，没法确认这张是不是图片（不是 404）';
        }
        continue;
      }
      return { ok: true, file: String(result?.file || fileName), via: source.kind, bytes: Number(result?.bytes) || 0, contentType };
    } catch (error) {
      const timedOut = error === TIMED_OUT;
      const message = timedOut ? '下载超时' : String(error?.message || error);
      lastError = source.kind + '：' + message;
      const status = Number((message.match(/HTTP (\d{3})/) || [])[1] || 0);
      if (status === 404 || status === 410) missing += 1;
    }
  }
  return { ok: false, dead: attempts > 0 && missing === attempts, untyped: attempts > 0 && untyped === attempts, budgetOut, error: lastError || '下载失败' };
}

/** 走宿主发文件。hostBroken=true 表示「这个部署根本发不了文件」，换 URL 也没用。 */
async function sendViaHost(item, chatKey, cfg, deadline) {
  const got = await downloadImage(item, cfg, deadline);
  if (!got.ok) return got;
  if (remaining(deadline) < 1000) {
    // 预算已经不够了：这次不发上传请求（否则 Math.min(超时, 0) 会退化成 1ms 超时，被误报成「发送超时」）。
    return { ok: false, dead: false, budgetOut: true, error: '时间预算用完，这次没有发出上传请求' };
  }
  try {
    await withTimeout(callHost('cap.send.file', { chatKey, file: got.file, name: displayNameOf(item) }), Math.min(cfg.downloadTimeoutMs, remaining(deadline)));
    return { ok: true, file: got.file, via: got.via, bytes: got.bytes };
  } catch (error) {
    const message = error === TIMED_OUT ? '发送超时' : String(error?.message || error);
    return { ok: false, dead: false, hostBroken: HOST_FILE_BROKEN_RE.test(message), error: '下载成功但发送失败：' + message };
  }
}

async function probeOne(url, cfg) {
  try {
    return await withTimeout(httpStatus(url), cfg.probeTimeoutMs);
  } catch {
    return { ok: false, status: 0, reached: false, timedOut: true };
  }
}

// ── 工具 1：search ──────────────────────────────────────────────────────

async function search(args, context) {
  const startedAt = Date.now();
  const cfg = config();
  const deadline = startedAt + cfg.budgetMs;
  const input = args && typeof args === 'object' ? args : {};
  const ctx = context && typeof context === 'object' ? context : {};
  const chatKey = String(ctx.chatKey || '');
  const isGroup = /^group:\d+$/.test(chatKey);
  const wantCount = num(input.count, cfg.maxCount, 1, MAX_COUNT);
  const requestedCount = Math.floor(Number(input.count));
  const state = await loadState();
  prune(state, cfg);
  const ratings = effectiveRatings(cfg, state, chatKey);

  // 这次用哪条路：link（发不了） / forward（协议端读不到宿主文件） / host（宿主发文件）
  let mode = 'link';
  let sendHostRecord = null;
  if (isGroup && cfg.sendImages === true) {
    sendHostRecord = await readSendHostRaw();
    if (cfg.sendMode === 'forward') mode = 'forward';
    else if (cfg.sendMode === 'host') mode = 'host';
    else mode = sendHostActive(sendHostRecord, cfg) ? 'forward' : 'host';
  }

  const finish = async (payload) => {
    state.seen = [...new Set([...state.seen, ...(payload.results || []).map((item) => item.pid)])];
    prune(state, cfg);
    await saveState();
    const result = { ok: true, ...payload };
    if (stateBroken) result.note = storageNote(payload.note);
    return result;
  };

  // ① 直接给作品：链接或作品号 —— 不搜索、不碰去重（用户明确要这一张）
  const directPid = Number(input.pid) || pidFromUrl(input.url);
  if (directPid) {
    const item = fromPid(directPid, cfg.imageTemplate);
    if (mode === 'host') {
      const sent = await sendViaHost(item, chatKey, cfg, deadline);
      if (sent.ok) {
        await clearSendHost();
        return { ok: true, results: [{ ...item, verified: true, sent: true, via: sent.via, bytes: sent.bytes }], note: '已经直接把这张图发到这个群了。', advise: SENT_ADVISE };
      }
      if (sent.hostBroken) {
        await markSendHostBroken(sent.error, sendHostRecord && sendHostRecord.failures);
        await logWarn('宿主发文件不可用（pid=' + directPid + '）：' + sent.error);
        const forward = forwardOf(item, chatKey);
        return {
          ok: true,
          results: [{ ...item, verified: false, sent: false, sendError: HOST_BROKEN_HUMAN, forward }],
          note: HOST_BROKEN_HUMAN + '。',
          advise: forward ? FORWARD_ADVISE : '这个部署发不了图，把 imageUrl 与 pageUrl 给用户。'
        };
      }
      await logWarn('直取作品发图失败 pid=' + directPid + '：' + sent.error);
      if (sent.dead) return errorResult('E_GONE', '作品 ' + directPid + ' 的图取不到（图源都 404）—— 多半已被作者删除或限制访问。换一张吧。');
      if (sent.untyped) {
        return errorResult('E_NO_CONTENT_TYPE', '作品 ' + directPid + ' 这次没发出去，但原因不是 404：'
          + String(sent.error || '').slice(0, 80)
          + '。作品大概率还在，重试一次通常就好；一直这样就先把发送方式改成「只转发」，让协议端自己去取图。');
      }
    }
    const probe = await probeOne(item.imageUrl, cfg);
    if (probe.reached && (probe.status === 404 || probe.status === 410)) {
      return errorResult('E_GONE', '作品 ' + directPid + ' 的图取不到（HTTP ' + probe.status + '）—— 多半已被作者删除或限制访问。换一张吧。');
    }
    const forward = mode === 'forward' ? forwardOf(item, chatKey) : null;
    return {
      ok: true,
      results: [{ ...item, verified: probe.ok, sent: false, forward }],
      note: probe.ok ? '直接给的作品号只带图链（标题/作者/标签要经过搜索才拿得到）；这条图链已验证可用。'
        : '直接给的作品号只带图链。这条图链没验成：' + (probe.reached ? 'HTTP ' + probe.status : '网络异常或超时'),
      advise: forward ? FORWARD_ADVISE : ('把 imageUrl 原样给用户，并按 ![图](imageUrl) 贴出来。' + TWO_LINKS + LINK_HINT)
    };
  }

  // ② 搜索
  const keyword = String(input.kw ?? input.keyword ?? input.tag ?? '').trim();
  if (!keyword) return errorResult('E_ARGS', '要给关键词（kw，例如 初音ミク），或者给作品号（pid）/ 作品链接（url）。');
  let url;
  try {
    url = new URL(cfg.apiUrl);
  } catch {
    return errorResult('E_ARGS', '配置里的「内置搜索接口地址」不是合法 URL：' + cfg.apiUrl);
  }
  const adultsWanted = ratings.some((r) => r !== 'safe');
  url.searchParams.set('num', String(Math.min(MAX_NUM, Math.max(wantCount * 4, 12))));
  url.searchParams.set('r18', adultsWanted ? '2' : '0');
  url.searchParams.set('size', 'original');
  url.searchParams.set('keyword', keyword);
  if (cfg.excludeAI) url.searchParams.set('excludeAI', 'true');

  let payload;
  try {
    payload = await withTimeout(httpJson(url.toString()), remaining(deadline));
  } catch (error) {
    if (error === TIMED_OUT) return errorResult('E_UPSTREAM_TIMEOUT', '上游检索接口 ' + Math.round(cfg.budgetMs / 1000) + ' 秒内没有返回 —— 网络不佳时容易这样，过一会儿再试。');
    if (error?.code === 'E_RATE') return errorResult('E_RATE', '内置检索接口在限流（HTTP 429）—— 过一会儿再试，或者换一个接口地址。');
    return errorResult(error?.code || 'E_UPSTREAM', '搜索失败：' + (error?.message || error));
  }
  if (payload?.error) return errorResult('E_UPSTREAM', '内置检索接口报错：' + payload.error);
  const raw = Array.isArray(payload?.data) ? payload.data : [];
  if (!raw.length) return errorResult('E_EMPTY', '没搜到「' + keyword + '」的作品。换个标签试试（日文原标签命中率最高，例如 初音ミク / オリジナル）。');

  const seen = new Set(state.seen);
  const dead = state.dead;
  const droppedByRating = [];
  const droppedBySeen = [];
  const candidates = [];
  for (const item of raw) {
    const built = buildItem(item, cfg.imageTemplate);
    if (!built.pid) continue;
    if (!ratings.includes(built.rating)) { droppedByRating.push(built.rating); continue; }
    if (seen.has(built.pid)) { droppedBySeen.push(built.pid); continue; }
    if (dead[built.pid]) continue;
    if (candidates.some((c) => c.pid === built.pid)) continue;
    candidates.push(built);
  }
  if (!candidates.length) {
    const parts = [];
    if (droppedByRating.length) parts.push(droppedByRating.length + ' 张被分级设置滤掉（当前允许：' + ratings.map((r) => RATING_LABEL[r]).join(' / ') + '）');
    if (droppedBySeen.length) parts.push(droppedBySeen.length + ' 张之前已经给过');
    if (!parts.length) parts.push('候选都已经被标记成取不到图');
    return errorResult('E_FILTERED', '「' + keyword + '」这次没有可给的图：' + parts.join('；') + '。这不是没有图 —— 换关键词，或把分级放宽（配置或 set_rating）。');
  }

  // ③ 从前 poolSize 张里随机挑
  const pool = candidates.slice(0, Math.min(cfg.poolSize, candidates.length));
  for (let i = pool.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = pool[i]; pool[i] = pool[j]; pool[j] = tmp;
  }
  const targets = pool.slice(0, Math.min(pool.length, wantCount + cfg.retryCandidates));

  const picked = [];
  const unreachable = [];
  let unverified = 0;
  let budgetRanOut = false;
  let hostBrokeNow = '';

  // ④ 宿主发文件
  if (mode === 'host') {
    for (const candidate of targets) {
      if (picked.length >= wantCount) break;
      if (remaining(deadline) < 2000) { budgetRanOut = true; break; }
      const sent = await sendViaHost(candidate, chatKey, cfg, deadline);
      if (sent.ok) {
        picked.push({ ...candidate, verified: true, sent: true, via: sent.via, bytes: sent.bytes });
        await clearSendHost();
        continue;
      }
      await logWarn('发图失败 kw=' + keyword + ' pid=' + candidate.pid + '：' + sent.error);
      if (sent.hostBroken) { hostBrokeNow = sent.error; break; }
      if (sent.dead) { dead[candidate.pid] = Date.now(); unreachable.push(candidate.pid); continue; }
      if (sent.budgetOut) { budgetRanOut = true; break; }   // 预算用完：不算「没验成」，也不必再试下一张
      unverified += 1;
      picked.push({ ...candidate, verified: false, sent: false, sendError: String(sent.error).slice(0, 200) });
    }
    if (hostBrokeNow) {
      await markSendHostBroken(hostBrokeNow, sendHostRecord && sendHostRecord.failures);
      mode = 'forward';
    }
  }

  // ⑤ 剩余名额：探活（forward 模式还多给一条转发指令）
  if (picked.length < wantCount) {
    const usedPids = new Set(picked.map((item) => item.pid));
    const rest = targets.filter((c) => !usedPids.has(c.pid) && !unreachable.includes(c.pid));
    const probes = await Promise.all(rest.map((c) => probeOne(c.imageUrl, cfg)));
    for (let i = 0; i < rest.length; i += 1) {
      if (picked.length >= wantCount) break;
      const candidate = rest[i];
      const probe = probes[i];
      if (probe.reached && (probe.status === 404 || probe.status === 410)) { dead[candidate.pid] = Date.now(); unreachable.push(candidate.pid); continue; }
      if (!probe.ok) unverified += 1;
      const entry = { ...candidate, verified: probe.ok, sent: false };
      if (mode === 'forward') entry.forward = forwardOf(candidate, chatKey);
      picked.push(entry);
    }
  }

  if (!picked.length) {
    const list = unreachable.slice(0, 5).join('、') + (unreachable.length > 5 ? '…' : '');
    await finish({ results: [] });
    return errorResult('E_ALL_GONE', '「' + keyword + '」搜到了 ' + candidates.length + ' 张候选，但图一张都取不到（' + list + '）—— 多半是索引里的旧作品已被作者删除/限制。已把这些作品拉黑 ' + cfg.deadTtlDays + ' 天，同一个关键词再来会换别的图。');
  }

  const sentCount = picked.filter((item) => item.sent).length;
  const forwardCount = picked.filter((item) => item.forward).length;
  const note = [
    sentCount ? '已直接把 ' + sentCount + ' 张图发到这个群。' : '',
    forwardCount ? (hostBrokeNow ? HOST_BROKEN_HUMAN + '：结果里带了 forward，按它调 send_group_file 即可。' : '这个部署走转发：按结果里的 forward 调 send_group_file。') : '',
    !isGroup ? '当前不在群聊里（私聊/控制台），插件发不了文件，只给图链。' : '',
    isGroup && !cfg.sendImages ? '配置里关掉了「把图直接发到群里」，这次只给图链。' : '',
    unreachable.length ? '另有 ' + unreachable.length + ' 张候选取不到图，已拉黑 ' + cfg.deadTtlDays + ' 天。' : '',
    unverified ? '其中 ' + unverified + ' 张没验成（网络慢或超时）—— 链接大概率仍然可用。' : '',
    budgetRanOut ? '这次时间预算用完了，图没发到群里，已改成给图链。' : '',
    Number.isFinite(requestedCount) && requestedCount > wantCount ? '你要了 ' + requestedCount + ' 张，但一次最多给 ' + MAX_COUNT + ' 张，已按 ' + wantCount + ' 张给。' : ''
  ].filter(Boolean).join('');

  const advise = sentCount
    ? SENT_ADVISE
    : (forwardCount ? FORWARD_ADVISE
      : '把 imageUrl 贴给用户，并按 ![标题](imageUrl) 的 Markdown 图片语法给出；归档时带上【PID·标题·作者】。' + TWO_LINKS + LINK_HINT);

  return finish({ keyword, count: picked.length, mode, results: picked, note, advise });
}

// ── 工具 2：set_rating ─────────────────────────────────────────────────

async function setRating(args, context) {
  const cfg = config();
  const input = args && typeof args === 'object' ? args : {};
  const ctx = context && typeof context === 'object' ? context : {};
  const chatKey = String(ctx.chatKey || '');
  const state = await loadState();
  prune(state, cfg);
  if (!chatKey) return errorResult('E_NO_CHAT', '这个工具要在会话里用（控制台调用没有会话上下文）。在群里由主人 @ 我 说「本群只发全年龄」即可。');
  const action = String(input.action || 'status').toLowerCase();
  const isOwner = ctx.senderIsOwner === true;
  const override = ownRating(state, chatKey);

  if (action === 'status') {
    return {
      ok: true, chatKey, override,
      effective: effectiveRatings(cfg, state, chatKey),
      source: override ? '本会话覆盖' : '全局配置',
      canChange: isOwner,
      note: isOwner ? '你可以用 action=set 带 ratings（safe/r18/r18g 之一或多个），或 action=clear 恢复默认。'
        : '只有主人能改这个会话的分级；你只能查看。'
    };
  }
  if (!isOwner) {
    return { ok: false, error: { code: 'E_NOT_OWNER', message: '只有主人能改分级（群主/管理员也不行）。这条是刻意的：分级意味着可能往这个群发成人内容。' }, chatKey, effective: effectiveRatings(cfg, state, chatKey) };
  }
  if (action === 'clear') {
    if (hasOwn(state.chatRatings, chatKey)) delete state.chatRatings[chatKey];
    await saveState();
    return { ok: true, chatKey, override: null, effective: effectiveRatings(cfg, state, chatKey), note: storageNote('已恢复默认分级。') };
  }
  if (action !== 'set') return errorResult('E_ARGS', 'action 只能是 status / set / clear。');
  const wanted = Array.isArray(input.ratings)
    ? [...new Set(input.ratings.map((r) => String(r).toLowerCase()).filter((r) => RATING_KEYS.includes(r)))]
    : [];
  if (!wanted.length) return errorResult('E_ARGS', 'set 需要 ratings：safe / r18 / r18g 里至少一个。');
  // 字典是无原型的，chatKey 是 __proto__ / toString 时也只有自身键，不会种到 Object.prototype 上。
  state.chatRatings[chatKey] = wanted;
  prune(state, cfg);
  await saveState();
  return { ok: true, chatKey, override: wanted, effective: wanted, note: storageNote('已按会话设置分级：' + wanted.map((r) => RATING_LABEL[r]).join(' / ') + '。没勾的档一律不出。') };
}

const TOOLS = { search, set_rating: setRating };

// ── 协议 ────────────────────────────────────────────────────────────────

function handleLine(line) {
  let message = null;
  try { message = JSON.parse(line); } catch { message = null; }
  if (!message || typeof message !== 'object') return;
  if (message.method === 'init') {
    settings = message.params?.settings && typeof message.params.settings === 'object' ? message.params.settings : {};
    stateCache = null;
    stateBroken = '';
    write({ id: message.id, result: { ok: true } });
    return;
  }
  if (message.method === 'callTool') {
    const fn = TOOLS[message.params?.name];
    const callArgs = message.params?.args ?? {};
    const context = message.params?.context && typeof message.params.context === 'object' ? message.params.context : {};
    if (!fn) { write({ id: message.id, error: { code: 'E_NO_TOOL', message: '没有这个工具：' + message.params?.name } }); return; }
    Promise.resolve()
      .then(() => fn(callArgs, context))
      .then((result) => write({ id: message.id, result }))
      .catch((error) => write({ id: message.id, error: { code: error?.code || 'E_TOOL', message: String(error?.message || error) } }));
    return;
  }
  if (message.method === 'probe') {
    const cfg = config();
    // 设置页会等这条回执：真发一次请求，但只给 1200ms 硬预算 —— 超时当「没测到」，不把页面吊死。
    withTimeout(httpJson(cfg.apiUrl + (cfg.apiUrl.includes('?') ? '&' : '?') + 'num=1&r18=0'), PROBE_BUDGET_MS)
      .then((payload) => write({ id: message.id, result: { ok: true, api: cfg.apiUrl, sample: Array.isArray(payload?.data) ? payload.data.length : 0 } }))
      .catch((error) => write({
        id: message.id,
        result: {
          ok: false,
          api: cfg.apiUrl,
          note: error === TIMED_OUT ? '没能在 ' + PROBE_BUDGET_MS + 'ms 内确认接口可达' : String(error?.message || error)
        }
      }));
    return;
  }
  if (message.method === 'ping' || message.method === 'schedule') {
    write({ id: message.id, result: {} });
    return;
  }
  if (message.method === 'shutdown') {
    // 宿主退出时发的 shutdown 不带 id：无条件回执会序列化成 {"result":{}}，宿主记一条 protocolErrors。
    if (message.id !== undefined && message.id !== null) write({ id: message.id, result: { ok: true } });
    setTimeout(() => process.exit(0), 10);
    return;
  }
  if (message.id !== undefined) {
    const entry = pending.get(message.id);
    if (!entry) return;
    pending.delete(message.id);
    if (message.error) entry.reject(Object.assign(new Error(message.error.message || '能力调用失败'), { code: message.error.code }));
    else entry.resolve(message.result === undefined ? null : message.result);
  }
}

function startServer() {
  // 宿主重启 / 管道关闭时 stdout 会 EPIPE；没有 error 处理就是未捕获异常，整个进程直接打崩。
  process.stdout.on('error', () => process.exit(0));
  let buffer = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (chunk) => {
    buffer += chunk;
    let index = buffer.indexOf('\n');
    while (index !== -1) {
      const line = buffer.slice(0, index).trim();
      buffer = buffer.slice(index + 1);
      if (line) handleLine(line);
      index = buffer.indexOf('\n');
    }
  });
  process.stdin.on('end', () => process.exit(0));
}

const entryScript = process.argv[1] ? pathToFileURL(process.argv[1]).href : '';
if (entryScript && import.meta.url === entryScript) startServer();

export { TOOLS, DEFAULTS, MAX_COUNT, ratingOf, pidFromUrl, extOf, forwardOf, sendHostWindowMs, config };
