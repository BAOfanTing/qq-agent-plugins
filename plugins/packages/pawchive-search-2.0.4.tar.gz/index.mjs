// 爪上搜 pawchive-search · qq-agent 插件（apiVersion 2）
//
// ── v2 改了什么 ───────────────────────────────────────────────────────────
// ① HTTP 全部走宿主：cap.http.request { url, maxChars } → { status, truncated, body }，
//    域名白名单由 manifest.httpDomains（pawchive.pw，后缀匹配，file./n2./t1. 都覆盖）。
//    宿主把 maxChars 夹在 httpMaxBytes（本插件声明 524288）与 512KB 之间，返回体超限时
//    truncated=true —— 那是错误，不能把半截 JSON 丢进 JSON.parse。
// ② 能把图发到群：cap.media.download 下到插件自己的 media 目录，再 cap.send.file 发群文件。
//    send.file 只支持 group:<数字>，私聊/失败都不许影响本来要给的链接。
// ③ 作者名查询变成双通道：其余请求都走宿主；只有「按名字找作者要拉 15.6MB 全量作者表」这一路，
//    因为 512KB 上限必然截断，才由插件自己 fetch（可关、限时、失败给可读降级）。
//
// ── 为什么 /posts/random 要靠解析 HTML ────────────────────────────────────
// safeFetchRequest 对 GET 会跟随 302，但 cap.http.request 的回执只有 { status, truncated, body }，
// 没有最终 URL。所以从落地页 HTML 里取 <link rel="canonical">，其次 <meta property="og:url">。
// 实测该页 30KB、两种标记都在。
//
// ── 一个文件有三种状态（实测，2.0.1 的由来）──────────────────────────────
// 用户报的 "send_group_file retcode=100 fetch failed" 不是发送链路的问题：我们给的原图直链本身 404。
// 逐主机实测同一条 path：
//   file.pawchive.pw/data<path>             原图；preview_only 的与已失效的都 404
//   img.pawchive.pw/thumbnail/data<path>    缩略图；preview_only 的这条通常还在（png/jpg 206）
// 于是状态是三种：① 原图+缩略图都在 ② 只有缩略图（preview_only 或原图被清理）③ 两个都没了。
// 所以：attachmentUrl 给原图（可能 404），thumbnailUrl 给缩略图（更容易命中，但不保证），
// 发图按 原图 → 缩略图 回退；两个都取不到才在 note 里说"只能给作品页"。
// 另外：404 页是 162 字节 text/html，宿主仍会把它当文件下下来，所以下载回执要看 contentType 是不是 image/。
//
// 少数作品详情会多给 "temp_url"（t1 主机签名链接，约两周过期），有就作为 attachmentUrl 的兜底。
//
// ── tags（实测）──────────────────────────────────────────────────────────
// 详情接口的 tags 不是数组，而是 postgres 数组字面量字符串（"{a,\"b c\"}"），约四成是 null；
// 抽样 10 篇里 6 篇字符串、4 篇 null、0 篇数组 —— 所以必须过 parseTags，否则一半标签被丢掉。

import { pathToFileURL } from 'node:url';

const write = (message) => { process.stdout.write(JSON.stringify(message) + '\n'); };

let requestSeq = 0;
const pending = new Map();
const callHost = (method, params) => new Promise((resolve, reject) => {
  const id = ++requestSeq;
  pending.set(id, { resolve, reject });
  write({ id, method, params });
});

const DEFAULTS = {
  baseUrl: 'https://pawchive.pw',
  fileBaseUrl: 'https://file.pawchive.pw',
  maxCount: 5,
  withImage: true,
  budgetMs: 15000,
  creatorsTtlMinutes: 10,
  sendImage: true,
  sendMode: 'auto',
  sendHostRetryMinutes: 30,
  sendCount: 1,
  maxImageMb: 20,
  allowSelfFetch: true
};
const MAX_COUNT = 5;
const PAGE_SIZE = 50;
const CREATORS_STATE_KEY = 'creators';
const CREATORS_STATE_CAP = 200;
const MAX_PROFILE_LOOKUPS = 5;
const MAX_TAGS = 12;
const SEND_MODES = ['auto', 'forward', 'host'];
const REQUEST_GAP_MS = 400;
const RETRY_AFTER_429_MS = 2500;
const RETRY_AFTER_5XX_MS = 1500;   // 站点忙时会回 503 "Temporarily busy, please retry in a few seconds."
// 与 manifest.httpMaxBytes 取同一个数：宿主是 limit = min(maxChars, httpCap) 且先按 httpCap 读、
// 再 slice 到 limit —— maxChars 比 httpMaxBytes 小时，524288 到 maxChars 这 12KB 会被切掉却
// 不带 truncated 标记（JSON.parse 只会报"不是 JSON"）。两者相等时，唯一的截断信号就是 truncated。
const HTTP_MAX_CHARS = 524288;
const SEND_ATTEMPTS_LIMIT = 6;   // 下载尝试次数（一条结果最多两次：原图 + 缩略图）
const SEND_MARGIN_MS = 4000;              // 发送留给自己的最小余量

// 工具级 timeoutMs（manifest 里同步声明）。预算必须比它小 5 秒，留出宿主往返与收尾。
const TOOL_TIMEOUT_MS = { search: 30000, creator: 45000, random: 30000 };
const BUDGET_MARGIN_MS = 5000;

const LINK_HINT = 'QQ 里这些链接通常点不开，回复时必须提醒用户「复制链接到浏览器地址栏打开」。';
const NO_FAKE_TAGS = '不要编造标签：拿不到就不写。';

const num = (value, fallback, min, max) => {
  const n = Math.floor(Number(value));
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
};

const trimSlash = (value) => String(value || '').trim().replace(/[/]+$/, '');

const has = (object, key) => Object.prototype.hasOwnProperty.call(object || {}, key);

/** 配置可能是手改的 JSON：形状不对一律退回默认值，不让一个坏值把整次调用炸掉。 */
export function config(settings) {
  const s = settings && typeof settings === 'object' ? settings : {};
  return {
    baseUrl: trimSlash(s.baseUrl) || DEFAULTS.baseUrl,
    fileBaseUrl: DEFAULTS.fileBaseUrl,
    maxCount: num(s.maxCount, DEFAULTS.maxCount, 1, MAX_COUNT),
    withImage: s.withImage !== false,
    budgetMs: num(s.budgetMs, DEFAULTS.budgetMs, 5000, 60000),
    creatorsTtlMinutes: num(s.creatorsTtlMinutes, DEFAULTS.creatorsTtlMinutes, 1, 120),
    sendImage: s.sendImage !== false,
    sendMode: SEND_MODES.includes(String(s.sendMode || '').trim()) ? String(s.sendMode).trim() : DEFAULTS.sendMode,
    sendHostRetryMinutes: num(s.sendHostRetryMinutes, DEFAULTS.sendHostRetryMinutes, 15, 720),
    sendCount: num(s.sendCount, DEFAULTS.sendCount, 1, 3),
    maxImageMb: num(s.maxImageMb, DEFAULTS.maxImageMb, 2, 40),
    allowSelfFetch: s.allowSelfFetch !== false
  };
}

/** 实际预算：配置值，但不能超过该工具 timeoutMs 减 5 秒（宿主到点会硬杀）。 */
export function toolBudget(tool, configuredBudget) {
  const limit = (TOOL_TIMEOUT_MS[tool] || 20000) - BUDGET_MARGIN_MS;
  return Math.max(3000, Math.min(Number(configuredBudget) || DEFAULTS.budgetMs, limit));
}

/** 站点名只接受小写字母数字下划线；返回空串表示没给，null 表示形状不合法。 */
export function normalizeService(value) {
  const s = String(value === undefined || value === null ? '' : value).trim().toLowerCase();
  if (!s) return '';
  return /^[a-z0-9_][a-z0-9_-]{1,19}$/.test(s) ? s : null;
}

const filesOf = (item) => [item && item.file, ...(Array.isArray(item && item.attachments) ? item.attachments : [])]
  .filter((f) => f && typeof f === 'object');

/** 整篇都是 preview_only：这类文件在 file 主机上实测 404，直链不可用。 */
export function isPreviewOnly(item) {
  const files = filesOf(item);
  return files.length > 0 && files.every((f) => f.preview_only === true);
}

const fileUrl = (fileBase, path) => trimSlash(fileBase) + '/data' + (String(path).startsWith('/') ? String(path) : '/' + String(path));

const IMAGE_EXT_RE = /[.](png|jpe?g|gif|webp|bmp|avif|apng)$/i;
const looksLikeImage = (file) => IMAGE_EXT_RE.test(String(file && (file.path || file.name) || ''));

/**
 * 附件直链：优先没有 preview_only 标记的文件（file 优先、其次 attachments），同档优先图片
 * （附件里会混整包 zip）；全篇都 preview_only 时退回签名 temp_url；都没有给 null。
 */
export function attachmentUrlOf(item, fileBase = DEFAULTS.fileBaseUrl, withImage = true) {
  if (withImage === false) return null;
  const files = filesOf(item);
  const direct = files.filter((f) => typeof f.path === 'string' && f.path && f.preview_only !== true);
  const usable = direct.find(looksLikeImage) || direct[0];
  if (usable) return fileUrl(fileBase, usable.path);
  const signed = files.filter((f) => typeof f.temp_url === 'string' && /^https?:[/][/]/i.test(f.temp_url));
  const temp = signed.find(looksLikeImage) || signed[0];
  if (temp) return String(temp.temp_url);
  return null;
}

// 缩略图主机：preview_only 的文件在 file 主机上实测 404，但这一条通常还在（实测 png/jpg 都 206）。
// 反过来也有两个主机同时 404 的（站点的文件真的没了），所以它只是"更容易命中"，不是保证。
const THUMBNAIL_BASE = 'https://img.pawchive.pw/thumbnail';

/**
 * 缩略图直链：在 file 与 attachments 里挑第一个"图片扩展名"的 path（有整包 rar/zip 的帖子，
 * 它的 file 是压缩包、第一张附件才是图）；全是压缩包时才退回第一个 path。
 * 比"一律用 file.path"多一步，但能救回一类本来发不出图的帖子。
 */
export function thumbnailUrlOf(item, base = THUMBNAIL_BASE) {
  const withPath = filesOf(item).filter((f) => typeof f.path === 'string' && f.path);
  const file = withPath.find(looksLikeImage) || withPath[0];
  if (!file) return null;
  return trimSlash(base) + '/data' + (String(file.path).startsWith('/') ? String(file.path) : '/' + String(file.path));
}

/** attachmentKind：image / archive / null（拿不到）。zip 也照给，但要标明它不是图。 */
export function attachmentKindOf(url) {
  if (!url) return null;
  return IMAGE_EXT_RE.test(String(url).split('?')[0]) ? 'image' : 'archive';
}

function splitPgArray(inner) {
  // 按 postgres 数组字面量切分：逗号分隔，但双引号内的逗号不算分隔符，引号内支持 \" 与 \\ 转义。
  // 引号没闭合也不抛错（剩下的一律当元素内容）—— 接口脏数据不该炸掉整次调用。
  const parts = [];
  let current = '';
  let quoted = false;
  for (let i = 0; i < inner.length; i += 1) {
    const ch = inner[i];
    if (quoted) {
      if (ch === '\\') { current += inner[i + 1] === undefined ? '' : inner[i + 1]; i += 1; }
      else if (ch === '"') quoted = false;
      else current += ch;
    } else if (ch === '"') {
      quoted = true;
    } else if (ch === ',') {
      parts.push(current);
      current = '';
    } else {
      current += ch;
    }
  }
  parts.push(current);
  return parts;
}

/** tags → 字符串数组：postgres 字面量字符串、真数组、null 三种都收，去空去重，最多 12 个。 */
export function parseTags(value, limit = MAX_TAGS) {
  const out = [];
  const push = (raw) => {
    const text = String(raw === undefined || raw === null ? '' : raw).trim();
    if (text && out.length < limit && !out.includes(text)) out.push(text);
  };
  const walk = (node) => {
    if (node === undefined || node === null) return;
    if (Array.isArray(node)) { for (const entry of node) walk(entry); return; }
    if (typeof node === 'object') { walk(node.name); return; }
    const text = String(node).trim();
    if (!text) return;
    if (text.startsWith('{') && text.endsWith('}')) {
      for (const part of splitPgArray(text.slice(1, -1))) push(part);
      return;
    }
    push(text);
  };
  walk(value);
  return out.slice(0, limit);
}

const POST_URL_RE = /(?:^|[/])([a-z0-9_][a-z0-9_-]*)[/]user[/](\d+)[/]post[/](\d+)/i;
const USER_URL_RE = /(?:^|[/])([a-z0-9_][a-z0-9_-]*)[/]user[/](\d+)/i;

/** 从作品页链接里取 { service, uid, pid }；认不出返回 null。 */
export function parsePostUrl(raw) {
  const m = String(raw === undefined || raw === null ? '' : raw).match(POST_URL_RE);
  return m ? { service: m[1].toLowerCase(), uid: m[2], pid: m[3] } : null;
}

/** 从作者页链接里取 { service, uid }；认不出返回 null。 */
export function parseUserUrl(raw) {
  const m = String(raw === undefined || raw === null ? '' : raw).match(USER_URL_RE);
  return m ? { service: m[1].toLowerCase(), uid: m[2] } : null;
}

export function pageUrlOf(triple, base = DEFAULTS.baseUrl) {
  return trimSlash(base) + '/' + triple.service + '/user/' + triple.uid + '/post/' + triple.pid;
}

export function userPageUrlOf(creator, base = DEFAULTS.baseUrl) {
  return trimSlash(base) + '/' + creator.service + '/user/' + creator.id;
}

/**
 * 从 /posts/random 的落地页 HTML 里认作品：先 <link rel="canonical">，其次 <meta property="og:url">。
 * 两种标记的属性顺序都可能调换，所以各给两种正则；都认不出返回 null（调用方报错，绝不瞎猜）。
 */
export function parseCanonicalPostUrl(html) {
  const text = String(html === undefined || html === null ? '' : html);
  const patterns = [
    /<link[^>]+rel=["']?canonical["']?[^>]*href=["']([^"']+)["']/i,
    /<link[^>]+href=["']([^"']+)["'][^>]*rel=["']?canonical["']?/i,
    /<meta[^>]+property=["']?og:url["']?[^>]*content=["']([^"']+)["']/i,
    /<meta[^>]+content=["']([^"']+)["'][^>]*property=["']?og:url["']?/i
  ];
  for (const pattern of patterns) {
    const matched = text.match(pattern);
    if (!matched) continue;
    const triple = parsePostUrl(String(matched[1]).replace(/&amp;/gi, '&'));
    if (triple) return triple;
  }
  return null;
}

/**
 * 媒体文件名：pw_<service>_<pid>.<ext>，同时满足宿主的 ^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$。
 * 扩展名跟着"实际要下那个 URL"走 —— 回退到缩略图时名字也要跟着变，否则宿主会以为还是原图。
 */
export function mediaNameOf(result, urlOverride) {
  const url = String(urlOverride || (result && (result.attachmentUrl || result.thumbnailUrl)) || '').split('?')[0];
  const rawExt = (url.match(IMAGE_EXT_RE) || [null, 'jpg'])[1].toLowerCase();
  const ext = rawExt === 'jpeg' ? 'jpg' : rawExt;
  const service = String(result && result.service || 'x').toLowerCase().replace(/[^a-z0-9]/g, '') || 'x';
  const pid = String(result && result.postId || '0').replace(/[^A-Za-z0-9]/g, '') || '0';
  return ('pw_' + service.slice(0, 12) + '_' + pid.slice(0, 16) + '.' + ext).slice(0, 64);
}

/** 只有 group:<数字> 才是可发的目标（cap.send.file 不支持私聊）。 */
export function sendTargetOf(context) {
  const chatKey = String(context && context.chatKey || '').trim();
  return /^group:\d+$/.test(chatKey) ? chatKey : '';
}

/**
 * 发不发：调用参数 sendImage:false 优先（显式拒绝），其次设置项，最后看会话类型。
 * 三态都在这里定，工具函数只管照做。
 */
export function sendPlan(cfg, context, args) {
  const chatKey = sendTargetOf(context);
  if (args && args.sendImage === false) return { chatKey, allowed: false, reason: 'explicit-off' };
  if (!cfg || cfg.sendImage !== true) return { chatKey, allowed: false, reason: 'off' };
  if (!chatKey) return { chatKey, allowed: false, reason: 'not-group' };
  return { chatKey, allowed: true, reason: '' };
}

/**
 * 名字匹配：先找完全相等的（name / public_id，大小写不敏感），没有再退回子串。
 * 按 favorited 从高到低取前 limit 个 —— 全站 9.7 万个作者，重名的太多，热度是最省事的判别信号。
 */
export function pickCreatorCandidates(list, name, limit = 2) {
  const q = String(name === undefined || name === null ? '' : name).trim().toLowerCase();
  if (!q || !Array.isArray(list)) return [];
  const norm = (v) => String(v === undefined || v === null ? '' : v).toLowerCase();
  const exact = [];
  const partial = [];
  for (const c of list) {
    if (!c || !c.id || !c.service) continue;
    const n = norm(c.name);
    const p = norm(c.public_id);
    if (n === q || p === q) exact.push(c);
    else if (n.includes(q) || p.includes(q)) partial.push(c);
  }
  const byFavorited = (a, b) => (Number(b.favorited) || 0) - (Number(a.favorited) || 0);
  exact.sort(byFavorited);
  partial.sort(byFavorited);
  return (exact.length ? exact : partial).slice(0, limit);
}

/** 作者状态最多留 200 个，超出丢「最久没查」的。 */
export function pruneCreatorState(state, cap = CREATORS_STATE_CAP) {
  const source = state && typeof state === 'object' ? state : {};
  const entries = Object.entries(source);
  if (entries.length <= cap) return source;
  entries.sort((a, b) => String(b[1] && b[1].checkedAt || '').localeCompare(String(a[1] && a[1].checkedAt || '')));
  const next = {};
  for (const [key, value] of entries.slice(0, cap)) next[key] = value;
  return next;
}

/** checkUpdate 的状态推进：首次见 build 基线；最新 postId 变了才算 updated。 */
export function nextCreatorState(prev, works, name, nowIso) {
  // 调用方给的是内部 item（字段叫 postId），单测里给的是原始作品（字段叫 id），两种都认
  const list = Array.isArray(works) ? works.filter((w) => w && (w.id || w.postId)) : [];
  const latest = list[0] || null;
  if (!latest) return { record: prev || null, baseline: !prev, updated: false, newer: [] };
  const record = {
    postId: String(latest.id || latest.postId),
    published: String(latest.published || ''),
    name: String(name || ''),
    checkedAt: String(nowIso || '')
  };
  if (!prev || !prev.postId) return { record, baseline: true, updated: false, newer: list };
  const newer = list.filter((w) => String(w.published || '') > String(prev.published || ''));
  const updated = String(latest.id || latest.postId) !== String(prev.postId);
  return { record, baseline: false, updated, newer: updated ? (newer.length ? newer : [latest]) : [] };
}

// ── 宿主通道 ─────────────────────────────────────────────────────────────

const sleep = (ms) => new Promise((resolve) => {
  const timer = setTimeout(resolve, Math.max(0, ms));
  if (typeof timer.unref === 'function') timer.unref();
});

const remaining = (deadline) => deadline - Date.now();

const TIMED_OUT = Symbol('timedOut');

/** 宿主能力调用没有超时参数：自己掐表，超了就按超时处理（迟到的回执丢弃）。 */
function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => { if (!settled) { settled = true; resolve(TIMED_OUT); } }, Math.max(200, ms));
    if (typeof timer.unref === 'function') timer.unref();
    promise.then(
      (value) => { if (!settled) { settled = true; clearTimeout(timer); resolve(value); } },
      (error) => { if (!settled) { settled = true; clearTimeout(timer); reject(error); } }
    );
  });
}

let lastRequestAt = 0;
async function gate(deadline) {
  const wait = REQUEST_GAP_MS - (Date.now() - lastRequestAt);
  if (wait > 0) await sleep(Math.min(wait, Math.max(0, remaining(deadline))));
  lastRequestAt = Date.now();
}

const fail = (code, message) => Object.assign(new Error(message), { code });

let settings = {};

function logHost(level, message) {
  // 不 await：日志不该拖慢一次已经算好的调用
  callHost('cap.log.write', { level, message: String(message).slice(0, 500) }).catch(() => {});
}

/**
 * GET 一段文本，走宿主 cap.http.request。
 * truncated=true 是硬错误：那是「响应超过 manifest.httpMaxBytes」的信号，
 * 半截 JSON 交给 JSON.parse 只会得到一句没头没脑的解析失败。
 */
async function httpText(url, deadline, options = {}) {
  const timeoutMs = Math.max(1000, Number(options.timeoutMs) || 9000);
  const retries = Number.isFinite(Number(options.retries)) ? Number(options.retries) : 1;
  for (let attempt = 0; ; attempt += 1) {
    if (remaining(deadline) < 500) throw fail('E_BUDGET', '时间预算用完了');
    await gate(deadline);
    // 能力调用本身也可能拒（宿主侧 DNS/连接失败时回的是 E_UPSTREAM 之类的 error），
    // 那种情况下原始文案往往只有一句 "fetch failed"，必须翻成人话，别原样丢给用户。
    let raw;
    try {
      raw = await withTimeout(
        callHost('cap.http.request', { url, maxChars: HTTP_MAX_CHARS }),
        Math.min(timeoutMs, remaining(deadline))
      );
    } catch (error) {
      const message = String(error && error.message || error);
      if (!(error && error.code === 'E_NETWORK')) logHost('warn', 'cap.http.request 失败：' + message);
      throw fail('E_NETWORK', '宿主请求失败：' + message);
    }
    if (raw === TIMED_OUT) throw fail('E_TIMEOUT', '请求超时（' + Math.round(timeoutMs / 1000) + ' 秒）');
    const status = Number(raw && raw.status) || 0;
    const body = String(raw && raw.body !== undefined && raw.body !== null ? raw.body : '');
    if (raw && raw.truncated === true) {
      throw fail('E_TRUNCATED', '响应超过 httpMaxBytes（' + HTTP_MAX_CHARS + ' 字符上限）被截断');
    }
    if (status === 429) {
      if (attempt < retries && remaining(deadline) > RETRY_AFTER_429_MS + 1500) {
        await sleep(RETRY_AFTER_429_MS);
        continue;
      }
      throw fail('E_RATE', '站点在限流（HTTP 429）');
    }
    // 502/503/504 是站点自己过载（响应体原话："Temporarily busy, please retry in a few seconds."），
    // 隔一两秒重试一次比直接报错有用得多
    if (status === 502 || status === 503 || status === 504) {
      if (attempt < retries && remaining(deadline) > RETRY_AFTER_5XX_MS + 1500) {
        await sleep(RETRY_AFTER_5XX_MS);
        continue;
      }
      throw fail('E_UPSTREAM', '上游返回 HTTP ' + status + '（站点暂时过忙，隔几秒再试）');
    }
    if (status !== 200) throw fail('E_UPSTREAM', '上游返回 HTTP ' + (status || '?'));
    return body;
  }
}

async function httpJson(url, deadline, options = {}) {
  const text = await httpText(url, deadline, options);
  try {
    return JSON.parse(text);
  } catch {
    throw fail('E_UPSTREAM', '上游返回的不是 JSON（' + text.length + ' 字符）');
  }
}

/**
 * 插件自己 fetch（**只有全量作者表走这条**）：15.6MB 远超 512KB 上限，走宿主必然截断。
 * 限时 + 限额 + 失败可读降级；allowSelfFetch 关掉时不尝试。
 */
async function selfFetchJson(url, deadline, timeoutMs) {
  const limit = Math.max(1000, Math.min(Number(timeoutMs) || 12000, remaining(deadline)));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), limit);
  if (typeof timer.unref === 'function') timer.unref();
  try {
    const response = await fetch(url, { signal: controller.signal, redirect: 'follow' });
    if (!response.ok) throw fail('E_UPSTREAM', 'HTTP ' + response.status);
    const text = await response.text();
    if (text.length > 64 * 1024 * 1024) throw fail('E_UPSTREAM', '作者表异常大（' + text.length + ' 字符）');
    return JSON.parse(text);
  } catch (error) {
    if (error && error.code) throw error;
    if (controller.signal.aborted) throw fail('E_NETWORK', '作者表下载超时（' + Math.round(limit / 1000) + ' 秒）');
    throw fail('E_NETWORK', String(error && error.message || error));
  } finally {
    clearTimeout(timer);
  }
}

/** 把内部错误码翻成用户能读的一句话。 */
function describe(error, what) {
  const code = error && error.code;
  const detail = String(error && error.message || error);
  if (code === 'E_RATE') return what + '被站点限流了（HTTP 429）—— 隔十几秒再试；连续问太快时最容易这样。';
  if (code === 'E_TIMEOUT') return what + '超时：站点没在规定时间内返回（' + detail + '）。过一会儿再试。';
  if (code === 'E_BUDGET') return what + '没做完：单次调用的时间预算用完了，缩小范围（少要几条、别翻页）再试。';
  if (code === 'E_TRUNCATED') return what + '失败：响应太大被截断（' + detail + '）。这通常意味着接口返回体超过了插件的 httpMaxBytes。';
  if (code === 'E_NETWORK') return what + '失败：连不上站点（' + detail + '）。';
  if (code === 'E_UPSTREAM') return what + '失败：' + detail + '。站点可能临时不可用或改版了。';
  return what + '失败：' + detail;
}

async function storageGet(key) {
  try {
    const result = await callHost('cap.storage.get', { key });
    if (result && typeof result === 'object') return has(result, 'value') ? result.value : result;
    return null;
  } catch {
    return null;
  }
}

async function storageSet(key, value) {
  try {
    await callHost('cap.storage.set', { key, value });
    return true;
  } catch {
    return false;
  }
}

let creatorsCache = { at: 0, list: null };
const nameCache = new Map();   // service:uid → 作者名，进程内一直留住

/**
 * 全量作者表：97464 条 / 15.6MB / 约 1.4 秒。**只能自己 fetch**（宿主 512KB 上限会截断），
 * 进程内只下一次（TTL 默认 10 分钟）。
 */
async function loadCreators(deadline) {
  const cfg = config(settings);
  const ttl = cfg.creatorsTtlMinutes * 60 * 1000;
  if (Array.isArray(creatorsCache.list) && Date.now() - creatorsCache.at < ttl) return creatorsCache.list;
  if (!cfg.allowSelfFetch) throw fail('E_SELFFETCH_OFF', 'allowSelfFetch 已关闭');
  const raw = await selfFetchJson(cfg.baseUrl + '/api/v1/creators', deadline, 12000);
  if (!Array.isArray(raw)) throw fail('E_UPSTREAM', '作者表返回的不是数组');
  creatorsCache = {
    at: Date.now(),
    list: raw.map((c) => ({
      id: String(c && c.id || ''),
      name: String(c && c.name || ''),
      public_id: String(c && c.public_id || ''),
      service: String(c && c.service || ''),
      favorited: Number(c && c.favorited) || 0,
      updated: c && c.updated
    }))
  };
  return creatorsCache.list;
}

async function authorNameOf(service, uid, deadline) {
  const key = service + ':' + uid;
  if (nameCache.has(key)) return nameCache.get(key);
  try {
    const profile = await httpJson(config(settings).baseUrl + '/api/v1/' + service + '/user/' + uid + '/profile', deadline, { timeoutMs: 6000, retries: 0 });
    const name = String(profile && profile.name || '').trim();
    if (name) { nameCache.set(key, name); return name; }
  } catch {
    // 作者名是锦上添花：查不到就用兜底名，不能让它把整次搜索拖失败
  }
  return '';
}

// ── 发图到群 / 转发指令 ───────────────────────────────────────────────────

const SEND_HOST_KEY = 'sendHost';
const SEND_HOST_BASE_MINUTES = 30;
const SEND_HOST_MAX_MS = 12 * 60 * 60 * 1000;
// 协议端与宿主不在同一个文件系统时（NapCat 在另一个容器/机器），upload_group_file 收到宿主给的
// 绝对路径会 realpath ENOENT；一键宿主人自己踩过：retcode=100 ENOENT ... realpath '/mnt/data/...'。
const HOST_FILE_BROKEN_RE = /ENOENT|realpath|retcode=100/i;
// auto 降级时给用户看的话：原始报错里有宿主绝对路径，不该出现在聊天里
const HOST_BROKEN_HUMAN = '本部署的协议端读不到宿主给的文件路径，已改为转发（细节见插件日志）';

/**
 * 探测窗口：首次失败 30 分钟，连续失败翻倍（60 / 120 / 240 / 480 分钟），最长 12 小时。
 * 翻倍的目的是别把"每 30 分钟冒一次同样的原始报错"这种事反复塞给用户。
 */
export function sendHostWindowMs(failures, baseMinutes = SEND_HOST_BASE_MINUTES) {
  const count = Math.max(1, Math.floor(Number(failures) || 1));
  const base = Math.max(1, Number(baseMinutes) || SEND_HOST_BASE_MINUTES);
  return Math.min(SEND_HOST_MAX_MS, base * 60 * 1000 * Math.pow(2, count - 1));
}

/** 读记录（不看窗口）：累加 failures 需要它，即使当前窗口已经过期也照样拿得到。 */
async function readSendHostRaw() {
  const raw = await storageGet(SEND_HOST_KEY);
  if (!raw || typeof raw !== 'object') return null;
  return {
    brokenAt: Number(raw.brokenAt) || 0,
    failures: Math.max(0, Math.floor(Number(raw.failures) || 0)),
    reason: String(raw.reason || '')
  };
}

/** 窗口内才认为"这个部署的宿主发文件确实不可用"。 */
function sendHostActive(record, cfg) {
  if (!record || !record.brokenAt) return false;
  const failures = Math.max(1, record.failures);
  return Date.now() - record.brokenAt <= sendHostWindowMs(failures, cfg && cfg.sendHostRetryMinutes);
}

/** 记一次失败：failures += 1、刷新 brokenAt，并原样留下 reason（便于排查）。 */
async function markSendHostBroken(reason, previousFailures) {
  const record = {
    brokenAt: Date.now(),
    failures: Math.max(1, Math.floor(Number(previousFailures) || 0) + 1),
    reason: String(reason || '').slice(0, 200)
  };
  await storageSet(SEND_HOST_KEY, record);
  return record;
}

async function clearSendHost() {
  await storageSet(SEND_HOST_KEY, null);
}

/**
 * 转发指令：让模型一步调用宿主内置 send_group_file，别自己拼参数。
 * url 优先缩略图（更容易命中）；name 按内置工具的规则（≤60 字、去掉 \\/:*?"<>|），扩展名从 URL 取。
 */
export function forwardOf(item, chatKey) {
  if (!chatKey || !item) return null;
  const url = [item.thumbnailUrl, item.attachmentUrl]
    .find((candidate) => candidate && IMAGE_EXT_RE.test(String(candidate).split('?')[0]));
  if (!url) return null;
  return { tool: 'send_group_file', url, name: forwardNameOf(item, url) };
}

export function forwardNameOf(item, url) {
  const matched = String(url || '').split('?')[0].match(/[.](png|jpe?g|gif|webp|bmp|avif)$/i);
  const ext = (matched ? matched[1] : 'jpg').toLowerCase();
  const base = String((item && (item.author || item.title)) || 'pawchive')
    .replace(/[\\/:*?"<>|]/g, '_')
    .replace(/\s+/g, ' ')
    .trim() || 'pawchive';
  const room = 60 - ext.length - 1;
  return base.slice(0, Math.max(1, room)) + '.' + ext;
}

/**
 * 发图：每个候选按 attachmentUrl（原图）→ thumbnailUrl（缩略图）回退，最多 sendCount 张。
 *
 * 站点上的文件有三种状态：原图+缩略图都在 / 只有缩略图 / 两个都没了。所以：
 *   · 下载成功不等于拿到图片 —— 404 页是 162 字节 text/html，宿主照样会把它当文件写下来，
 *     必须看回执的 contentType 是不是 image/ 才决定发不发；
 *   · 某个 URL 不行（E_UPSTREAM / E_TOO_BIG / 不是图片）就换下一个 URL，不影响别的结果；
 *   · 只有「没发送队列 / 参数不合法 / 超时」这类结构性失败才整体收手。
 *
 * sendMode（2.0.2）：
 *   auto    —— 先按上面的路走；send.file 报"协议端读不到这个路径"就记 30 分钟并把剩余条目改成
 *              转发指令（容器化部署里协议端看不到宿主的 media 目录，这条路本来就走不通）；
 *   forward —— 一开始就不下载、不调用宿主的发文件，直接给转发指令（省一次几 MB 下载）；
 *   host    —— 只走宿主发文件（调试用），失败如实报错，不给转发指令。
 */
async function deliverImages(results, { plan, cfg, deadline }) {
  const summary = { sent: 0, thumbnailSent: 0, attempted: 0, gone: 0, error: '', skipped: '', forwards: 0, mode: cfg.sendMode };
  if (!plan.allowed) { summary.skipped = plan.reason; return summary; }
  const isImageUrl = (url) => Boolean(url) && IMAGE_EXT_RE.test(String(url).split('?')[0]);
  const attachForwards = () => {
    if (summary.mode === 'host') return;
    for (const item of results) {
      if (item.sent || item.forward) continue;
      item.forward = forwardOf(item, plan.chatKey);
      if (item.forward) summary.forwards += 1;
    }
  };

  // 记录要读两份语义：raw 用来累加 failures（窗口过期了也要接着涨），active 决定这次是否还探。
  const sendHostRecord = await readSendHostRaw();
  const cached = sendHostActive(sendHostRecord, cfg);
  const hostUsable = summary.mode === 'host' || (summary.mode === 'auto' && !cached);
  if (!hostUsable) {
    attachForwards();
    summary.skipped = summary.mode === 'forward' ? 'forward-mode' : 'host-broken';
    if (!summary.forwards) summary.skipped = 'no-image';
    if (cached && sendHostRecord) {
      const window = sendHostWindowMs(Math.max(1, sendHostRecord.failures), cfg.sendHostRetryMinutes);
      summary.retryMinutes = Math.max(1, Math.ceil((window - (Date.now() - sendHostRecord.brokenAt)) / 60000));
    }
    return summary;
  }

  // 只发"真的能当图看"的：原图是图片，或者缩略图本身是图片（附件里常有整包 rar/zip，
  // 但它的第一张附件仍是 png —— 那种情况用缩略图发出去，比什么都不发好）。
  const candidates = results.filter((item) => isImageUrl(item.attachmentKind === 'image' ? item.attachmentUrl : null) || isImageUrl(item.thumbnailUrl));
  if (!candidates.length) { summary.skipped = 'no-image'; return summary; }
  const maxBytes = cfg.maxImageMb * 1024 * 1024;
  let hostBrokeNow = false;
  let brokenMessage = '';
  for (const item of candidates) {
    if (summary.sent >= cfg.sendCount) break;
    if (summary.attempted >= SEND_ATTEMPTS_LIMIT) break;
    const attempts = [];
    const pool = [
      { url: item.attachmentKind === 'image' ? item.attachmentUrl : null, via: 'attachmentUrl' },
      { url: isImageUrl(item.thumbnailUrl) ? item.thumbnailUrl : null, via: 'thumbnailUrl' }
    ];
    for (const entry of pool) {
      if (entry.url && !attempts.some((seen) => seen.url === entry.url)) attempts.push(entry);
    }
    let lastError = '';
    let aborted = false;
    let missing = false;   // 站点上确实没有这个文件（404 页 / 不是图片），区别于"太大"这类
    for (const entry of attempts) {
      if (remaining(deadline) < SEND_MARGIN_MS) { summary.skipped = 'budget'; aborted = true; break; }
      summary.attempted += 1;
      const name = mediaNameOf(item, entry.url);
      let stage = 'download';
      try {
        const downloaded = await withTimeout(
          callHost('cap.media.download', { url: entry.url, name, maxBytes }),
          Math.min(20000, Math.max(1000, remaining(deadline)))
        );
        const contentType = String(downloaded && downloaded.contentType || '').toLowerCase();
        if (contentType && !contentType.startsWith('image/')) {
          throw fail('E_NOT_IMAGE', '下载到的不是图片（contentType=' + contentType + '），站点上这个文件已经没了');
        }
        stage = 'send';
        await withTimeout(
          callHost('cap.send.file', { chatKey: plan.chatKey, file: name, name }),
          Math.min(15000, Math.max(1000, remaining(deadline)))
        );
        item.sent = true;
        item.sendError = '';
        item.sentVia = entry.via;
        summary.sent += 1;
        if (entry.via === 'thumbnailUrl') summary.thumbnailSent += 1;
        lastError = '';
        break;
      } catch (error) {
        const timedOut = error === TIMED_OUT;
        const code = error && error.code;
        const message = timedOut ? '下载/发送超时' : String(error && error.message || error);
        lastError = message;
        item.sent = false;
        item.sendError = message;
        if (code === 'E_UPSTREAM' || code === 'E_NOT_IMAGE' || code === 'E_DOMAIN') missing = true;
        // 原始报错（含 /mnt/data/... 这种宿主路径）只进日志与 storage.reason，不给用户看
        logHost('warn', '发图失败 ' + item.postId + '（' + stage + '/' + entry.via + '）：' + message);
        // 协议端读不到宿主路径：这是部署形态问题，换 URL 也没用，直接改走转发
        if (stage === 'send' && summary.mode !== 'host' && HOST_FILE_BROKEN_RE.test(message)) {
          hostBrokeNow = true;
          brokenMessage = message;
          item.sendError = HOST_BROKEN_HUMAN;
          aborted = true;
          summary.skipped = 'host-broken';
          break;
        }
        if (timedOut || code === 'E_NO_SENDER' || code === 'E_ARGS') { aborted = true; summary.skipped = 'error'; break; }
        // E_UPSTREAM / E_TOO_BIG / E_NOT_IMAGE / E_DOMAIN：这个 URL 不行，回退到下一个
      }
    }
    // 只有"这一条彻底没发出去"才记顶层错误：回退成功的那些不该留下失败字样
    if (!item.sent && lastError) {
      if (!summary.error) summary.error = lastError;
      if (missing && !aborted) summary.gone += 1;
    }
    if (aborted) break;
  }

  // 发成功一次就认为这个部署恢复了：清掉记录（下次真要再坏，窗口从头算）
  if (summary.sent && sendHostRecord) await clearSendHost();
  if (hostBrokeNow) {
    const record = await markSendHostBroken(brokenMessage || 'cap.send.file 报 ENOENT/realpath', sendHostRecord ? sendHostRecord.failures : 0);
    summary.retryMinutes = Math.round(sendHostWindowMs(record.failures, cfg.sendHostRetryMinutes) / 60000);
    logHost('warn', '本部署协议端读不到宿主路径，已降级为转发；探测窗口 ' + summary.retryMinutes + ' 分钟（连续失败 ' + record.failures + ' 次）');
    summary.error = '';   // 已经降级成转发指令，不再当"失败"报给用户
    attachForwards();
  }
  // 其它失败（没发送队列 / 预算不够 / 站点文件没了）不塞 forward：
  // 那些情况下转发也发不出去，硬塞一条只会让模型白调一次工具。
  return summary;
}

function sendNoteOf(summary) {
  if (summary.sent) {
    return '已把 ' + summary.sent + ' 张图发到本群（群文件）'
      + (summary.thumbnailSent ? '，其中 ' + summary.thumbnailSent + ' 张用的是缩略图（原图不在站点上了）' : '')
      + '；用户不用再点链接，也不用再调 send_group_file 转发。';
  }
  if (summary.skipped === 'explicit-off') return '这次调用显式要求不发图（sendImage=false），只给链接。';
  if (summary.skipped === 'off') return '设置里关掉了发图（sendImage=false），只给链接。';
  if (summary.skipped === 'not-group') return '不在群聊里，发群文件只支持群聊，所以没有发图，只给链接。';
  if (summary.skipped === 'budget') return '时间预算不够了，没发图（链接照给）。';
  if (summary.forwards) {
    if (summary.skipped === 'forward-mode') {
      return 'sendMode=forward：跳过宿主发文件（省一次下载），直接给 forward 转发指令 —— 让模型按 forward.url/forward.name 调 send_group_file。';
    }
    if (summary.skipped === 'host-broken') {
      return '本部署的协议端读不到宿主给的文件路径（ENOENT/realpath），宿主发文件这条路走不通；'
        + '已改为让协议端自己去取 URL —— 按 forward.url/forward.name 调 send_group_file 即可'
        + '（探测窗口 ' + (summary.retryMinutes || 30) + ' 分钟内不再重试宿主发文件，连续失败会翻倍、最长 12 小时）。';
    }
    return '宿主发文件在这个部署里不成立（协议端看不到宿主的 media 目录，报 ENOENT），已改为给转发指令：'
      + '按 forward.url/forward.name 调 send_group_file，让协议端自己去下载。';
  }
  if (summary.gone) return '有 ' + summary.gone + ' 条的原图与缩略图都已经不在站点上，只能给作品页；别的结果照给。';
  if (summary.skipped === 'no-image') return '这次没有可发的图片（附件是压缩包或拿不到 path），也没有可转发的地址，只能给作品页。';
  if (summary.error) return '发图失败：' + summary.error + '（链接照给，用户可以自己打开）。';
  return '';
}



// ── 工具 ─────────────────────────────────────────────────────────────────

const emptyInput = (args) => (args && typeof args === 'object' ? args : {});

function parseCount(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  const n = Number(value);
  if (!Number.isFinite(n) || !Number.isInteger(n) || n < 1 || n > MAX_COUNT) return null;
  return n;
}

function parsePage(value) {
  if (value === undefined || value === null || value === '') return 0;
  const n = Number(value);
  if (!Number.isFinite(n) || !Number.isInteger(n) || n < 0) return null;
  return n;
}

function imageNoteOf(results, withImage) {
  if (!withImage) return '设置里关掉了附件直链（withImage=false），所以只给作品页链接。';
  const noAttach = results.filter((r) => !r.attachmentUrl).length;
  const archives = results.filter((r) => r.attachmentKind === 'archive').length;
  const parts = ['attachmentUrl 是原图直链、可能已经不在了；thumbnailUrl 是缩略图，比原图更容易命中，但不保证（也有两个都没了的作品）。'];
  if (noAttach > 0) parts.push('有 ' + noAttach + ' 条整篇只有 preview_only 预览图，没有 attachmentUrl，要图就用 thumbnailUrl。');
  if (archives > 0) parts.push('有 ' + archives + ' 条给的是压缩包（attachmentKind=archive），不是单张图。');
  return parts.join(' ');
}

function buildResult(item, cfg) {
  const triple = { service: item.service, uid: item.uid, pid: item.postId };
  const attachmentUrl = attachmentUrlOf(item.raw, cfg.fileBaseUrl, cfg.withImage);
  return {
    postId: String(item.postId),
    title: item.title || '（无标题）',
    published: item.published,
    service: item.service,
    uid: item.uid,
    author: item.author,
    pageUrl: pageUrlOf(triple, cfg.baseUrl),
    attachmentUrl,
    attachmentKind: attachmentKindOf(attachmentUrl),
    thumbnailUrl: cfg.withImage === false ? null : thumbnailUrlOf(item.raw),
    previewOnly: isPreviewOnly(item.raw),
    sent: false,
    sentVia: '',
    sendError: '',
    forward: null
  };
}

// sent=true 表示插件已经把图发到群里 —— 模型再转发一次就是同一个文件发两遍，用户看到刷屏。
// 要转发（或提示用户手动贴图）时用缩略图：原图直链在站点上经常已经 404，缩略图更容易命中。
const SEND_ADVISE = '插件已经把图发到群里（sent=true）时，不要再调 send_group_file 重复转发，也不要再贴一遍链接让用户另开浏览器；'
  + '必须把图片地址交给 send_group_file 或别的下载方时，用 thumbnailUrl（缩略图，更容易命中），不要用 attachmentUrl（原图，可能已经 404）；'
  + '插件自己发图失败时也按这个说法告诉用户：给 thumbnailUrl，或者直接打开作品页。';

// 容器化部署里宿主的 cap.send.file 会把 media 目录的绝对路径交给协议端，协议端读不到就 ENOENT。
// 那种部署下唯一走得通的是"让协议端自己去下载 URL"，也就是结果里的 forward（内置工具 send_group_file）。
const FORWARD_ADVISE = 'sent=false 且结果里有 forward 时：立刻调用宿主内置 send_group_file，把 forward.url 与 forward.name 原样传进去'
  + '（不要自己拼参数，也不要把链接丢给用户让他自己开）；发成功后再按上面的话术回复。';

const SEARCH_ADVISE = '每条按这个说法回复用户：<作者>的作品《<作品名>》 链接：<pageUrl>。'
  + '有 attachmentUrl 就再附上；没有（preview_only 那类）就把 thumbnailUrl 附上。'
  + '发图这件事插件自己做，你不用自己下载、也不用转存。'
  + SEND_ADVISE + FORWARD_ADVISE + NO_FAKE_TAGS + LINK_HINT;

async function search(args, context) {
  const cfg = config(settings);
  const deadline = Date.now() + toolBudget('search', cfg.budgetMs);
  const input = emptyInput(args);

  const keyword = String(input.kw === undefined || input.kw === null ? '' : input.kw).trim();
  if (!keyword) return { error: '要给关键词（kw），例如 frieren、mavuika，或者作品名里的一段英文。' };
  const count = parseCount(input.count, cfg.maxCount);
  if (count === null) return { error: '条数（count）要是 1-' + MAX_COUNT + ' 之间的整数。' };
  const page = parsePage(input.page);
  if (page === null) return { error: '页码（page）要是 0 或正整数（0 是第一页，每页 50 条）。' };
  let service = '';
  if (input.service !== undefined && input.service !== null && String(input.service).trim() !== '') {
    service = normalizeService(input.service);
    if (!service) return { error: 'service 只认站点名（小写英文，例如 patreon / fanbox / discord），收到的是：' + String(input.service) };
  }

  const url = cfg.baseUrl + '/api/v1/posts?q=' + encodeURIComponent(keyword) + '&o=' + page * PAGE_SIZE;
  let raw;
  try {
    raw = await httpJson(url, deadline, { timeoutMs: 12000 });
  } catch (error) {
    return { error: describe(error, '搜索') };
  }
  if (!Array.isArray(raw)) return { error: '搜索接口返回的不是数组 —— 站点可能改版了，这个插件得跟着更新。' };
  if (!raw.length) {
    return { error: '没搜到「' + keyword + '」的作品' + (page > 0 ? '（第 ' + page + ' 页）' : '') + '。换关键词试试（英文名、罗马音命中率最高），或者回第 0 页看看。' };
  }

  const items = raw
    .filter((x) => x && x.id)
    .map((x) => ({
      postId: String(x.id),
      uid: String(x.user === undefined || x.user === null ? '' : x.user),
      service: String(x.service || ''),
      title: String(x.title || '').trim(),
      published: String(x.published || ''),
      raw: x
    }));
  const pool = service ? items.filter((item) => item.service === service) : items;
  if (!pool.length) {
    const seenServices = [...new Set(items.map((item) => item.service))].join(' / ');
    return { error: '这一页没有 ' + service + ' 的作品（本页出现过的站点：' + seenServices + '）。去掉 service 再搜一次试试。' };
  }

  // 排序：有可用图片的（原图或缩略图都算）保持站点相关度顺序，压缩包与什么都没有的排后面。
  // 2.0.1 之前把 preview_only 一律压到最后 —— 那时它们确实只有死链；现在有 thumbnailUrl 可用，
  // 再压就变成"一半目录永远看不见"，反而丢了用户要的图。
  const rankOf = (item) => {
    const link = attachmentUrlOf(item.raw, cfg.fileBaseUrl, cfg.withImage);
    const thumb = cfg.withImage === false ? null : thumbnailUrlOf(item.raw);
    if (link && attachmentKindOf(link) === 'image') return 0;
    if (thumb) return 0;
    if (link) return 1;
    return 2;
  };
  const picked = [...pool].sort((a, b) => rankOf(a) - rankOf(b)).slice(0, count);

  let lookups = 0;
  for (const item of picked) {
    if (!item.uid || !item.service) { item.author = item.uid ? '作者#' + item.uid : ''; continue; }
    const cached = nameCache.get(item.service + ':' + item.uid);
    if (cached) { item.author = cached; continue; }
    if (lookups >= MAX_PROFILE_LOOKUPS || remaining(deadline) < 3000) { item.author = '作者#' + item.uid; continue; }
    lookups += 1;
    item.author = (await authorNameOf(item.service, item.uid, deadline)) || '作者#' + item.uid;
  }

  const results = picked.map((item) => buildResult(item, cfg));
  const plan = sendPlan(cfg, context, input);
  const summary = await deliverImages(results, { plan, cfg, deadline });

  const note = [
    '第 ' + page + ' 页取回 ' + items.length + ' 条，' + (service ? '按 ' + service + ' 本地过滤后 ' : '') + '给了 ' + results.length + ' 条。',
    service ? '接口本身不按站过滤（service 参数被服务端忽略），这里是拿到结果后在本地筛的。' : '',
    lookups ? '作者名查了 ' + lookups + ' 次作者资料（同一作者只查一次）。' : '',
    imageNoteOf(results, cfg.withImage),
    sendNoteOf(summary, cfg)
  ].filter(Boolean).join(' ');

  return {
    keyword,
    service: service || null,
    page,
    count: results.length,
    results,
    sent: summary.sent,
    sendError: summary.error,
    forwardCount: summary.forwards,
    sendMode: cfg.sendMode,
    note,
    advise: SEARCH_ADVISE
  };
}

const CREATOR_ADVISE = '作者维度：updated 为 true 时按这个说法回复：<作者> 有新的作品：《<作品名>》 链接：<pageUrl>。'
  + 'baseline 为 true 说明这是第一次记录，直接给最新几条并告诉用户「已建立基线，之后再问只会告诉你新的」。'
  + 'updated 为 false 就说没有新作品，并提一下 lastChecked 这个时间。'
  + '如果返回的是 candidates（没有 results），把候选列给用户让他挑，不要自己选一个往下走。'
  + SEND_ADVISE + FORWARD_ADVISE + NO_FAKE_TAGS + LINK_HINT;

const CREATORS_UNAVAILABLE = '当前部署拿不到全量作者表（插件进程无外网，或设置里关了 allowSelfFetch），'
  + '请改用作者页链接（https://pawchive.pw/<站点>/user/<作者号>）或 service + id；有链接时其余功能完全不受影响。';

async function creator(args, context) {
  const cfg = config(settings);
  const deadline = Date.now() + toolBudget('creator', cfg.budgetMs);
  const input = emptyInput(args);

  const count = parseCount(input.count, cfg.maxCount);
  if (count === null) return { error: '条数（count）要是 1-' + MAX_COUNT + ' 之间的整数。' };
  const checkUpdate = input.checkUpdate === true;

  let target = null;
  const urlText = String(input.url === undefined || input.url === null ? '' : input.url).trim();
  if (urlText) {
    target = parsePostUrl(urlText) || parseUserUrl(urlText);
    if (!target) return { error: '这个链接里认不出作者：' + urlText + '。要的是 https://pawchive.pw/<站点>/user/<作者号> 这种形式（作品页链接也行）。' };
  } else {
    let service = '';
    if (input.service !== undefined && input.service !== null && String(input.service).trim() !== '') {
      service = normalizeService(input.service);
      if (!service) return { error: 'service 只认站点名（小写英文，例如 patreon / fanbox / discord），收到的是：' + String(input.service) };
    }
    const id = String(input.id === undefined || input.id === null ? '' : input.id).trim();
    if (service && id) {
      if (!/^[0-9]+$/.test(id)) return { error: '作者号（id）要是一串数字，收到的是：' + id };
      target = { service, uid: id };
    } else if (service || id) {
      return { error: '要给齐 service 和 id（例如 service=patreon、id=3180459），只给一个没法查。' };
    }
  }

  let candidates = null;
  if (!target) {
    const name = String(input.name === undefined || input.name === null ? '' : input.name).trim();
    if (!name) return { error: '要给作者名（name）、作者页或作品页链接（url），或者 service + id。' };
    let list;
    try {
      list = await loadCreators(deadline);
    } catch (error) {
      // 双通道的降级点：作者表只能自己 fetch，拿不到就明确告诉用户换条路 —— 其余功能不受影响
      return { error: CREATORS_UNAVAILABLE, detail: String(error && error.message || error) };
    }
    const hits = pickCreatorCandidates(list, name, 2);
    if (!hits.length) {
      return { error: '作者表里没有名字含「' + name + '」的作者（全表 ' + list.length + ' 条）。名字是大小写不敏感的子串匹配，试试少打几个字，或者直接给作者页链接。' };
    }
    if (hits.length > 1) {
      return {
        candidates: hits.map((c) => ({
          name: c.name,
          service: c.service,
          id: c.id,
          favorited: c.favorited,
          url: userPageUrlOf({ service: c.service, id: c.id }, cfg.baseUrl)
        })),
        note: '名字「' + name + '」命中了 ' + hits.length + ' 个作者（按收藏数从高到低），没有替你猜。让用户挑一个，或者把上面的 url 再传回来。',
        advise: CREATOR_ADVISE
      };
    }
    target = { service: hits[0].service, uid: hits[0].id };
    candidates = hits;
  }

  const service = target.service;
  const uid = String(target.uid);
  let works;
  try {
    works = await httpJson(cfg.baseUrl + '/api/v1/' + service + '/user/' + uid + '?o=0', deadline, { timeoutMs: 12000 });
  } catch (error) {
    if (error && error.code === 'E_TRUNCATED') {
      // 高产作者的一页能到 700KB（实测 97517362：707,095 字符），而站点忽略所有翻页/限量参数，
      // 宿主单次响应又卡在 512KB —— 这条路上只能如实说清楚，别让用户以为是站点挂了。
      return {
        error: '这个作者的作品列表超过单次响应上限（512KB），站点又不支持缩小页长，暂时取不到。'
          + '改用作品名搜索（search），或者用作者页链接换个更靠前的页码场景；其他功能不受影响。'
      };
    }
    return { error: describe(error, '取作者作品列表') };
  }
  if (!Array.isArray(works)) return { error: '作者作品接口返回的不是数组 —— 站点可能改版了。' };
  if (!works.length) return { error: '作者 ' + service + '/' + uid + ' 名下没有作品（可能还没被索引，或者作者号不对）。' };

  const items = works
    .filter((x) => x && x.id)
    .map((x) => ({
      postId: String(x.id),
      uid: String(x.user === undefined || x.user === null ? uid : x.user),
      service: String(x.service || service),
      title: String(x.title || '').trim(),
      published: String(x.published || ''),
      raw: x
    }));
  const authorName = (candidates && candidates[0] && candidates[0].name)
    || (await authorNameOf(service, uid, deadline))
    || '作者#' + uid;

  const payload = {
    creator: { service, id: uid, name: authorName, url: userPageUrlOf({ service, id: uid }, cfg.baseUrl) },
    checkUpdate
  };

  const plan = sendPlan(cfg, context, input);

  if (!checkUpdate) {
    const results = items.slice(0, count).map((item) => ({ ...buildResult(item, cfg), author: authorName }));
    const summary = await deliverImages(results, { plan, cfg, deadline });
    return {
      ...payload,
      count: results.length,
      results,
      sent: summary.sent,
      sendError: summary.error,
      forwardCount: summary.forwards,
      sendMode: cfg.sendMode,
      note: '作者 ' + authorName + ' 最新的 ' + results.length + ' 条（这一页共取回 ' + items.length + ' 条）。'
        + imageNoteOf(results, cfg.withImage) + ' ' + sendNoteOf(summary, cfg),
      advise: CREATOR_ADVISE
    };
  }

  // checkUpdate：状态按 service:id 记在 cap.storage 的 creators 里
  const stored = await storageGet(CREATORS_STATE_KEY);
  const state = stored && typeof stored === 'object' ? { ...stored } : {};
  const key = service + ':' + uid;
  const prev = state[key] && typeof state[key] === 'object' ? state[key] : null;
  const outcome = nextCreatorState(prev, items, authorName, new Date().toISOString());
  state[key] = outcome.record;
  const saved = await storageSet(CREATORS_STATE_KEY, pruneCreatorState(state, CREATORS_STATE_CAP));
  const stateNote = saved ? '' : '（状态没能写进 storage，下次问还会当成第一次查。）';

  if (outcome.baseline) {
    const results = items.slice(0, count).map((item) => ({ ...buildResult(item, cfg), author: authorName }));
    const summary = await deliverImages(results, { plan, cfg, deadline });
    return {
      ...payload,
      baseline: true,
      updated: false,
      count: results.length,
      results,
      sent: summary.sent,
      sendError: summary.error,
      forwardCount: summary.forwards,
      sendMode: cfg.sendMode,
      note: '第一次记录这个作者，已建立基线（最新作品 ' + outcome.record.postId + '，发布 ' + outcome.record.published + '）。'
        + '之后再问，只会告诉你比它更新的作品。' + stateNote + ' ' + imageNoteOf(results, cfg.withImage) + ' ' + sendNoteOf(summary, cfg),
      advise: CREATOR_ADVISE
    };
  }

  if (!outcome.updated) {
    return {
      ...payload,
      baseline: false,
      updated: false,
      lastChecked: prev && prev.checkedAt ? String(prev.checkedAt) : null,
      count: 0,
      results: [],
      sent: 0,
      sendError: '',
      forwardCount: 0,
      sendMode: cfg.sendMode,
      note: '没有新作品：最新一条还是 ' + outcome.record.postId + '（' + outcome.record.published + '），和上次记录的一致。'
        + '上次检查：' + (prev && prev.checkedAt || '未知') + '。' + stateNote,
      advise: CREATOR_ADVISE
    };
  }

  const newer = outcome.newer.slice(0, 20).map((item) => ({ ...buildResult(item, cfg), author: authorName }));
  const summary = await deliverImages(newer, { plan, cfg, deadline });
  return {
    ...payload,
    baseline: false,
    updated: true,
    lastChecked: prev && prev.checkedAt ? String(prev.checkedAt) : null,
    count: newer.length,
    results: newer,
    sent: summary.sent,
    sendError: summary.error,
    forwardCount: summary.forwards,
    sendMode: cfg.sendMode,
    note: '有 ' + outcome.newer.length + ' 条新作品（' + (prev && prev.published || '?') + ' 之后发布的）'
      + (outcome.newer.length > 20 ? '，只列前 20 条' : '') + '。' + stateNote + ' '
      + imageNoteOf(newer, cfg.withImage) + ' ' + sendNoteOf(summary, cfg),
    advise: CREATOR_ADVISE
  };
}

const RANDOM_ADVISE = '按这个说法回复：随机链接：<pageUrl>，作者：<作者>，名字：《<作品名>》，tags：……（tags 有才写，没有就把那一段整个省掉）。'
  + SEND_ADVISE + FORWARD_ADVISE + NO_FAKE_TAGS + LINK_HINT;

async function random(args, context) {
  const cfg = config(settings);
  const deadline = Date.now() + toolBudget('random', cfg.budgetMs);
  const input = emptyInput(args);

  let wantService = '';
  if (input.service !== undefined && input.service !== null && String(input.service).trim() !== '') {
    wantService = normalizeService(input.service);
    if (!wantService) return { error: 'service 只认站点名（小写英文，例如 patreon / fanbox / discord），收到的是：' + String(input.service) };
  }

  let lastService = '';
  for (let attempt = 0; attempt < 3; attempt += 1) {
    if (remaining(deadline) < 6000) return { error: '时间预算不够了（随机要跳转 + 查详情 + 可能发图）。过一会儿再试，或者把 budgetMs 调大。' };

    // GET 会跟随 302；回执没有最终 URL，所以从落地页 HTML 的 canonical / og:url 里认作品
    let html;
    try {
      html = await httpText(cfg.baseUrl + '/posts/random', deadline, { timeoutMs: 9000 });
    } catch (error) {
      return { error: describe(error, '取随机作品') };
    }
    const triple = parseCanonicalPostUrl(html);
    if (!triple) {
      return {
        error: '随机跳转的落地页里没找到作品地址（canonical / og:url 都没有）—— 站点可能改版了，或者这次被跳到了非作品页。',
        detail: String(html || '').slice(0, 200)
      };
    }
    lastService = triple.service;
    if (wantService && triple.service !== wantService) continue;

    let detail;
    try {
      detail = await httpJson(cfg.baseUrl + '/api/v1/' + triple.service + '/user/' + triple.uid + '/post/' + triple.pid, deadline, { timeoutMs: 10000 });
    } catch (error) {
      return { error: describe(error, '取随机作品详情') };
    }
    if (!detail || typeof detail !== 'object') return { error: '随机作品详情接口返回的形状不对。' };

    const item = {
      postId: String(detail.id || triple.pid),
      uid: String(detail.user || triple.uid),
      service: String(detail.service || triple.service),
      title: String(detail.title || '').trim(),
      published: String(detail.published || ''),
      raw: detail
    };
    const name = (await authorNameOf(item.service, item.uid, deadline)) || ('作者#' + item.uid);
    const result = { ...buildResult(item, cfg), author: name };
    result.tags = parseTags(detail.tags);

    const summary = await deliverImages([result], { plan: sendPlan(cfg, context, input), cfg, deadline });
    return {
      count: 1,
      results: [result],
      sent: summary.sent,
      sendError: summary.error,
      forwardCount: summary.forwards,
      sendMode: cfg.sendMode,
      note: '随机来源：' + cfg.baseUrl + '/posts/random（落地页 ' + pageUrlOf(triple, cfg.baseUrl) + '）。'
        + (result.tags.length ? '' : '这篇没有标签（详情接口的 tags 约四成是 null），所以不给 tags。')
        + (result.previewOnly ? ' 这篇是 preview_only：直链主机上实测 404，所以没有 attachmentUrl。' : '')
        + ' ' + sendNoteOf(summary, cfg),
      advise: RANDOM_ADVISE
    };
  }

  return { error: '随机了 3 次都没随到 ' + wantService + ' 的作品（随到的是 ' + lastService + '）。去掉 service 再来一次。' };
}

const TOOLS = { search, creator, random };

// ── probe（控制台「检测」按钮，v2.1）──────────────────────────────────────

async function probeStatus() {
  const cfg = config(settings);
  const deadline = Date.now() + 6000;
  const base = { base: cfg.baseUrl, reachable: false, creatorsCached: Array.isArray(creatorsCache.list), selfFetch: cfg.allowSelfFetch };
  try {
    const raw = await httpJson(cfg.baseUrl + '/api/v1/posts?q=test&o=0', deadline, { timeoutMs: 6000, retries: 0 });
    const reachable = Array.isArray(raw);
    return {
      ok: reachable,
      ...base,
      reachable,
      note: reachable ? '接口可达（返回 ' + raw.length + ' 条）' : '接口返回的不是数组，站点可能改版了'
    };
  } catch (error) {
    return { ok: false, ...base, note: describe(error, '检测') };
  }
}

// ── 协议 ─────────────────────────────────────────────────────────────────

function handleLine(line) {
  let message = null;
  try { message = JSON.parse(line); } catch { message = null; }
  if (!message || typeof message !== 'object') return;

  if (message.method === 'init') {
    const params = message.params && typeof message.params === 'object' ? message.params : {};
    settings = params.settings && typeof params.settings === 'object' ? params.settings : {};
    creatorsCache = { at: 0, list: null };
    nameCache.clear();
    write({ id: message.id, result: { ok: true } });
    return;
  }
  if (message.method === 'callTool') {
    const name = message.params && message.params.name;
    const fn = TOOLS[name];
    if (!fn) {
      write({ id: message.id, error: { code: 'E_NO_TOOL', message: '没有这个工具：' + String(name) } });
      return;
    }
    const args = message.params && message.params.args;
    const context = message.params && message.params.context && typeof message.params.context === 'object' ? message.params.context : {};
    Promise.resolve()
      .then(() => fn(args, context))
      .then((result) => write({ id: message.id, result }))
      .catch((error) => write({ id: message.id, error: { code: error && error.code || 'E_TOOL', message: String(error && error.message || error) } }));
    return;
  }
  if (message.method === 'probe') {
    Promise.resolve()
      .then(() => probeStatus())
      .then((result) => write({ id: message.id, result }))
      .catch((error) => write({ id: message.id, error: { code: 'E_PROBE', message: String(error && error.message || error) } }));
    return;
  }
  if (message.method === 'ping' || message.method === 'schedule') {
    write({ id: message.id, result: {} });
    return;
  }
  if (message.method === 'shutdown') {
    // 宿主退出时发的 shutdown **不带 id**：无条件回执会序列化成 {"result":{}}，宿主记一条 protocolErrors。
    if (message.id !== undefined && message.id !== null) write({ id: message.id, result: { ok: true } });
    setTimeout(() => process.exit(0), 10);
    return;
  }
  // 剩下的都是能力调用（cap.*）的回执
  if (message.id !== undefined) {
    const entry = pending.get(message.id);
    if (!entry) return;
    pending.delete(message.id);
    if (message.error) entry.reject(Object.assign(new Error(message.error.message || '能力调用失败'), { code: message.error.code }));
    else entry.resolve(message.result === undefined ? null : message.result);
  }
}

function startServer() {
  let buffer = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (chunk) => {
    buffer += chunk;
    let index = buffer.indexOf('\n');
    while (index !== -1) {
      const line = buffer.slice(0, index).trim();
      buffer = buffer.slice(index + 1);
      if (line) handleLine(line);
      index = buffer.indexOf('\n');
    }
  });
  process.stdin.on('end', () => process.exit(0));
}

const entryScript = process.argv[1] ? pathToFileURL(process.argv[1]).href : '';
if (entryScript && import.meta.url === entryScript) startServer();

export { TOOLS, DEFAULTS, MAX_COUNT, PAGE_SIZE, MAX_TAGS, CREATORS_STATE_CAP, TOOL_TIMEOUT_MS, HTTP_MAX_CHARS, CREATORS_UNAVAILABLE };
