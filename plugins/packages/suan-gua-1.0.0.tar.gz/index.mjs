// 算卦（suan-gua）——「起一卦」的娱乐插件：六十四卦、摇卦、动爻变卦与两档语气素材全部内置，
// 文案交给模型转述。零依赖、单文件 ESM、不联网、不写文件；唯一的持久化走宿主的 cap.storage
// （单键读-改-写：一次工具调用最多读一次、写一次）。
//
// ── 为什么卦只能在这里掷 ────────────────────────────────────────────
// 让模型自己「起一卦」会把 1/8 的老阴说成 1/2，也会把「天地否」说成「地天否」。所以铜钱只有一处
// 来源（tossLines：三枚铜钱，字=3 背=2），模型拿到的是既成事实，只能转述。rng 可注入是为了单测。
//
// ── 为什么 who 必须由模型传 ─────────────────────────────────────────
// 宿主的 callTool 只发 {name, args}，不带 chatKey / uid（已核实）。插件根本不知道是谁在问卦，
// 所以「谁的卦史」只能由模型从对话里取出来当参数传；缺省时不报错、照样起卦，但 record.recorded=false，
// 免得模型谎称「已经给你记上了」。
//
// ── 为什么不宜/三道符是「候选」而不是定稿 ────────────────────────────
// 同一卦对「明天要不要签合同」和「要不要分手」说的是两件事。插件给的是骨架（taboos 的 text+why、
// remedies 的 hint+material、supplement 的话术素材），具体那一句由模型按对方的事重写。
import path from 'node:path';
import { pathToFileURL } from 'node:url';

// ───────────────────────── 配置默认值 ─────────────────────────

export const PLUGIN_ID = 'suan-gua';

export const DEFAULTS = Object.freeze({
  enabled: true,
  tone: 'daozhang',
  recordHistory: true,
  historyPerUser: 10
});

/** 语气档：daozhang 道长（贫道/符/玉简/拂尘）/ straight 正经话术（同样四段）。 */
export const TONES = Object.freeze(['daozhang', 'straight']);
/** 评级五档，从最好到最坏。 */
export const RATINGS = Object.freeze(['大吉', '吉', '平', '凶', '大凶']);
const RATING_RANK = Object.freeze({ '大吉': 4, '吉': 3, '平': 2, '凶': 1, '大凶': 0 });

/** who 的长度上限：它同时是 storage 里的对象键，太长会撑爆存档。 */
export const MAX_WHO = 40;
/** question 的长度上限（一句摘要，不是整段转述）。 */
export const MAX_QUESTION = 60;
/** 存档里只留问题摘要的前 40 字（卦辞才是主体，问题只是索引）。 */
export const MAX_QUESTION_STORED = 40;
export const MAX_HISTORY_LIMIT = 10;
export const DEFAULT_HISTORY_LIMIT = 5;
export const MAX_HISTORY_PER_USER = 20;

export const STORAGE_KEY = 'suan-gua.v1';
/** 宿主的硬上限是单值 32KB；这里按 28KB 预算，超了按「最久没算卦」淘汰用户。 */
const MAX_STATE_BYTES = 28 * 1024;

// ───────────────────────── 小工具 ─────────────────────────

const isPlainObject = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v);

/** 去掉孤立代理项（半个 emoji）—— 它会让整个模型请求 400。 */
function stripLoneSurrogates(value) {
  const s = String(value ?? '');
  let out = '';
  for (let i = 0; i < s.length; i++) {
    const code = s.charCodeAt(i);
    if (code >= 0xd800 && code <= 0xdbff) {
      const next = s.charCodeAt(i + 1);
      if (next >= 0xdc00 && next <= 0xdfff) { out += s[i] + s[i + 1]; i += 1; }
      continue;
    }
    if (code >= 0xdc00 && code <= 0xdfff) continue;
    out += s[i];
  }
  return out;
}

/** 按**码位**截断（emoji 不会被切成半个），并剥掉孤立代理项。 */
function safeSlice(value, max) {
  const s = String(value ?? '');
  const limit = Math.max(0, Math.floor(Number(max)) || 0);
  if (limit <= 0) return '';
  const chars = [...s];
  return stripLoneSurrogates(chars.length <= limit ? s : chars.slice(0, limit).join(''));
}

/** 按码位数长度（与工具 schema 的 maxLength 口径一致）。 */
function charLength(value) {
  return [...String(value ?? '')].length;
}

function safeInt(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.trunc(n)) : fallback;
}

function clampInt(value, fallback, lo, hi) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(hi, Math.max(lo, Math.trunc(n)));
}

/** 布尔读取：配置里 "false" 不能被当成 true。 */
function toBool(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'boolean') return value;
  const s = String(value).trim().toLowerCase();
  if (['true', '1', 'yes', 'on', '是', '开'].includes(s)) return true;
  if (['false', '0', 'no', 'off', '否', '关'].includes(s)) return false;
  return fallback;
}

/** rng 归一化到 [0,1)：坏 rng（NaN / 1 / 负数）不能把摇卦卡死或抛异常。 */
function unit(rng) {
  let r;
  try { r = Number(rng()); } catch { r = 0; }
  if (!Number.isFinite(r) || r < 0) return 0;
  if (r >= 1) return 0.9999999999999;
  return r;
}

export function normalizeTone(raw) {
  const text = String(raw ?? '').trim().toLowerCase();
  return TONES.includes(text) ? text : DEFAULTS.tone;
}

// ───────────────────────── 八卦与六十四卦 ─────────────────────────
// bits 一律按「自下而上」写：第 1 位是初爻。乾=111（三阳）、坤=000（三阴）、坎=010（阴阳阴）……
// 上下卦各三爻拼起来就是六爻：下卦=初二三，上卦=四五六。这也是摇出六爻后反查卦序的唯一依据。

export const TRIGRAMS = Object.freeze([
  Object.freeze({ name: '乾', image: '天', bits: '111' }),
  Object.freeze({ name: '兑', image: '泽', bits: '110' }),
  Object.freeze({ name: '离', image: '火', bits: '101' }),
  Object.freeze({ name: '震', image: '雷', bits: '100' }),
  Object.freeze({ name: '巽', image: '风', bits: '011' }),
  Object.freeze({ name: '坎', image: '水', bits: '010' }),
  Object.freeze({ name: '艮', image: '山', bits: '001' }),
  Object.freeze({ name: '坤', image: '地', bits: '000' })
]);

const TRIGRAM_NAME_OF_BITS = new Map(TRIGRAMS.map((t) => [t.bits, t.name]));
const TRIGRAM_IMAGE = new Map(TRIGRAMS.map((t) => [t.name, t.image]));

function trigramBits(name) {
  for (const t of TRIGRAMS) if (t.name === String(name)) return t.bits;
  return '';
}

/**
 * 通行本六十四卦：[卦序, 卦名, 上卦, 下卦, 评级, 卦辞原文]。
 * 上卦×下卦 8×8 恰好一一对应（自测脚本会断言：64 条、无重复、无缺失）。
 * fullName 由「上卦象 + 下卦象 + 卦名」拼出，八纯卦按传统写成「乾为天」这种。
 */
const HEX_RAW = [
  [1, '乾', '乾', '乾', '大吉', '元亨利贞。'],
  [2, '坤', '坤', '坤', '大吉', '元亨，利牝马之贞。君子有攸往，先迷后得主，利。西南得朋，东北丧朋。安贞吉。'],
  [3, '屯', '坎', '震', '平', '元亨，利贞。勿用有攸往，利建侯。'],
  [4, '蒙', '艮', '坎', '平', '亨。匪我求童蒙，童蒙求我。初筮告，再三渎，渎则不告。利贞。'],
  [5, '需', '坎', '乾', '吉', '有孚，光亨，贞吉。利涉大川。'],
  [6, '讼', '乾', '坎', '凶', '有孚窒，惕，中吉，终凶。利见大人，不利涉大川。'],
  [7, '师', '坤', '坎', '平', '贞，丈人吉，无咎。'],
  [8, '比', '坎', '坤', '吉', '吉。原筮元永贞，无咎。不宁方来，后夫凶。'],
  [9, '小畜', '巽', '乾', '平', '亨。密云不雨，自我西郊。'],
  [10, '履', '乾', '兑', '平', '履虎尾，不咥人，亨。'],
  [11, '泰', '坤', '乾', '大吉', '小往大来，吉亨。'],
  [12, '否', '乾', '坤', '凶', '否之匪人，不利君子贞，大往小来。'],
  [13, '同人', '乾', '离', '吉', '同人于野，亨。利涉大川，利君子贞。'],
  [14, '大有', '离', '乾', '大吉', '元亨。'],
  [15, '谦', '坤', '艮', '大吉', '亨，君子有终。'],
  [16, '豫', '震', '坤', '吉', '利建侯行师。'],
  [17, '随', '兑', '震', '吉', '元亨利贞，无咎。'],
  [18, '蛊', '艮', '巽', '平', '元亨，利涉大川。先甲三日，后甲三日。'],
  [19, '临', '坤', '兑', '吉', '元亨利贞。至于八月有凶。'],
  [20, '观', '巽', '坤', '平', '盥而不荐，有孚颙若。'],
  [21, '噬嗑', '离', '震', '平', '亨。利用狱。'],
  [22, '贲', '艮', '离', '平', '亨。小利有攸往。'],
  [23, '剥', '艮', '坤', '大凶', '不利有攸往。'],
  [24, '复', '坤', '震', '大吉', '亨。出入无疾，朋来无咎。反复其道，七日来复。利有攸往。'],
  [25, '无妄', '乾', '震', '平', '元亨利贞。其匪正有眚，不利有攸往。'],
  [26, '大畜', '艮', '乾', '吉', '利贞。不家食吉，利涉大川。'],
  [27, '颐', '艮', '震', '平', '贞吉。观颐，自求口实。'],
  [28, '大过', '兑', '巽', '凶', '栋桡，利有攸往，亨。'],
  [29, '坎', '坎', '坎', '大凶', '习坎，有孚，维心亨，行有尚。'],
  [30, '离', '离', '离', '平', '利贞，亨。畜牝牛吉。'],
  [31, '咸', '兑', '艮', '吉', '亨，利贞。取女吉。'],
  [32, '恒', '震', '巽', '吉', '亨，无咎，利贞，利有攸往。'],
  [33, '遁', '乾', '艮', '平', '亨，小利贞。'],
  [34, '大壮', '震', '乾', '吉', '利贞。'],
  [35, '晋', '离', '坤', '大吉', '康侯用锡马蕃庶，昼日三接。'],
  [36, '明夷', '坤', '离', '凶', '利艰贞。'],
  [37, '家人', '巽', '离', '吉', '利女贞。'],
  [38, '睽', '离', '兑', '凶', '小事吉。'],
  [39, '蹇', '坎', '艮', '凶', '利西南，不利东北。利见大人，贞吉。'],
  [40, '解', '震', '坎', '吉', '利西南。无所往，其来复吉。有攸往，夙吉。'],
  [41, '损', '艮', '兑', '平', '有孚，元吉，无咎，可贞。利有攸往。曷之用，二簋可用享。'],
  [42, '益', '巽', '震', '大吉', '利有攸往，利涉大川。'],
  [43, '夬', '兑', '乾', '平', '扬于王庭，孚号，有厉。告自邑，不利即戎，利有攸往。'],
  [44, '姤', '乾', '巽', '凶', '女壮，勿用取女。'],
  [45, '萃', '兑', '坤', '吉', '亨。王假有庙，利见大人，亨，利贞。用大牲吉。利有攸往。'],
  [46, '升', '坤', '巽', '大吉', '元亨，用见大人，勿恤，南征吉。'],
  [47, '困', '兑', '坎', '大凶', '亨，贞，大人吉，无咎。有言不信。'],
  [48, '井', '坎', '巽', '平', '改邑不改井，无丧无得，往来井井。汔至，亦未繘井，羸其瓶，凶。'],
  [49, '革', '兑', '离', '平', '己日乃孚，元亨利贞，悔亡。'],
  [50, '鼎', '离', '巽', '大吉', '元吉，亨。'],
  [51, '震', '震', '震', '平', '亨。震来虩虩，笑言哑哑，震惊百里，不丧匕鬯。'],
  [52, '艮', '艮', '艮', '平', '艮其背，不获其身，行其庭，不见其人，无咎。'],
  [53, '渐', '巽', '艮', '吉', '女归吉，利贞。'],
  [54, '归妹', '震', '兑', '凶', '征凶，无攸利。'],
  [55, '丰', '震', '离', '吉', '亨，王假之，勿忧，宜日中。'],
  [56, '旅', '离', '艮', '平', '小亨，旅贞吉。'],
  [57, '巽', '巽', '巽', '吉', '小亨，利有攸往，利见大人。'],
  [58, '兑', '兑', '兑', '吉', '亨，利贞。'],
  [59, '涣', '巽', '坎', '吉', '亨。王假有庙，利涉大川，利贞。'],
  [60, '节', '坎', '兑', '平', '亨。苦节不可贞。'],
  [61, '中孚', '巽', '兑', '吉', '豚鱼吉，利涉大川，利贞。'],
  [62, '小过', '震', '艮', '凶', '亨，利贞。可小事，不可大事。飞鸟遗之音，不宜上，宜下。大吉。'],
  [63, '既济', '坎', '离', '平', '亨小，利贞。初吉终乱。'],
  [64, '未济', '离', '坎', '凶', '亨。小狐汔济，濡其尾，无攸利。']
];

export const HEXAGRAMS = Object.freeze(HEX_RAW.map(([number, name, upper, lower, rating, judgment]) => Object.freeze({
  number,
  name,
  upper,
  lower,
  rating,
  judgment,
  fullName: upper === lower
    ? upper + '为' + TRIGRAM_IMAGE.get(upper)
    : String(TRIGRAM_IMAGE.get(upper)) + String(TRIGRAM_IMAGE.get(lower)) + name
})));

export const HEX_BY_NUMBER = new Map(HEXAGRAMS.map((h) => [h.number, h]));
const HEX_BY_PAIR = new Map(HEXAGRAMS.map((h) => [h.upper + '/' + h.lower, h]));

/** 上下卦反查卦。拼错的组合返回 null（调用方自己兜底），不猜。 */
export function hexagramOf(upper, lower) {
  return HEX_BY_PAIR.get(String(upper) + '/' + String(lower)) || null;
}

/** 六爻的阴阳取值（7 少阳 / 8 少阴），自下而上。卦史里只存卦序，回放爻名靠它。 */
export function linesOf(hexagram) {
  const hex = hexagram && typeof hexagram === 'object' ? hexagram : {};
  const bits = (trigramBits(hex.lower) + trigramBits(hex.upper)).split('').map((bit) => (bit === '1' ? 7 : 8));
  return bits.length === 6 ? bits : [7, 7, 7, 7, 7, 7];
}

/** 评级谁更凶（本卦与变卦比，取更凶的那一个定不宜的方向）。 */
export function worseRating(a, b) {
  const left = RATING_RANK[String(a)] ?? 2;
  const right = RATING_RANK[String(b)] ?? 2;
  return left <= right ? String(a) : String(b);
}

// ───────────────────────── 摇卦 ─────────────────────────
// 三枚铜钱，一枚正面（字）=3、反面（背）=2，三枚之和即该爻：
// 6 老阴 1/8、7 少阳 3/8、8 少阴 3/8、9 老阳 1/8。先掷初爻，依次到上爻。

const COIN_HEAD = 3;
const COIN_TAIL = 2;

/** 掷一次（三枚）。返回 6/7/8/9。 */
export function tossValue(rng = Math.random) {
  let sum = 0;
  for (let i = 0; i < 3; i++) sum += unit(rng) < 0.5 ? COIN_HEAD : COIN_TAIL;
  return sum;
}

/** 掷六爻：index 1..6 自下而上（初爻→上爻）。 */
export function tossLines(rng = Math.random) {
  const lines = [];
  for (let index = 1; index <= 6; index++) {
    const value = tossValue(rng);
    lines.push({ index, value, moving: value === 6 || value === 9 });
  }
  return lines;
}

const CN_POSITION = Object.freeze(['', '初', '二', '三', '四', '五', '上']);

/**
 * 爻名：阳爻称九、阴爻称六；初爻在前（初九/初六），上爻在前（上九/上六），
 * 二至五爻把数字放后面（九二/六二 … 九五/六五）。
 */
export function lineName(index, value) {
  const position = clampInt(index, 1, 1, 6);
  const yang = Number(value) === 7 || Number(value) === 9;
  const bit = yang ? '九' : '六';
  if (position === 1) return '初' + bit;
  if (position === 6) return '上' + bit;
  return bit + CN_POSITION[position];
}

/** 六爻位通用判词（初/二/三/四/五/上）：位置义只有这六条，不写成 64×6 的表。 */
export const POSITION_HINTS = Object.freeze([
  '初爻主始：事在萌芽，根基未立，宜稳不宜躁',
  '二爻居内卦之中：得中而不过，守中可进',
  '三爻处内卦之极：进退两难之地，最忌躁动',
  '四爻初入外卦：贴近事之要冲，宜谨言慎行',
  '五爻居外卦之中：得中得尊，事之枢机在你手上',
  '上爻处卦之终：物极必反，过则生变'
]);

/** 按本卦评级给爻位判词做吉凶微调。 */
const RATING_TWEAKS = Object.freeze({
  '大吉': '本卦大吉，此爻可放手施为，别自己吓自己',
  '吉': '本卦为吉，此爻顺势可进，但别趁势加码',
  '平': '本卦平平，此爻按常理走，不必加戏',
  '凶': '本卦为凶，此爻宜收手，先守住已有的',
  '大凶': '本卦大凶，此爻切勿强求，退一步才是本事'
});

export function lineHint(index, value, rating) {
  const position = clampInt(index, 1, 1, 6);
  const tweak = RATING_TWEAKS[String(rating)] || RATING_TWEAKS['平'];
  const turn = Number(value) === 9 ? '（老阳转阴）' : '（老阴转阳）';
  return POSITION_HINTS[position - 1] + '；' + tweak + turn;
}

function bitsOfLines(lines) {
  return lines.map((line) => ((line.value === 7 || line.value === 9) ? '1' : '0'));
}

function sideOf(hexagram) {
  return {
    number: hexagram.number,
    name: hexagram.name,
    fullName: hexagram.fullName,
    upper: hexagram.upper,
    lower: hexagram.lower,
    rating: hexagram.rating
  };
}

function sideText(hexagram) {
  return hexagram.fullName + '（' + hexagram.upper + '上' + hexagram.lower + '下）· ' + hexagram.rating;
}

/**
 * 起一卦：摇六爻 → 拼上下卦 → 反查本卦 → 动爻 → 变卦。
 * rng 可注入，所以「分布」与「一致性」都能被单测钉住。
 */
export function castHexagram(rng = Math.random) {
  const raw = tossLines(rng);
  const bits = bitsOfLines(raw);
  const lower = TRIGRAM_NAME_OF_BITS.get(bits.slice(0, 3).join(''));
  const upper = TRIGRAM_NAME_OF_BITS.get(bits.slice(3, 6).join(''));
  const hexagram = hexagramOf(upper, lower);
  if (!hexagram) {
    // 8×8 表是满的，走到这里说明数据表坏了：如实报错，不编一个卦出来。
    throw new Error('六十四卦表里查不到「' + upper + '上' + lower + '下」这个组合');
  }

  const lines = raw.map((line) => ({
    index: line.index,
    name: lineName(line.index, line.value),
    value: line.value,
    moving: line.moving
  }));

  const moving = lines
    .filter((line) => line.moving)
    .map((line) => ({ index: line.index, name: line.name, hint: lineHint(line.index, line.value, hexagram.rating) }));

  let changed = null;
  if (moving.length) {
    const flipped = bits.map((bit, i) => (lines[i].moving ? (bit === '1' ? '0' : '1') : bit));
    const target = hexagramOf(TRIGRAM_NAME_OF_BITS.get(flipped.slice(3, 6).join('')), TRIGRAM_NAME_OF_BITS.get(flipped.slice(0, 3).join('')));
    if (target) changed = sideOf(target);
  }

  const movingNames = moving.map((line) => line.name).join('、');

  return {
    hexagram,
    lines,
    moving,
    changed,
    summary: '第' + hexagram.number + '卦 ' + sideText(hexagram),
    changeSummary: changed ? movingNames + '动 → 变卦：' + sideText(changed) : null
  };
}

// ───────────────────────── 语气素材池 ─────────────────────────
// 两档语气各自一套：不宜候选（severity 3 = 最重，按评级方向挑）+ 三道符骨架 + 补充话术。
// severity 只用于「按吉凶方向挑」，不参与任何概率。

const TABOOS = {
  daozhang: [
    { severity: 3, key: '签约', text: '不宜今天落笔签字、按手印、答应口头合同——那张纸先压在玉简下头过一夜。', why: '落笔就是定数，定数写死了，贫道这道符也翻不回来。' },
    { severity: 3, key: '求财', text: '不宜借钱出去，不宜碰高利，不宜承诺「下周就还」——今天贫道的钱袋子也是空的。', why: '凶位上的财是漏的，借出去的是钱，收回来的是账。' },
    { severity: 3, key: '主动出击', text: '不宜先开口：不宜主动挑事、不宜主动表白、不宜主动提离职。', why: '动爻在外卦，先出头的人先挨风。' },
    { severity: 3, key: '熬夜', text: '不宜通宵赶工、通宵开黑、通宵想一件想不明白的事。', why: '子时之后人的判断力要打折，账是第二天结的。' },
    { severity: 3, key: '开局', text: '不宜今天上新、开新坑、立新项目、搬新家——开工不如择日。', why: '卦在始位上偏着，头一锄挖歪，一垄都歪。' },
    { severity: 3, key: '询问', text: '不宜追着一个人问第三遍，也不宜拿一句话去问一个不想答的人。', why: '问急了人说假话，假话比不回更贵。' },
    { severity: 3, key: '远行', text: '不宜远行，不宜赶那一班红眼航班，不宜当天临时改行程。', why: '卦里的方向是逆的，越赶越堵。' },
    { severity: 3, key: '交易', text: '不宜先款后货，不宜把东西和钱在同一天换手。', why: '阴爻压在上头，对面还有话没说完。' },
    { severity: 3, key: '对线', text: '不宜在群里对线，不宜发那条已经改了三次的话——贫道替你把它塞回拂尘里。', why: '对线的输赢不上账，气上账。' },
    { severity: 3, key: '删库', text: '不宜删库，不宜在生产上敲 rm -rf，不宜嘴上一句「我先试试」。', why: '凶卦里的手最滑，删完才想起没备份。' },
    { severity: 2, key: '担保', text: '不宜替人担保，不宜在别人的欠条上添上自己的名字。', why: '担保这一笔记的不是善心，是别人的账。' },
    { severity: 2, key: '冲动消费', text: '不宜冲动下单，不宜清空购物车——先把玉简合上睡一觉。', why: '卦里的「想要」比「需要」大一圈，钱花了才看清。' },
    { severity: 2, key: '把话说满', text: '不宜把话说满，不宜立「这事包在我身上」的军令状。', why: '上爻居终，话说满了没有回头的位置。' },
    { severity: 2, key: '翻旧账', text: '不宜翻旧账，不宜把去年的截图再甩一遍。', why: '旧账翻出来的都是利息，本金早花完了。' },
    { severity: 2, key: '重蹈覆辙', text: '不宜在同一个坑里试第二次「这次不一样」。', why: '同一爻动两回，卦已经明说了。' },
    { severity: 2, key: '酒后发信', text: '不宜酒后发消息，不宜凌晨三点回那条朋友圈。', why: '子丑之交说的话，天亮都归你自己收拾。' },
    { severity: 2, key: '押注', text: '不宜押注，不宜梭哈，不宜把生活费挪去补仓。', why: '此卦财位虚，赢了是运气，输了是日子。' },
    { severity: 2, key: '硬扛病情', text: '不宜拿身体赌：报告没出来之前别当自己没事，该吃的药别停。', why: '贫道只推吉凶，不断生死——卦象再好也替不了医生签字。' },
    { severity: 2, key: '借钱', text: '不宜把生活费借给同事朋友，也不宜指望「这个月一定还」。', why: '借出去的是钱，收回来的是关系，两样总缺一样。' },
    { severity: 2, key: '玩游戏', text: '不宜为一场排位熬到三点，也不宜在游戏里氪金补心情。', why: '赢了不涨工资，输了掉段位还掉心情，账都算在你身上。' },
    { severity: 1, key: '趁吉加码', text: '不宜趁吉加码：顺的时候最容易一口气答应太多事。', why: '吉卦给的是势，不是额度。' },
    { severity: 1, key: '提前张扬', text: '不宜把计划说给太多人听——先做完一件再说。', why: '说出去的进度会被别人当成承诺。' },
    { severity: 1, key: '三心二意', text: '不宜一天里换三个主意。', why: '心思太散，符也画不圆。' },
    { severity: 1, key: '贪多', text: '不宜贪多：今天只挑一件最要紧的做。', why: '多线并进，等于一条都没走。' },
    { severity: 1, key: '凭感觉', text: '不宜靠「感觉对了」拍板，至少要有一张纸上的依据。', why: '感觉不落纸，事后没法对账。' },
    { severity: 1, key: '迷信卦象', text: '不宜把这一卦当成永久免死金牌。', why: '卦只管这一段，下一段还得再掷一次。' }
  ],
  straight: [
    { severity: 3, key: '签约', text: '今天不要签字、不要按手印、不要答应口头合同——那份文件先放一晚。', why: '签下去就定了，写死的条款之后很难改回来。' },
    { severity: 3, key: '求财', text: '不要借钱出去，不要碰高利息，不要承诺「下周就还」。', why: '这一段的财务判断偏松，借出去的是钱，收回来的是一笔账。' },
    { severity: 3, key: '主动出击', text: '不要先开口：不主动挑事、不主动表白、不主动提离职。', why: '这一段是慢的人占便宜，先出头的先承压。' },
    { severity: 3, key: '熬夜', text: '不要通宵赶工，不要通宵开黑，不要通宵想一件想不明白的事。', why: '深夜的判断力比白天低，代价第二天才付。' },
    { severity: 3, key: '开局', text: '不要在今天上新项目、开新坑、搬新家——开工往后挪两天。', why: '开局这一步偏了，后面整条线都要返工。' },
    { severity: 3, key: '询问', text: '不要追着一个人问第三遍，也不要拿一句话去问一个明显不想答的人。', why: '问急了对方会说假话，假话的成本比沉默高。' },
    { severity: 3, key: '远行', text: '不要远行，不要赶那班红眼航班，不要当天临时改行程。', why: '这里的方向是逆的，越赶越堵。' },
    { severity: 3, key: '交易', text: '不要先款后货，不要让东西和钱在同一天换手。', why: '对方还有没说清的部分。' },
    { severity: 3, key: '对线', text: '不要在群里对线，也不要发那条已经改了三遍的话——先删了。', why: '对线的输赢记不上，情绪的成本记在你身上。' },
    { severity: 3, key: '删库', text: '不要删库，不要在生产环境敲 rm -rf，不要说「我先试试」。', why: '这一段的容错很低，删完才想起没备份。' },
    { severity: 2, key: '担保', text: '不要替人担保，也不要在别人的欠条上添自己的名字。', why: '担保记下的不是善意，是别人的负债。' },
    { severity: 2, key: '冲动消费', text: '不要冲动下单，不要清空购物车——先睡一觉再看。', why: '这时候的「想要」比「需要」大一圈。' },
    { severity: 2, key: '把话说满', text: '不要把话说满，不要立「这事包在我身上」的军令状。', why: '上爻是终位，话说满了没有转身的位置。' },
    { severity: 2, key: '翻旧账', text: '不要翻旧账，不要把去年的截图再发一遍。', why: '翻出来的是利息，本金早就花完了。' },
    { severity: 2, key: '重蹈覆辙', text: '不要在同一个坑里再试一次「这次不一样」。', why: '同一爻动两次，卦里已经说了。' },
    { severity: 2, key: '酒后发信', text: '不要酒后发消息，不要凌晨三点回那条朋友圈。', why: '深夜说的话，天亮都要自己收尾。' },
    { severity: 2, key: '押注', text: '不要押注，不要梭哈，不要把生活费挪去补仓。', why: '这里的财位是虚的，赢了是运气，输了是生活。' },
    { severity: 2, key: '硬扛病情', text: '不要拿身体赌：报告出来之前别当自己没事，也别停掉该吃的药。', why: '这边只谈吉凶，不谈生死；卦象再好也不能替医生签字。' },
    { severity: 2, key: '借钱', text: '不要把生活费借给同事朋友，也不要指望「这个月一定还」。', why: '借出去的是钱，收回来的是关系，两样总缺一样。' },
    { severity: 2, key: '玩游戏', text: '不要为一场排位熬到三点，也不要在游戏里氪金补心情。', why: '赢了不涨工资，输了掉段位还掉心情，成本都算在你身上。' },
    { severity: 1, key: '趁吉加码', text: '不要趁顺加码：顺利的时候最容易一口气答应太多事。', why: '顺是势，不是额度。' },
    { severity: 1, key: '提前张扬', text: '不要把计划讲给太多人听——先做完一件再说。', why: '说出去的进度会被当成承诺。' },
    { severity: 1, key: '三心二意', text: '不要一天换三个主意。', why: '注意力散开，什么也做不完。' },
    { severity: 1, key: '贪多', text: '不要贪多：今天挑一件最要紧的做完。', why: '多线并进等于一条都没走通。' },
    { severity: 1, key: '凭感觉', text: '不要靠「感觉对了」拍板，至少要有一条写在纸上的依据。', why: '感觉落不到纸上，事后没法对账。' },
    { severity: 1, key: '迷信卦象', text: '不要把这一卦当成长期免死金牌。', why: '卦只管这一段，下一段还要重新看。' }
  ]
};

/** 三道符骨架：hint 是「怎么做」，material 是可用素材（模型按对方的事重写）。 */
const REMEDIES = {
  // 三道符固定是「定位 → 取证复核 → 处置求援」，不是止损话术换皮：
  // hint 是动词开头的动作骨架，material 是能真拿到手的具体手段。模型必须按对方问的那件事重写。
  daozhang: [
    { slot: '第一符', hint: '先定位：把范围缩到最小的一件事，只留一个变量，其余先停用或搁置三天，看它还在不在。', material: '单件试验、停掉其他变量、三天观察记录、同一处对比' },
    { slot: '第二符', hint: '再取证复核：把证据取到手，再找资料或懂行的第三人对着核一遍。', material: '日志原文、版本号、序列号与机芯型号、官方文档、同款成交记录、懂行的第三人' },
    { slot: '第三符', hint: '再处置：能改就带备份改一步，能退就回滚到上一个好状态，改不动就把材料整包递给能解决的人。', material: '备份、回滚、退货与保修条款、卖家或客服、能接手的第三人' }
  ],
  straight: [
    { slot: '第一符', hint: '先定位：范围缩到最小的一件事，只留一个变量，其他先停掉搁三天，看问题还在不在。', material: '单件试验、只留一个变量、三天观察、同一处对比' },
    { slot: '第二符', hint: '再取证复核：证据先取到手，再找官方文档或懂行的第三人核一遍。', material: '日志原文、版本号、序列号与机芯型号、官方文档、同款成交记录、懂行的第三人' },
    { slot: '第三符', hint: '再处置：能改就带备份改一步，能退就回滚或退货，改不动就把材料整包交给能解决的人。', material: '备份、回滚、退货与保修条款、卖家或客服、能接手的第三人' }
  ]
};

/** 补充话术素材：sample 一般版，escalation 对方再犯时的终极话术。 */
const SUPPLEMENT = {
  daozhang: {
    sample: '贫道观你这一卦，凶不在天，在你自己那只不肯停的手。空手问卦的先记着：事儿都说不明白，符画得再好也只治你三分。真要较真，就用截图大法——把关键那句截下来，比两个人凭记忆争强。',
    escalation: '又是你。贫道把照妖镜擦干净了：上回那道符你压在玉简底下当没看见，这回还空手来问。行，贫道再说最后一遍——这卦不是不灵，是你不记事。三次之内不改，贫道拂尘一摆，下回只回你四个字：照卦办。',
    hints: [
      '只说「报错了」不说报什么错：下次把错误报告导出，连版本号一起发来。',
      '用手机拍屏代替截图：下次直接贴日志原文，拍屏里关键那行往往是糊的。',
      '不说怎么复现：下次先写清第几步崩的、点了哪里。',
      '没定「什么算解决」：下次先说清判定标准，别到时候好了也说没好。'
    ],
    // 损人素材：补充段要靠它开涮，不是技术清单
    jabs: [
      '空手来问卦的：事儿都不说，贫道掐指一算，先算出你懒得打字。',
      '拿手机拍屏当证据的：糊成一片还问贫道「哪行是错的」，那行大概是「看不清」。',
      '同一件事问第三遍的：卦没变，是你的记性变了。'
    ]
  },
  straight: {
    sample: '这次按卦象直说。（接卦象）顺带提醒：空手问卦的话，先把事情说明白再算，不然算得再准也帮不到你。真要较真，用截图大法——把关键的话截下来，比凭记忆争强。',
    escalation: '同一个问题你已经问了不止一次。上次说的办法你没做，这次结果不会不一样。话我放到这里：不改，下回我只回你四个字——按卦办。真要我拿照妖镜照一遍才肯改，那也只能这样了。',
    hints: [
      '只说「报错了」不说报什么错：下次把错误报告导出，附上版本号。',
      '用手机拍屏代替截图：下次直接贴日志原文。',
      '不说怎么复现：下次先写清第几步崩的、点了哪里。',
      '没定「什么算解决」：下次先说清判定标准。'
    ],
    jabs: [
      '空手问卦的：连问的什么都没说清，算得再准也用不上。',
      '用手机拍屏当证据的：糊成一片还要看「哪行是错的」，那句大概是「看不清」。',
      '同一件事问第三遍的：卦没变，是你的记性变了。'
    ]
  }
};

const TABOO_COUNT = Object.freeze({ '大吉': 6, '吉': 7, '平': 8, '凶': 9, '大凶': 10 });
// 与池子里的 severity 同一套量纲（3 最重、1 最轻）：越凶的卦越该拿到越重的「不宜」。
const TABOO_SEVERITY = Object.freeze({ '大吉': 1, '吉': 1, '平': 2, '凶': 3, '大凶': 3 });

/**
 * 按评级方向挑不宜候选：severity 与「该卦的凶险档」越接近越先出现，
 * 同档内按卦序旋转（同一个人重算几次不会永远看到同样六条）。
 * 条数固定 6–10（大吉 6 / 吉 7 / 平 8 / 凶 9 / 大凶 10）。
 */
export function pickTaboos(rating, seed = 0, tone = DEFAULTS.tone) {
  const which = normalizeTone(tone);
  const pool = TABOOS[which] || TABOOS[DEFAULTS.tone];
  const key = RATINGS.includes(String(rating)) ? String(rating) : '平';
  const want = TABOO_COUNT[key];
  const target = TABOO_SEVERITY[key];
  const groups = new Map();
  for (const item of pool) {
    const distance = Math.abs(item.severity - target);
    if (!groups.has(distance)) groups.set(distance, []);
    groups.get(distance).push(item);
  }
  const ordered = [];
  for (const distance of [...groups.keys()].sort((a, b) => a - b)) {
    const list = groups.get(distance);
    const rotate = ((safeInt(seed, 0) % list.length) + list.length) % list.length;
    for (let i = 0; i < list.length; i++) ordered.push(list[(i + rotate) % list.length]);
  }
  return ordered.slice(0, want).map((item) => ({ key: item.key, text: item.text, why: item.why }));
}

export function buildFlavor({ cast, tone = DEFAULTS.tone, severity = '平' } = {}) {
  const which = normalizeTone(tone);
  const seed = cast?.hexagram?.number ?? 0;
  const rating = RATINGS.includes(String(severity)) ? String(severity) : '平';
  return {
    persona: which,
    taboos: pickTaboos(rating, seed, which),
    remedies: (REMEDIES[which] || REMEDIES[DEFAULTS.tone]).map((item) => ({
      slot: item.slot,
      hint: item.hint,
      material: item.material
    })),
    // hints 单独拷贝一份：返回的对象不能与模块常量共用同一个数组。
    supplement: (() => {
      const src = SUPPLEMENT[which] || SUPPLEMENT[DEFAULTS.tone];
      return { sample: src.sample, escalation: src.escalation, hints: src.hints.slice(), jabs: src.jabs.slice() };
    })()
  };
}

// ───────────────────────── 四段结构与硬规则 ─────────────────────────

export const GUIDANCE = Object.freeze({
  format: Object.freeze([
    Object.freeze({ section: '卦象', rule: '【卦象】起头、逐字照抄 cast.summary（第几卦 + 卦名 + 上下卦 + 评级）；有动爻补爻名，有变卦补 cast.changeSummary。默认不念卦辞（hexagram.judgment），只有对方追问或说「要原文」时才附。卦序/卦名/上下卦/评级一个字都不许改。' }),
    Object.freeze({ section: '不宜', rule: '【不宜】起头：先给 3–4 个 taboo.key 组成的顿号短词表、不加别的字（例：签约、求财、主动出击、询问、玩游戏）；理由压成 1–2 句、合在同一段里说完，不许一条理由一条消息，也不许把 10 条全倒完。' }),
    Object.freeze({ section: '解决方案', rule: '【解决方案】起头：只讲对方问的那件事怎么查、怎么处理，按「定位 → 取证复核 → 处置求援」三步写在同一段里（slot 仍是第一符/第二符/第三符），写他今天就能做的第一步；严禁把【不宜】的止损话搬过来，严禁「多喝热水」式空话，严禁讲卦理。' }),
    Object.freeze({ section: '补充', rule: '【补充】起头：以阴阳为主——先从 flavor.supplement.jabs / sample / escalation 里挑一句损他（空手问卦、拍屏、反复问），再把 1 条 supplement.hints 包进损话里说（hints 只是素材），收在「照卦办」；不许写成技术清单，不许许诺改运。' })
  ]),
  sendModeHint: '默认整卦一条消息说完，四段用换行分段。只有对方要求「一段一段发」或整段超长时才拆，最多 2 条，任何一段都不许再拆成多条。整卦 260 字以内，嫌长先删理由，不许先加消息条数。'
});

function fail(code, message) {
  return { ok: false, error: { code, message: safeSlice(message, 400) } };
}

/** 参数解析：who（cast 可缺省，history 必填）。 */
function parseWho(raw) {
  if (raw === undefined || raw === null || raw === '') return { ok: true, name: '' };
  if (typeof raw === 'number' && Number.isFinite(raw)) return { ok: true, name: safeSlice(String(raw), MAX_WHO) };
  if (typeof raw !== 'string') {
    return { ok: false, name: '', message: 'who 必须是字符串（问卦人的昵称或 QQ 号，≤' + MAX_WHO + ' 字）。给了对象/数组这类值没法当存档的键。' };
  }
  const name = stripLoneSurrogates(raw).replace(/\s+/g, ' ').trim();
  if (!name) return { ok: true, name: '' };
  if (charLength(name) > MAX_WHO) {
    return { ok: false, name: '', message: 'who 太长了（' + charLength(name) + ' 字，上限 ' + MAX_WHO + ' 字）：who 只放昵称或 QQ 号，不要塞整句话，否则会撑爆卦史存档。' };
  }
  return { ok: true, name };
}

function parseQuestion(raw) {
  if (raw === undefined || raw === null || raw === '') return { ok: true, text: '' };
  if (typeof raw !== 'string') {
    return { ok: false, text: '', message: 'question 必须是字符串（对方问的什么事，一句话摘要）。不想传就不传，照样起卦。' };
  }
  const text = stripLoneSurrogates(raw)
    .replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (charLength(text) > MAX_QUESTION) {
    return { ok: false, text: '', message: 'question 太长了（' + charLength(text) + ' 字，上限 ' + MAX_QUESTION + ' 字）：这里只放一句话摘要，不是对方的原话转述。' };
  }
  return { ok: true, text };
}

/** limit → 数字或 null（null = 越界；越界不静默夹取，否则 11 看起来像只查了 10 条）。 */
function parseLimit(raw) {
  if (raw === undefined || raw === null || raw === '') return DEFAULT_HISTORY_LIMIT;
  const n = Number(raw);
  if (!Number.isFinite(n) || !Number.isInteger(n) || n < 1 || n > MAX_HISTORY_LIMIT) return null;
  return n;
}

// ───────────────────────── 持久化 ─────────────────────────
// 单键读-改-写：一次工具调用最多读一次、写一次。宿主的硬限制是单值 32KB / 总量 256KB /
// 每分钟 120 写，所以预算按 28KB 算：超了先淘汰「最久没算卦」的人，宁可丢老记录也不能让写入被拒。

function byteLengthOf(state) {
  try { return Buffer.byteLength(JSON.stringify(state), 'utf8'); } catch { return 0; }
}

function recordOf(raw) {
  if (!isPlainObject(raw)) return null;
  const number = safeInt(raw.number, 0);
  const hexagram = HEX_BY_NUMBER.get(number);
  if (!hexagram) return null;
  const moving = Array.isArray(raw.moving)
    ? raw.moving.map((item) => safeInt(item, 0)).filter((item) => item >= 1 && item <= 6)
    : [];
  const changedNumber = raw.changed === null || raw.changed === undefined ? 0 : safeInt(raw.changed, 0);
  return {
    at: safeInt(raw.at, 0),
    number,
    rating: RATINGS.includes(String(raw.rating)) ? String(raw.rating) : hexagram.rating,
    question: safeSlice(String(raw.question ?? '').replace(/\s+/g, ' ').trim(), MAX_QUESTION_STORED),
    moving: [...new Set(moving)].sort((a, b) => a - b),
    changed: HEX_BY_NUMBER.has(changedNumber) ? changedNumber : null
  };
}

/** 存档读坏了/是旧形状都不报错：能认的字段留下，认不出的丢掉（不猜）。 */
export function normalizeState(raw) {
  const src = isPlainObject(raw) ? raw : {};
  const state = { v: 1, users: {} };
  const users = isPlainObject(src.users) ? src.users : {};
  for (const [key, value] of Object.entries(users)) {
    const name = safeSlice(String(key ?? '').replace(/\s+/g, ' ').trim(), MAX_WHO);
    if (!name || !isPlainObject(value)) continue;
    const records = (Array.isArray(value.records) ? value.records : []).map(recordOf).filter(Boolean);
    records.sort((a, b) => a.at - b.at);
    state.users[name] = {
      total: Math.max(safeInt(value.total, records.length), records.length),
      lastAt: safeInt(value.lastAt, records.length ? records[records.length - 1].at : 0),
      records
    };
  }
  return state;
}

/**
 * 淘汰：①每人只留最新 perUser 条 ②还超字节预算就按「最久没算卦」一个人一个人删。
 * 存档里没有别的全局计数，所以人删光了必然很小，不需要再兜一层。
 */
export function trimState(state, budget = MAX_STATE_BYTES, perUser = DEFAULTS.historyPerUser) {
  const limit = Number.isFinite(Number(budget)) ? Math.max(1024, Number(budget)) : MAX_STATE_BYTES;
  const keep = clampInt(perUser, DEFAULTS.historyPerUser, 1, MAX_HISTORY_PER_USER);
  for (const entry of Object.values(state.users)) {
    if (entry.records.length > keep) {
      entry.records.sort((a, b) => a.at - b.at);
      entry.records = entry.records.slice(entry.records.length - keep);
    }
  }
  while (byteLengthOf(state) > limit) {
    const names = Object.keys(state.users).sort((a, b) => state.users[a].lastAt - state.users[b].lastAt);
    if (!names.length) break;
    delete state.users[names[0]];
  }
  return state;
}

/** 把这一次起卦落到存档上，返回这个人算到现在的总卦数。 */
function applyCast(state, { who, at, cast, question, perUser }) {
  const entry = state.users[who] || { total: 0, lastAt: 0, records: [] };
  entry.total += 1;
  entry.lastAt = at;
  entry.records.push({
    at,
    number: cast.hexagram.number,
    rating: cast.hexagram.rating,
    question: safeSlice(question, MAX_QUESTION_STORED),
    moving: cast.moving.map((line) => line.index),
    changed: cast.changed ? cast.changed.number : null
  });
  const keep = clampInt(perUser, DEFAULTS.historyPerUser, 1, MAX_HISTORY_PER_USER);
  if (entry.records.length > keep) {
    entry.records.sort((a, b) => a.at - b.at);
    entry.records = entry.records.slice(entry.records.length - keep);
  }
  state.users[who] = entry;
  return entry.total;
}

// ───────────────────────── 两个工具 ─────────────────────────

function degradedWarning(phase, error, whoName) {
  const timedOut = error?.kind === 'timeout';
  const detail = safeSlice(String(error?.message || error || '未知原因'), 140);
  const reason = (timedOut ? '超时' : '被宿主拒绝或出错') + '：' + detail;
  return {
    code: 'E_STORAGE_DEGRADED',
    message: (phase === 'read' ? '读卦史存档失败' : '写卦史存档失败') + '（' + reason + '）：这一卦照常算，但没有记进卦史' + (whoName ? '（' + whoName + '）' : '') + '。'
  };
}

/** 一次降级调用恰好写一条宿主日志：宿主明确拒绝 → error，超时/未知 → warn。 */
function warnDegraded(ctx, phase, error, warning) {
  const level = error?.kind === 'timeout' ? 'warn' : 'error';
  try { ctx.io.warn('[suan-gua] cast 降级（' + phase + '）：' + warning.message, level); } catch { /* 日志失败不影响起卦 */ }
}

function castAdvise(cast, record, tone) {
  const which = normalizeTone(tone);
  const parts = [];
  parts.push('卦象与六爻是插件掷出的既成事实：hexagram、lines、moving、changed 一律照返回转述，不许改名、改卦序、升降评级，也不许自己新编一卦。');
  parts.push('格式硬规则（不许违反）：四段逐字以【卦象】【不宜】【解决方案】【补充】开头，一行一段，前缀不许省、不许改成「卦象：」这类变体；默认整卦一条消息，只有对方要求「一段一段发」或超长才拆，最多 2 条，任何一段不许再拆成多条；不念卦辞（hexagram.judgment）；整卦 260 字以内，嫌长先删理由，不许加条数。');
  parts.push('四段缺一段都算没说完；顺序就是卦象 → 不宜 → 解决方案 → 补充，四行同属一条消息。');
  parts.push('「不宜」挑 3–4 条 taboo：先只列 taboo.key 的顿号短词表（不加别的字），理由压成 1–2 句合在同一段里说完；不许一条理由一条消息。');
  parts.push('「解决方案」只讲这件事怎么查、怎么处理：定位 → 取证 → 处置三步写成一行，是他今天就能做的第一步；不许写成【不宜】的翻版，不许空话讲卦理。');
  parts.push('「补充」是拿他开涮、不是技术清单：用 jabs / sample / escalation 损一句，把 1 条 hints 包进去，收在「照卦办」。');
  if (which === 'daozhang') {
    parts.push('语气走道长档：自称贫道，用符、玉简、拂尘、照妖镜这些标记词；凶卦说的是「别硬来」，不是「你有血光之灾」。');
  } else {
    parts.push('语气走正经档（tone=straight）：不装神弄鬼、不自称道长，把话说清楚；四段结构与内容量不变。');
  }
  if (cast.moving.length) {
    parts.push('这次有 ' + cast.moving.length + ' 个动爻：要按爻名逐个说（' + cast.moving.map((line) => line.name).join('、') + '），变卦是「' + (cast.changed ? cast.changed.fullName : '不明') + '」，changeSummary 可原样用。');
  } else {
    parts.push('这次没有动爻：变卦是空（changed=null、changeSummary=null），不要说成「变卦不明」，也不要自己补一个变卦。');
  }
  parts.push('不许算生死病灾、不许断人婚配、不许说「必有血光之灾」这类断言：卦是提醒，不是判决书。对方拿它当决策依据时，明说「这只是个乐子，正事按常识办」。');
  if (record.warning) {
    parts.push('这次卦史没写进去（' + record.warning.code + '）：' + record.warning.message + '不要说已经记好了，也不要替对方补记；想留档就下次带上 who 再算一次。');
  } else if (!record.recorded) {
    parts.push('这次没有记档（没传 who，或插件设置里关掉了 recordHistory）：不要说「已经给你记上了」，也不许编一段卦史；下次带上 who 再算才记。');
  } else {
    parts.push('这一卦已经记进「' + String(record.who ?? '') + '」的卦史（这是他的第 ' + String(record.total ?? 0) + ' 卦）。有人问「我上次算的什么」时调 suan-gua__history 查，不许凭记忆编。');
  }
  return parts;
}

export async function castTool(ctx, args) {
  const whoParsed = parseWho(args.who);
  if (!whoParsed.ok) return fail('E_ARGS', whoParsed.message);
  const questionParsed = parseQuestion(args.question);
  if (!questionParsed.ok) return fail('E_ARGS', questionParsed.message);
  const whoName = whoParsed.name;
  const question = questionParsed.text;

  let cast;
  try {
    cast = castHexagram(ctx.rng);
  } catch (error) {
    return fail('E_INTERNAL', '摇卦失败：' + safeSlice(String(error?.message || error), 160) + '。这是插件自己的问题，不是你的参数错了。');
  }

  const tone = normalizeTone(ctx.tone);
  const severity = worseRating(cast.hexagram.rating, cast.changed ? cast.changed.rating : cast.hexagram.rating);
  const flavor = buildFlavor({ cast, tone, severity });

  // 读不到存档时**绝不写**：把「读失败」当成空存档写回去，会顺手抹掉所有人的卦史。
  let warning = null;
  let recorded = false;
  let total = null;
  if (ctx.recordHistory && whoName) {
    let state = null;
    try {
      state = normalizeState(await ctx.io.read());
    } catch (error) {
      warning = degradedWarning('read', error, whoName);
      warnDegraded(ctx, 'read', error, warning);
      state = null;
    }
    if (!warning) {
      try {
        const at = safeInt(ctx.io.now(), Date.now());
        total = applyCast(state, { who: whoName, at, cast, question, perUser: ctx.historyPerUser });
        await ctx.io.write(trimState(state, MAX_STATE_BYTES, ctx.historyPerUser));
        recorded = true;
      } catch (error) {
        recorded = false;
        total = null;
        warning = degradedWarning('write', error, whoName);
        warnDegraded(ctx, 'write', error, warning);
      }
    }
  }

  const record = { recorded, who: whoName || null, total: recorded ? total : null, warning };
  return {
    ok: true,
    cast: {
      hexagram: {
        number: cast.hexagram.number,
        name: cast.hexagram.name,
        fullName: cast.hexagram.fullName,
        upper: cast.hexagram.upper,
        lower: cast.hexagram.lower,
        rating: cast.hexagram.rating,
        judgment: cast.hexagram.judgment
      },
      lines: cast.lines.map((line) => ({ index: line.index, name: line.name, value: line.value, moving: line.moving })),
      moving: cast.moving.map((line) => ({ index: line.index, name: line.name, hint: line.hint })),
      changed: cast.changed ? { ...cast.changed } : null,
      summary: cast.summary,
      changeSummary: cast.changeSummary
    },
    flavor,
    guidance: { format: GUIDANCE.format.map((item) => ({ ...item })), sendModeHint: GUIDANCE.sendModeHint },
    record,
    advise: castAdvise(cast, record, tone)
  };
}

/** 卦史里只存爻位，爻名要按本卦的阴阳回放——所以 number 必须一起存。 */
function movingTextOf(number, moving) {
  if (!Array.isArray(moving) || !moving.length) return '无动爻';
  const hexagram = HEX_BY_NUMBER.get(safeInt(number, 0));
  const values = hexagram ? linesOf(hexagram) : [7, 7, 7, 7, 7, 7];
  const names = moving
    .map((index) => safeInt(index, 0))
    .filter((index) => index >= 1 && index <= 6)
    .sort((a, b) => a - b)
    .map((index) => lineName(index, values[index - 1]));
  return names.length ? names.join('、') + '动' : '无动爻';
}

export async function historyTool(ctx, args) {
  const whoParsed = parseWho(args.who);
  if (!whoParsed.ok) return fail('E_ARGS', whoParsed.message);
  const whoName = whoParsed.name;
  if (!whoName) {
    return fail('E_ARGS', 'history 必须传 who（问卦人的昵称或 QQ 号，≤' + MAX_WHO + ' 字）：卦史是按人存的，不说是谁就无从查起。');
  }
  const limit = parseLimit(args.limit);
  if (limit === null) {
    return fail('E_ARGS', 'limit 必须是 1–' + MAX_HISTORY_LIMIT + ' 之间的整数（收到「' + safeSlice(String(args.limit), 20) + '」）。不填就是最近 ' + DEFAULT_HISTORY_LIMIT + ' 卦。');
  }
  if (!ctx.recordHistory) {
    return fail('E_NOT_FOUND', '卦史记录在插件设置里被关掉了（recordHistory=false），所以「' + whoName + '」没有任何可查的卦；打开记录之后新算的卦才会入档。');
  }

  let state;
  try { state = normalizeState(await ctx.io.read()); }
  catch (error) {
    return fail('E_STORAGE', '卦史读不出来：' + safeSlice(String(error?.message || error), 160) + '。稍后再查一次；一直失败多半是宿主的状态存储满了（单值 32KB）。');
  }

  const entry = state.users[whoName];
  if (!entry || !entry.records.length) {
    return fail('E_NOT_FOUND', '卦史里没有「' + whoName + '」的记录：可能还没算过，或者 who 和当时拼得不一样（昵称/QQ 号要一致），也可能太久没算被淘汰了（每人的记录有条数上限，满员时按最久没算卦先删）。如实转述，不要编造。');
  }

  const records = entry.records
    .slice()
    .sort((a, b) => b.at - a.at)
    .slice(0, limit)
    .map((item) => {
      const hexagram = HEX_BY_NUMBER.get(item.number);
      const changedHex = item.changed === null ? null : HEX_BY_NUMBER.get(item.changed);
      return {
        at: item.at,
        number: item.number,
        name: hexagram ? hexagram.name : '未知卦',
        fullName: hexagram ? hexagram.fullName : '未知卦',
        rating: item.rating || (hexagram ? hexagram.rating : '平'),
        question: item.question,
        movingText: movingTextOf(item.number, item.moving),
        changedName: changedHex ? changedHex.name : null
      };
    });

  const advise = [
    'records 已经按时间从新到旧排好，只返回了最近 ' + records.length + ' 卦；total 是「' + whoName + '」算到现在的总卦数（含早已被淘汰的老卦），两者不必相等。',
    'at 是毫秒时间戳，转成「几月几号」再说；question 是当时的一句话摘要（最多存 ' + MAX_QUESTION_STORED + ' 字），不是原话。',
    'movingText 为「无动爻」表示那一卦没有动爻、changedName 为 null 表示没有变卦；不要说成「变卦不明」，也不要自己补一个变卦。',
    '只转述存档里的卦：不要顺手再给他算一卦，也不要补上不存在的卦或替他改评级。'
  ];

  return { ok: true, who: whoName, total: entry.total, records, advise };
}

/** 工具总入口：永远返回纯 JSON 对象，绝不抛协议级异常。 */
export async function runTool(ctx, name, args) {
  const tool = String(name ?? '');
  try {
    if (!ctx || ctx.enabled !== true) {
      return fail('E_DISABLED', '算卦在插件设置里被关掉了（enabled=false），先在宿主控制台的插件设置里打开再算。');
    }
    if (!isPlainObject(args)) {
      return fail('E_ARGS', 'args 必须是对象，例如 {"who":"小明","question":"要不要接这个项目"}。传 null 会丢掉 who，算了也不会记档。');
    }
    if (tool === 'cast') return await castTool(ctx, args);
    if (tool === 'history') return await historyTool(ctx, args);
    return fail('E_UNKNOWN_TOOL', '本插件没有工具「' + safeSlice(tool, 40) + '」，只有 cast / history。');
  } catch (error) {
    return fail('E_INTERNAL', '插件内部出错：' + safeSlice(String(error?.message || error), 200));
  }
}

// ───────────────────────── 上下文 ─────────────────────────

export function makeContext(settings, io) {
  const raw = isPlainObject(settings) ? settings : {};
  const source = isPlainObject(io) ? io : {};
  return {
    settings: raw,
    enabled: toBool(raw.enabled, DEFAULTS.enabled),
    tone: normalizeTone(raw.tone),
    recordHistory: toBool(raw.recordHistory, DEFAULTS.recordHistory),
    historyPerUser: clampInt(raw.historyPerUser, DEFAULTS.historyPerUser, 1, MAX_HISTORY_PER_USER),
    rng: typeof source.rng === 'function' ? source.rng : Math.random,
    io: {
      read: typeof source.read === 'function' ? source.read : async () => null,
      write: typeof source.write === 'function' ? source.write : async () => {},
      now: typeof source.now === 'function' ? source.now : () => Date.now(),
      warn: typeof source.warn === 'function' ? source.warn : () => {}
    }
  };
}

// ───────────────────────── stdio NDJSON 协议 ─────────────────────────

/** 只有被当主模块跑时才进协议循环；被 import（单测/其它脚本）时什么都不做。 */
function isMainModule() {
  try {
    const argv1 = process.argv[1];
    if (typeof argv1 !== 'string' || !argv1) return false;
    const here = import.meta.url;
    const ran = pathToFileURL(path.resolve(argv1)).href;
    return process.platform === 'win32' ? here.toLowerCase() === ran.toLowerCase() : here === ran;
  } catch {
    return false;
  }
}

function main() {
  const write = (msg) => { try { process.stdout.write(JSON.stringify(msg) + '\n'); } catch { /* 管道断了也没别的办法 */ } };
  const warn = (text) => { try { process.stderr.write('[suan-gua] ' + text + '\n'); } catch { /* ignore */ } };

  let seq = 0;
  const pending = new Map();
  let settingsFromInit = {};
  let settings = null;

  /**
   * 调宿主能力，resolve 的是**整条回执**（{result} 或 {error}），超时返回 null。
   * 只有这样才能分清「读不到」和「被拒」——存档被拒不能当成空存档，否则下一次写入就把别人的卦史覆盖了。
   */
  const capCall = (method, params, timeoutMs = 3000) => new Promise((resolve) => {
    const id = 'cap-' + (++seq);
    const timer = setTimeout(() => { pending.delete(id); resolve(null); }, timeoutMs);
    pending.set(id, (msg) => { clearTimeout(timer); resolve(msg ?? null); });
    write({ id, method, params });
  });

  const capResult = async (method, params, timeoutMs) => {
    const reply = await capCall(method, params, timeoutMs);
    return reply && isPlainObject(reply.result) ? reply.result : null;
  };

  const storageError = (text, kind) => Object.assign(new Error(text), { code: 'E_STORAGE', kind });
  const replyDetail = (reply) => safeSlice(String(reply?.error?.message || reply?.error?.code || ''), 120);

  const io = {
    read: async () => {
      const reply = await capCall('cap.storage.get', { key: STORAGE_KEY }, 4000);
      if (!reply) throw storageError('读存档超时（宿主的 storage 没有回话）', 'timeout');
      if (reply.error) throw storageError('读存档被拒：' + replyDetail(reply), 'rejected');
      const result = isPlainObject(reply.result) ? reply.result : {};
      return result.value === undefined ? null : result.value;
    },
    write: async (state) => {
      const reply = await capCall('cap.storage.set', { key: STORAGE_KEY, value: state }, 4000);
      if (!reply) throw storageError('写存档超时（宿主的 storage 没有回话）', 'timeout');
      if (reply.error) throw storageError('写存档被拒：' + replyDetail(reply), 'rejected');
    },
    now: () => Date.now(),
    // level：宿主明确拒绝 → error（进异常面板）；超时/未知 → warn。只写一行，不重试。
    warn: (text, level = 'warn') => {
      void capCall('cap.log.write', { level: level === 'error' ? 'error' : 'warn', message: safeSlice(text, 300) }, 1000);
    }
  };

  const readSettings = async () => {
    if (settings) return settings;
    const fromHost = await capResult('cap.config.get', {});
    settings = isPlainObject(fromHost?.settings)
      ? fromHost.settings
      : (isPlainObject(settingsFromInit) ? settingsFromInit : {});
    return settings;
  };

  const handleCallTool = async (msg) => {
    let result;
    try {
      const config = await readSettings();
      const ctx = makeContext(config, io);
      // args 缺省当空对象（宿主对无参工具可能不发 args）；显式 null 原样交给 runTool 报 E_ARGS。
      const args = msg.params?.args === undefined ? {} : msg.params.args;
      result = await runTool(ctx, msg.params?.name, args);
    } catch (error) {
      result = fail('E_INTERNAL', '插件内部出错：' + safeSlice(String(error?.message || error), 200));
    }
    let payload;
    try {
      payload = JSON.parse(JSON.stringify(result));
    } catch {
      payload = fail('E_INTERNAL', '结果没法序列化成 JSON（插件内部错误）。');
    }
    write({ id: msg.id, result: payload });
  };

  const onMessage = (msg) => {
    if (!msg || typeof msg !== 'object') return;
    if (typeof msg.id === 'string' && pending.has(msg.id)) {
      const done = pending.get(msg.id);
      pending.delete(msg.id);
      done(msg);
      return;
    }
    switch (msg.method) {
      case 'init':
        if (isPlainObject(msg.params?.settings)) settingsFromInit = msg.params.settings;
        settings = null; // 重新握手就重读配置
        write({ id: msg.id, result: { ok: true } });
        return;
      case 'ping':
        write({ id: msg.id, result: { ok: true } });
        return;
      case 'shutdown':
        // 宿主退出时发的是**不带 id** 的 shutdown；此时回执会变成 {"result":{}}，
        // 宿主侧记成一条无法识别的消息（protocolErrors +1）。没有 id 就不回话，只退出。
        if (msg.id !== undefined && msg.id !== null) write({ id: msg.id, result: { ok: true } });
        setTimeout(() => process.exit(0), 30);
        return;
      case 'callTool':
        void handleCallTool(msg);
        return;
      default:
        return; // 未声明/不认识的方法忽略，不回话
    }
  };

  let buffer = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (chunk) => {
    buffer += chunk;
    let index = buffer.indexOf('\n');
    while (index !== -1) {
      const line = buffer.slice(0, index).trim();
      buffer = buffer.slice(index + 1);
      if (line) {
        let parsed = null;
        try { parsed = JSON.parse(line); } catch { parsed = null; }
        if (parsed) onMessage(parsed);
      }
      index = buffer.indexOf('\n');
    }
  });
  process.stdin.on('error', (error) => warn('stdin 出错：' + (error?.message || error)));
  process.on('uncaughtException', (error) => warn('未捕获异常（已忽略，进程继续）：' + (error?.message || error)));
  process.on('unhandledRejection', (error) => warn('未处理的 Promise 拒绝（已忽略）：' + (error?.message || error)));
}

if (isMainModule()) main();
