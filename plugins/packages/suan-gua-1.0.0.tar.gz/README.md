# 算卦（suan-gua）

有人想算一卦，插件**真的摇六爻起卦**：三枚铜钱掷六次，得本卦、动爻与变卦，评级（大吉/吉/平/凶/大凶）
由插件掷出；**四段断语由模型照着对方具体那件事写**（卦象 → 不宜 → 解决方案/三道符 → 补充）。

零依赖、单文件 ESM、**不联网、不写文件**：唯一持久化走宿主的 `cap.storage`（单键 `suan-gua.v1`）。

包内三件：`plugin.json` / `index.mjs` / `README.md`，没有 `package.json`、没有 `node_modules`、没有构建步骤。

## 装

把整个 `suan-gua/` 目录放进 `$DATA_DIR/plugins/suan-gua/`（目录名必须等于 id），在控制台「插件」页
启用 + 授权（**装上 ≠ 授权**，不点启用它不跑、也不给模型任何工具）。或按官方索引一键安装。

```bash
tar --format=ustar -czf suan-gua-1.0.0.tar.gz -C suan-gua README.md index.mjs plugin.json
```

## 模型侧看到的名字

| 工具 | 模型侧名字 |
| --- | --- |
| 起一卦 | `suan-gua__cast` |
| 查卦史 | `suan-gua__history` |

两个工具都是**只读工具 + 一次存储写**：不发言、不联网、不改宿主的任何东西。
插件不声明 `observe` / `schedule`，所以不投递入站消息、没有定时任务，进程按需懒启动
（第一次调用时宿主才起进程，多约 100ms）。

---

## `cast` —— 起一卦

### 参数

| 参数 | 类型 | 必填 | 约束 | 说明 |
| --- | --- | --- | --- | --- |
| `who` | string | 否 | `maxLength: 40` | 问卦人昵称或 QQ 号。**强烈建议传**：传了才记卦史 |
| `question` | string | 否 | `maxLength: 60` | 对方问的什么事的一句话摘要；存档只取前 40 字 |

`required: []`、`additionalProperties: false`。严格按 schema 校验，不做"尽力而为"的宽容解析：

- `who` / `question` 不是字符串、或超长 → `E_ARGS`（不会被悄悄截断后照常掷卦）；
- 传了契约里没有的参数 → `E_ARGS`；
- 两个参数都省略是**允许**的：照样起卦，只是 `record.recorded = false`（空手问卦，道长会阴阳一句）。

### 返回骨架

```json
{
  "ok": true,
  "cast": {
    "hexagram": { "number": 12, "name": "否", "fullName": "天地否", "upper": "乾", "lower": "坤", "rating": "凶", "judgment": "否之匪人，不利君子贞，大往小来。" },
    "lines": [ { "index": 1, "name": "初六", "value": 8, "moving": false } ],
    "moving": [ { "index": 2, "name": "六二", "hint": "该爻位通用判词 + 按本卦评级的吉凶微调" } ],
    "changed": { "number": 6, "name": "讼", "fullName": "天水讼", "upper": "乾", "lower": "坎", "rating": "凶" },
    "summary": "第12卦 天地否（乾上坤下）· 凶",
    "changeSummary": "六二、九五动 → 变卦：天水讼（乾上坎下）· 凶"
  },
  "flavor": { "persona": "daozhang", "taboos": [ { "key": "签约", "text": "…", "why": "…" } ], "remedies": [], "supplement": { "sample": "…", "escalation": "…", "jabs": ["…"], "hints": ["…"] } },
  "guidance": { "format": [], "sendModeHint": "默认整卦一条消息（四段换行分段）；对方要求或超长才拆，最多 2 条" },
  "record": { "recorded": true, "who": "小明", "total": 3, "warning": null },
  "advise": []
}
```

（`lines` 实际固定 6 条、`moving` 0–6 条、`taboos` 6–10 条（每条都带 `key`）、`hints` 2–4 条；上面为省篇幅各留一条。）

### 字段逐条

| 字段 | 说明 |
| --- | --- |
| `hexagram.number` | 1–64，**通行本卦序**（乾 1 … 未济 64） |
| `hexagram.name` | 卦名，如 `乾` / `否` / `既济` |
| `hexagram.fullName` | 全名 = 上卦自然象 + 下卦自然象 + 卦名，如 `天地否` / `乾为天` |
| `hexagram.upper` / `lower` | 上卦（外）/ 下卦（内）的八卦名：乾 兑 离 震 巽 坎 艮 坤 |
| `hexagram.rating` | 只能是 `大吉` / `吉` / `平` / `凶` / `大凶` 五档之一 |
| `hexagram.judgment` | 该卦卦辞**原文一句**（不加解释、不加自己的断语） |
| `lines[]` | 固定 6 条，`index` 1–6 **自下而上**（初爻 → 上爻） |
| `lines[].value` | `6` 老阴 / `7` 少阳 / `8` 少阴 / `9` 老阳 |
| `lines[].name` | 初九/初六、九二/六二、九三/六三、九四/六四、九五/六五、上九/上六 |
| `lines[].moving` | `value === 6 || value === 9` |
| `moving[]` | 0–6 条，与 `lines` 里 `moving: true` 的条目一一对应（从下到上） |
| `moving[].hint` | 该爻位的**通用判词** + 按**本卦**评级的吉凶微调（不是按对方的事写的断语） |
| `changed` | 变卦（动爻取反：6→7、9→8，其余不动）；**无动爻时为 `null`** |
| `cast.summary` | 一行卦象，可原样使用：`第N卦 全名（上卦上 下卦下）· 评级` |
| `cast.changeSummary` | `六二、九五动 → 变卦：全名（上上 下下）· 评级`；无动爻为 `null` |
| `record.recorded` | 这次有没有写进卦史（没传 `who`、`recordHistory=false`、存档不可用都可能 `false`） |
| `record.who` / `record.total` | 记在谁名下 / 这个人累计第几卦（没记时为 `null`） |
| `record.warning` | 存档降级时为 `{ code: "E_STORAGE_DEGRADED", message }`，否则 `null` |
| `advise` | 给模型的硬规则条文（do / 不许 do 的风格），模型侧说明书的一部分 |

注意：`changed` 里**没有** `judgment`（只有 `number/name/fullName/upper/lower/rating`）——
变卦只用于四段里的"往哪儿走"，不当成第二个本卦来断。

### `flavor`：素材，不是文案

| 字段 | 形状 | 用法 |
| --- | --- | --- |
| `persona` | `"daozhang"` / `"straight"` | 直接取自设置 `tone`，决定口吻 |
| `taboos[]` | 6–10 条 `{ key, text, why }` | 「不宜」候选：`key` 是 **2–6 字短词**（签约 / 求财 / 主动出击），`text` 一句说明、`why` 为什么；按本卦/变卦的凶象方向给，模型挑 3–4 个按对方的事改写 |
| `remedies[]` | 3 条 `{ slot, hint, material }` | 三道符骨架，固定三步：**隔离/定位 → 取证/复核 → 处置/求援**；`slot` 形如 `第一符` / `第二符` / `第三符`，**第一符是对方今天就能做的第一步**；这是针对他那件事的可执行步骤，不是「不宜」止损话术的换皮（拖几天 / 找人挑刺 / 想最坏结果这类通通不要） |
| `supplement` | `{ sample, escalation, jabs, hints }` | 【补充】素材：`jabs` **2–3 条损人短句**（拿空手问卦 / 手机拍屏 / 说不清就开算 / 反复问同一件事这类毛病开涮——【补充】是要阴阳他，不是技术清单）、`hints` **2–4 条**「这次最容易漏掉什么、下次该补什么」（只挑 1–2 条，包在损话里）、`sample` 一般版、`escalation` 对方再犯时的终极话术 |

这三类都是**方向素材**，不是成品文案：模型必须照对方具体那件事重写，不许照抄。`key`、`jabs` 与 `hints` 尤其只是骨架——
`key` 给的是短词位（该不该提醒「签约」要看对方是不是在签约）、`jabs` 给的是损人的角度（要落到他这次具体的毛病上）、
`hints` 给的是检查清单（哪一步最容易漏），落到话里还得接上对方具体的事。插件给不出针对性
（它不知道对方的事，只有 `question` 的一句话摘要），所以"抄了会很空洞"是设计上的必然而非缺陷。

### `guidance`

`format` 固定四项，顺序就是四段顺序；**每段必须逐字以【卦象】【不宜】【解决方案】【补充】开头**——即使整卦只有一条消息，也要四行、四个前缀齐全（用户实测过模型四段一个前缀都没加）。默认四段在**同一条消息**里用换行分段（见下面的 `sendModeHint`）：

| section | 内容 |
| --- | --- |
| `卦象` | 以【卦象】开头：本卦 + 动爻 + 变卦 + 评级（照 `summary` / `changeSummary` 说，数字与卦名不许改）；**卦辞 `judgment` 默认不念，对方追问才给** |
| `不宜` | 以【不宜】开头：先列 3–4 个 `taboos[].key` 的顿号短词表（如「签约、求财、主动出击」），再每个各补一句为什么（都按对方的事改写）；短词表与理由在同一段里，**不许一段拆成多条消息** |
| `解决方案` | 以【解决方案】开头：**针对他问的那件事**给可执行步骤，三道符固定 **隔离/定位 → 取证/复核 → 处置/求援**，第一符是他今天就能做的第一步；一段内写完。**严禁把「不宜」的止损话搬进来、严禁空话、严禁讲卦理**——用户实测过这一栏被写成「拖三天 / 找人挑刺 / 写最坏结果」，等于没回答他的问题 |
| `补充` | 以【补充】开头：**用 `supplement.jabs` 阴阳他**（拿他这次的毛病开涮），把 1–2 条 `supplement.hints` 的实用提醒**包在损话里**，收在「照卦办」、不许许诺改运；`sample` / `escalation` 只当语气素材。**不是技术清单**——用户实测过这一栏干巴巴只剩技术提醒 |

`sendModeHint` 的口径是**默认一条、最多 2 条**：整卦一条消息说完（四段用换行分段）；只有对方明确要求分段、
或确实超长才拆，**最多 2 条**，任何一段不许再拆成多条。整卦建议 **≤260 字**，嫌长先删理由、不要加条数。
（用户实测过模型把四段拆成 10 条发——那是实现缺陷，不是设计选项。）

---

## `history` —— 查某人的卦史

### 参数

| 参数 | 类型 | 必填 | 约束 | 说明 |
| --- | --- | --- | --- | --- |
| `who` | string | **是** | `maxLength: 40` | 要和起卦时传的一致 |
| `limit` | integer | 否 | `minimum: 1`、`maximum: 10`、`default: 5` | 返回最近几卦 |

`required: ["who"]`、`additionalProperties: false`。`limit` 越界（0 / 99 / 小数 / 字符串）
直接 `E_ARGS`，**不会**被夹到边界值——静默夹边界会让模型以为"我要 50 条但它只给我 10"。

### 返回

```json
{
  "ok": true,
  "who": "小明",
  "total": 7,
  "records": [
    { "at": 1730000000000, "number": 6, "name": "讼", "fullName": "天水讼", "rating": "凶",
      "question": "明天面试能不能过", "movingText": "六二、九五动", "changedName": "天水讼" }
  ],
  "advise": []
}
```

- `records` **新的在前**，最多 `limit` 条；
- `movingText`：如 `六二、九五动`；无动爻为 `无动爻`；
- `changedName`：无变卦（即无动爻）为 `null`；
- `at` 是毫秒时间戳（存档里也是它，不再存一份可读时间——渲染由模型做）；
- `total` 是这个人的**累计**卦数（可能大于 `records.length`：只返回最近 `limit` 条）。

### 没有记录

`{ "ok": false, "error": { "code": "E_NOT_FOUND", "message": "…" } }` —— 可能是这个人从没算过、
当时没传 `who`、或设置里关了 `recordHistory`。**如实转述**，不要编造卦名或评级。

---

## 错误码

| code | 什么时候 | 模型/用户该看到什么 |
| --- | --- | --- |
| `E_ARGS` | 参数类型/长度/枚举/多余字段不合法，或 `limit` 越界 | 说明哪个参数、为什么、正确取值范围 |
| `E_NOT_FOUND` | `history` 里这个人没有卦史 | 如实说没记录，不要编 |
| `E_DISABLED` | 设置里 `enabled=false`（此时模型其实也看不到这两个工具，兜底再判一次） | 插件被关掉了 |
| `E_STORAGE_DEGRADED` | **不是**失败：存档读/写异常的 warning code，出现在 `record.warning` | 卦照常算出来了，但这次**没记上** |

失败一律返回 `{ ok:false, error:{ code, message } }`，**不抛协议级异常、不静默返回空**
（空结果会被模型当成"查到了但没有"）。`message` 是给人看的中文说明。

---

## 摇卦规则（固定，模型不许改）

三枚铜钱，一枚正面（字）= 3、反面（背）= 2，三枚之和即该爻：

| 和 | 爻 | 概率 | 组合数 |
| --- | --- | --- | --- |
| 6 | 老阴（动） | 1/8 = 12.5% | 1（背背背） |
| 7 | 少阳 | 3/8 = 37.5% | 3 |
| 8 | 少阴 | 3/8 = 37.5% | 3 |
| 9 | 老阳（动） | 1/8 = 12.5% | 1（字字字） |

**先掷初爻，依次到上爻**（自下而上），六次独立。于是：

- 一次起卦的动爻数期望是 `6 × 1/4 = 1.5`；`无动爻`（六爻全是 7/8）的概率是 `(3/4)^6 ≈ 17.8%`，
  `六爻全动` 的概率是 `(1/4)^6 ≈ 0.024%`——两种极端都要能正常返回（`changed: null` 与 6 条动爻）。
- 变卦：动爻取反（6→7 少阴转阳、9→8 少阳转阴），其余爻不动。**无动爻 → `changed: null`**。
- 爻名：位 1 与位 6 把"初/上"放前面（初九 / 初六、上九 / 上六），位 2–5 把数字放前面
  （九二 / 六二 … 九五 / 六五）；阳爻用"九"、阴爻用"六"（**按掷出的 value 判阴阳**：
  6/8 是阴 → 六，7/9 是阳 → 九；老阴老阳的"变"不影响爻名）。
- `rng` **必须可注入**（默认 `Math.random`）：单测要能用固定序列把"全 6 / 全 7 / 混合"逼出来。
  每次起卦消耗 18 次随机数（6 爻 × 3 枚），或 6 次（若一次 `rng()` 直接判组合）——两种都行，
  但**分布必须是上表**。

分布怎么验：注入固定种子的 `mulberry32` 跑 10 万次起卦，每个 value 的实测频率与
12.5 / 37.5 / 37.5 / 12.5 的偏差应 < 1 个百分点；四个概率相加应为 1。

## 卦象表与评级

- 64 卦按**通行本卦序**编号（乾 1、坤 2、屯 3 … 未济 64）；`fullName` 用传统全名
  （八纯卦是 `乾为天` / `坤为地` 这类，其余为「上象 + 下象 + 卦名」，如 `天地否`、`水火既济`）。
- `judgment` 是该卦**卦辞原文一句**（如 `否之匪人，不利君子贞，大往小来。`）：只作卦象底色，
  不许改写成"插件认为你会……"。
- `rating` 五档是**固定评级**，同一卦永远同一档；64 卦要覆盖到全部五档（验收会查每档至少一卦）。
- 评级只影响 `moving[].hint` 的吉凶微调与 `taboos` 的方向，**不影响**爻值、动爻、变卦。

## 存档

**单键**：`suan-gua.v1`（宿主的 `cap.storage`，落在 `$DATA_DIR/plugin-data/suan-gua/`，
卸载插件不删、重装还在）。

```json
{ "v": 1,
  "users": {
    "小明": { "total": 7, "lastAt": 1730000000000,
              "records": [ { "at": 1730000000000, "number": 6, "rating": "凶",
                             "question": "明天面试能不能过", "moving": [2, 5], "changed": 6 } ] } } }
```

| 字段 | 说明 |
| --- | --- |
| `v` | 存档版本，固定 `1`；读到不认识的版本按空存档处理（不覆盖、不猜） |
| `users[who].total` | 该人累计卦数（用于 `history.total` 与"第几卦"） |
| `users[who].lastAt` | 这个人最后一次起卦的时间戳，**淘汰顺序靠它** |
| `records[]` | 新的在前；只存 `at / number / rating / question / moving / changed` |
| `moving` | 动爻位号数组，如 `[2, 5]`（不存爻名，读的时候按卦推） |
| `changed` | 变卦卦序，无动爻为 `null` |

**纪律**（宿主硬上限：单值 ≤32KB、总 256KB、每分钟 ≤120 写）：

1. 一次工具调用**最多 1 次读 + 1 次写**。`cast` 是"读一次 → 改 → 写一次"；`history` 只读一次。
2. 每人 `records` 超过 `historyPerUser` 就丢最旧的（只丢这个人自己的，不牵动别人）。
3. 序列化后总占用超过预算（建议 **28KB**，给宿主 32KB 留余量）时，按 `lastAt` 最旧淘汰**整个用户**，
   直到回到预算内；正在算卦的这个人**最后才淘汰**（不要为腾地方把这次刚算的卦丢了）。
4. 读失败 = 当成空存档（`cast` 继续掷卦，但这次不记）；写失败 = 这次不记。
   **两种都不算失败**：`ok:true` + `record.recorded=false` 或 `warning.code=E_STORAGE_DEGRADED`，
   且 `advise` 里明确"不要说已经记好了"。
5. 存档只记"算过什么卦"，**不记** `question` 全文（只前 40 字）、不记模型写的断语。

## 设置（`configSchema` 四项）

| 键 | 类型 | 默认 | 说明 | 代价 |
| --- | --- | --- | --- | --- |
| `enabled` | boolean | `true` | 插件总开关 | 关掉后两个工具消失、调用 `E_DISABLED`；卦史还在但查不了 |
| `tone` | `"daozhang"` / `"straight"` | `daozhang` | 口吻：道长腔 / 正经话术 | 只改 `flavor.persona` 与话术方向，**不掷骰子**；两种口吻的卦与评级完全一样 |
| `recordHistory` | boolean | `true` | 是否记卦史 | 关掉后完全不碰 storage，`history` 永远 `E_NOT_FOUND` |
| `historyPerUser` | number | `10` | 每人留几卦（1–20） | 留得越多越容易触发"淘汰整个用户"；调小后老卦真的没了，无备份 |

设置从 `cap.config.get` 读**自己这一段**（`plugins.settings.suan-gua`）。缺省值见上表；
非法值（如 `historyPerUser: 999`）夹到 1–20 的边界并记一条 `cap.log.write` 警告——
**设置读不到时不报错**，按默认值继续服务（配置面板一时写坏不该让功能停摆）。

## 隐私

- 存的是**群里的昵称或 QQ 号明文**（`who`）+ 时间 + 卦序 + 评级 + `question` 前 40 字。
  不存聊天原文、不存上下文、不存模型输出。
- 数据只在宿主的数据目录里（`plugin-data/suan-gua/`）；**插件进程自己一个字节都不落盘**，
  也读不到别的插件的数据与宿主凭据。
- 不想留痕：把 `recordHistory` 关掉，或起卦时不传 `who`（`record.recorded=false`）。
- 卸载插件**不会**删这份存档（宿主的既定行为）；要彻底清掉得手动删目录。

## 已知限制

1. **不联网、不写文件、不 spawn**：只用 `node:` 内置模块，零第三方依赖。
2. **不保证灵验**：卦是真摇的（均匀随机），吉凶是传统评级的近似，属于娱乐，不构成任何建议。
3. **模型可能不传 `who`**：插件无法强制。没传就这次没记，`history` 也查不到；返回的
   `advise` 会要求它下次带上，但最终取决于模型。
4. **模型可能照抄素材**：`flavor` 只给方向，插件没有语义审核能力，改写得对不对只能靠提示词
   约束与人工抽查。
5. **评级是固定的表**：同一卦永远同一档，不会因为谁算、问了什么而变——这是设计（否则"改命"的说法
   就成立了）。
6. **`hint` 不针对具体事**：`moving[].hint` 是爻位通用判词 + 评级微调，四段里真正"对症"
   的部分必须由模型写。
7. **红线靠提示词兜底**：`taboos` 不放成人向、政治、真人隐私、医疗诊断与投资建议的内容；模型侧的
   `prompt` 与 `advise` 写的是同一套约束，但插件无法在执行时判定语义。
8. **消息条数：默认 1 条，最多 2 条**。整卦一条消息说完（四段用换行分段），只有对方明确要求分段或确实
   超长才拆，任何一段不许再拆；模型若违反（例如把四段 + 短词表 + 三道符拆成 10 条）属**实现缺陷**，
   不是插件给的可选口径——插件没有发送能力，拦不住发送次数，只能在 `advise` / `prompt` / 工具描述里
   把口径写死。

## 单测约定（实现侧）

单文件 `index.mjs` 要能被当模块 `import`，**只有作为主模块运行时才启动 stdin 的 NDJSON 循环**：

```js
if (import.meta.url === pathToFileURL(process.argv[1] || '').href) main();
```

建议导出的纯函数（名字以实现为准，但这几条**能力**验收要用到）：

| 能力 | 作用 |
| --- | --- |
| 卦表 / 常量 | 64 条卦表（number/name/fullName/upper/lower/rating/judgment）与五档评级 |
| 装卦 | 由六个 value 推出本卦、上下卦、评级、动爻、变卦——不含随机性，可纯函数验证 |
| 摇卦 | 接受注入的 `rng`，返回 6 个 value；同一序列必须复现同一卦 |
| 爻名 / 动爻文字 | value + index → 初九 … 上六；动爻数组 → `六二、九五动` / `无动爻` |
| 存档 | 归一化脏存档、按 `historyPerUser` 截断、按 `lastAt` 淘汰、序列化字节数 |
| 工具入口 | `runTool(ctx, name, args)` 或等价物，`io`（read/write/now/warn/rng）可注入 |
| 设置归一化 | `tone` / `recordHistory` / `historyPerUser` / `enabled` 的缺省与夹边界 |

关键算例（可以直接抄成断言）：

- 六爻全 `7` → 本卦「乾为天」（1），动爻 0 条，`changed: null`，`changeSummary: null`，
  `history` 里 `movingText` 为 `无动爻`；
- 六爻全 `6` → 本卦「坤为地」（2），六爻全动，变卦「乾为天」，动爻 6 条，`changeSummary` 以
  `初六、六二、六三、六四、六五、上六动 → 变卦：` 开头；
- 上下卦最容易写反：**`index 1–3 是下卦（内），4–6 是上卦（外）**；给了 value 序列就能算出
  `upper` / `lower` 时，先取 `lines[3..6]` 为上、`lines[1..3]` 为下；
- `history` 的 `limit=0` / `limit=11` / `limit=1.5` → 全部 `E_ARGS`；`limit` 缺省 → 5 条。

## 本地怎么验

```bash
# ① plugin.json 是合法 JSON，且过宿主真实的 manifest 校验器（fail-closed）
node --input-type=module -e "
import { readFileSync } from 'node:fs'; import path from 'node:path';
import { parsePluginManifest } from './.work/manifest.mjs';
const raw = JSON.parse(readFileSync('suan-gua/plugin.json','utf8'));
const r = parsePluginManifest(raw, { dir: path.resolve('suan-gua') });
console.log(r.ok ? 'manifest OK ' + r.manifest.tools.map(t => t.name) : 'FAIL ' + r.error);"

# ② 真协议 + 假宿主（config / storage / log 都已实现）：起一卦 -> 查卦史
node .work/jm-harness.mjs ./suan-gua '{"enabled":true,"tone":"daozhang"}' \
  '{"calls":[{"name":"cast","args":{"who":"验收甲","question":"明天面试能不能过"}},{"name":"history","args":{"who":"验收甲"}}]}'

# ③ 错误路径：参数超长 / 没记录 / limit 越界 / 插件关掉
node .work/jm-harness.mjs ./suan-gua '{"enabled":true}' \
  '{"calls":[{"name":"history","args":{"who":"查无此人"}},{"name":"history","args":{"who":"验收甲","limit":99}},{"name":"cast","args":{"who":"01234567890123456789012345678901234567890"}}]}'
node .work/jm-harness.mjs ./suan-gua '{"enabled":false}' '{"name":"cast","args":{}}'

# ④ 存档降级：让 storage 读写抛错，cast 仍要 ok:true 且带 warning.code=E_STORAGE_DEGRADED
#    （.work/gacha-degrade-host.mjs 是同类用例的现成写法，照它改一个 suan-gua 版本）
```

验收要看的四件事：

1. `cast` 的 `lines` 恰好 6 条、`index` 1..6 递增、`value` ∈ {6,7,8,9}，
   `moving` 与 `lines[].moving` 完全对应；`changed` 与 `moving` 同空同有；
2. 同一份存档连调两次 `cast` 后 `total` 递增、`history` 新的在前、`limit` 生效；
3. `recordHistory=false` 时 storage 的读/写次数都是 **0**，`record.recorded=false`，
   `history` → `E_NOT_FOUND`；
4. 400 个 `who` 各算 3 卦后存档序列化 ≤28KB，且每人 `records` ≤ `historyPerUser`。

## 协议纪律（容易踩的两条）

- **`shutdown` 回执要判 id**：宿主退出时发的是**不带 id** 的 `shutdown`，无条件
  `write({ id: msg.id, result: {} })` 会序列化成 `{"result":{}}`，宿主记一条 `protocolErrors`。
  写法：`if (msg.id !== undefined && msg.id !== null) write({ id: msg.id, result: { ok: true } });`
- **工具调用硬超时 20 秒**：本插件全是内存计算 + 一次 storage，正常在 10ms 量级，不需要自建超时预算。
