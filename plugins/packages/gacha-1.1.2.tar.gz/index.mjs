// 抽卡（gacha）—— 「抽一张卡」的娱乐插件：等级 / 星级 / 词条全部由内置卡池生成，
// 文案交给模型转述。零依赖、单文件 ESM、不联网、不写文件；唯一的持久化走宿主的
// cap.storage（单键读-改-写，一次工具调用只写一次）。
//
// ── 为什么随机只在这里发生 ────────────────────────────────────────────
// 让模型自己「抽」会把 0.6% 的 ??? 抽成家常便饭，也会把 N 说成 SSR。所以概率只有一处来源
// （pickTier 的整数万分比权重表），模型拿到的是既成事实，只能转述。
//
// ── 为什么 who 必须由模型传 ──────────────────────────────────────────
// 宿主的 callTool 只发 {name, args}，**不带 chatKey / uid**（已核实）。插件根本不知道是谁在
// 抽，所以「谁抽的卡」只能由模型从对话里取出来当参数传；缺省时不报错、照抽，但返回里写明
// recorded=false（只抽不记），避免模型谎称「已经记进你的图鉴」。
//
// ── 卡名与词条：模型创作，池子只当素材 ────────────────────────────────
// 插件只掷「等级 + 概率」——这是本轮的官方结果，任何档位下都不许改。卡名与词条按
// flavorMode 分三档：
//   free（默认）  模型自己起池子里没有的卡名、自己写全部词条，lines 只是同风格素材与兜底；
//   extend        卡名用池子的，词条照 lines 转述 + 可再加 1–2 条；
//   off           完全照抄（旧行为，适合完全不想让模型改一个字风的场合）。
// 默认 free 是因为「照抄」会把模型变成复读机。自创完由模型调 save_card 回执，图鉴才记得下自创卡名。
import path from 'node:path';
import { pathToFileURL } from 'node:url';

// 插件 id / 版本：probe 回执里要报（控制台打开设置页时会先调一次 probe）。
export const PLUGIN_ID = 'gacha';
export const PLUGIN_VERSION = '1.1.2';

// ───────────────────────── 配置默认值 ─────────────────────────

export const DEFAULTS = Object.freeze({
  enabled: true,
  count: 1,
  maxCount: 10,
  flavorMode: 'free',
  recordHistory: true
});

/** 词条档位：off 只照抄 / extend 照抄+加 1-2 条 / free 模型自创（默认）。 */
export const FLAVOR_MODES = Object.freeze(['off', 'extend', 'free']);

/**
 * flavorMode 归一化。向后兼容：配置里**没有** flavorMode 时读旧布尔项 allowModelFlavor
 * （false → off，true → free）；两者都没有按默认 free。认不出的值也按 free 处理，不报错。
 */
export function normalizeFlavorMode(raw, legacyAllowModelFlavor) {
  const text = String(raw ?? '').trim().toLowerCase();
  if (FLAVOR_MODES.includes(text)) return text;
  const hasMode = raw !== undefined && raw !== null && String(raw).trim() !== '';
  if (!hasMode && legacyAllowModelFlavor !== undefined && legacyAllowModelFlavor !== null && legacyAllowModelFlavor !== '') {
    return toBool(legacyAllowModelFlavor, true) ? 'free' : 'off';
  }
  return 'free';
}

/** count 的硬上限（与 plugin.json 的 schema 一致；maxCount 只能在此之下收窄）。 */
export const MAX_DRAW_COUNT = 10;
/** top 的硬上限。 */
export const MAX_TOP = 20;
/** who 的长度上限：它同时是 storage 里的对象键，太长会撑爆存档。 */
export const MAX_WHO = 40;
/** save_card 的 lines 上限：只用来数条数（词条不入存档）。 */
export const MAX_CUSTOM_LINES = 6;

// ───────────────────────── 等级表 ─────────────────────────

/**
 * bp = 万分之一（basisPoints）。用整数权重是因为「六个概率之和恰好等于 100%」这件事必须能被
 * 断言，浮点只在最后一步 rate = bp / TOTAL_BP 出现。词条条数严格随等级递增：1/2/3/4/5/6。
 */
export const TIERS = Object.freeze([
  Object.freeze({ tier: 'N', stars: 1, bp: 5200, lines: 1 }),
  Object.freeze({ tier: 'R', stars: 2, bp: 2600, lines: 2 }),
  Object.freeze({ tier: 'SR', stars: 3, bp: 1300, lines: 3 }),
  Object.freeze({ tier: 'SSR', stars: 4, bp: 600, lines: 4 }),
  Object.freeze({ tier: 'UR', stars: 5, bp: 240, lines: 5 }),
  Object.freeze({ tier: '???', stars: 6, bp: 60, lines: 6 })
]);

export const TIER_KEYS = Object.freeze(TIERS.map((t) => t.tier));
const TIER_INDEX = new Map(TIERS.map((t, i) => [t.tier, i]));
const TOTAL_BP = TIERS.reduce((sum, t) => sum + t.bp, 0);
/** 每级的概率：rateOf('N') === 0.52 … rateOf('???') === 0.006，六个加起来是 1。 */
export const TIER_RATES = Object.freeze(
  Object.fromEntries(TIERS.map((t) => [t.tier, t.bp / TOTAL_BP]))
);

export function rateOf(tier) {
  const spec = tierSpec(tier);
  return spec.bp / TOTAL_BP;
}

function tierSpec(tier) {
  const key = String(tier ?? '');
  for (const spec of TIERS) if (spec.tier === key) return spec;
  return TIERS[0];
}

// ───────────────────────── 内置卡池 ─────────────────────────
// 元组顺序：[卡名, kind, 手写 hook（可选，占掉一条词条的位置）]
// hook 只加在 SR 及以上（那些等级的词条数 ≥3），保证 N/R 的同一张卡重抽必定换组合。

// neutral = 原来的日常/抽象池，一条都不删（切回 tone=neutral 时行为必须与旧版完全一致）。
const NEUTRAL_POOLS = {
  N: [
    ['电饭煲', 'object'], ['拖鞋', 'object'], ['遥控器', 'object'], ['保温杯', 'object'],
    ['塑料袋', 'object'], ['台灯', 'object'], ['充电线', 'object'], ['折叠伞', 'object'],
    ['机械键盘', 'object'], ['鼠标垫', 'object'], ['螺丝刀', 'object'], ['订书机', 'object'],
    ['便利贴', 'object'], ['垃圾桶', 'object'], ['拖把', 'object'], ['抱枕', 'object'],
    ['闹钟', 'object'], ['指甲刀', 'object'], ['保鲜膜', 'object'], ['泡面碗', 'object'],
    ['牙膏', 'object'], ['电风扇', 'object'], ['插线板', 'object'], ['洗衣液', 'object'],
    ['塑料挂钩', 'object'], ['小板凳', 'object'], ['卷尺', 'object'], ['手电筒', 'object'],
    ['计算器', 'object'], ['橡皮擦', 'object'], ['水果刀', 'object'], ['砧板', 'object'],
    ['保温饭盒', 'object'], ['钥匙串', 'object'], ['晾衣架', 'object'], ['矿泉水瓶', 'object'],
    ['空气炸锅', 'object'], ['微波炉', 'object'], ['一次性筷子', 'object'], ['地毯', 'object'],
    ['快递纸箱', 'object'], ['洗手液', 'object'], ['小夜灯', 'object'], ['蚊香', 'object'],
    ['公交卡', 'object'], ['冰箱贴', 'object'], ['流浪猫', 'animal'], ['楼下的麻雀', 'animal']
  ],
  R: [
    ['加了双蛋的煎饼', 'food'], ['深夜的便利店', 'place'], ['会唱歌的电热水壶', 'object'],
    ['半自动咖啡机', 'object'], ['二手自行车', 'object'], ['阳台上的绿萝', 'plant'],
    ['沙发缝里的硬币', 'object'], ['说完梦话的加湿器', 'object'], ['隔壁的钢琴声', 'event'],
    ['一只橘猫', 'animal'], ['加班到十点的地铁', 'place'], ['自动售货机的灯', 'object'],
    ['用旧的皮夹', 'object'], ['食堂的糖醋排骨', 'food'], ['会自己回消息的键盘', 'object'],
    ['楼下便利店的关东煮', 'food'], ['凌晨三点的外卖', 'food'], ['掉在床底下的耳机', 'object'],
    ['打折的羽绒服', 'object'], ['小区门口的修车摊', 'place'], ['刚出炉的蛋挞', 'food'],
    ['会数数的扫地机器人', 'object'], ['贴满计划的便利贴', 'object'], ['一只戴铃铛的柴犬', 'animal'],
    ['会变色的马克杯', 'object'], ['早班车的靠窗位', 'place'], ['影院最后一排', 'place'],
    ['打烊前的面包柜', 'object'], ['会讲价的菜市场', 'place'], ['一盒没拆的拼图', 'object'],
    ['去年冬天的围巾', 'object'], ['会飘雪的玻璃球', 'object'], ['清晨的豆浆油条', 'food'],
    ['没看完的漫画', 'object'], ['会等人的自动贩卖机', 'object']
  ],
  SR: [
    ['未寄出的信', 'object', '信封上的收件人一栏是空的。'],
    ['隔壁没开门的房间', 'place'], ['雨停前的三分钟', 'event'], ['借来的伞', 'object'],
    ['半句话的梦', 'concept'], ['会重复的走廊', 'place'], ['深夜的自动洗衣机', 'object'],
    ['没有编号的街', 'place'], ['记忆里潮湿的夏天', 'concept'], ['会丢失重量的石头', 'object'],
    ['站台上的第七分钟', 'event'], ['会认人的旧电梯', 'object'], ['空房间的回声', 'concept'],
    ['昨天的天气预报', 'concept'], ['会慢慢变冷的汤', 'food'],
    ['只在下雨时开的花', 'plant', '花期只有一个下午，而且从没人拍到过。'],
    ['半透明的猫', 'animal'], ['走不完的楼梯', 'place'], ['会自己翻页的日历', 'object'],
    ['借给别人的影子', 'concept'], ['一段被剪掉的录音', 'object'], ['第三个人的座位', 'place'],
    ['会说话的镜子', 'object'], ['打不通的号码', 'concept'], ['掉帧的黄昏', 'event'],
    ['一直没长高的树', 'plant'], ['会自己亮的台灯', 'object'], ['时间之外的单程票', 'object'],
    ['名字被涂掉的信箱', 'object', '邮编还在，地址没有了。'], ['不属于任何人的钥匙', 'object']
  ],
  SSR: [
    ['逆流的河', 'place'], ['没有影子的钟楼', 'place'], ['会说话的甲虫', 'animal'],
    ['一整座失眠的城', 'place'], ['第三次日出', 'event'], ['会做梦的废墟', 'place'],
    ['正在冷却的太阳', 'object'], ['名字被抹掉的骑士', 'being'], ['会自己走路的衣柜', 'object'],
    ['打烊之后的海', 'place'], ['别人的记忆', 'concept', '借来的那部分，你分得清吗。'],
    ['会返回的潮汐', 'event'], ['十二点的列车', 'object'], ['会唱歌的玻璃棺', 'object'],
    ['逆生的森林', 'place'], ['空白的航海图', 'object'], ['一直在等你的门', 'object'],
    ['会吃掉时间的沙漏', 'object', '翻过来一次，就少一个小时。'],
    ['沉默的守夜人', 'being'], ['第七个季节', 'event']
  ],
  UR: [
    ['折叠的星图', 'object'], ['会重写历史的笔', 'object'], ['归零之海', 'place'],
    ['无名的守门人', 'being'], ['逆流者', 'being'], ['会吞下黎明的兽', 'animal'],
    ['千年一遇的潮', 'event'], ['没有出口的图书馆', 'place', '书都在，只有墙没有窗。'],
    ['被遗忘的神龛', 'place'], ['时间背面的一行字', 'concept'], ['永夜的信使', 'being'],
    ['会走路的月亮', 'object']
  ],
  '???': [
    ['未命名的第零号', 'being'], ['谁在敲门', 'concept'], ['无法被记录的观测者', 'being'],
    ['所有结局的合集', 'concept'], ['名字之前', 'concept', '在它出现之前的那个东西。'],
    ['尽头之外的那句话', 'concept'], ['不该存在的第八天', 'event']
  ]
};

// yang = 阴阳池：只阴阳「事 / 物 / 泛化身份」，不点名真人。
// 三条用户给定示例（等级与 hook 原句照抄）：鱼缸金鱼 SR「会吃不会说」/ 电饭锅 UR「里面还剩半锅白饭，不是给你的」/ 食堂打饭阿姨 SSR「手抖得比你多」。
// hook 只挂在 SR 及以上（那些等级词条 ≥3 条），保证 N/R 的同一张卡重抽必定换组合。
const YANG_POOLS = {
  N: [
    ['保温杯', 'object'], ['通勤背包', 'object'], ['工位显示器', 'object'], ['无线鼠标（第三个）', 'object'],
    ['会议纪要', 'object'], ['打卡机', 'object'], ['加班餐补', 'concept'], ['门禁卡', 'object'],
    ['快递纸箱', 'object'], ['一次性拖鞋', 'object'], ['外卖塑料袋', 'object'], ['共享单车', 'object'],
    ['地铁扶手', 'object'], ['电梯里的镜子', 'object'], ['打印店的名片', 'object'], ['团建通知', 'concept'],
    ['电子发票', 'object'], ['键盘上的油光', 'object'], ['空了的纸巾盒', 'object'], ['隔夜咖啡', 'food'],
    ['微波炉饭盒', 'object'], ['会议室的名牌', 'object'], ['工牌挂绳', 'object'], ['掉漆的转椅', 'object'],
    ['三合一充电线', 'object'], ['塑料绿萝', 'plant'], ['工位隔板', 'object'], ['楼下便利店的关东煮', 'food'],
    ['食堂的不锈钢盘', 'object'], ['空调出风口', 'object'], ['贴歪了贴纸的笔记本', 'object'], ['待办清单', 'object'],
    ['未读消息 999+', 'concept'], ['记不住的那个密码本', 'object'], ['会议室墙上的钟', 'object'],
    ['二手的显示器支架', 'object'], ['免费提供的矿泉水', 'object'], ['加班报销单', 'object'],
    ['折叠脸盆', 'object'], ['通勤鞋', 'object'], ['桌面小风扇', 'object'], ['没电的充电宝', 'object'],
    ['保温饭盒', 'object'], ['墙上的励志标语', 'concept']
  ],
  R: [
    ['会响的打印机', 'object'], ['永远在维修的电梯', 'object'], ['公司发的月饼', 'food'],
    ['团建的大巴', 'place'], ['凌晨的关东煮', 'food'], ['饮水机上的水桶', 'object'],
    ['周五下午的会', 'event'], ['锁着的免费健身房', 'place'], ['请假流程', 'concept'],
    ['打卡范围外的早点摊', 'place'], ['老板的语音条', 'object'], ['甲方的最新想法', 'concept'],
    ['实习生转正答辩', 'event'], ['一家三口的共享单车', 'object'], ['加了双蛋的加班餐', 'food'],
    ['团购的速溶咖啡', 'food'], ['通勤的最后一公里', 'event'], ['工位上的假绿植', 'plant'],
    ['只响不亮的台灯', 'object'], ['午休的折叠床', 'object'], ['楼道里的外卖柜', 'object'],
    ['人均八十的团建餐', 'food'], ['早八的地铁换乘', 'event'], ['排队两小时的网红店', 'place'],
    ['年会的抽奖箱', 'object'], ['老板画的饼（印刷版）', 'food'], ['会自己关机的笔记本', 'object'],
    ['会议室的投影仪', 'object'], ['只发一半的工资条', 'object'], ['楼下会跑路的理发店', 'place'],
    ['食堂的免费例汤', 'food'], ['通勤路上的共享雨伞', 'object'], ['只剩一格电的手机', 'object']
  ],
  SR: [
    ['我家鱼缸里那条金鱼', 'animal', '会吃不会说'],
    ['会挑刺的沙发', 'object'], ['永远在「稍后回复」的对话框', 'concept'], ['团建照片里的我', 'concept'],
    ['只会转发通知的群', 'concept'], ['三分钟热度的健身卡', 'object'], ['一到周末就下雨', 'event'],
    ['点赞之交', 'concept'], ['复盘会上的「下次注意」', 'concept'], ['简历上的「精通」', 'concept'],
    ['开工第一天的决心', 'concept'], ['会自己长回来的待办', 'concept'], ['朋友圈的分组可见', 'concept'],
    ['通勤耳机里的白噪音', 'object'], ['五年陈的 KPI', 'concept'], ['只对账不对人的财务', 'concept'],
    ['会演戏的体重秤', 'object'], ['一直响的洗衣机', 'object'], ['楼下的猫（不让你摸）', 'animal'],
    ['半夜的工作群', 'concept'], ['加了备注的通讯录', 'object'], ['假期的最后一天', 'event'],
    ['会漏水的信心', 'concept'], ['纪要里的「已达成共识」', 'concept'], ['只用过一次的空气炸锅', 'object'],
    ['说好一起早睡的群友', 'concept']
  ],
  SSR: [
    ['食堂打饭阿姨', 'being', '手抖得比你多'],
    ['会点头的甲方', 'being'], ['只说「在吗」的同事', 'being'], ['永远在开会的经理', 'being'],
    ['出差报销的审批人', 'being'], ['通勤路上的人形闹钟', 'being'], ['会讲价的房东', 'being'],
    ['认识所有人的保安', 'being'], ['永远准点的下班打卡', 'event'], ['会写周报的 AI', 'being'],
    ['传说中的「隔壁组」', 'place'], ['凌晨三点的工作群', 'concept'], ['年会上最会演的同事', 'being'],
    ['会在群里 @全体 的人', 'being'], ['一喊就到的外卖小哥', 'being'], ['永远排到最后的体检', 'event'],
    ['会自我感动的加班', 'concept'], ['只看标题就转发的亲戚', 'being']
  ],
  UR: [
    ['电饭锅', 'object', '里面还剩半锅白饭，不是给你的'],
    ['会自己续杯的保温杯', 'object'], ['永远不凉的加班夜', 'event'], ['会做梦的周报', 'concept'],
    ['只在月底出现的余额', 'concept'], ['通勤路上的第三年', 'event'], ['会自我修复的 KPI', 'concept'],
    ['永远在路上的快递', 'object'], ['记住所有人的门禁', 'object'], ['一种叫「还可以」的评价', 'concept'],
    ['会自己加班的键盘', 'object'], ['永远不会开的窗', 'object']
  ],
  '???': [
    ['老板的「简单聊两句」', 'concept'], ['永远在路上的「以后再说」', 'concept'],
    ['一份没有署名的加班', 'concept'], ['会背锅的显示器', 'object'],
    ['朋友圈里的人生赢家', 'concept'], ['一场没有议程的会', 'event'],
    ['会自己写评语的绩效', 'concept']
  ]
};

const POOLS = { yang: YANG_POOLS, neutral: NEUTRAL_POOLS };

/** 卡片风格：yang 阴阳（默认）/ neutral 原来的日常抽象。 */
export const TONES = Object.freeze(['yang', 'neutral']);

/** 认不出的 tone 一律按 yang（默认阴阳，用户要的就是这个）。 */
export function normalizeTone(raw) {
  const text = String(raw ?? '').trim().toLowerCase();
  return TONES.includes(text) ? text : 'yang';
}

// ───────────────────────── DENY 名单（兜底） ─────────────────────────
// 真正的关卡是人工把关卡池（本文件里没有任何真实政治人物）。这道过滤只是运行时兜底：
// 一旦有人往池子里塞进这类名字，抽卡会直接跳过它、权重顺延给同等级其它卡，而不是抽出来。
// 用「称谓 + 敏感词」形状而不是列具体人名，避免把名字本身写进插件代码。
export const DENY_PATTERNS = Object.freeze([
  '主席', '总书记', '总统', '首相', '总理', '天皇', '教皇', '元首', '独裁者', '委员长',
  '大统领', '领袖', '革命家', '政治犯', '法西斯', '纳粹'
]);

export function isDeniedName(name) {
  const text = String(name ?? '').trim();
  if (!text) return true;
  const low = text.toLowerCase();
  return DENY_PATTERNS.some((p) => low.includes(String(p).toLowerCase()));
}

const CARD_CACHE = new Map();

/** 某个等级**过滤后**的卡池。DENY 命中的卡在这里就被剔掉，抽卡时权重自然顺延。 */
function cardsOf(tier, tone = 'yang') {
  const which = normalizeTone(tone);
  const key = which + '|' + tierSpec(tier).tier;
  if (CARD_CACHE.has(key)) return CARD_CACHE.get(key);
  const list = ((POOLS[which] || {})[tierSpec(tier).tier] || [])
    .map(([name, kind, hook]) => ({ name: String(name ?? ''), kind: String(kind ?? 'object'), hook: String(hook ?? '') }))
    // DENY 过滤对两套池子一视同仁：命中即剔除，同等级其它卡等概率顺延。
    .filter((card) => card.name && !isDeniedName(card.name));
  CARD_CACHE.set(key, list);
  return list;
}

/** 某套 tone 某个等级（过滤后）的全部卡名——给验收做「抽到的名字必须来自这套池子」的包含校验。 */
export function cardNamesOf(tier, tone = 'yang') {
  return cardsOf(tier, tone).map((card) => card.name);
}

/** 某套 tone 某个等级的词条池原文（同样给验收用）。 */
export function flavorLinesOf(tier, tone = 'yang') {
  return ((FLAVORS[normalizeTone(tone)] || {})[tierSpec(tier).tier] || []).slice();
}

/** 每套 tone 每个等级过滤后还剩几张卡（README 的承诺，也是一条可断言的承诺）。 */
export const CARD_COUNTS = Object.freeze(
  Object.fromEntries(TONES.map((tone) => [
    tone,
    Object.fromEntries(TIER_KEYS.map((t) => [t, cardsOf(t, tone).length]))
  ]))
);

/** 名字 → 等级，给「热门卡」显示等级用。两套池子同名不同级时以 yang 为准（只影响热门榜的展示）。 */
const TIER_OF_CARD = new Map();
for (const tone of ['neutral', 'yang']) {
  for (const t of TIER_KEYS) for (const card of cardsOf(t, tone)) TIER_OF_CARD.set(card.name, t);
}

// ───────────────────────── 词条池 ─────────────────────────
// 每级 ≥30 条，风格分层：N/R 日常具象，SR 起偏抽象，UR/??? 传奇化。
// {name} 会被替换成卡名。

// neutral = 原来的词条池，一条都不删。
const NEUTRAL_FLAVORS = {
  N: [
    '有点旧，但还能用。', '边缘有一道看不出来的划痕。', '拿起来比看上去轻。',
    '总在需要的时候找不到。', '便宜货，但意外地耐用。', '上面贴着一张早就褪色的标签。',
    '用久了会发出轻微的声音。', '落了一层薄薄的灰。', '手感很熟，像是用了很多年。',
    '放在桌上会挡住一半的光。', '有人试过修它，没修好。', '每次搬动都要小心一点。',
    '一直摆在同一位置，没人动过。', '有点味道，说不清是什么。', '买回来之后就没怎么用过。',
    '有时候会自己滑到桌边。', '现在还在保修期内。', '二手市场二十块钱淘的。',
    '上面留着一圈水渍。', '比同类产品安静一些。', '线有点短。',
    '一直插在插座上没拔过。', '偶尔需要拍两下才好。', '冬天摸上去很凉。',
    '被小孩拿去玩过一次。', '边角已经磨圆了。', '说明书早就丢了。',
    '属于那种「总得有一个」的东西。', '收进柜子里就忘了。', '看起来比实际年龄年轻。',
    '被人偷偷擦干净过。', '用它能做成的最好的事很有限。', '有股淡淡的洗衣粉味。',
    '打算换掉，一直没换。', '摆在货架最下面那层。'
  ],
  R: [
    '它记得自己被人夸过一次。', '用坏了也不心疼，但一直没坏。', '有一种「刚好够用」的精确。',
    '深夜的时候会显得比白天新。', '碰到它就会想起某个具体的人。', '上面留着别人的字迹。',
    '用法有很多种，没人用完过。', '从别处流通过来的。', '它自己大概不知道自己很贵。',
    '有时候会响得不是时候。', '在安静的地方显得格外大声。', '有一点不属于它的气味。',
    '一直放在门口，谁都能拿。', '曾经被当作礼物送出去过。', '见过很多次告别。',
    '摆在这里是为了让人看见。', '偶尔会被误认成更贵的那种。', '用它的通常是同一个时间段。',
    '它的主人换过三次。', '说明书上说不要靠近水。', '总在快坏的时候表现最好。',
    '从很远的地方带回来的。', '有一点点歪，但不影响用。', '只在人少的时候才显得对。',
    '打了折之后才被买下的。', '被写进过某个人的日记。', '它身上有一处补过的痕迹。',
    '会漏出一点点东西。', '被人认真比较过价格。', '和另一件东西总是一起出现。',
    '上面沾着一点机油。', '开合的时候有个固定的角度。'
  ],
  SR: [
    '它的边界比看上去模糊。', '你越描述它，它越不像。', '它在你转身之后才存在。',
    '声音先到，形状后到。', '记忆是它唯一的原料。', '它借用了某个下午的光。',
    '每次回想都少一点细节。', '它只在对的时候被认出来。', '里面装着一段没发生的事。',
    '它的重量随时间改变。', '你确认过的部分最不牢靠。', '它出现的时间总是提前一点。',
    '有人在里面留了言，没人收到。', '它拒绝被计数。', '影子比本体更真实。',
    '你可以进去，但出不来同一个地方。', '它从不重复同一个答案。', '边缘还留着被删掉的痕迹。',
    '它喜欢安静的房间。', '靠近它会听见自己的呼吸。', '它是别人叙述里的一段。',
    '颜色取决于当时的天色。', '只在关灯后才完整。', '它有自己的作息。',
    '摸上去不冷也不热。', '它记得你来过。', '你一开口它就变了。',
    '提示很少，代价很高。', '它不属于任何一个季节。', '一半是猜测，一半是空白。',
    '它在等一个不会来的确认。', '它把提问也当成了回答。'
  ],
  SSR: [
    '目击者的说法互相矛盾。', '它出现过的城市会有一阵子不下雨。', '记录它的人后来都不再说话。',
    '所有地图上都留了它的位置，但没人指得出来。', '它在时间上有一个接缝。',
    '每一次描述都会让它更旧一点。', '它曾经是人，这一点没人敢确定。', '它出现时，钟表会慢一秒。',
    '见过它的人开始做同一个梦。', '它从一段被删除的历史里被捞出来。', '它不接受名字。',
    '它的边界上有一整排被抹掉的字。', '它只在有人彻底放弃时才出现。', '传说里它是代价，不是奖赏。',
    '它让所有人都想起同一件事。', '它需要被忘记才能继续存在。', '它的影子和它不同步。',
    '有人为它改写了自己的姓氏。', '它走过的路后来都不长草。', '它从不说自己是什么。',
    '它有一个被划掉的名字。', '它的一端插在别的年份里。', '它在夜里会往北移动一点。',
    '它出现之后，那个地方改了名。', '它是某个结局的原因。', '它不属于任何一个传说里的角色。',
    '它被三份文件同时否认过。', '靠近它会想起不属于自己的童年。', '它保留着一句没说完的话。',
    '它把观者也收进了自己的记录。', '它在等它自己的下一次出现。'
  ],
  UR: [
    '关于它的一切记录都被改写过三次。', '它诞生于一句没有说完的道歉。', '太阳的位置因它偏移过。',
    '它对时间的态度是「借用」。', '它在你叫出它名字之前就先回答。', '所有关于它的叙述都以「据说」开头。',
    '它不能同时存在于两个传说里。', '它把潮汐当作一种语言。', '它收留过一段被放弃的永恒。',
    '它从不年轻，也从不老。', '通往它的路会自己改道。', '它是不该被命名的那种东西之一。',
    '它把每次相遇都记成第一次。', '它的影子落在别的季节。', '它给过七次承诺，兑现了六次。',
    '门后面是门本身。', '它是某个文明留下的错误。', '它一开口，历史就重排一次。',
    '它记得所有人，但没人记得它。', '它把黑暗当作储存方式。', '它出现的地方，方向会失效。',
    '它既是守门人，也是门。', '它被写下过，又被擦掉过。', '它用「还能再见」当封印。',
    '它只在结局之后出现一次。', '它的沉默被当成天象记录了下来。', '它的名字一旦被念完就不再存在。',
    '它是所有传说的共同来源。', '它要求你留下一件不能带走的东西。', '它把时间花在了等待上。',
    '它的注视有重量。'
  ],
  '???': [
    '它不是一个物件，而是一个还没有被填上的位置。', '描述它的句子会自己删掉自己。',
    '没有人第一次见到它。', '它的名字在被念出的同一秒被收回。', '它既是问题，也是拒绝回答。',
    '它不在这条时间线上，但它知道你在哪。', '记录它的人写到这里就停了。',
    '它在每个传说里负责「之后」。', '它把所有的结局折成一句「再等等」。',
    '它与观测者的关系是互为因果。', '它从不出现在同一张照片里两次。',
    '它让「之前」和「之后」变成了同一个词。', '它存在的证据是它的缺席。',
    '它是所有被删掉的段落想要的东西。', '它在你转身时换了一次内容。',
    '它的位置被很多人占据过，每一次都是它。', '它说话时，语言会先老去。',
    '它把时间当作随身物品。', '它不承诺任何事，包括存在。', '它只在第四次之后才是真的。',
    '它把提问者写进了答案里。', '它不需要被理解，只需要被提起。',
    '它把自己保存成了别人的记忆。', '它的边界之外也是它。',
    '它允许自己被描述，但不允许被记住。', '它是最初那句「如果」的剩余部分。',
    '它出现的地方，计数会失效。', '它把「接下来」当成一种材料。',
    '它把所有未完成的东西收在一起。', '它从不重复，包括它自己。',
    '它的沉默与它说的话意思不同。'
  ]
};

// yang = 阴阳词条：表面在夸、实际在损，短、准、不骂脏字、不人身攻击。
const YANG_FLAVORS = {
  N: [
    '你把它当宝，它把你当备用。', '挺新的，就是没人用过。', '便宜，也确实便宜。',
    '用久了，跟你一样没脾气。', '看上去很专业，其实就是个摆设。', '位置挺好的，就是没人在那儿。',
    '你能找到它，算它运气好。', '一直没用，但一直占地方。', '它比你会休息。',
    '你要的不是它，是买它那一下。', '落了灰，说明你也没多想用。', '上面还有别人的指纹。',
    '说明书比它有用。', '买回来那天最像样。', '有点旧，但不会请假。',
    '你不用它，它也不催你。', '便宜货，配你正好。', '放着也是放着。',
    '忘了它吧，它已经忘了你。', '能用，仅此而已。', '谁都能拿，谁都不想拿。',
    '它不是不好，是没必要。', '你上次用它还是上次。', '摆着好看，用着不顺手。',
    '只在你收拾房间时被看见。', '有它没它，日子一样。', '它存在的意义是占个位置。',
    '看着像新的，因为它确实没动过。', '它比你有耐心。', '便宜到不值得修。',
    '你妈看了会说：又乱买。', '它没坏，就是没用了。', '提起来不重，提起来你也不高兴。',
    '属于那种买了就忘的类型。', '它唯一的优点是没占你多少时间。'
  ],
  R: [
    '它陪你熬过的那几个夜，都没跟你说谢谢。', '挺有用，就是用处不大。', '东西是好东西，就是不解决问题。',
    '它从来不掉链子，因为根本不上场。', '你夸它的时候，它正想着下班。', '它比你会装，装得还挺像。',
    '一如既往地稳定：稳定地不行。', '关键时刻，它准时消失。', '有点贵，配得上你那份热情（三天）。',
    '它的优点是安静，缺点也是安静。', '别人用它干活，你用它摆拍。', '你俩挺像：都在硬撑。',
    '看着挺高级，用起来挺抽象。', '它的问题是它没问题，只是没人在乎。', '也算是个东西，虽然不知道算个什么。',
    '你留下的痕迹比它本身的用处多。', '它一直在这儿，你也一直没看它。', '会响，就是不管用。',
    '它值得更好的主人，比如垃圾桶。', '坏了也不心疼，说明它很成功。', '用完记得说谢谢，它比你懂事。',
    '能凑合用，跟你一样。', '它不挑人，可惜你挑。', '一直挺好，就是没什么用。',
    '你为它花的时间比它给你的多。', '它没那么差，你也没那么需要它。', '上一次用它的人，已经离职了。',
    '它的保质期比你的热情长。', '稳稳地占着那个位置，谁也没意见。', '挺体面，就是没什么内容。',
    '你俩共用一句话：就这样吧。', '它从不抱怨，所以一直是被用的那个。'
  ],
  SR: [
    '它的优点是不会反抗，缺点是没人问它意见。', '你管这叫坚持，它管这叫没人换。', '每次都能准时到，因为它根本不想来。',
    '它说好要改变，改的是说法。', '你俩的关系很稳定：谁都不主动。', '它一直在进步，往反方向。',
    '说得很好，下次别说了。', '它把「尽力了」当成了一种完成。', '看上去是团队的功劳，其实是它的锅。',
    '它的存在感约等于它起的作用。', '你不是离不开它，你是懒得换。', '它从不让人失望，因为本就不抱期望。',
    '它答应得那么快，你就该警觉了。', '混得挺好，就是没做出什么。', '它很努力地证明自己不重要。',
    '只要你不在，它运转得更顺。', '它把平庸经营成了一种稳定。', '它擅长把简单的事做得很复杂，显得忙。',
    '你俩的默契是：谁都不提那件事。', '它没做错什么，也没做对什么。', '它的沉默不是深沉，是没内容。',
    '一年了，它还在「准备开始」。', '它对你很客气，因为不打算真帮忙。', '它很会总结，就是没开始过。',
    '它把「差不多」执行得很彻底。', '它一直在等一个不存在的时机。', '你俩都在等对方先开口。',
    '它擅长把责任说成「客观情况」。', '它没什么毛病，就是没什么用。', '它的效率高在解释为什么没做完。',
    '它很擅长「下次一定」。', '它把日子过成了会议记录。'
  ],
  SSR: [
    '传说它一开口，所有人的午休就结束了。', '它的名字出现在所有群里，唯独不在功劳簿上。', '它出现的地方，气氛会礼貌地安静下来。',
    '大家说它很靠谱，说的时候都笑了一下。', '它的意见很重要，重要到没人敢用。', '它一直在「统筹全局」，具体做了什么没人说得清。',
    '它走的那天，工作量减少了四成，没人提。', '它属于那种一开会就要先讲十分钟背景的人。', '它把「我来跟进」说成了「这事归你了」。',
    '它总能在最后一刻提出最有道理的意见。', '它的存在证明了一句话：忙不等于有用。', '它的口头禅是「这不难吧」，说给的是别人。',
    '它一出现，所有人都开始有事。', '它擅长把别人的成果说成团队的努力。', '它记得所有人的错，就是不记得自己的。',
    '它的方案永远在第三版，永远在要资源。', '它在群里说话很客气，在会上一句不让。', '它的资历比它的产出长得多。',
    '它把「咱们」用得很熟练，尤其是分活的时候。', '它走流程的速度，比流程本身还慢。', '没人讨厌它，也没人想跟它一组。',
    '它的每次发言都精准地绕开了重点。', '它说自己「不争」，争得比谁都早。', '它善于把简单的问题总结成一句「再看吧」。',
    '它的名字等于一句承诺，从来没兑现过。', '它在会上最活跃，在工位上最安静。', '它的汇报很漂亮，细节一句没有。',
    '它把「稳定」经营成了一种躺法。', '它每次都说「最后一次」，说了三年。', '它让你明白：能力是加分项，会说话是必选项。',
    '它总在关键时刻出现，出现的方式是发言。'
  ],
  UR: [
    '关于它的评价有三种：很好、挺好、以及大家都懂的挺好。', '它一出现，所有人都想起自己还有别的事。', '它的每句话都对，就是合起来没有意义。',
    '它成功地让「负责」变成了一个动词之外的词。', '它不需要加班，它只需要别人加班。', '它做过最大的贡献，是不再参与。',
    '它的名字被写进了三份周报，一次成果都没写。', '它在所有复盘会上都有一句「我提醒过」。', '它从不出错，因为它从不开始。',
    '它的沉默被误认为是深沉，其实是不会。', '它把「我这边没问题」说成了别人的问题。', '它一开会，时间就失去了意义。',
    '它最擅长的技能是让别人显得不够努力。', '它的存在让「公平」变成了一个需要讨论的问题。', '它答应的事都记在别人心里。',
    '它永远在「推进中」，推到项目结束。', '它的建议永远正确，永远不落地。', '它把一个季度的工作，浓缩成了一句「很忙」。',
    '它不加班的时候，别人都在加班。', '它走后，会议时长缩短了一半，议题一个没少。', '它从不说「我不会」，它说「这不是我的部分」。',
    '它的每一次出现都在提醒别人：说话比做事划算。', '它把「再等等」做成了公司制度。', '它的功劳由别人代领，因为它在忙。',
    '它从不抢功，因为功都在它这儿。', '它说「都行」的时候，通常都行不通。', '它的每份文档都像谜语，谜底是「以后再补」。',
    '它成功地让「打工人」这个词变得不再自嘲。', '它一站起来，所有人都开始看手机。', '它把「正常流程」四个字用成了一道墙。',
    '它的名字是所有人心里的一口气，谁都没呼出来。'
  ],
  '???': [
    '它不说人话，但比你会说。', '它不存在，但你每天都在为它加班。', '它是一句「我们是一家人」，后面跟着一张表。',
    '它是一个承诺，写在只有它看得见的地方。', '它是所有人的共识，具体内容没人记得。', '它什么也没做，但什么都绕不开它。',
    '它的意思是「再想想」，想的是怎么不背这个锅。', '它是一个更大的饼，画在上一张饼上面。', '它从不出现，却决定了每一次奖金的算法。',
    '它是所有人都同意的一个误会。', '它是「流程」本人，流程之外都是它。', '它在每次述职里出现一次，形式是一张图。',
    '它不叫权力，它叫「沟通一下」。', '它是一份没有正文的通知，只有抄送。', '它把「优化」翻译成了「你自己看着办」。',
    '它是所有人都懂、都不说、都配合的那件事。', '它是时间，被分成了很多份，你那份最少。', '它是一句「辛苦了」，工资单上没有这一项。',
    '它是「自愿」的另一种写法，加粗了一下。', '它是一个圆，所有人都在边缘走。', '它是一个会议纪要，纪要里你不在场。',
    '它不撒谎，它只是把话说完整了。', '它是那个永远在「下一步」的下一步。', '它是一份责任，署名处是空白。',
    '它不说话，但它决定了谁能说话。', '它把「以后」当成了常用的量词。', '它是所有人共同维护的沉默。',
    '它是那句「都是为了你好」，说给的是它自己。', '它不需要被理解，只需要被转发。', '它是一句口号，贴在墙上，朝向空处。',
    '它是会议开始前那句「简单说一下」，说完两小时。'
  ]
};

const FLAVORS = { yang: YANG_FLAVORS, neutral: NEUTRAL_FLAVORS };

export const FLAVOR_COUNTS = Object.freeze(
  Object.fromEntries(TONES.map((tone) => [
    tone,
    Object.fromEntries(TIER_KEYS.map((t) => [t, (FLAVORS[tone][t] || []).length]))
  ]))
);

// ───────────────────────── 小工具 ─────────────────────────

const isPlainObject = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v);

/** 去掉孤立代理项（半个 emoji）—— 它会让整个模型请求 400。 */
function stripLoneSurrogates(value) {
  const s = String(value ?? '');
  let out = '';
  for (let i = 0; i < s.length; i++) {
    const code = s.charCodeAt(i);
    if (code >= 0xd800 && code <= 0xdbff) {
      const next = s.charCodeAt(i + 1);
      if (next >= 0xdc00 && next <= 0xdfff) { out += s[i] + s[i + 1]; i += 1; }
      continue;
    }
    if (code >= 0xdc00 && code <= 0xdfff) continue;
    out += s[i];
  }
  return out;
}

function safeSlice(value, max) {
  const s = String(value ?? '');
  const limit = Math.max(0, Math.floor(Number(max)) || 0);
  return stripLoneSurrogates(limit >= s.length ? s : s.slice(0, limit));
}

function clampInt(value, fallback, lo, hi) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(hi, Math.max(lo, Math.trunc(n)));
}

function safeInt(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.trunc(n)) : fallback;
}

/** 布尔读取：模型/配置里 "false" 不能被当成 true。 */
function toBool(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'boolean') return value;
  const s = String(value).trim().toLowerCase();
  if (['true', '1', 'yes', 'on', '是', '开'].includes(s)) return true;
  if (['false', '0', 'no', 'off', '否', '关'].includes(s)) return false;
  return fallback;
}

/** rng 归一化到 [0,1)：坏 rng（NaN / 1 / 负数）不能把抽卡卡死或抛异常。 */
function unit(rng) {
  let r;
  try { r = Number(rng()); } catch { r = 0; }
  if (!Number.isFinite(r) || r < 0) return 0;
  if (r >= 1) return 0.9999999999999;
  return r;
}

function formatPct(rate) {
  const pct = Number(rate) * 100;
  return Number.isFinite(pct) ? String(Number(pct.toFixed(2))) : '0';
}

function fillTemplate(line, cardName) {
  const text = String(line ?? '');
  const name = String(cardName ?? '');
  return name ? text.split('{name}').join(name) : text;
}

// ───────────────────────── 抽卡纯函数 ─────────────────────────

/** 按权重表抽一个等级。注入 rng 就能测分布。 */
export function pickTier(rng = Math.random) {
  const point = unit(rng) * TOTAL_BP;
  let acc = 0;
  for (const spec of TIERS) {
    acc += spec.bp;
    if (point < acc) return spec.tier;
  }
  return TIERS[0].tier;
}

/** 在同等级卡池里等概率抽一张卡。DENY 命中的名字已在 cardsOf 里被剔除，权重顺延。 */
export function pickCard(tier, rng = Math.random, tone = 'yang') {
  const list = cardsOf(tier, tone);
  if (!list.length) return null;
  const index = Math.min(list.length - 1, Math.floor(unit(rng) * list.length));
  const card = list[index];
  return { name: card.name, kind: card.kind, hook: card.hook };
}

/**
 * 取 count 条词条（不放回），所以同一个卡名重抽必然换组合。
 * hook 占第一条的位置；等级决定了总条数（1/2/3/4/5/6），不会多也不会少。
 */
export function pickFlavors(tier, rng = Math.random, count = 0, hook = '', cardName = '', tone = 'yang') {
  const spec = tierSpec(tier);
  const want = clampInt(count, spec.lines, 0, spec.lines);
  const pool = (FLAVORS[normalizeTone(tone)] || {})[spec.tier] || [];
  const picked = [];
  if (hook) picked.push(fillTemplate(hook, cardName));
  const rest = pool.map((_, i) => i);
  while (picked.length < want && rest.length) {
    const at = Math.min(rest.length - 1, Math.floor(unit(rng) * rest.length));
    const [index] = rest.splice(at, 1);
    picked.push(fillTemplate(pool[index], cardName));
  }
  if (!picked.length) picked.push('它没有词条，只是在那里。');
  return picked;
}

/** 抽一张：等级由 pickTier 决定，卡与词条由 rng 决定。返回的是定稿形状里的一「draws[i]」。 */
export function drawOne(tier, rng = Math.random, tone = 'yang') {
  const spec = tierSpec(tier);
  const which = normalizeTone(tone);
  const card = pickCard(spec.tier, rng, which) || { name: '无名之物', kind: 'concept', hook: '' };
  return {
    tier: spec.tier,
    tierName: spec.tier,
    stars: spec.stars,
    starsText: '★'.repeat(spec.stars),
    card: { name: card.name, kind: card.kind },
    lines: pickFlavors(spec.tier, rng, spec.lines, card.hook, card.name, which),
    rate: spec.bp / TOTAL_BP
  };
}

function zeroCounts() {
  return TIER_KEYS.map(() => 0);
}

export function countsToObject(counts) {
  const out = {};
  TIER_KEYS.forEach((key, i) => { out[key] = safeInt(counts?.[i], 0); });
  return out;
}

function highestTier(tiers) {
  let best = null;
  let bestIndex = -1;
  for (const tier of tiers) {
    const index = TIER_INDEX.has(tier) ? TIER_INDEX.get(tier) : -1;
    if (index > bestIndex) { bestIndex = index; best = tier; }
  }
  return best;
}

/**
 * 说明文案（advise）：三档口径完全不同，不要写成同一句话。
 * 共同点只有一条 —— 等级与概率是插件掷的官方结果，任何档位都不许改。
 */
export function buildDrawAdvise(result, { flavorMode = 'free', allowModelFlavor, tone = 'yang' } = {}) {
  const out = result || {};
  const mode = normalizeFlavorMode(flavorMode, allowModelFlavor);
  const which = normalizeTone(tone);
  const spec = tierSpec(out.tier);
  const poolName = String(out.card?.name ?? '');
  const poolLines = Array.isArray(out.lines) ? out.lines.length : 0;
  const multi = Array.isArray(out.draws) && out.draws.length > 1;
  // 多连时每张的档位与词条条数都不同：逐张列出来，模型才不会拿第一张的档位套全部。
  const perDrawText = multi
    ? out.draws.map((draw, i) => '第 ' + (i + 1) + ' 张 ' + tierSpec(draw?.tier).tier + '（' + tierSpec(draw?.tier).lines + ' 条词条）').join('、')
    : '';
  const parts = [];

  if (mode === 'free') {
    // ① 官方只掷了等级与概率
    if (multi) {
      parts.push('本轮插件掷出来的只有等级与概率：draws 里每张的 tier / starsText / rate 就是官方结果（共 ' + out.draws.length + ' 张），等级、星级、概率都不得改动。每张的档位与词条条数：' + perDrawText + '。');
    } else {
      parts.push('本轮插件掷出来的只有等级与概率：' + String(out.tierName ?? '') + ' ' + String(out.starsText ?? '') + '（' + formatPct(out.rate) + '%）就是官方结果，等级、星级、概率都不得改动。');
    }
    // ② 风格定义（只阴阳事与身份，不点名真人）+ 卡名自己起
    if (which === 'yang') {
      parts.push('这次的风格是「阴阳怪气」：表面在夸，实际在损；短、准、不留情面，但不骂脏字、不人身攻击、不点名任何一个真人。');
      parts.push('照着这个调性写，但不要照抄下面这三句：①「我家鱼缸里那条金鱼」SR「会吃不会说」；②「电饭锅」UR「里面还剩半锅白饭，不是给你的」；③「食堂打饭阿姨」SSR「手抖得比你多」。');
      parts.push('卡名不要用返回里的 card.name（「' + poolName + '」只是 ' + spec.tier + ' 档的素材）：先自己想一个卡名，路子是「物或泛化身份 + 一句反讽」，池子里没有、不超过 40 字。');
    } else {
      parts.push('卡名不要用返回里的 card.name（「' + poolName + '」只是 ' + spec.tier + ' 档的风格素材）：先自己想一个卡名，要求是池子里没有、贴合 ' + spec.tier + ' 的气质、不超过 40 字。');
    }
    // ③ 词条条数固定，内容自写
    parts.push('词条条数必须' + (multi ? '逐张等于那一张自己的规定条数（' + perDrawText + '，不多不少）' : '等于 ' + spec.lines + ' 条（' + spec.tier + ' 的规定条数，不多不少）') + '，每条不超过 60 字，内容全部由你自己写；返回的 lines（' + poolLines + ' 条）只是' + (multi ? '第一张的' : '同风格') + '素材，可以借词风，但不要整句照搬。');
    // ④ 自创完要回执
    if (out.who?.recorded) {
      parts.push(multi
        ? '自创完请每张各调用一次 gacha__save_card 回执（' + out.draws.length + ' 张就调 ' + out.draws.length + ' 次）：who="' + out.who.name + '"，每次的 name=你给那一张起的卡名、tier=那一张自己的档位（' + perDrawText + '，一张一次，不要拿第一张的档位套全部）、lines=那一张的词条（最多 6 条）。漏调的那几张就只是没记账的抽卡，别人用 gacha__card_dex 查不到它们。'
        : '自创完请顺手调用一次 gacha__save_card 回执：who="' + out.who.name + '"，name=你起的卡名，tier="' + spec.tier + '"，lines=你写的词条（最多 6 条）。不调用就只是一次没记账的抽卡，别人用 gacha__card_dex 查不到这张卡。');
    } else if (out.warning) {
      parts.push('这次图鉴没写进去，所以不要凭空说已经记账；等图鉴恢复后，自创卡再用 gacha__save_card 补记。');
    } else {
      parts.push('这次没有记名（没传 who，或图鉴被关掉），gacha__save_card 现在也记不了：想让卡进图鉴，下一次带上 who 再抽。');
    }
    // ⑤ 内容红线
    if (which === 'yang') {
      parts.push('内容红线（逐条）：①不出现任何真人姓名或隐私；②不用真实政治人物或其影射；③不做地域、性别、民族、职业等群体歧视；④不写色情；⑤不针对群里的某个具体人。可以自嘲，也可以损甲方、老板、打工人、食堂阿姨这类泛化身份。');
    } else {
      parts.push('内容红线：不用真实政治人物的姓名或影射，不写任何真人的隐私，不写色情内容，也不要把现实中的具体人做成卡。');
    }
    // ⑥ 兜底
    parts.push('实在想不出来才退回兜底：把返回里的 lines 原样列出，并说明这是兜底。');
  } else if (mode === 'extend') {
    if (multi) {
      parts.push('这次一共抽了 ' + out.draws.length + ' 张，逐张把卡名、等级、星级、词条如实转述（draws 里已经按顺序排好）；顶层字段是其中第一张。');
    } else {
      parts.push('把这张卡如实转述：「' + poolName + '」' + String(out.tierName ?? '') + ' ' + String(out.starsText ?? '') + '（概率 ' + formatPct(out.rate) + '%）。');
    }
    parts.push('等级、星级、概率、卡名都以本返回为准：不要自己升/降等级，也不要编造返回里没有的卡名。');
    parts.push('词条照 lines 原样列出（' + poolLines + ' 条），你可以在同样的风格下自己再加 1–2 条（这是 extend 档允许的额外两三条里的量，本级规定条数本身是 ' + spec.lines + ' 条）。');
  } else {
    if (multi) {
      parts.push('这次一共抽了 ' + out.draws.length + ' 张，逐张把卡名、等级、星级、词条如实转述（draws 里已经按顺序排好）；顶层字段是其中第一张。');
    } else {
      parts.push('把这张卡如实转述：「' + poolName + '」' + String(out.tierName ?? '') + ' ' + String(out.starsText ?? '') + '（概率 ' + formatPct(out.rate) + '%）。');
    }
    parts.push('等级、星级、概率、卡名都以本返回为准：不要自己升/降等级，也不要编造返回里没有的卡名。');
    parts.push('词条只能照 lines 原样列出（' + poolLines + ' 条），不要合并、改写或增加（本次设置 flavorMode=off）。');
  }

  if (out.warning) {
    parts.push('这次没能记进图鉴：' + String(out.warning.message || '存档不可用。') + '不要说已记录，也不要替对方补记。');
  } else if (!out.who?.recorded) {
    parts.push('这次没有记进任何人的图鉴（没传 who，或图鉴记录被关掉），不要说「已经记进你的图鉴」。');
  }
  if (out.firstTime) {
    parts.push('这是对方第一次抽到 ' + String(out.firstTimeTier ?? '') + ' 级别的东西，可以提一句。');
  }
  return parts.join('');
}

/** 定稿返回形状。draws 只有 count>1 时才出现；汇总里六个等级都在（没有的记 0）。 */
export function buildDrawResult({ draws = [], who = {}, firstTime = false, firstTimeTier = null, flavorMode = 'free', allowModelFlavor, tone = 'yang', warning = null } = {}) {
  const list = (Array.isArray(draws) ? draws : []).filter(isPlainObject);
  const primary = list[0] || drawOne('N', Math.random, tone);
  const byTier = countsToObject(zeroCounts());
  for (const item of list) {
    const spec = tierSpec(item.tier);
    byTier[spec.tier] = (byTier[spec.tier] || 0) + 1;
  }
  const result = {
    ok: true,
    tier: primary.tier,
    stars: primary.stars,
    starsText: primary.starsText,
    tierName: primary.tierName,
    card: primary.card,
    lines: primary.lines,
    firstTime: Boolean(firstTime),
    firstTimeTier: firstTimeTier ? tierSpec(firstTimeTier).tier : null,
    rate: Number.isFinite(Number(primary.rate)) ? Number(primary.rate) : rateOf(primary.tier)
  };
  if (list.length > 1) result.draws = list;
  result.summary = { total: list.length, byTier };
  // 降级时 recorded 一律按没记算：存档没成功，说记了就是骗人。
  result.who = { name: String(who?.name || '匿名'), recorded: Boolean(who?.recorded) && !warning };
  if (warning && warning.code) result.warning = { code: String(warning.code), message: String(warning.message || '') };
  result.advise = buildDrawAdvise(result, { flavorMode, allowModelFlavor, tone });
  return result;
}

// ───────────────────────── 上下文 ─────────────────────────

/**
 * 把配置与宿主 io 收成一次调用用的 ctx。
 * io 全部可选：不传时用内存空实现（纯函数测试、被 import 时都能跑）。
 *   io.read:  async () => 存档对象 | null      （宿主的 cap.storage.get）
 *   io.write: async (state) => void            （宿主的 cap.storage.set，失败要 throw）
 *   io.now:   () => 毫秒时间戳
 *   io.warn:  (text) => void
 *   io.rng:   () => [0,1)                     随机源，便于注入固定种子
 */
export function makeContext(settings = {}, io = {}) {
  const rawSettings = isPlainObject(settings) ? settings : {};
  const merged = { ...DEFAULTS };
  for (const [key, value] of Object.entries(rawSettings)) {
    if (value !== undefined && value !== null) merged[key] = value;
  }
  const maxCount = clampInt(merged.maxCount, DEFAULTS.maxCount, 1, MAX_DRAW_COUNT);
  const source = isPlainObject(io) ? io : {};
  return {
    settings: merged,
    enabled: toBool(merged.enabled, DEFAULTS.enabled),
    // 旧的 allowModelFlavor 只在**原始配置**没有 flavorMode 时生效（默认值不算「配置了」）
    flavorMode: normalizeFlavorMode(rawSettings.flavorMode, rawSettings.allowModelFlavor),
    // 卡片风格：yang 阴阳（默认）/ neutral 原来的日常抽象。旧配置没有 tone → yang。
    tone: normalizeTone(rawSettings.tone),
    recordHistory: toBool(merged.recordHistory, DEFAULTS.recordHistory),
    maxCount,
    defaultCount: clampInt(merged.count, DEFAULTS.count, 1, maxCount),
    rng: typeof source.rng === 'function' ? source.rng : Math.random,
    io: {
      read: typeof source.read === 'function' ? source.read : async () => null,
      write: typeof source.write === 'function' ? source.write : async () => {},
      acquire: typeof source.acquire === 'function' ? source.acquire : async () => () => {},
      now: typeof source.now === 'function' ? source.now : () => Date.now(),
      warn: typeof source.warn === 'function' ? source.warn : () => {}
    }
  };
}

// ───────────────────────── 持久化 ─────────────────────────
// 单键（STORAGE_KEY）读-改-写：一次工具调用最多读一次、写一次。
// 宿主的硬限制：单个值 ≤32KB、总量 ≤256KB、每分钟 ≤120 写。所以下面这套预算是按
// 「单值 32KB」算的：软预算 26KB，超了先删最久没抽的人，宁可丢老记录也不能让写入被拒。

export const STORAGE_KEY = 'gacha.v1';
const MAX_STATE_BYTES = 26 * 1024;
const MAX_USERS = 200;
// 每人 24 条**共用**名额：池内稀有（SSR+）与自创卡抢同一批名额，按时间淘汰最旧的。
const MAX_RARE_PER_USER = 24;
const MAX_HOT = 48;

function byteLengthOf(state) {
  try { return Buffer.byteLength(JSON.stringify(state), 'utf8'); } catch { return 0; }
}

/**
 * 稀有/自创记录：`[卡名, 等级下标, 首次时间, src]`，src=0 池内稀有（draw_card 记，SSR+），
 * src=1 自创（save_card 记，任意等级）。
 * 兼容旧存档：3 元组一律当 src=0；认不出的一律丢掉（不猜）。
 */
function rareOf(raw) {
  if (!Array.isArray(raw) || raw.length < 2) return null;
  const name = safeSlice(String(raw[0] ?? '').replace(/\s+/g, ' '), MAX_WHO);
  const tierIndex = safeInt(raw[1], -1);
  const firstAt = safeInt(raw[2], 0);
  if (!name || tierIndex < 0 || tierIndex >= TIER_KEYS.length) return null;
  const src = raw.length >= 4 && safeInt(raw[3], 0) === 1 ? 1 : 0;
  return [name, tierIndex, firstAt, src];
}

function countsOf(raw) {
  const out = zeroCounts();
  if (Array.isArray(raw)) for (let i = 0; i < out.length; i++) out[i] = safeInt(raw[i], 0);
  return out;
}

/** 存档读坏了/是旧形状都不报错：能认的字段留下，认不出的丢掉。 */
export function normalizeState(raw) {
  const src = isPlainObject(raw) ? raw : {};
  // u 用无原型对象：who 里出现 __proto__ / constructor / toString 时，读到的不能是
  // Object.prototype 上的东西（否则会污染原型或抛 TypeError）。
  const state = { v: 1, u: Object.create(null), g: { c: 0, t: zeroCounts() }, h: {}, x: safeInt(src.x, 0) };
  const users = isPlainObject(src.u) ? src.u : {};
  for (const [key, item] of Object.entries(users)) {
    const name = safeSlice(String(key ?? '').replace(/\s+/g, ' ').trim(), MAX_WHO);
    if (!name || !isPlainObject(item)) continue;
    const rare = (Array.isArray(item.r) ? item.r : []).map(rareOf).filter(Boolean);
    state.u[name] = {
      c: safeInt(item.c, 0),
      t: countsOf(item.t),
      r: rare.slice(Math.max(0, rare.length - MAX_RARE_PER_USER)),
      a: safeInt(item.a, 0)
    };
  }
  const global = isPlainObject(src.g) ? src.g : {};
  state.g = { c: safeInt(global.c, 0), t: countsOf(global.t) };
  const hot = isPlainObject(src.h) ? src.h : {};
  for (const [key, value] of Object.entries(hot)) {
    const name = safeSlice(String(key ?? ''), MAX_WHO);
    const count = safeInt(value, 0);
    if (name && count > 0) state.h[name] = count;
  }
  return state;
}

/**
 * 淘汰：①每人稀有 + 自创记录共用，只留最新 MAX_RARE_PER_USER 条 ②热门卡表只留 MAX_HOT 个
 * ③who 条目只留最近抽过的 MAX_USERS 个 ④还超字节预算就按「最久没抽」一个人一个人删
 * ⑤病态情况（热门表本身超预算）就清空热门表。全局计数与存档永不退（它只有一个对象）。
 */
export function trimState(state, budget = MAX_STATE_BYTES) {
  const limit = Number.isFinite(Number(budget)) ? Math.max(1024, Number(budget)) : MAX_STATE_BYTES;
  for (const entry of Object.values(state.u)) {
    if (entry.r.length > MAX_RARE_PER_USER) {
      entry.r.sort((a, b) => a[2] - b[2]);
      entry.r = entry.r.slice(entry.r.length - MAX_RARE_PER_USER);
    }
  }
  const hotKeys = Object.keys(state.h);
  if (hotKeys.length > MAX_HOT) {
    hotKeys.sort((a, b) => state.h[a] - state.h[b] || (a < b ? -1 : 1));
    for (const key of hotKeys.slice(0, hotKeys.length - MAX_HOT)) delete state.h[key];
  }
  const names = Object.keys(state.u);
  if (names.length > MAX_USERS) {
    names.sort((a, b) => state.u[a].a - state.u[b].a);
    for (const key of names.slice(0, names.length - MAX_USERS)) delete state.u[key];
  }
  // 还超预算就按「最久没抽」一个人一个人删。旧写法每删一个人就把整份 state 重新 stringify
  // （O(n²)）；这里排序只做一次、按序把每个条目的字节增量递减，判定与逐次 stringify 等价。
  let bytes = byteLengthOf(state);
  if (bytes > limit) {
    const order = Object.keys(state.u).sort((a, b) => state.u[a].a - state.u[b].a);
    let rest = order.length;
    for (const key of order) {
      if (bytes <= limit) break;
      // 这一条在 JSON 里占的字节：键 + 冒号 + 值 + 后面的逗号（它是最后一个成员时没有逗号）。
      bytes -= Buffer.byteLength(JSON.stringify(key), 'utf8') + 1 + Buffer.byteLength(JSON.stringify(state.u[key]), 'utf8') + (rest > 1 ? 1 : 0);
      delete state.u[key];
      rest -= 1;
    }
  }
  if (byteLengthOf(state) > limit) state.h = {};
  return state;
}

function ensureUser(state, who, at) {
  // 只认自己的键：who 命中 __proto__ / constructor / toString 时必须走「正常新建用户」。
  if (!Object.prototype.hasOwnProperty.call(state.u, who)) state.u[who] = { c: 0, t: zeroCounts(), r: [], a: at };
  return state.u[who];
}

function bumpHot(state, cardName) {
  const name = String(cardName ?? '');
  if (!name) return;
  state.h[name] = safeInt(state.h[name], 0) + 1;
}

/**
 * 把一次调用的全部抽卡结果落到存档上（全局计数、热门表、个人累计/稀有），
 * 返回这次「第一次抽到」的稀有卡（SSR 及以上）列表，供 firstTime 判断。
 */
function applyDraws(state, { who, draws, at }) {
  const freshRare = [];
  const ssrIndex = TIER_INDEX.get('SSR');
  for (const draw of draws) {
    const index = TIER_INDEX.has(draw.tier) ? TIER_INDEX.get(draw.tier) : 0;
    state.g.c += 1;
    state.g.t[index] += 1;
    bumpHot(state, draw.card?.name);
    if (!who) continue;
    const entry = ensureUser(state, who, at);
    entry.c += 1;
    entry.t[index] += 1;
    entry.a = at;
    if (index >= ssrIndex && !entry.r.some((item) => item[0] === draw.card?.name)) {
      entry.r.push([String(draw.card?.name ?? ''), index, at, 0]);
      freshRare.push({ name: String(draw.card?.name ?? ''), tier: draw.tier });
    }
  }
  return freshRare;
}

// ───────────────────────── 三个工具 ─────────────────────────

function fail(code, message) {
  return { ok: false, error: { code, message: safeSlice(message, 400) } };
}

/** card_dex 的存档异常：没有存档就没有统计可展示，只能报 E_STORAGE。 */
function storageFail(error) {
  const detail = safeSlice(String(error?.message || error || '未知原因'), 160);
  return fail('E_STORAGE', '抽卡图鉴读不出来：' + detail + '。稍后再查一次；如果一直失败，多半是宿主的状态存储满了（256KB / 单值 32KB）。');
}

/**
 * draw_card 的存档异常走**降级**而不是失败：抽卡结果不依赖存档，存档挂了不该让所有人都抽不出卡
 * （宿主每分钟 120 写的限频、群聊热潮时最容易撞上）。返回里挂一个 warning 告诉模型这次没记，
 * 个人的 recorded / firstTime 一律按「没记」算，绝不让模型谎称已入库。
 */
function degradedWarning(phase, error, whoName, tool = 'draw_card') {
  const timedOut = error?.kind === 'timeout';
  const detail = safeSlice(String(error?.message || error || '未知原因'), 140);
  const reason = (timedOut ? '超时' : '被宿主拒绝或出错') + '：' + detail;
  const consequence = tool === 'save_card'
    ? '这张自创卡没能记进图鉴'
    : '这次抽卡照常出结果，但没有记进图鉴';
  const text = (phase === 'read' ? '读存档失败' : '写存档失败') + '（' + reason + '）：' + consequence + (whoName ? '（' + whoName + '）' : '') + '。';
  return { code: 'E_STORAGE_DEGRADED', message: text };
}

/** 一次降级调用**恰好**写一条宿主日志：宿主明确拒绝 → error（进异常面板），超时/未知 → warn。 */
function warnDegraded(ctx, phase, error, warning, tool = 'draw_card') {
  const level = error?.kind === 'timeout' ? 'warn' : 'error';
  try {
    ctx.io.warn('[gacha] ' + tool + ' 降级（' + phase + '）：' + warning.message, level);
  } catch { /* 日志本身失败也不能影响抽卡 */ }
}

/** who → { ok, name }。缺省/空串 = 匿名（照抽，只是不记个人图鉴）。 */
function parseWho(raw) {
  if (raw === undefined || raw === null || raw === '') return { ok: true, name: '' };
  if (typeof raw === 'number' && Number.isFinite(raw)) return { ok: true, name: String(raw).slice(0, MAX_WHO) };
  if (typeof raw !== 'string') {
    return { ok: false, name: '', message: 'who 必须是字符串（昵称或 QQ 号）。不给 who 也能抽，但不会记进任何人的图鉴。' };
  }
  const name = stripLoneSurrogates(raw).replace(/\s+/g, ' ').trim();
  if (!name) return { ok: true, name: '' };
  if (name.length > MAX_WHO) {
    return { ok: false, name: '', message: 'who 太长了（超过 ' + MAX_WHO + ' 个字）：who 只放昵称或 QQ 号，不要塞整句话，否则会撑爆图鉴存档。' };
  }
  return { ok: true, name };
}

/** count → 数字或 null（null = 越界）。越界不静默夹取：夹取会让「count=999」看起来像抽了 999 张。 */
function parseCount(raw, ctx) {
  if (raw === undefined || raw === null || raw === '') return ctx.defaultCount;
  const n = Number(raw);
  if (!Number.isFinite(n) || !Number.isInteger(n) || n < 1 || n > ctx.maxCount) return null;
  return n;
}

function parseTop(raw) {
  if (raw === undefined || raw === null || raw === '') return 10;
  const n = Number(raw);
  if (!Number.isFinite(n) || !Number.isInteger(n) || n < 1 || n > MAX_TOP) return null;
  return n;
}

/** 自创卡的卡名：去控制字符与孤立代理项、压平空白，≤MAX_WHO 字，命中 DENY 一律拒。 */
function parseCardName(raw) {
  if (typeof raw !== 'string' && !(typeof raw === 'number' && Number.isFinite(raw))) {
    return { ok: false, name: '', message: 'name 必须是字符串：请填你给这张卡起的名字（不是对象/数组）。' };
  }
  const text = stripLoneSurrogates(String(raw))
    .replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!text) return { ok: false, name: '', message: 'name 不能为空：这是要记进图鉴的卡名。' };
  if (text.length > MAX_WHO) {
    return { ok: false, name: '', message: 'name 太长了（' + text.length + ' 字，上限 ' + MAX_WHO + ' 字）：卡名只放一个名字，不要塞整段描述。' };
  }
  if (isDeniedName(text)) {
    return { ok: false, name: '', message: 'name 命中了插件的 DENY 名单（真实政治人物/敏感称谓的兜底过滤），不能当卡名：换一个你自己创作的虚构名字。' };
  }
  return { ok: true, name: text };
}

/** tier 只认六级（大小写不敏感，归一化成表里的写法），其它一律 null → E_ARGS。 */
function parseTierArg(raw) {
  const key = String(raw ?? '').trim();
  if (!key) return null;
  for (const spec of TIERS) if (spec.tier === key || spec.tier === key.toUpperCase()) return spec.tier;
  return null;
}

/** lines 只用来数条数（不入存档），所以宽松：数组、≤6 条、每条 ≤60 字，不合规的直接忽略。 */
function countCustomLines(raw) {
  if (!Array.isArray(raw)) return { count: 0, ignored: 0 };
  let count = 0;
  let ignored = 0;
  for (const item of raw) {
    if (count >= MAX_CUSTOM_LINES) break;
    const text = stripLoneSurrogates(String(item ?? '')).replace(/\s+/g, ' ').trim();
    if (!text) continue;
    // 每条 ≤60 字是 plugin.json / README 对模型的承诺：超长的那条不计数，回执里说明被忽略了几条。
    if (text.length > 60) { ignored += 1; continue; }
    count += 1;
  }
  return { count, ignored };
}

function globalTotal(state) {
  return { users: Object.keys(state.u).length, draws: state.g.c, byTier: countsToObject(state.g.t) };
}

function topHotCards(state, top) {
  return Object.entries(state.h)
    .map(([name, count]) => ({ name, tier: TIER_OF_CARD.get(name) || null, count: safeInt(count, 0) }))
    .sort((a, b) => b.count - a.count || (a.name < b.name ? -1 : 1))
    .slice(0, top);
}

async function drawCard(ctx, args) {
  const count = parseCount(args.count, ctx);
  if (count === null) {
    return fail('E_ARGS', 'count 必须是 1–' + ctx.maxCount + ' 之间的整数（收到「' + safeSlice(String(args.count), 20) + '」）。多抽就把张数填进 count，例如 count=' + ctx.maxCount + '；不填就按插件设置的默认张数抽。');
  }
  const whoParsed = parseWho(args.who);
  if (!whoParsed.ok) return fail('E_ARGS', whoParsed.message);
  const whoName = whoParsed.name;
  const recorded = Boolean(ctx.recordHistory && whoName);

  // 抽卡计算在临界区之外：存档排队不该拖住掷骰子。
  const tone = normalizeTone(ctx.tone);
  const draws = [];
  for (let i = 0; i < count; i++) draws.push(drawOne(pickTier(ctx.rng), ctx.rng, tone));

  // 读不到存档时**绝不写**：把「读失败」当成空存档再写回去，会顺手抹掉所有人的图鉴。
  // 读-改-写在同一个临界区里（同一调用里的读与写仍用同一个 state 对象）。
  let state = null;
  let warning = null;
  let releaseStorage = null;
  if (ctx.recordHistory) {
    releaseStorage = await ctx.io.acquire();
    try {
      state = normalizeState(await ctx.io.read());
    } catch (error) {
      warning = degradedWarning('read', error, whoName);
      warnDegraded(ctx, 'read', error, warning);
      state = null;
      releaseStorage();
    }
  }

  let firstTimeTier = null;
  if (ctx.recordHistory && !warning) {
    try {
      const at = safeInt(ctx.io.now(), Date.now());
      const fresh = applyDraws(state, { who: recorded ? whoName : '', draws, at });
      firstTimeTier = fresh.length ? highestTier(fresh.map((item) => item.tier)) : null;
      state.x = at;
      await ctx.io.write(trimState(state));
    } catch (error) {
      // 卡已经抽出来了：照常返回，只是这次没记进图鉴。
      firstTimeTier = null;
      warning = degradedWarning('write', error, whoName);
      warnDegraded(ctx, 'write', error, warning);
    } finally {
      if (releaseStorage) releaseStorage(); // 写的成败都要放行，否则后面的调用全被卡住
    }
  }

  return buildDrawResult({
    draws,
    who: { name: whoName || '匿名', recorded: recorded && !warning },
    firstTime: Boolean(firstTimeTier),
    firstTimeTier,
    flavorMode: ctx.flavorMode,
    tone,
    warning
  });
}

async function cardDex(ctx, args) {
  const top = parseTop(args.top);
  if (top === null) {
    return fail('E_ARGS', 'top 必须是 1–' + MAX_TOP + ' 之间的整数（收到「' + safeSlice(String(args.top), 20) + '」）。不填就是前 10。');
  }
  const whoParsed = parseWho(args.who);
  if (!whoParsed.ok) return fail('E_ARGS', whoParsed.message);
  if (!ctx.recordHistory) {
    return fail('E_ARGS', '图鉴记录在插件设置里被关掉了（recordHistory=false），所以没有任何统计可查：要让图鉴生效，先在插件设置里把它打开。');
  }

  let state;
  // 只读也排一次队：避免读到别的调用写了一半的存档（读完立刻放行，不占着等计算）。
  const releaseStorage = await ctx.io.acquire();
  try { state = normalizeState(await ctx.io.read()); }
  catch (error) { return storageFail(error); }
  finally { releaseStorage(); }

  const whoName = whoParsed.name;
  const total = globalTotal(state);
  const topCards = topHotCards(state, top);

  if (!whoName) {
    return {
      ok: true,
      who: null,
      draws: state.g.c,
      byTier: countsToObject(state.g.t),
      rare: [],
      custom: [],
      total,
      top: topCards,
      advise: '没有传 who，所以这是全局统计（含没记名的匿名抽卡）：总共 ' + state.g.c + ' 次、图鉴里 ' + total.users + ' 个人。想知道某个人抽了什么，带上 who（昵称或 QQ 号）再查一次；稀有记录只按人存，所以全局这边 rare 是空的。等级与概率由插件决定，不要自己推算或编造数据。'
    };
  }

  // 用 hasOwnProperty 守卫：who='__proto__'/'constructor' 时不能从 Object.prototype 上取到值。
  const entry = Object.prototype.hasOwnProperty.call(state.u, whoName) ? state.u[whoName] : null;
  if (!entry) {
    return fail('E_NOT_FOUND', '图鉴里没有「' + whoName + '」的记录：可能还没抽过卡，或者 who 拼得和当时不一样（昵称/QQ 号要和抽卡时一致），也可能因为太久没抽被淘汰了（每人上限 ' + MAX_USERS + ' 人、存档按最久没抽先删）。如实转述，不要编造这个人的数据。');
  }

  // rare = 池内稀有（src=0，由 draw_card 记的 SSR+）；custom = 模型自创（src=1，由 save_card 记）。
  const toItem = (item) => ({ name: item[0], tier: TIER_KEYS[item[1]], firstAt: item[2] });
  const newestFirst = (a, b) => b[2] - a[2];
  const rare = entry.r.filter((item) => (item[3] || 0) === 0).sort(newestFirst).map(toItem);
  const custom = entry.r.filter((item) => (item[3] || 0) === 1).sort(newestFirst).map(toItem);

  return {
    ok: true,
    who: whoName,
    draws: entry.c,
    byTier: countsToObject(entry.t),
    rare,
    custom,
    total,
    top: topCards,
    advise: '「' + whoName + '」一共抽了 ' + entry.c + ' 次' + (rare.length ? '，抽到过 ' + rare.length + ' 张 SSR 及以上的稀有卡（rare 里按第一次抽到的时间从新到旧）' : '，还没抽到过 SSR 及以上') + (custom.length ? '，图鉴里还记着 ' + custom.length + ' 张自创卡（custom）' : '，还没有自创卡进过图鉴') + '。稀有与自创共用每人 ' + MAX_RARE_PER_USER + ' 条记录名额，按时间淘汰最旧的。top 是全局被抽到次数最多的卡。这些数字都来自插件存档，如实转述，不要自己推算概率或补上不存在的卡。'
  };
}

/**
 * 把模型自创的卡记进某人的图鉴（D1）。
 * 这只是记账：**不动抽数 c**（抽数由 draw_card 记）、不动全局计数、不动热门表、不入档词条。
 * 同名同人只记一次（保留最早的 firstAt）。存档挂了不失败 —— 群里那句话不能因为记账失败就发不出去。
 */
async function saveCard(ctx, args) {
  if (args.who === undefined || args.who === null || String(args.who).trim() === '') {
    return fail('E_ARGS', 'save_card 必须传 who（抽卡人的昵称或 QQ 号，≤40 字）：卡记在谁名下只有你知道。');
  }
  const whoParsed = parseWho(args.who);
  if (!whoParsed.ok) return fail('E_ARGS', whoParsed.message);
  const whoName = whoParsed.name;
  if (!whoName) return fail('E_ARGS', 'who 不能是空白：请填抽卡人的昵称或 QQ 号。');

  const nameParsed = parseCardName(args.name);
  if (!nameParsed.ok) return fail('E_ARGS', nameParsed.message);
  const cardName = nameParsed.name;

  const tier = parseTierArg(args.tier);
  if (!tier) {
    return fail('E_ARGS', 'tier 只认 ' + TIER_KEYS.join(' / ') + '（收到「' + safeSlice(String(args.tier ?? ''), 20) + '」）。等级以 draw_card 当时返回的 tier 为准，不要自己造新的等级。');
  }
  const lineStats = countCustomLines(args.lines);
  const lineCount = lineStats.count;

  if (!ctx.recordHistory) {
    return {
      ok: true,
      who: { name: whoName, recorded: false },
      saved: null,
      advise: '图鉴记录在插件设置里关掉了（recordHistory=false）：这张卡没记进「' + whoName + '」的图鉴，gacha__card_dex 里也不会出现它。卡本身照常发出去就行。'
    };
  }

  let state = null;
  let warning = null;
  // 读-改-写在同一个临界区里：duplicate 分支不写存档，也要把临界区放开。
  const releaseStorage = await ctx.io.acquire();
  try { state = normalizeState(await ctx.io.read()); }
  catch (error) {
    warning = degradedWarning('read', error, whoName, 'save_card');
    warnDegraded(ctx, 'read', error, warning, 'save_card');
    state = null;
    releaseStorage();
  }

  let saved = null;
  let customCount = 0;
  if (!warning) {
    try {
      const at = safeInt(ctx.io.now(), Date.now());
      const entry = ensureUser(state, whoName, at);
      // 记账也算一次活动：淘汰按 a（最近一次活动时间）排，不刷新会被当成「最久没抽」先删掉。
      entry.a = at;
      const existing = entry.r.find((item) => item[0] === cardName);
      if (existing) {
        // 同名同人只记一次：保留最早的 firstAt，也不写存档。
        saved = { name: existing[0], tier: TIER_KEYS[existing[1]], firstAt: existing[2], duplicate: true };
      } else {
        entry.r.push([cardName, TIER_INDEX.get(tier), at, 1]);
        // 自创卡与稀有卡共用 24 条名额，超了按时间淘汰最旧的。
        trimState(state);
        state.x = at;
        await ctx.io.write(state);
        saved = { name: cardName, tier, firstAt: at, duplicate: false };
        customCount = entry.r.filter((item) => (item[3] || 0) === 1).length;
      }
    } catch (error) {
      saved = null;
      warning = degradedWarning('write', error, whoName, 'save_card');
      warnDegraded(ctx, 'write', error, warning, 'save_card');
    } finally {
      releaseStorage(); // duplicate 分支与写失败都要放行
    }
  }

  let advise;
  if (warning || !saved) {
    advise = '这张卡没能记进「' + whoName + '」的图鉴（' + String(warning?.message || '存档不可用').replace(/。$/, '') + '）。卡照常发出去，但不要说已经记好了；等存档恢复后可以再调一次 gacha__save_card。';
  } else if (saved.duplicate) {
    advise = '「' + saved.name + '」这张卡之前就记过了（' + saved.tier + '，首次记录时间戳 ' + saved.firstAt + '），这次没有重复添加。不要说因此抽到了 SSR —— 等级以 draw_card 当时的返回为准。';
  } else {
    advise = '已经记进「' + whoName + '」的图鉴：这是他/她的第 ' + customCount + ' 张自创卡（' + saved.tier + '，首次记录时间戳 ' + saved.firstAt + '）。词条不进存档 —— 存档只记名字 + 等级 + 首次时间（26KB 预算），你写的' + (lineCount ? ' ' + lineCount + ' 条词条' : '词条') + (lineStats.ignored ? '（其中 ' + lineStats.ignored + ' 条超过 60 字被忽略）' : '') + '请直接发在聊天里，不要说已经存进插件。不要说因此抽到了 SSR —— 等级以 draw_card 当时的返回为准。';
  }

  const result = { ok: true, who: { name: whoName, recorded: Boolean(saved) }, saved };
  if (warning) result.warning = warning;
  result.advise = advise;
  return result;
}

/**
 * 工具总入口：永远返回一个纯 JSON 对象，绝不抛异常。
 * code 只有 E_ARGS / E_NOT_FOUND / E_STORAGE / E_UNKNOWN_TOOL / E_NETWORK 五种；
 * 本插件不联网，所以「插件自己出意外」落到 E_NETWORK，message 里写明不是网络问题。
 * E_STORAGE 现在只由 card_dex 返回（没存档就没统计可看）；draw_card 存档失败走降级，
 * 照常出卡并在结果里挂 warning.code = E_STORAGE_DEGRADED。
 */
export async function runTool(ctx, name, args) {
  const tool = String(name ?? '');
  try {
    if (!ctx || ctx.enabled !== true) {
      return fail('E_ARGS', '抽卡在插件设置里被关掉了（enabled=false），先在宿主控制台的插件设置里打开。');
    }
    if (!isPlainObject(args)) {
      return fail('E_ARGS', 'args 必须是对象，例如 {"who":"小明","count":1}。传 null 会丢掉 who，抽了卡也不会记进图鉴，所以这里直接报错。');
    }
    if (tool === 'draw_card') return await drawCard(ctx, args);
    if (tool === 'save_card') return await saveCard(ctx, args);
    if (tool === 'card_dex') return await cardDex(ctx, args);
    return fail('E_UNKNOWN_TOOL', '本插件没有工具「' + safeSlice(tool, 40) + '」，只有 draw_card / save_card / card_dex。');
  } catch (error) {
    return fail('E_NETWORK', '插件内部出错（不是网络问题，本插件不联网）：' + safeSlice(String(error?.message || error), 200));
  }
}

// ───────────────────────── stdio NDJSON 协议 ─────────────────────────

/** 只有被当主模块跑时才进协议循环；被 import（单测/其它脚本）时什么都不做。 */
function isMainModule() {
  try {
    const argv1 = process.argv[1];
    if (typeof argv1 !== 'string' || !argv1) return false;
    const here = import.meta.url;
    const ran = pathToFileURL(path.resolve(argv1)).href;
    return process.platform === 'win32' ? here.toLowerCase() === ran.toLowerCase() : here === ran;
  } catch {
    return false;
  }
}

function main() {
  const write = (msg) => { try { process.stdout.write(JSON.stringify(msg) + '\n'); } catch { /* 管道断了也没别的办法 */ } };
  const warn = (text) => { try { process.stderr.write('[gacha] ' + text + '\n'); } catch { /* ignore */ } };
  // 回执统一走这里：不带 id 的消息（宿主的 shutdown 就是）回了会变成 {"result":…}，
  // 宿主侧记成一条无法识别的消息（protocolErrors +1）。没有 id 就不回话。
  const reply = (msg, result) => {
    if (msg.id === undefined || msg.id === null) return;
    write({ id: msg.id, result });
  };

  let seq = 0;
  const pending = new Map();
  let settingsFromInit = {};
  let settings = null;

  /**
   * 调宿主能力，resolve 的是**整条回执**（{result} 或 {error}），超时返回 null。
   * 和「直接取 result」相比，只有这样才分得清「读不到（null）」和「被拒（error）」——
   * 存档被拒不能当成空存档，否则下一次写入就把别人的记录覆盖没了。
   * `kind` 挂在抛出的 Error 上，供上层区分「超时（warn）」与「被明确拒绝（error）」。
   */
  const capCall = (method, params, timeoutMs = 3000) => new Promise((resolve) => {
    const id = 'cap-' + (++seq);
    const timer = setTimeout(() => { pending.delete(id); resolve(null); }, timeoutMs);
    pending.set(id, (msg) => { clearTimeout(timer); resolve(msg ?? null); });
    write({ id, method, params });
  });

  const capResult = async (method, params, timeoutMs) => {
    const reply = await capCall(method, params, timeoutMs);
    return reply && isPlainObject(reply.result) ? reply.result : null;
  };

  const storageError = (text, kind) => Object.assign(new Error(text), { code: 'E_STORAGE', kind });

  const replyDetail = (reply) => safeSlice(String(reply?.error?.message || reply?.error?.code || ''), 120);

  // 宿主的 storage 是单键读-改-写：两个 callTool 交错时（draw 还没写完，另一个已经在读旧值），
  // 后写的会把先写的整键覆盖掉。这里用一条 promise 链把「读存档 → 改 → 写存档」串成临界区；
  // 只串存档段，抽卡计算不排队。
  let storageChain = Promise.resolve();
  const acquireStorage = () => {
    let open = null;
    const gate = new Promise((resolve) => { open = resolve; });
    const wait = storageChain;
    storageChain = gate;
    let released = false;
    return wait.then(() => () => {
      if (released) return;
      released = true;
      open();
    });
  };

  const io = {
    read: async () => {
      const reply = await capCall('cap.storage.get', { key: STORAGE_KEY }, 4000);
      if (!reply) throw storageError('读存档超时（宿主的 storage 没有回话）', 'timeout');
      if (reply.error) throw storageError('读存档被拒：' + replyDetail(reply), 'rejected');
      const result = isPlainObject(reply.result) ? reply.result : {};
      const value = result.value;
      if (value === undefined || value === null) return null;
      // 存档存在、但顶层不是对象（被手改或别的版本写坏了）：当成空存档再整键写回会抹掉
      // 所有人的图鉴，所以这里必须抛出去，让上层走既有的降级分支（不写）。
      if (!isPlainObject(value)) throw storageError('存档格式不对：顶层应该是对象，实际是 ' + (Array.isArray(value) ? '数组' : typeof value), 'corrupt');
      return value;
    },
    write: async (state) => {
      const reply = await capCall('cap.storage.set', { key: STORAGE_KEY, value: state }, 4000);
      if (!reply) throw storageError('写存档超时（宿主的 storage 没有回话）', 'timeout');
      if (reply.error) throw storageError('写存档被拒：' + replyDetail(reply), 'rejected');
    },
    // 读-改-写的临界区入口：返回的函数负责放行（重复调用无副作用）。
    acquire: acquireStorage,
    now: () => Date.now(),
    // level：宿主明确拒绝 → error（进异常面板）；超时/未知 → warn。只写一行，不重试。
    warn: (text, level = 'warn') => {
      void capCall('cap.log.write', { level: level === 'error' ? 'error' : 'warn', message: safeSlice(text, 300) }, 1000);
    }
  };

  const readSettings = async () => {
    if (settings) return settings;
    const fromHost = await capResult('cap.config.get', {});
    settings = isPlainObject(fromHost?.settings)
      ? fromHost.settings
      : (isPlainObject(settingsFromInit) ? settingsFromInit : {});
    return settings;
  };

  const handleCallTool = async (msg) => {
    let result;
    try {
      const config = await readSettings();
      const ctx = makeContext(config, io);
      // args 缺省当空对象（宿主对无参工具可能不发 args）；显式 null 原样交给 runTool 报 E_ARGS。
      const args = msg.params?.args === undefined ? {} : msg.params.args;
      result = await runTool(ctx, msg.params?.name, args);
    } catch (error) {
      result = fail('E_NETWORK', '插件内部出错（不是网络问题，本插件不联网）：' + safeSlice(String(error?.message || error), 200));
    }
    write({ id: msg.id, result });
  };

  /**
   * 控制台打开设置页时会先 probe 一次（host.probe 最长等 15 秒）。不实现 probe 的插件得等满
   * 超时才出面板，表现就是「这个插件的设置加载比别的慢」——这里立刻回，且不读写任何状态。
   */
  const handleProbe = (msg) => {
    let info;
    try {
      // 只用 init 快照：probe 里再发一次 cap.config.get 要等宿主回执，白白多几毫秒到几秒。
      const config = isPlainObject(settings) ? settings : (isPlainObject(settingsFromInit) ? settingsFromInit : {});
      const ctx = makeContext(config, io);
      info = {
        ok: true,
        plugin: PLUGIN_ID,
        version: PLUGIN_VERSION,
        enabled: ctx.enabled,
        tone: ctx.tone,
        flavorMode: ctx.flavorMode,
        recordHistory: ctx.recordHistory
      };
    } catch (error) {
      info = { ok: false, plugin: PLUGIN_ID, version: PLUGIN_VERSION, error: safeSlice(String(error?.message || error), 120) };
    }
    reply(msg, info);
  };

  const onMessage = (msg) => {
    if (!msg || typeof msg !== 'object') return;
    if (typeof msg.id === 'string' && pending.has(msg.id)) {
      const done = pending.get(msg.id);
      pending.delete(msg.id);
      done(msg);
      return;
    }
    switch (msg.method) {
      case 'init':
        if (isPlainObject(msg.params?.settings)) settingsFromInit = msg.params.settings;
        settings = null; // 重新握手就重读配置
        reply(msg, { ok: true });
        return;
      case 'ping':
        reply(msg, { ok: true });
        return;
      case 'probe':
        handleProbe(msg);
        return;
      case 'shutdown':
        // 宿主退出时发的是**不带 id** 的 shutdown：reply 在没有 id 时不回话，只退出。
        reply(msg, { ok: true });
        setTimeout(() => process.exit(0), 30);
        return;
      case 'callTool':
        void handleCallTool(msg);
        return;
      default:
        return; // 未声明/不认识的方法忽略，不回话
    }
  };

  const MAX_BUFFER_CHARS = 1024 * 1024; // 单条 NDJSON 消息的字符上限，超了就丢
  let buffer = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (chunk) => {
    buffer += chunk;
    let index = buffer.indexOf('\n');
    while (index !== -1) {
      const line = buffer.slice(0, index).trim();
      buffer = buffer.slice(index + 1);
      if (line) {
        let parsed = null;
        try { parsed = JSON.parse(line); } catch { parsed = null; }
        if (parsed) onMessage(parsed);
      }
      index = buffer.indexOf('\n');
    }
    // 一直没有换行就一直涨：超过阈值直接丢弃这段缓冲，别让一条坏消息把内存吃光。
    if (buffer.length > MAX_BUFFER_CHARS) {
      warn('单条消息超过 ' + MAX_BUFFER_CHARS + ' 字符还没有换行：已丢弃这段缓冲');
      buffer = '';
    }
  });
  // stdout 断了（宿主已经走了）：再写只会一直 EPIPE，直接退出。
  process.stdout.on('error', () => process.exit(0));
  process.stdin.on('error', (error) => warn('stdin 出错：' + (error?.message || error)));
  process.on('uncaughtException', (error) => warn('未捕获异常（已忽略，进程继续）：' + (error?.message || error)));
  process.on('unhandledRejection', (error) => warn('未处理的 Promise 拒绝（已忽略）：' + (error?.message || error)));
}

if (isMainModule()) main();
