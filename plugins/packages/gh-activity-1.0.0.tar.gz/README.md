# GitHub 仓库动态（gh-activity）

查一个 GitHub 仓库最近怎么样：star / fork / 未关闭 issue 数、最近几次提交、最新 issue 标题、
最后推送时间、是否已归档。**不需要任何 Key**（走 GitHub 公开 API；未认证有速率限制，个人使用足够）。

## 装

控制台 →「设置 → 插件」→ 索引里点安装 → 点启用（装上 ≠ 授权）。或手工把本目录拷到
`$DATA_DIR/plugins/gh-activity/`。

## 配置（可选）

```json
{ "plugins": { "settings": { "gh-activity": { "perPage": 5 } } } }
```

`perPage`：返回多少条提交/issue，默认 5（1-20）。

## 它不做什么

- 只读：不 star、不提 issue、不改任何东西（`capabilities` 里也没有 `send`，它没法在群里发言）。
- 不自己 `fetch`：请求经宿主的 `cap.http.request`（内网地址被拦、有体积上限与超时，日志里查得到）。
- 不缓存：每次调用都是即时查询，所以数字是最新的，也意味着会消耗 GitHub 的速率额度。
