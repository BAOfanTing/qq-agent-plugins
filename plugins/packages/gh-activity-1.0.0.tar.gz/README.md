# GitHub 仓库动态（gh-activity）

"这个项目还活着吗"—— 一条命令看 star / fork / 未关闭 issue 与 PR 数、最近几次提交、最新 issue 标题、
最后推送时间、是否已归档。走 GitHub 公开 API，**不需要任何 Key**（未认证有速率限制，个人使用足够）。

## 群里可以这么问

- 「sakurawwwxh/qq-agent-plus 最近还更新吗」
- 「facebook/react 现在多少 star」
- 「这个库最近有没有人提 issue」+ 仓库地址

模型会调 `gh-activity__repo_activity`，再把数字整理成一句话给你。

## 它给出什么

- star / fork / 未关闭 issue 与 PR 数
- 最近几次提交（作者 + 标题 + 时间）
- 最新 issue 标题
- 最后推送时间、是否已归档

## 配置（可选）

```json
{ "plugins": { "settings": { "gh-activity": { "perPage": 5 } } } }
```

`perPage`：返回多少条提交 / issue，默认 5（1-20）。

## 边界

- **只读**：不 star、不提 issue、不改任何东西；也没有 `send` 能力，不能在群里发言。
- 请求经宿主的 `cap.http.request`（内网地址被拦、有体积上限与超时，日志里查得到）。
- **不缓存**：每次都是即时查询 —— 数字是最新的，也意味着会消耗 GitHub 的速率额度。

## 装

控制台左侧「插件」→ 目录里点安装 → 点启用（装上 ≠ 授权）。手工的话把本目录拷到
`$DATA_DIR/plugins/gh-activity/`。
