# 阴阳抽卡（gacha，可切回日常风格）

有人「抽一张卡」「来张卡」「@Bot 抽卡」时，给他抽一张卡：**等级 + 星级 + 卡名 + 词条**。
默认调性就是**阴阳怪气**（只阴阳事、物与泛化身份，不点名真人）；把设置 `tone` 改成 `neutral`
就退回原来的日常/抽象风格。返回纯 JSON，文案由模型转述。

零依赖、单文件 ESM、**不联网、不写文件**：唯一的持久化走宿主的 `cap.storage`。

## 装

把整个 `gacha/` 目录放进 `$DATA_DIR/plugins/gacha/`（或按宿主的方式打包安装），在控制台
「插件」页启用 + 授权。三个文件，没有 `package.json`、没有 `node_modules`：

```bash
tar --format=ustar -czf gacha-1.0.0.tar.gz -C gacha README.md index.mjs plugin.json
```

## 等级与概率（固定，模型不许改）

| 等级 | 星级 | 概率 | 词条条数 | yang 卡池 / 词条池 | neutral 卡池 / 词条池 |
| --- | --- | --- | --- | --- | --- |
| `N` | ★ | 52% | 1 条 | 44 张 / 35 条 | 48 张 / 35 条 |
| `R` | ★★ | 26% | 2 条 | 33 张 / 32 条 | 35 张 / 32 条 |
| `SR` | ★★★ | 13% | 3 条 | 26 张 / 32 条 | 30 张 / 32 条 |
| `SSR` | ★★★★ | 6% | 4 条 | 18 张 / 31 条 | 20 张 / 31 条 |
| `UR` | ★★★★★ | 2.4% | 5 条 | 12 张 / 31 条 | 12 张 / 31 条 |
| `???` | ★★★★★★ | 0.6% | 6 条 | 7 张 / 31 条 | 7 张 / 31 条 |

两栏**只有内容不同**：概率、星级、词条条数、存档口径完全一样。切 `tone` 不影响掷骰子。

- 概率用**整数万分比**存（5200 / 2600 / 1300 / 600 / 240 / 60，和恰好 10000），`rate = bp / 10000`，
  六个 `rate` 加起来是 1，不是「大致 1」。
- `starsText` 就是 `"★"` 重复 `stars` 次；`???` 的等级字面量在 JSON 里是 `"???"`。
- 词条条数**严格** = 1/2/3/4/5/6，不分等级内大小 —— 这条规则在任何档位下都成立（模型自创时也只能写这么多条）。
  内置的卡池与词条池每级 ≥30 条，**默认只当「同风格素材 + 兜底」**：卡名与词条真正由模型创作（见下节）。
- 卡池风格分两套：**yang**（默认）从 N 的「保温杯 / 打卡机」一路到 ??? 的「老板的『简单聊两句』」，
  全是「物 / 事 / 泛化身份 + 一句反讽」；**neutral** 是原来的分层（N/R 日常具象、SR 起偏抽象、UR/??? 传奇化）。
  `card.kind` 是粗分类：`object` / `animal` / `food` / `place` / `plant` / `event` / `concept` / `being`。

## 卡片风格：阴阳（默认）/ 日常

设置 `tone` 两档，只换**卡名与词条的调性**，不动概率与规则：

| 档位 | 调性 | 例子 |
| --- | --- | --- |
| `yang`（**默认**） | 阴阳怪气：表面在夸，实际在损；短、准、不留情面，不骂脏字、不人身攻击 | 见下面三句 |
| `neutral` | 原来的日常 / 抽象 / 传奇三层风格 | 「电饭煲」「半句话的梦」「归零之海」 |

用户给定的三条目标调性（就是卡池里挂的 hook，原句照抄，一字未改）：

| 卡名 | 等级 | hook |
| --- | --- | --- |
| 我家鱼缸里那条金鱼 | `SR` | 会吃不会说 |
| 电饭锅 | `UR` | 里面还剩半锅白饭，不是给你的 |
| 食堂打饭阿姨 | `SSR` | 手抖得比你多 |

### 为什么只阴阳「事、物、身份梗」

大群里阴阳**人**就是吵架，阴阳**东西**才是梗。所以风格落在三类对象上：物（保温杯、电饭锅、
永远在维修的电梯）、事（周五下午的会、通勤的最后一公里）、泛化身份（甲方、老板、打工人、
食堂阿姨、会点头的同事）。**红线（写进 `advise` 与 prompt，逐条）**：

1. 不出现任何真人姓名或隐私；
2. 不用真实政治人物或其影射（`DENY_PATTERNS` 仍然兜底，`save_card` 命中直接 `E_ARGS`）；
3. 不做地域、性别、民族、职业等**群体歧视**；
4. 不写色情；
5. 不针对群里的某个具体人。

可以自嘲，可以损甲方/老板/打工人/食堂阿姨这类**泛化身份**，但不能落到群里某个真实的人头上。
代价：`yang` 的「阴阳对象」由模型自行把握，插件在执行时**无法判定**它有没有越界（见「已知限制」）。

## 词条档位（`flavorMode`，治「复读机」的那个旋钮）

插件只负责**掷等级与概率**；卡名与词条由谁写，由设置 `flavorMode` 决定：

| 档位 | 卡名 | 词条 | 适合 |
| --- | --- | --- | --- |
| `free`（**默认**） | 模型**自己起**一个池子里没有的名字，返回的 `card.name` 只是同档风格素材 | 内容全由模型写，**条数必须等于**该等级规定条数（1/2/3/4/5/6）；`lines` 只当素材 | 想要活人感、不想复读 |
| `extend` | 用插件返回的卡名 | 照 `lines` 转述 + 可自己再加 1–2 条 | 想稳一点、又不要太死板 |
| `off` | 用插件返回的卡名 | **只能**照 `lines` 原样列出 | 完全不想让模型改一个字 |

- 默认 `free`：卡名与词条全部来自模型，池子退化成素材与兜底。这就是之前「模型照抄 `lines`」问题的解法。
- `free` 的风格指令按 `tone` 换：`yang` 下 `advise` 要求「明褒暗贬 / 先夸后损 / 短句收尾」并附上面那三条示例
  当 few-shot（明写「不要照抄这三句」）；`neutral` 下保持原来的写法（不提阴阳）。`off` / `extend` 与 `tone` 无关。
- 三档的 `advise` **文案完全不同**（不是同一句话换个词）：`off` 明写「词条只能照 lines 原样列出」，
  `extend` 明写「照 lines 转述 + 可再加 1–2 条」，`free` 明写「卡名不要用返回里的 card.name」「词条条数
  必须等于 N 条」「内容全部由你自己写」「自创完调 `save_card` 回执」「内容红线」「想不出才退回照抄」。
- **旧设置被推翻**：以前的 `allowModelFlavor` 布尔项不再出现在设置里；配置里没有 `flavorMode` 时会读它
  （`false` → `off`，`true` → `free`），两者都没有按 `free`。
- 任何档位下，**等级、星级、概率**都不可改（那是官方结果），插件也不会给自创内容做内容审核 —— 见「已知限制」。

## 三个工具

### `draw_card({ count?, who? })`

| 参数 | 说明 |
| --- | --- |
| `who` | **必须传**（schema 上可选，但描述里要求模型传）：抽卡人的昵称或 QQ 号，≤40 字，模型从对话里取。不传照样能抽，只是不记个人图鉴 |
| `count` | 1–10，默认取设置 `count`（一般 1）。**越界直接 E_ARGS**，不静默夹取（`count=999` 被夹成 10 会让模型以为抽了 999 张） |

成功返回（定稿形状）：

```json
{ "ok": true, "tier": "SR", "stars": 3, "starsText": "★★★", "tierName": "SR",
  "card": { "name": "时间之外的单程票", "kind": "object" },
  "lines": ["它出现的时间总是提前一点。", "提示很少，代价很高。", "它把提问也当成了回答。"],
  "firstTime": false, "firstTimeTier": null, "rate": 0.13,
  "summary": { "total": 1, "byTier": { "N": 0, "R": 0, "SR": 1, "SSR": 0, "UR": 0, "???": 0 } },
  "who": { "name": "小明", "recorded": true },
  "advise": "本轮插件掷出来的只有等级与概率：SR ★★★（13%）就是官方结果……卡名不要用返回里的 card.name（「时间之外的单程票」只是 SR 档的风格素材）：先自己想一个卡名……词条条数必须等于 3 条……自创完请顺手调用一次 gacha__save_card 回执……" }
```

- `count > 1` 时多一个 `draws` 数组（每项形状同上，去掉 `summary`/`who`/`advise`）；
  **顶层字段永远是其中第一张**，`summary.byTier` 是本次六级的计数（六个键都在，没抽到记 0）。
- `firstTime` = 这次有没有**第一次**抽到某个 SSR 及以上的卡（稀有记录按人存，同名卡不重复记）；
  `firstTimeTier` 是这次新记录里最高的那一级，没新记录就是 `null`。没传 `who` 时恒为 false。
- `who.recorded` = 这次有没有真的记进图鉴（没传 `who`，或设置 `recordHistory=false` 时是 false）。
- **降级字段 `warning`**：只有存档没读写成功时才出现，形如
  `{ "code": "E_STORAGE_DEGRADED", "message": "读存档失败（…）：这次抽卡照常出结果，但没有记进图鉴（小明）。" }`。
  此时 `ok` 仍是 `true`、卡照常返回，但 `who.recorded=false`、`firstTime=false`、`firstTimeTier=null`，
  `advise` 里会多一句「这次没能记进图鉴……不要说已记录」。**读失败时一个字节都不会写回**（把读失败
  当空存档写回去会抹掉所有人的图鉴），并且每次降级只写**一条**宿主日志。
- `card.name` 与 `lines` 的定位随档位变化（见上节）：`free` 下它们**只是素材**，模型要自己起名字、自己写
  词条，并调 `save_card` 回执才进图鉴；`extend`/`off` 下卡名就是结果、词条照 `lines`。
- `advise` 是给模型看的指令：三档文案互不相同（`free` 会点名「卡名不要用返回里的 card.name」「词条条数
  必须等于 N 条」「调用 gacha__save_card」「内容红线」「想不出才退回照抄」）。

### `save_card({ who, name, tier, lines? })` —— 自创卡的记账口

`draw_card` 只掷等级，**不记自创卡名**；模型自创完再调一次 `save_card`，那张卡才进图鉴。

| 参数 | 说明 |
| --- | --- |
| `who` | **必填**，抽卡人的昵称/QQ 号，≤40 字，和抽卡时一致（超长/非字符串 → `E_ARGS`） |
| `name` | **必填**，模型起的卡名，≤40 字；去掉控制字符与孤立代理项；**命中 DENY 名单 → `E_ARGS`**（并说明理由） |
| `tier` | **必填**，只认 `N`/`R`/`SR`/`SSR`/`UR`/`???`（大小写不敏感），其它 → `E_ARGS` |
| `lines` | 可选，数组 ≤6 条、每条 ≤60 字；**只用于回执，不进存档**（存档只记名字+等级+首次时间，26KB 预算） |

返回：

```json
{ "ok": true, "who": { "name": "小明", "recorded": true },
  "saved": { "name": "折叠的便利店", "tier": "SR", "firstAt": 1767225600000, "duplicate": false },
  "advise": "已经记进「小明」的图鉴：这是他/她的第 1 张自创卡（SR…）。词条不进存档 —— …" }
```

- 同名同人**只记一次**：返回 `duplicate:true`（保留最早的 `firstAt`），不新增条目、也不写存档。
- **不增加抽数** `c`、不改全局计数与热门卡榜（那些由 `draw_card` 记）；只往 `r` 里放一条 `src=1`。
- 设置 `recordHistory=false` 时直接返回 `ok:true` + `saved:null` + `who.recorded=false`，advise 说明「图鉴关了，没记」，**不碰存档**。
- 存档读/写失败时**不失败**：`ok:true` + `warning.code=E_STORAGE_DEGRADED`（同 `draw_card` 的降级形状），并写一条宿主日志 —— 群里那句话不能因为记账失败就发不出去。
- `advise` 会说明「第 N 张自创卡」或「这张之前就记过」，并提醒不要因此宣称抽到了 SSR。

### `card_dex({ who?, top? })`

| 参数 | 说明 |
| --- | --- |
| `who` | 要查谁（昵称/QQ 号，要和抽卡时一致）。不传就只返回全局统计 + 热门卡榜 |
| `top` | 热门榜 1–20 条，默认 10 |

返回：

```json
{ "ok": true, "who": "小明", "draws": 4,
  "byTier": { "N": 1, "R": 2, "SR": 1, "SSR": 0, "UR": 0, "???": 0 },
  "rare": [ { "name": "未命名的第零号", "tier": "???", "firstAt": 1767225600000 } ],
  "custom": [ { "name": "折叠的便利店", "tier": "SR", "firstAt": 1767225600001 } ],
  "total": { "users": 1, "draws": 4, "byTier": { "N": 1, "R": 2, "SR": 1, "SSR": 0, "UR": 0, "???": 0 } },
  "top": [ { "name": "钥匙串", "tier": "N", "count": 186 } ],
  "advise": "「小明」一共抽了 4 次……" }
```

- `rare` = 池内抽到的稀有卡（`src=0`，SSR 及以上，由 `draw_card` 记）；`custom` = 模型自创卡（`src=1`，
  任意等级，由 `save_card` 记）。两个数组都按首次时间从新到旧，**共用每人 24 条名额**。
  全局查询时两者恒为 `[]`，`advise` 会说明。
- `total` 是全局的：`users` = 当前还留在存档里的图鉴人数（会被淘汰，见下），`draws` = 累计抽数（含匿名抽卡）。
- 查不到这个人 → `ok:false` + `E_NOT_FOUND`，如实转述，不要编数据。

### 失败

`{ "ok": false, "error": { "code": "…", "message": "中文、可照做" } }`，code 只有五种：

| code | 什么时候 |
| --- | --- |
| `E_ARGS` | args 不是对象 / `count`、`top` 越界 / `who` 不是字符串或超过 40 字 / `save_card` 的 `name` 空或命中 DENY、`tier` 不是六级之一 / `enabled=false` / `recordHistory=false` 时查图鉴 |
| `E_NOT_FOUND` | `card_dex` 查的人没有记录（没抽过、名字不一致，或被淘汰） |
| `E_STORAGE` | **只由 `card_dex` 返回**：读不出存档（超 32KB 单值 / 超 256KB 总量 / 超时）就没有统计可展示。`draw_card` **不会**返回它 —— 抽卡存档失败走降级（见 `draw_card` 的 `warning` 字段），照常出卡 |
| `E_UNKNOWN_TOOL` | 调了不存在的工具名（只有 `draw_card` / `save_card` / `card_dex`） |
| `E_NETWORK` | 插件自己出意外。**本插件完全不联网**，message 里会写明「不是网络问题」 |

## 设置（5 项）

| 键 | 默认 | 说明与代价 |
| --- | --- | --- |
| `enabled` | `true` | 关掉后模型看不到这三个工具。已存的图鉴还在，只是暂时抽不了也查不了 |
| `count` | `1` | 模型不传 `count` 时抽几张。调大之后每句「抽一张卡」都变多连，返回体积和提示词占用一起涨 |
| `maxCount` | `10` | `count` 的上限，最多 10（工具 schema 的硬上限）。调小之后模型传超了会直接 E_ARGS |
| `flavorMode` | `free` | `off` / `extend` / `free` 三档（见上节）。**代价**：`free` 下卡名与词条由模型负责，插件只掷等级与概率，内容不再受卡池与人工审阅保护（只有 DENY 名单兜底）；模型忘记调 `save_card` 时那一抽只有抽数、没有卡名。旧的 `allowModelFlavor` 仍兼容（`false`→`off`，`true`→`free`） |
| `tone` | `yang` | 卡片风格：`yang` 阴阳（默认）/ `neutral` 原来的日常风格。**代价**：两套卡池与词条池都要打包进来（体积翻倍，仍是零依赖单文件）；`yang` 的阴阳对象由模型把握，插件无法在执行时判定是否越界。旧配置没有 `tone` 时按 `yang` |
| `recordHistory` | `true` | 用 storage 记个人图鉴与全局统计（含自创卡名）。**代价**：每次抽卡 / `save_card` 各一次读 + 一次写（宿主上限 120 写/分钟）；撞上限时**抽卡与记账都照常、只是这次不记**（返回 `warning` + 一条宿主日志）。关掉后完全不碰 storage，但图鉴查不到任何数据，`save_card` 也只返回「没记」 |

刻意**没有**做：保底（pity）、冷却 CD、排行榜、每日次数限制 —— 需求里没有，加了只是多一堆能出错的旋钮。

## 持久化与淘汰

一个键 `gacha.v1`，**一次工具调用只读一次、写一次**（读-改-写，`count=10` 也只写一次）：

```json
{ "v": 1,
  "u": { "小明": { "c": 4, "t": [1,2,1,0,0,0],
                  "r": [["未命名的第零号",5,1767225600000,0], ["折叠的便利店",2,1767225600001,1]],
                  "a": 1767225600000 } },
  "g": { "c": 4, "t": [1,2,1,0,0,0] },
  "h": { "钥匙串": 186 },
  "x": 1767225600000 }
```

`c`=抽数、`t`=六级计数（顺序 N,R,SR,SSR,UR,???）、`a`=最近一次抽卡时间、`g`=全局、`h`=全局热门卡计数。

`r` 的每条是四元组 `[卡名, 等级下标, 首次时间毫秒, src]`：`src=0` 池内稀有（`draw_card` 记，SSR 及以上），
`src=1` 模型自创（`save_card` 记，任意等级）。**词条不入存档** —— 只记名字 + 等级 + 首次时间。
旧存档的三元组 `[卡名, 等级下标, 首次时间]` 读进来时一律补成 `src=0`（不丢数据）。

宿主的硬限制：**单值 ≤32KB、总量 ≤256KB、每分钟 ≤120 写**。所以淘汰按「单值 32KB」算，
软预算 **26KB**：

1. 每人 **稀有 + 自创共用 24 条**，只留最新的（自创卡会占掉稀有记录的名额，README 这句就是口径）；
2. 热门卡表只留 **48** 张；
3. `who` 条目只留最近抽过的 **200** 人；
4. 还超 26KB 就按「**最久没抽**」一个人一个人删（最后删的是刚抽的人）；
5. 病态情况（热门表本身超预算）就清空热门表兜底。

读坏了 / 旧形状都不报错：能认的字段留下，认不出的丢掉（`normalizeState`）。

**存档不可用时的行为**（不让存档拖死抽卡）：

| 场景 | `draw_card` | `save_card` | `card_dex` |
| --- | --- | --- | --- |
| 读失败 | 照常出卡，**不写**存档，挂 `warning`，宿主明确拒绝记 `error` / 超时记 `warn` | `ok:true` + `warning`，**不写**存档，日志同上 | `E_STORAGE`（没数据就没得展示），不写 |
| 写失败 | 照常出卡（卡已经抽出来了），挂 `warning`，日志同上 | `ok:true` + `warning`（`saved:null`），日志同上 | — |
| 正常 | 一次读 + 一次写 | 一次读 + 一次写（`duplicate` 时只读不写） | 一次读、不写 |

## 已知限制

1. **不会知道是谁在抽**。宿主的 `callTool` 只发 `{name, args}`，**不带 `chatKey`/`uid`**，
   所以「谁抽的卡」完全依赖模型把昵称/QQ 号填进 `who`。模型漏传时这一抽只能匿名（`recorded:false`），
   返回的 `advise` 会明确要求它不要谎称「已记进你的图鉴」。
2. **不按群隔离**：存档是全局一张表，`who` 相同就算同一个人，没有群维度（宿主的调用里拿不到群号）。
3. **DENY 名单只是兜底**。内置卡池是人工把关的（本文件里没有任何真实政治人物），运行时另有一道
   `DENY_PATTERNS` 子串过滤：池内命中就**直接跳过这张卡**、同等级其它卡等概率顺延；`save_card` 的
   自创卡名命中则直接 `E_ARGS`。它不是内容安全的保证 —— 它只挡住「称谓类」名字（主席/总统/教皇…），
   **往池子里加卡、以及模型自创的卡名，仍然必须人工过一遍**。
4. **同名卡不重复记稀有**：`firstTime` 只在第一次抽到某个 SSR+ 卡时为 true；之后再抽同一张卡，
   词条会变，但稀有记录不会多一条。
5. **图鉴会被淘汰**：超过 200 人或存档超 26KB 时，最久没抽的人先消失（不是 bug，是 32KB 单值上限下
   唯一能选的策略）。查不到时 `card_dex` 报 `E_NOT_FOUND`，message 里写明了这个原因。
6. **参数越界直接报错**（`count=0/999`、`top=0/99`、`who` 超 40 字）：不静默夹取，
   免得模型以为「999 张」真的抽了。`count` 上限同时受工具 schema（10）与设置 `maxCount` 限制。
7. 词条与卡名在默认档位由**模型创作**，质量与安全由模型负责；插件只保证「条数正确、等级没被改、
   名字过了 DENY 过滤」。想让文案完全由插件产出、可复现，把 `flavorMode` 调成 `off`。
8. **存档失败时那一抽不会被记下**（返回 `warning.code=E_STORAGE_DEGRADED`）：抽卡本身照常，但没有
   重试队列也没有本地补偿 —— 想记进图鉴只能重抽一次。宿主每分钟 120 写的限频在群聊热潮时会被撞到，
   这是有意的取舍：宁可少记一次，也不让所有人抽不出卡。
9. **插件不存词条**：`save_card` 的 `lines` 只回执不入档（26KB 预算），所以图鉴里只能看到自创卡的名字、
   等级与首次时间；有人问「那次的词条呢」只能回答没保存。
10. **模型可能忘记调 `save_card`**：`draw_card` 与 `save_card` 是两次独立调用，插件无法强制。忘了调时
   那一抽只有抽数与等级统计、没有卡名；返回的 `advise` 会明确要求它回执，但最终能不能记上取决于模型。
11. **阴阳的对象由模型自行把握，插件无法在执行时判定「是否点名了真人」**：插件只能掷等级、过滤池内文案、
   在 `advise`/prompt 里写红线、并对 `save_card` 的卡名做 DENY 子串兜底；它没有语义审核能力。
   所以红线本质是**提示词约束 + 人工把关词库**。一旦发现模型越界（点名群友、地图炮、碰政治），
   立刻把 `tone` 切回 `neutral` 或直接关掉插件（`enabled=false`）——这两个开关是唯一可靠的止血手段。

## 导出的纯函数（便于单独测）

`pickTier(rng)` / `pickCard(tier, rng, tone)` / `pickFlavors(tier, rng, count, hook, cardName, tone)` /
`drawOne(tier, rng, tone)` / `buildDrawResult({draws, who, firstTime, firstTimeTier, flavorMode, tone, warning})` /
`buildDrawAdvise(result, {flavorMode, tone})` / `normalizeFlavorMode(raw, legacyAllowModelFlavor)` /
`normalizeTone(raw)` / `cardNamesOf(tier, tone)` / `flavorLinesOf(tier, tone)` /
`makeContext(settings, io)` / `runTool(ctx, name, args)` / `normalizeState(raw)` / `trimState(state, budget)` /
`countsToObject(counts)` / `rateOf(tier)` / `isDeniedName(name)`，外加常量 `TIERS` / `TIER_KEYS` /
`TIER_RATES` / `CARD_COUNTS`（按 tone 分组）/ `FLAVOR_COUNTS`（按 tone 分组）/ `TONES` / `FLAVOR_MODES` /
`DENY_PATTERNS` / `STORAGE_KEY` / `DEFAULTS` / `MAX_WHO` / `MAX_CUSTOM_LINES`。

`cardNamesOf(tier, tone)` / `flavorLinesOf(tier, tone)` 是为了验收「抽到的名字必须来自对应池子」而导出的
只读视图（两套池子都能抽，且互不串味）。

`rng` 全程可注入（`makeContext(settings, { rng })`），所以分布能测；
`io` 也可注入（`{ read, write, now, warn, rng }`），所以存档异常能测。
被 `import` 时什么都不跑，只有当主模块跑才进 stdin 的 NDJSON 循环。

## 本地怎么验

```bash
# ① 真协议 + 假宿主：draw_card -> save_card -> card_dex 一条链（tone=yang）
node .work/jm-harness.mjs ./gacha '{"enabled":true,"tone":"yang"}' \
  '{"calls":[{"name":"draw_card","args":{"who":"验收乙","count":2}},{"name":"save_card","args":{"who":"验收乙","name":"会自我感动的鱼缸","tier":"SR","lines":["词条一","词条二","词条三"]}},{"name":"card_dex","args":{"who":"验收乙"}}]}' \
  .work/gacha-acc3.json

# ①b 同一链条在 tone=neutral 下再跑一遍（两套池子都要能抽）
node .work/jm-harness.mjs ./gacha '{"enabled":true,"tone":"neutral"}' \
  '{"calls":[{"name":"draw_card","args":{"who":"验收丁","count":2}},{"name":"save_card","args":{"who":"验收丁","name":"半透明的猫","tier":"SR"}},{"name":"card_dex","args":{"who":"验收丁"}}]}' \
  .work/gacha-acc4.json

# ② 两套池子 / 三档 advise / save_card 分支 / 旧存档 / 降级 / 分布 / 压测（不需要宿主、不联网）
node .work/gacha-selftest.mjs

# ③ plugin.json 用宿主真实的 manifest 校验器过一遍
cd .work && node gacha-manifest-check.mjs
```

实测结论（本仓库 `.work/` 下脚本的真实输出，不是估计）：

- **两套池子都活着**：yang 抽到的卡名 100% 落在 yang 池、neutral 100% 落在 neutral 池（`cardNamesOf` 包含
  校验），且各自都抽到了「只有本档才有」的卡；三条示例卡（金鱼 / 电饭锅 / 食堂打饭阿姨）等级与 hook 原句一致。
- **缺省即 yang**：不带 `tone` → `yang`；`tone:"neutral"` 的池子数量与旧版逐项相等（48/35/30/20/12/7 与
  35/32/32/31/31/31），即切回 neutral 行为与旧版一致。
- **分布**：两套 tone 各 10000 次抽卡（mulberry32 固定种子）都是 N 52.030% / R 26.030% / SR 12.910% /
  SSR 5.840% / UR 2.520% / ??? 0.670%，与权重表最大偏差 **0.160 个百分点**（阈值 1.5pp）；
  六个 `rate` 之和与 1 的偏差是 0。换风格不动骰子。
- **词条**：1/2/3/4/5/6 条严格成立；同名卡连抽 20 次出现 14–20 种不同组合（池子不放回采样）。
- **三档 advise**：`off` 含「词条只能照 lines 原样列出」且不含「自创」；`extend` 含「照 lines …再加 1–2 条」
  且不含自创指令；`free` 含「自己想一个卡名」「词条条数必须等于」「save_card」「内容红线」「兜底」。
  三档文案互不相同（断言在 selftest 里）。`free+yang` 额外含风格定义、三条示例原句、「不要照抄」与五条红线；
  `free+neutral` 整段不含「阴阳」二字。
- **旧配置**：`{"allowModelFlavor":false}` → `off`，`{"allowModelFlavor":true}` → `free`，都没有 → `free`。
- **save_card**：正常记 `duplicate:false` 且 **不增加抽数**；同名重复 `duplicate:true` 且不新增条目、
  保留最早 `firstAt`；`tier` 乱填 / `name` 命中 DENY / `who` 超 40 字 → `E_ARGS`；存档写失败 →
  `ok:true` + `warning` + 恰好 1 条 `io.warn`。
- **旧存档**：三元组 `[名, 等级, 时间]` 读进来自动补 `src=0`，都出现在 `dex.rare`、`custom` 为空；
  四元组 `src=1` 出现在 `dex.custom`；坏数据丢弃。
- **压测**：300 个 `who` 各抽 50 次（15000 次抽卡）+ 每人 3 次 `save_card`（共 2400 次写入），
  存档序列化后 **26320 字节（25.7KB）**，0 次写入被宿主的 32KB 单值上限拒，每人记录 ≤24 条。
- **降级**：read/write 抛错时 `draw_card` 与 `save_card` 都仍然 `ok:true` 并带
  `warning.code=E_STORAGE_DEGRADED`，`io.warn` 每次恰好被调用 1 次（拒绝 → `error`、超时 → `warn`），
  read 失败时写入次数为 0；`card_dex` 读失败仍是 `E_STORAGE` 且不写存档。
