// Pixiv 来张图 · qq-agent-plus 插件 v1 移植版
//
// ── 这次移植改了什么（先看这段，再看代码）─────────────────────────────────
// 原插件是**同进程技能**：它能 import 宿主的 src/config.js、能写临时文件、能调
// sender.sendImage(img.file)。插件 v1 契约把这三条全部拿走了：
//   ① 能力白名单只有 tools / observe / schedule / http / log / storage / config / send；
//   ② cap.http.request 是 GET、无自定义头、body 按**字符串**返回（<=40000 字符）→ 拿不到图片二进制；
//   ③ 插件进程没有写权限（--allow-fs-write 一个都不给），状态只能进 cap.storage（单值 32KB）；
//   ④ cap.send.text 只收 { chatKey, text }，**纯文本**，没有图片段。
// 所以「下原图 → 落临时文件 → sendImage」这条路在 v1 里不存在。本移植保留的是**检索那一半**：
// 返回 PID / 标题 / 作者 / 标签 / 分级 + **可直接打开的图链**，由模型把链接讲出来。
//
// ── 图链为什么用接口给的 urls.original ──────────────────────────────────
// i.pximg.net 强制校验 Referer，插件发不出自定义头，所以直连原站必然 403。
// lolicon 返回的 urls.original 本身就是 i.pixiv.re 的**完整路径**反代地址（带日期目录），
// 2026-10-19 实测 200 / image/jpeg。而设置里那个 https://pixiv.re/{pid}.png **简写**同日实测
// 返回 500（原插件文档说它可用，已经过期）—— 所以它只留作兜底，且兜底失败会明确写进 note。
//
// ── 取不到图自动换下一张 ────────────────────────────────────────────────
// 内置索引是旧的，里面会留着已被作者删除/限制的作品。cap.http.request 虽然拿不到二进制，
// 但**状态码是可信的**（宿主 safeFetch 读到上限就截断并返回 statusCode）。于是每张候选先探一次：
// 非 200 → 记进 dead 表（带 deadTtlDays 过期）→ 换下一张备选。
// 网络类失败（status 0）**不拉黑**：那可能只是临时抖动，拉黑等于把这张图永久跳过。
//
// ── PID 索引（去重）──────────────────────────────────────────────────
// 给出去过的作品号存在 cap.storage 里（宿主落盘到 plugin-data/pixiv-illust/，重装插件不丢）。
// 只有**真的要给出去的结果**才记账 —— 探测失败的候选不记，否则一次抖动就把那张图永久跳过了。

const write = (message) => { process.stdout.write(JSON.stringify(message) + '\n'); };

let requestSeq = 0;
const pending = new Map();
const callHost = (method, params) => new Promise((resolve, reject) => {
  const id = ++requestSeq;
  pending.set(id, { resolve, reject });
  write({ id, method, params });
});

const DEFAULTS = {
  loliconApiUrl: 'https://api.lolicon.app/setu/v2',
  imageUrlTemplate: 'https://pixiv.re/{pid}.png',
  excludeAI: false,
  ratings: ['safe'],
  allowR18: false,
  maxCount: 2,
  poolSize: 5,
  stateCap: 800,
  retryCandidates: 3,
  deadTtlDays: 7
};

const RATING_LABEL = { safe: '全年龄', r18: 'R18', r18g: 'R18G' };
const MAX_COUNT = 5;
const MAX_NUM = 20;
const DAY_MS = 24 * 60 * 60 * 1000;

// QQ 端对机器人发出的链接基本不做成可点链接、也不渲染图片预览（2026-10-19 用户实测反馈）。
// 所以每次给图链都必须让模型**明说一句「复制到浏览器打开」** —— 否则用户只看到一串点不动的字，
// 会以为是插件给错了。这条文案放在 advise 里，是写给模型看的指令。
const LINK_HINT = '⚠️ QQ 里这条链接通常点不开、也不会显示预览：回复时必须提醒用户「复制链接到自己的浏览器地址栏打开」。';

let settings = {};

const num = (value, fallback, min, max) => {
  const n = Math.floor(Number(value));
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
};

/** 配置可能是手改的 JSON：形状不对一律退回默认值，不让一个坏值把整次调用炸掉。 */
function config() {
  const s = settings && typeof settings === 'object' ? settings : {};
  const ratings = Array.isArray(s.ratings)
    ? s.ratings.map((r) => String(r).toLowerCase()).filter((r) => Object.prototype.hasOwnProperty.call(RATING_LABEL, r))
    : null;
  return {
    apiUrl: String(s.loliconApiUrl || DEFAULTS.loliconApiUrl).trim(),
    imageTemplate: String(s.imageUrlTemplate || DEFAULTS.imageUrlTemplate).trim(),
    excludeAI: s.excludeAI === true,
    // 旧配置只有 allowR18 布尔值：没有 ratings 时按它回退（与原插件一致）
    ratings: ratings && ratings.length
      ? ratings
      : (s.allowR18 === true ? ['safe', 'r18', 'r18g'] : DEFAULTS.ratings),
    maxCount: num(s.maxCount, DEFAULTS.maxCount, 1, MAX_COUNT),
    poolSize: num(s.poolSize, DEFAULTS.poolSize, 1, 50),
    stateCap: num(s.stateCap, DEFAULTS.stateCap, 10, 2000),
    retryCandidates: num(s.retryCandidates, DEFAULTS.retryCandidates, 0, 10),
    deadTtlDays: num(s.deadTtlDays, DEFAULTS.deadTtlDays, 0, 365)
  };
}

// ── 能力调用 ────────────────────────────────────────────────────────────

async function httpStatus(url) {
  try {
    const result = await callHost('cap.http.request', { url, maxChars: 512 });
    return { ok: Number(result?.status) === 200, status: Number(result?.status) || 0, reached: true };
  } catch (error) {
    // 宿主侧抛错（内网拦截、超时、非法 URL）→ 当成"这条链接没验成"，不当成作品没了
    return { ok: false, status: 0, reached: false, error: String(error?.message || error) };
  }
}

async function httpJson(url) {
  const result = await callHost('cap.http.request', { url, maxChars: 200000 });
  const status = Number(result?.status) || 0;
  if (status !== 200) {
    const error = new Error('内置检索接口返回 HTTP ' + (status || '?'));
    error.code = status === 429 ? 'E_RATE' : 'E_UPSTREAM';
    throw error;
  }
  try {
    return JSON.parse(String(result?.body ?? ''));
  } catch {
    throw new Error('内置检索接口返回的不是 JSON（换个接口地址，或者稍后再试）');
  }
}

// ── 状态（cap.storage）───────────────────────────────────────────────────

let stateCache = null;

async function loadState() {
  if (stateCache) return stateCache;
  let raw = null;
  try {
    raw = await callHost('cap.storage.get', { key: 'state' });
  } catch {
    raw = null;   // 没声明 storage 或读失败：当空状态跑 —— 去重是能力，不是前提
  }
  const value = raw && typeof raw === 'object' ? raw.value : null;
  const seen = Array.isArray(value?.seen) ? value.seen.filter((pid) => Number.isFinite(Number(pid))).map(Number) : [];
  const deadRaw = value && typeof value.dead === 'object' && value.dead ? value.dead : {};
  const dead = {};
  for (const [pid, ts] of Object.entries(deadRaw)) {
    if (Number.isFinite(Number(pid)) && Number.isFinite(Number(ts))) dead[pid] = Number(ts);
  }
  stateCache = { seen, dead };
  return stateCache;
}

async function saveState() {
  if (!stateCache) return;
  try {
    await callHost('cap.storage.set', { key: 'state', value: stateCache });
  } catch {
    // 存不进去不影响本次已经算好的结果，只是下次可能重复给同一张
  }
}

/** 剪掉过期拉黑项，并把 seen 裁到 stateCap（落盘前做，storage 单值只有 32KB）。 */
function prune(state, cap) {
  const now = Date.now();
  const ttl = config().deadTtlDays * DAY_MS;
  if (ttl > 0) {
    for (const [pid, ts] of Object.entries(state.dead)) {
      if (now - Number(ts) > ttl) delete state.dead[pid];
    }
  }
  if (state.seen.length > cap) state.seen = state.seen.slice(state.seen.length - cap);
  return state;
}

// ── 作品 → 分级 / 图链 ───────────────────────────────────────────────────

/**
 * 分级只看一个布尔 r18 是不够的：它分不出 R18 与 R18G，**而且实测会漏判** ——
 * 2026-10-19 真接口里就有 tags 带 R-18、r18 却是 false 的作品（作者自己打的标签与 xRestrict 不一致）。
 * 默认档是全年龄（群聊场景），漏判的代价是往群里发成人图，比少出几张严重得多。
 * 所以标签只做**升档**、绝不降档：任一命中 R-18 → r18，命中 R-18G → r18g。
 */
function ratingOf(item) {
  const tags = Array.isArray(item.tags) ? item.tags.map((t) => String(t).toUpperCase().trim()) : [];
  const taggedR18G = tags.some((t) => t === 'R-18G' || t === 'R18G');
  const taggedR18 = taggedR18G || tags.some((t) => t === 'R-18' || t === 'R18');
  if (!taggedR18 && item?.r18 !== true) return 'safe';
  return taggedR18G ? 'r18g' : 'r18';
}

const pageUrlOf = (pid) => 'https://www.pixiv.net/artworks/' + pid;

/** 接口给的 urls.original 优先（实测 200）；没有才回落到模板（简写形式今天实测 500）。 */
function imageUrlOf(item, template) {
  const original = item?.urls?.original;
  if (original && /^https?:\/\//i.test(String(original))) return String(original);
  return template.replace('{pid}', String(item?.pid ?? '')).replace('{p}', String(item?.p ?? 0));
}

function buildItem(item, template) {
  const pid = Number(item?.pid) || 0;
  return {
    pid,
    p: Number(item?.p) || 0,
    title: String(item?.title || '').trim(),
    author: String(item?.author || '').trim(),
    uid: Number(item?.uid) || 0,
    tags: Array.isArray(item?.tags) ? item.tags.map((t) => String(t)).slice(0, 12) : [],
    rating: ratingOf(item),
    width: Number(item?.width) || 0,
    height: Number(item?.height) || 0,
    ai: Number(item?.aiType) === 1,
    pageUrl: pageUrlOf(pid),
    imageUrl: imageUrlOf(item, template)
  };
}

function fromPid(pid, template) {
  return {
    pid,
    p: 0,
    title: '',
    author: '',
    uid: 0,
    tags: [],
    rating: 'unknown',
    width: 0,
    height: 0,
    ai: false,
    pageUrl: pageUrlOf(pid),
    imageUrl: template.replace('{pid}', String(pid)).replace('{p}', '0')
  };
}

/** 从 pixiv 作品链接里取出作品号；取不到返回 0。 */
function pidFromUrl(raw) {
  const text = String(raw || '');
  const artwork = text.match(/artworks\/(\d+)/i);
  if (artwork) return Number(artwork[1]);
  const bare = text.match(/^\s*(\d{4,12})\s*$/);
  return bare ? Number(bare[1]) : 0;
}

// ── 工具 ────────────────────────────────────────────────────────────────

async function search(args) {
  const cfg = config();
  const input = args && typeof args === 'object' ? args : {};
  const wantCount = num(input.count, cfg.maxCount, 1, MAX_COUNT);
  const state = await loadState();
  prune(state, cfg.stateCap);

  // ① 直接给作品：链接或作品号 —— 不搜索、不碰去重（用户明确要这一张）
  const directPid = Number(input.pid) || pidFromUrl(input.url);
  if (directPid) {
    const item = fromPid(directPid, cfg.imageTemplate);
    const probe = await httpStatus(item.imageUrl);
    // 404/410 才是「作品真没了」；其他非 200（简写反代 500、宿主网络不通）只说明这条链接取不到，
    // 不能据此断定作品被删 —— 两者分开说，别让用户以为图没了。
    if (probe.reached && (probe.status === 404 || probe.status === 410)) {
      return { error: '作品 ' + directPid + ' 的图取不到（HTTP ' + probe.status + '）—— 多半已被作者删除或限制访问。换一张吧。' };
    }
    const note = probe.ok
      ? '直接给的作品号只带图链（标题/作者/标签要经过搜索才拿得到）；这条图链已验证可用。'
      : '直接给的作品号只带图链（标题/作者/标签要经过搜索才拿得到）。这条简写图链没验成：'
        + (probe.reached ? 'HTTP ' + probe.status : '宿主网络异常')
        + '。https://pixiv.re/{pid}.png 这个简写形式 2026-10-19 实测返回 500，不代表作品没了；要准确图链请用关键词搜索（内置接口给的是带日期目录的完整反代地址）。';
    return {
      results: [{ ...item, verified: probe.ok }],
      note,
      advise: '把 imageUrl 原样给用户，并按 ![图](imageUrl) 贴出来。' + LINK_HINT + '插件 v1 没有发图能力，图不会由插件直接发出。'
    };
  }

  // ② 搜索
  const keyword = String(input.kw ?? input.keyword ?? input.tag ?? '').trim();
  if (!keyword) {
    return { error: '要给关键词（kw，例如 初音ミク），或者给作品号（pid）/ 作品链接（url）。' };
  }
  let url;
  try {
    url = new URL(cfg.apiUrl);
  } catch {
    return { error: '配置里的「内置搜索接口地址」不是合法 URL：' + cfg.apiUrl };
  }
  // 想要成人档就按 r18=2（混合）取回，再在本机按标签精筛到 safe / r18 / r18g
  const adultsWanted = cfg.ratings.some((r) => r !== 'safe');
  url.searchParams.set('num', String(Math.min(MAX_NUM, Math.max(wantCount * 4, 12))));
  url.searchParams.set('r18', adultsWanted ? '2' : '0');
  url.searchParams.set('size', 'original');
  url.searchParams.set('keyword', keyword);
  if (cfg.excludeAI) url.searchParams.set('excludeAI', 'true');

  let payload;
  try {
    payload = await httpJson(url.toString());
  } catch (error) {
    if (error?.code === 'E_RATE') return { error: '内置检索接口在限流（HTTP 429）—— 过一会儿再试，或者换一个接口地址。' };
    return { error: '搜索失败：' + (error?.message || error) };
  }
  if (payload?.error) return { error: '内置检索接口报错：' + payload.error };
  const raw = Array.isArray(payload?.data) ? payload.data : [];
  if (!raw.length) {
    return { error: '没搜到「' + keyword + '」的作品。换个标签试试（日文原标签命中率最高，例如 初音ミク / オリジナル）。' };
  }

  const seen = new Set(state.seen);
  const dead = state.dead;
  const droppedByRating = [];
  const droppedBySeen = [];
  const candidates = [];
  for (const item of raw) {
    const built = buildItem(item, cfg.imageTemplate);
    if (!built.pid) continue;
    if (!cfg.ratings.includes(built.rating)) { droppedByRating.push(built.rating); continue; }
    if (seen.has(built.pid)) { droppedBySeen.push(built.pid); continue; }
    if (dead[built.pid]) continue;
    if (candidates.some((c) => c.pid === built.pid)) continue;
    candidates.push(built);
  }

  if (!candidates.length) {
    const parts = [];
    if (droppedByRating.length) parts.push(droppedByRating.length + ' 张被分级设置滤掉（当前允许：' + cfg.ratings.map((r) => RATING_LABEL[r]).join(' / ') + '）');
    if (droppedBySeen.length) parts.push(droppedBySeen.length + ' 张之前已经给过');
    if (!parts.length) parts.push('候选都已经被标记成取不到图');
    return { error: '「' + keyword + '」这次没有可给的图：' + parts.join('；') + '。这不是没有图 —— 换关键词，或把分级放宽（配置里的 ratings）。' };
  }

  // ③ 从前 poolSize 张里随机挑：既不永远是同一张，也不至于随机到太冷门的
  const pool = candidates.slice(0, Math.min(cfg.poolSize, candidates.length));
  for (let i = pool.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = pool[i]; pool[i] = pool[j]; pool[j] = tmp;
  }

  // ④ 逐张验图链：取不到就拉黑并换下一张（最多多试 retryCandidates 张）
  const picked = [];
  const unreachable = [];
  let attempts = 0;
  const budget = wantCount + cfg.retryCandidates;
  for (const candidate of pool) {
    if (picked.length >= wantCount || attempts >= budget) break;
    attempts += 1;
    const probe = await httpStatus(candidate.imageUrl);
    if (probe.ok) { picked.push({ ...candidate, verified: true }); continue; }
    if (probe.reached) {
      dead[candidate.pid] = Date.now();
      unreachable.push(candidate.pid);
      continue;
    }
    picked.push({ ...candidate, verified: false });   // 网络类失败：不拉黑，照给
  }

  if (!picked.length) {
    await saveState();
    const list = unreachable.slice(0, 5).join('、') + (unreachable.length > 5 ? '…' : '');
    return { error: '「' + keyword + '」搜到了 ' + candidates.length + ' 张候选，但图链一张都取不到（' + list + '）—— 多半是索引里的旧作品已被作者删除/限制。已把这些作品拉黑 ' + cfg.deadTtlDays + ' 天，同一个关键词再来会换别的图。' };
  }

  // ⑤ 记账：只有真要给出去的才进 seen
  state.seen = [...state.seen, ...picked.map((item) => item.pid)];
  prune(state, cfg.stateCap);
  await saveState();

  const note = [
    '图链优先用接口给的反代原图地址（实测 200）；插件 v1 没有发图能力，所以它只给链接，不代发图片。',
    unreachable.length ? '另有 ' + unreachable.length + ' 张候选取不到图，已拉黑 ' + cfg.deadTtlDays + ' 天。' : '',
    picked.some((item) => item.verified === false) ? '其中有一张没验成图链（宿主网络异常），链接可能仍然可用。' : ''
  ].filter(Boolean).join('');

  return {
    keyword,
    count: picked.length,
    results: picked,
    note,
    advise: '把 imageUrl 贴给用户，并按 ![标题](imageUrl) 的 Markdown 图片语法给出；归档时带上【PID·标题·作者】。' + LINK_HINT + '不要自己编造收藏数 —— 内置接口不返回收藏数。'
  };
}

const tools = { search };

// ── 协议 ────────────────────────────────────────────────────────────────

let buffer = '';
process.stdin.on('data', (chunk) => {
  buffer += chunk.toString('utf8');
  let index = buffer.indexOf('\n');
  while (index !== -1) {
    const line = buffer.slice(0, index).trim();
    buffer = buffer.slice(index + 1);
    if (line) {
      let message = null;
      try { message = JSON.parse(line); } catch { message = null; }
      if (message?.method === 'init') {
        settings = message.params?.settings && typeof message.params.settings === 'object' ? message.params.settings : {};
        stateCache = null;
        write({ id: message.id, result: { ok: true } });
      } else if (message?.method === 'callTool') {
        const fn = tools[message.params?.name];
        if (!fn) write({ id: message.id, error: { code: 'E_NO_TOOL', message: '没有这个工具：' + message.params?.name } });
        else {
          Promise.resolve()
            .then(() => fn(message.params?.args ?? {}))
            .then((result) => write({ id: message.id, result }))
            .catch((error) => write({ id: message.id, error: { code: error?.code || 'E_TOOL', message: String(error?.message || error) } }));
        }
      } else if (message?.method === 'ping') {
        write({ id: message.id, result: {} });
      } else if (message?.method === 'schedule') {
        write({ id: message.id, result: {} });
      } else if (message?.method === 'shutdown') {
        write({ id: message.id, result: {} });
        setTimeout(() => process.exit(0), 10);
      } else if (message?.id !== undefined) {
        const entry = pending.get(message.id);
        if (entry) {
          pending.delete(message.id);
          if (message.error) entry.reject(Object.assign(new Error(message.error.message || '能力调用失败'), { code: message.error.code }));
          else entry.resolve(message.result ?? null);
        }
      }
    }
    index = buffer.indexOf('\n');
  }
});
